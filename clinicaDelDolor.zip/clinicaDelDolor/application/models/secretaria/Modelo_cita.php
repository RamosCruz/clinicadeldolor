<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//MODELO
class Modelo_cita extends CI_Model { 

 public function __construct() {
      parent::__construct();
   }





    public function actualizarNotaDeCita(){

        $id_medico = $this->input->post('id_medico');
        $id_paciente = $this->input->post('id_paciente');
        $hora = $this->input->post('hora');

        $fecha =       new DateTime($this->input->post('fecha'));
        $fecha= $fecha->format('Y-m-d');

        $nota =$this->input->post('nota');

        $data = array(
        'nota' => $nota
        );

        $this->db->where('id_medico', $id_medico);
        $this->db->where('id_paciente',$id_paciente);
        $this->db->where('hora',$hora);
        $this->db->where('fecha',$fecha);

        $this->db->update('cita', $data);
        if($this->db->affected_rows() > 0){
                    return true; //se actualizo
            }
            else{
                return false;//Ocurrio algun error   
        }
    }



//-------------------------------------------------
    public function actualizarFechaDeCita(){

        $id_medico = $this->input->post('id_medico');
        $id_paciente = $this->input->post('id_paciente');
        $hora = $this->input->post('hora');

        $fecha =       new DateTime($this->input->post('fecha'));
        $fecha= $fecha->format('Y-m-d');

        $fecha_vieja =       new DateTime($hora_vieja = $this->input->post('fecha_vieja'));
        $fecha_vieja= $fecha_vieja->format('Y-m-d');
         
        $data = array(
        'fecha' => $fecha
        );

        $this->db->where('id_medico', $id_medico);
        $this->db->where('id_paciente',$id_paciente);
        $this->db->where('hora',$hora);
        $this->db->where('fecha',$fecha_vieja);

        $this->db->update('cita', $data);
        if($this->db->affected_rows() > 0){
                    return true; //se actualizo
            }
            else{
                return false;//Ocurrio algun error   
        }
    }
    public function actualizarIdGoogle(){

        $id_medico = $this->input->post('id_medico');
        $id_paciente = $this->input->post('id_paciente');
        $hora = $this->input->post('hora');

        $fecha =       new DateTime($this->input->post('fecha'));
        $fecha= $fecha->format('Y-m-d');

        $idEventgoogle = $this->input->post('idEventgoogle');
        
         
        $data = array(
        'idEventgoogle' => $idEventgoogle
        );

        $this->db->where('id_medico', $id_medico);
        $this->db->where('id_paciente',$id_paciente);
        $this->db->where('hora',$hora);
        $this->db->where('fecha',$fecha);

        $this->db->update('cita', $data);
        if($this->db->affected_rows() > 0){
                    return true; //se actualizo
            }
            else{
                return false;//Ocurrio algun error   
        }
    }




   public function ValidaFechaDelMedico(){

        $date = new DateTime($this->input->get('fecha'));
        $fecha = $date->format('Y-m-d');

        $hora = $this->input->get('hora');
        $id_medico = $this->input->get('id_medico');
        $id_paciente = $this->input->get('id_paciente');
        
        //  Verifico si la hora ya esta ocupado por el medico
        $query = $this->db->query("select * from cita where id_medico='$id_medico'  and fecha='$fecha' and hora='$hora'");
        
        if($query->num_rows()==0){
                    return true; //El doctor esta libre
            }
            else{
                return false;//El medico tiene registrado una cita a esa hora, favor de modificarla!    
            }
}


public function ValidaFechaDelPaciente(){

        $date = new DateTime($this->input->get('fecha'));
        $fecha = $date->format('Y-m-d');

        $hora = $this->input->get('hora');
        $id_medico = $this->input->get('id_medico');
        $id_paciente = $this->input->get('id_paciente');
        //  Verifico si la hora ya esta ocupado por el medico
        $query = $this->db->query("select * from cita where id_paciente='$id_paciente'  and fecha='$fecha' and hora='$hora'");
        if($query->num_rows()==0){
                    return true; //El Paciente esta libre
            }
            else{
                return false;//El Paciente tiene registrado una cita a esa hora, favor de modificarla!    
            }
}





   
//--------------------------------------------------------
    public function actualizarHoraDeCita(){

        $id_medico = $this->input->post('id_medico');
        $id_paciente = $this->input->post('id_paciente');
        $hora = $this->input->post('hora');

        $fecha =       new DateTime($this->input->post('fecha'));
        $fecha= $fecha->format('Y-m-d');

        $hora_vieja = $this->input->post('hora_vieja');
         
        $data = array(
        'hora' => $this->input->post('hora')
        );

        $this->db->where('id_medico', $id_medico);
        $this->db->where('id_paciente',$id_paciente);
        $this->db->where('hora',$hora_vieja);
        $this->db->where('fecha',$fecha);

        $this->db->update('cita', $data);
        if($this->db->affected_rows() > 0){
                    return true; //se actualizo
            }
            else{
                return false;//Ocurrio algun error   
        }
    }




   public function ValidaHoraDelMedico(){

        $date = new DateTime($this->input->get('fecha'));
        $fecha = $date->format('Y-m-d');

        $hora = $this->input->get('hora');
        $id_medico = $this->input->get('id_medico');
        $id_paciente = $this->input->get('id_paciente');
        
        //  Verifico si la hora ya esta ocupado por el medico
        $query = $this->db->query("select * from cita where id_medico='$id_medico'  and fecha='$fecha' and hora='$hora'");
        
        if($query->num_rows()==0){
                    return true; //El doctor esta libre
            }
            else{
                return false;//El medico tiene registrado una cita a esa hora, favor de modificarla!    
            }
}


public function ValidaHoraDelPaciente(){

        $date = new DateTime($this->input->get('fecha'));
        $fecha = $date->format('Y-m-d');

        $hora = $this->input->get('hora');
        $id_medico = $this->input->get('id_medico');
        $id_paciente = $this->input->get('id_paciente');
        //  Verifico si la hora ya esta ocupado por el medico
        $query = $this->db->query("select * from cita where id_paciente='$id_paciente'  and fecha='$fecha' and hora='$hora'");
        if($query->num_rows()==0){
                    return true; //El Paciente esta libre
            }
            else{
                return false;//El Paciente tiene registrado una cita a esa hora, favor de modificarla!    
            }
}

public function ValidaCitaAlActualizar(){

        $date = new DateTime($this->input->get('fecha'));

        $fecha = $date->format('Y-m-d');
        $hora = $this->input->get('hora');
        $id_medico = $this->input->get('doctor');
        $id_paciente = $this->input->get('paciente');
        //  Rectifico si la persona ya saco la fecha 

        $query = $this->db->query("select * from cita where id_medico='$id_medico' and id_paciente!='$id_paciente' and fecha='$fecha' and hora='$hora' union select * from cita where id_medico='$id_medico'  and fecha='$fecha' and hora='$hora' union select * from cita where id_paciente!='$id_paciente' and fecha='$fecha' and hora='$hora'");
        
        if($query->num_rows()==0){
                    return true;
            }
            else{
                return false;    
            }
}


public function validaCita(){

        $date = new DateTime($this->input->get('fecha'));

        $fecha = $date->format('Y-m-d');
        $hora = $this->input->get('hora');
        $id_medico = $this->input->get('doctor');
        $id_paciente = $this->input->get('paciente');
        //  Rectifico si la persona ya saco la fecha 

        $query = $this->db->query("select * from cita where id_medico='$id_medico' and id_paciente='$id_paciente' and fecha='$fecha' and hora='$hora' union select * from cita where id_medico='$id_medico'  and fecha='$fecha' and hora='$hora' union select * from cita where id_paciente='$id_paciente' and fecha='$fecha' and hora='$hora'");
        
        if($query->num_rows()==0){
                    return true;
            }
            else{
                return false;    
            }
}


public function agendarCita(){

        $date = new DateTime($this->input->post('fecha-cita'));
        $fecha_cita = $date->format('Y-m-d');

        
            $id_paciente = $this->input->post('id-nombre-paciente');
            $id_medico   = $this->input->post('id-medico');
            $fecha       = $fecha_cita;
            $hora        = $this->input->post('hora-cita');
            $nota        = $this->input->post('nota');
            $fecha_creacion = date('Y-m-d H:i:s');
            $idEventgoogle = $this->input->post('idEventgoogle');
        


        $this->db->query("INSERT INTO cita (id_paciente, id_medico, fecha, hora, nota,fecha_creacion,idEventgoogle) VALUES ('$id_paciente', '$id_medico', '$fecha', '$hora', '$nota','$fecha_creacion','$idEventgoogle')");
        
        
         if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }

}



public function getMedicos(){
		$this->db->order_by('id_medico', 'desc');
		$query = $this->db->get('medico');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}

public function buscarExpediente()
    {
        $id_expediente = $this->input->get('id_expediente');

        $this->db->select('id_expediente,curp, id_paciente, nombre, app as apellido_p, apm as apellido_m');
        $this->db->from('expediente');
        $this->db->join('paciente','paciente.curp=expediente.id_paciente');
        $this->db->where('id_expediente',$id_expediente);
        $query=$this->db->get();

         if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

    }

public function buscarPacienteLike()
    {
        //aqui cambiara la consulta por la tabla
        //echo $data_text->nombre;
        $text_nomb = $this->input->get('nombre');
        $text_ap = $this->input->get('apellido_p');
        $query;

        if($text_nomb=="" || $text_ap==""){
            if($text_nomb!=""){
                //Aqui texto nombre es el unico valor
                $this->db->select('id_expediente,curp, id_paciente, nombre, app as apellido_p, apm as apellido_m');
                $this->db->from('expediente');
                $this->db->join('paciente','paciente.curp=expediente.id_paciente');
                $this->db->like("nombre",$text_nomb);
                $query=$this->db->get();
            }
            else{
                //Aqui texto apellido es el unico valor
                $this->db->select('id_expediente,curp, id_paciente, nombre, app as apellido_p, apm as apellido_m');
                $this->db->from('expediente');
                $this->db->join('paciente','paciente.curp=expediente.id_paciente');
                $this->db->like("app",$text_ap);
                $query=$this->db->get();
            }

        }
        else{//Aqui se buscara con ambos 
             $this->db->select('id_expediente,curp, id_paciente, nombre, app as apellido_p, apm as apellido_m');
             $this->db->from('expediente');
             $this->db->join('paciente','paciente.curp=expediente.id_paciente');

             $this->db->like("nombre",$text_nomb); 
             $this->db->like("app",$text_ap);
             $query=$this->db->get();
        }

        if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
    }


    public function getCitas(){
        //Obtiene las citas pendientes
         $id_medico = $this->input->get('id_medico');
         $id_estatus = $this->input->get('id_status');

        $query = $this->db->query("SELECT p.curp as id_paciente, p.nombre as nombre_paciente, p.app as apellido_paciente, m.id_medico, m.nombre as nombre_medico ,c.idEventgoogle, c.id_user, c.id_status, date_format(c.fecha, '%d-%m-%Y') as fecha, date_format(hora,'%H:%i') as hora, c.nota, c.fecha_creacion FROM cita as c inner join medico as m using(id_medico) inner join paciente as p on(c.id_paciente=curp) where id_medico='$id_medico' and id_status='$id_estatus' order by fecha and hora desc");
    
        
        if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}

    }


        public function getCitaCompuesta($paciente,$medico,$fecha,$hora){

            $query = $this->db->query("SELECT p.curp as id_paciente, p.nombre as nombre_paciente, p.app as apellido_paciente, m.id_medico, m.nombre as nombre_medico , c.id_user, c.id_status, date_format(c.fecha, '%d-%m-%Y') as fecha, date_format(c.hora,'%H:%i') as hora, c.nota, c.fecha_creacion FROM cita as c inner join medico as m using(id_medico) inner join paciente as p on(c.id_paciente=curp) where id_paciente='$paciente' and  id_medico='$medico' and fecha='$fecha' and hora='$hora'");
            
            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }


    }

    public function actualizarCita(){

        $date = new DateTime($this->input->post('fecha-cita'));
        $fecha_cita = $date->format('Y-m-d');


        
            $id_paciente = $this->input->post('id-nombre-paciente');
            $id_medico   = $this->input->post('id-medico');
            $fecha       = $fecha_cita;
            $hora        = $this->input->post('hora-cita');
            $nota        = $this->input->post('nota');
            $fecha_creacion = date('Y-m-d H:i:s');

        
		$query = $this->db->query("UPDATE cita SET id_paciente='$id_paciente', id_medico='$id_medico', hora='$hora', fecha='$fecha', nota='$nota' WHERE id_paciente='$id_paciente'");
        $this->db->where('id_paciente', $id_paciente,'id_medico',$id_medico,'hora',$hora,'fecha',$fecha);
		$this->db->update('cita', $data);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}

    }


    function eliminarCita(){
		$id_paciente = $this->input->get('id_paciente');
        $id_medico = $this->input->get('id_medico');
        $hora = $this->input->get('hora');

        $date = new DateTime($this->input->get('fecha'));
        $fecha = $date->format('Y-m-d');



        $query = $this->db->query("DELETE FROM cita  where id_paciente='$id_paciente' and  id_medico='$id_medico' and fecha='$fecha' and hora='$hora'");
            
		if($this->db->affected_rows() > 0){
            ///echo $hora;
			return true;
		}else{
			return false;
		}
	}
    
    public function getFullCalendar($idDoctor = '')
    {
        $query = $this->db->query("SELECT paciente.nombre as nombreP, paciente.app as appP, paciente.apm as apmP, nota, fecha, hora, medico.nombre as nombreM  FROM cita JOIN paciente ON cita.id_paciente=paciente.curp JOIN medico ON medico.id_medico=cita.id_medico WHERE medico.id_medico ='$idDoctor';");
        
        if($query->num_rows() > 0){
                return $query->result();
            }else{
                return array();
            }
    }
    public function getFullCalendarTodas()
    {
        $query = $this->db->query("SELECT * FROM cita inner JOIN paciente ON (cita.id_paciente=paciente.curp)");
        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return array();
        }
    }
    public function getMedicosConCita()
    {
        $query = $this->db->query("SELECT DISTINCT id_medico FROM cita");
        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }
    public function nombreDelDoc($id_medico)
    {
        $query = $this->db->query("SELECT nombre FROM medico WHERE id_medico='".$id_medico."';");
        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }


}
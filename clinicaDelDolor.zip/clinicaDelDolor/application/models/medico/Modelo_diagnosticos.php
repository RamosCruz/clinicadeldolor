<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//MODELO
class Modelo_diagnosticos extends CI_Model { 

 public function __construct() {
      parent::__construct();
   }


function eliminarDianosticoFrecuentePor(){
        $id_diagnostico=$this->input->get('id_diagnostico');
        $id_medico=$this->input->get('id_medico');


        $query = $this->db->query("DELETE from diagnosticos_frecuentes where id_diagnostico='$id_diagnostico' and id_medico='$id_medico'");
        
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }




      


public function getDiagnosticosCon()
    {
        $nombre = $this->input->get('nombre');
        if(ctype_space($nombre)){//Valida si el texto recibe espacios en blanco
            $nombre_generico="null";
        }

         $this->db->select('CONSEC, clave, nombre');
         $this->db->from('catalogo_de_diagnosticos');
         //$this->db->where("'$nombre_generico.length'>3");
         $this->db->like("nombre",$nombre);
         $query=$this->db->get();

         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }

    }


public function insertarDiagnosticoFrecuente(){

        $data = array(
            'id_diagnostico'=>$this->input->post('id_diagnostico'),
            'id_medico'=>$this->input->post('id_medico')
            );

        $this->db->insert('diagnosticos_frecuentes', $data);
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
}


 function listarDiagnosticosUsadosPor(){
        $id_medico = $this->input->get('id_medico');
        $query = $this->db->query("SELECT id_medico,id_diagnostico,clave,nombre FROM diagnosticos_frecuentes inner join catalogo_de_diagnosticos on(id_diagnostico=CONSEC) where id_medico='$id_medico'");
        
        if($query->num_rows() > 0){
            return $query->result();
        }
            else{
                return false;    
            }

    }



public function validarDiagnosticoEnListaFrecuente(){

        $id_diagnostico = $this->input->get('id_diagnostico');
        $id_medico = $this->input->get('id_medico');


        $query = $this->db->query("SELECT * FROM diagnosticos_frecuentes where  id_diagnostico='$id_diagnostico' and id_medico='$id_medico'");
        
        if($query->num_rows()==0){
                    return true;
            }
            else{
                return false;    
            }
}


}
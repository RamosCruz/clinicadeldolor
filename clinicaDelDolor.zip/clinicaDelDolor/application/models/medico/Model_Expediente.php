<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_Expediente extends CI_Model{
    function __construct()
    {
        parent::__construct();
    }
    public function selExpedientes()
    {
        $query = $this->db->query('SELECT * FROM expediente');
        
        return $query->result();
    }
    public function selExpedienteCurp($curp)
    {
        $query = $this->db->query('SELECT * FROM expediente WHERE id_paciente="'.$curp.'"');
        
        return $query->result();
    }
    public function crearExpedienteCurp($curp)
    {
        $arrayD = array(
            'id_paciente' => $curp,
            'fecha_creacion' => date('Y-m-d H:i:s')
        );
        $this->db->insert('expediente',$arrayD);
    }
}
?>
<?php

class Fotos_model extends CI_Model{

	public function __construct() {
      parent::__construct();
   }

public function grabarFoto($id_paciente,$foto) {
      $this->db->query("INSERT INTO foto_paciente (id_paciente, foto) VALUES ('$id_paciente', '$foto')");
        
      if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
      
}

public function getLastFoto() {
    return $this->db->order_by('id','desc')->get('foto_paciente')->row()->foto;
}

public function obtenerFoto($id_paciente) {
    $query = $this->db->query("SELECT  id_paciente, foto  FROM foto_paciente where id_paciente='$id_paciente' order by id desc");
    
   if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }

}


public function eliminarFotos($id_paciente){
	$this->db->where('id_paciente', $id_paciente);
	$this->db->delete('foto_paciente'); 
	 if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
}


public function actualizaFoto($id_foto,$src){

	$data = array(
        'foto' => $src
        );

	$this->db->where('id_foto',$id_foto);
	$this->db->update('foto_paciente', $data);
        if($this->db->affected_rows() > 0){
                    return true; //se actualizo el status
            }
            else{
                return false;//Ocurrio algun error   
        }
}


}
<?php defined('BASEPATH') OR exit('No direct script access allowed');
    
class Historial extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model('Model_Historial');
    } 
    public function index()
	{
        $data ['contenido'] = 'historiales/create';
		$this->load->view('plantilla',$data);
	}
    public function guardarAnteGineObs()
    {
        $result = $this->Model_Historial->insertarAntGinecoObst();
		$msg['success'] = false;
		$msg['type'] = 'add';
		if($result){
			$msg['success'] = true;
		}
    }
    public function guardarAnteHeredoFam()
    {
        $datos = $this->input->post();
        if(isset($datos))
        {
            $diabetes_mellitus = $datos['diabetes_mellitus'];
            $hiper_sistemica = datos['hiper_sistemica'];
        }
        
    }
}
?>

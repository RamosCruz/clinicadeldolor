<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//MODELO
class Modelo_medicamentos extends CI_Model { 

 public function __construct() {
      parent::__construct();
   }


function eliminarMedicamentoUsadoPor(){
        $id_medicamento=$this->input->get('id_medicamento');
        $id_medico=$this->input->get('id_medico');


        $query = $this->db->query("DELETE from medicamentos_mas_usados where id_medicamento='$id_medicamento' and id_medico='$id_medico'");
        
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }




      


public function getMedicamentosCon()
    {
        $nombre_generico = $this->input->get('nombre_generico');
        if(ctype_space($nombre_generico)){//Valida si el texto recibe espacios en blanco
            $nombre_generico="null";
        }

         $this->db->select('id_medicamento, nombre_generico, presentacion, forma_farmaceutica, concentracion');
         $this->db->from('catalogo_de_medicamentos');
         //$this->db->where("'$nombre_generico.length'>3");
         $this->db->like("nombre_generico",$nombre_generico);
         $query=$this->db->get();

         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }

    }


public function insertarMedicamentoEnListaDeUsados(){

        $data = array(
            'id_medicamento'=>$this->input->post('id_medicamento'),
            'id_medico'=>$this->input->post('id_medico')
            );

        $this->db->insert('medicamentos_mas_usados', $data);
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
}


 function listarMedicamentosUsadosPor(){
        $id_medico = $this->input->get('id_medico');
        $query = $this->db->query("SELECT id_medico,id_medicamento,nombre_generico,presentacion,forma_farmaceutica,concentracion FROM medicamentos_mas_usados inner join catalogo_de_medicamentos using(id_medicamento) where id_medico='$id_medico'");
        
        if($query->num_rows() > 0){
            return $query->result();
        }
            else{
                return false;    
            }

    }



public function validarMedicamentoEnListaDeUsado(){

        $id_medicamento = $this->input->get('id_medicamento');
        $id_medico = $this->input->get('id_medico');


        $query = $this->db->query("SELECT * FROM medicamentos_mas_usados where  id_medicamento='$id_medicamento' and id_medico='$id_medico'");
        
        
         //$this->db->select('*');
         //$this->db->from('medicamentos_mas_usados');
         //$this->db->where('id_medicamento','$id_medicamento');
         //$this->db->where('id_medico','$id_medico');
         //$this->db->like("nombre_generico",$nombre_generico);
         //$query=$this->db->get();


        if($query->num_rows()==0){
                    return true;
            }
            else{
                return false;    
            }
}


}
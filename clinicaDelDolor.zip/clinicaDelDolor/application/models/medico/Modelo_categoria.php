<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//MODELO
class Modelo_categoria extends CI_Model { 

 public function __construct() {
      parent::__construct();
   }



public function actualizarCategoria(){
        $id_categoria = $this->input->post('id-categoria-model');
        $data = array(
        'categoria'=>$this->input->post('nombre-categoria-model')
        );
        $this->db->where('id_categoria', $id_categoria);
        $this->db->update('categoria', $data);
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }


public function editarCategoria(){
        $id_categoria = $this->input->get('id_categoria');
        $this->db->where('id_categoria', $id_categoria);
        $query = $this->db->get('categoria');
        if($query->num_rows() > 0){
            return $query->row();
        }else{
            return false;
        }
    }


function eliminarCategoria(){
        $id_categoria = $this->input->get('id_categoria');
        $this->db->where('id_categoria', $id_categoria);
        $this->db->delete('categoria');
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }



public function getCategorias($id_medico)
    {

        $query = $this->db->query("SELECT * FROM categoria WHERE id_mmedic='$id_medico' order by id_categoria desc");
        

        //$query = $this->db->get('categoria');

         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }

    }


public function insertarCategoria(){

        $data = array(
            'categoria'=>$this->input->post('categoria'),
            'id_mmedic'=>$this->input->post('id_mmedic')
            );

        $this->db->insert('categoria', $data);
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
}



public function validarCategoria(){

        $categoria = $this->input->get('categoria');
        $this->db->select('*');
        $this->db->from('categoria');
        $this->db->where('categoria', $categoria);
        $query = $this->db->get();

            if($query->num_rows()==0){
                    return true;
            }
            else{
                return false;    
            }
}
public function cargarImagen ($nombreArchivo,$id_categoria,$nombre,$id_mdco)
    {
        $arrayF = array(
            'nombreArchivo' => $nombreArchivo,
            'id_mdco' => $id_mdco,
            'id_categoria' => $id_categoria,
            'descripcion' => $nombre,
            'fecha_creacion'=> date('Y-m-d H:i:s')
            );
        $this->db->insert('img',$arrayF);
    }
    
    public function mostrarImg ($id_medico)
    {
        $query = $this->db->query("SELECT * FROM img WHERE id_mdco='$id_medico' order by fecha_creacion desc");
        
        return $query->result();
    }
    public function eliminarImagen($nombreArchivo)
    {
        $this->db->where('nombreArchivo',$nombreArchivo);
        $this->db->delete('img');
    }


}
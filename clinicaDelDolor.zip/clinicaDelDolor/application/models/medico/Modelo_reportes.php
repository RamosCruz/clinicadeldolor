<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modelo_reportes extends CI_Model{
    function __construct()
    {
        parent::__construct();
    }

    
    public function buscarCuenta($id_paciente,$id_medico)
    {
        $query = $this->db->query("SELECT * FROM contabilidad where idd_medico = '$id_medico' and id_paciente= '$id_paciente';");
        if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }    
    }
    public function registrarPago()
    {
        $id_contabilidad = $this->input->post('id_contabilidad');
        $arrayAtributos = array(
                'fecha_haber' => date('Y-m-d'),
                'haber' => $this->input->post('haber'),
                'formapago'=>$this->input->post('formapago'),
                'boucher'=>$this->input->post('boucher')
                );
        $this->db->where('id_contabilidad', $id_contabilidad);
        $this->db->update('contabilidad',$arrayAtributos);

        if($this->db->affected_rows() > 0){
            return true; //se actualizo
        }
        else{
            return false;//Ocurrio algun error   
        }
    }
    public function valance($id_medico,$fecha_inicio,$fecha_termino)
    {
       //"SELECT * FROM contabilidad where id_medico = 'CAEV710310HOCSSC06' and fecha_haber BETWEEN '2017-06-05' AND '2017-06-06';"
        $query = $this->db->query("SELECT * FROM contabilidad where idd_medico = '$id_medico' and fecha_haber BETWEEN '$fecha_inicio' AND '$fecha_termino';");
        if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            } 
    }



        public function BalanceGral($id_medico,$fecha_inicio,$fecha_termino)
    {
       //"SELECT * FROM contabilidad where id_medico = 'CAEV710310HOCSSC06' and fecha_haber BETWEEN '2017-06-05' AND '2017-06-06';"
        $query = $this->db->query("SELECT * FROM contabilidad where  idd_medico='$id_medico' and fecha_haber BETWEEN '$fecha_inicio' AND '$fecha_termino' union  SELECT * FROM contabilidad where idd_medico='$id_medico' and  fecha_debe BETWEEN '$fecha_inicio' AND '$fecha_termino';");
        if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            } 
    }
    
    public function cuentasDeHoy($id_medico)
    {
        $hoy = date('Y-m-d');
        
        $query = $this->db->query("SELECT id_contabilidad,paciente.nombre, paciente.app, paciente.apm,debe,haber,formapago,boucher FROM contabilidad inner join paciente on contabilidad.id_paciente=paciente.curp and fecha_debe='$hoy' and idd_medico='$id_medico';");
        if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            } 
    
    }
}
?>
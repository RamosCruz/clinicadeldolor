<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//MODELO
class Modelo_consulta extends CI_Model {
 public function __construct() {
      parent::__construct();
   }

//---------------------GESTION DE LOS MEDICAMENTOS EN LA CONSULTA PARA EL REGISTRO DEL MISMO-------------------------------

   public function getGenericosOMedicamentos(){
            $query = $this->db->query("SELECT nombre_generico  FROM catalogo_de_medicamentos   group by nombre_generico");
            return $query->result();
    }

   public function getFormaFarmaceutica(){
            $query = $this->db->query("SELECT forma_farmaceutica FROM catalogo_de_medicamentos  group by forma_farmaceutica");
            return $query->result();
    }

   public function getConcentracion(){
            $query = $this->db->query("SELECT concentracion FROM catalogo_de_medicamentos  group by concentracion");
            return $query->result();
    }

   public function getPresentacion(){
            $query = $this->db->query("SELECT presentacion FROM catalogo_de_medicamentos  group by presentacion");
            return $query->result();
    }

    public function getDosisDiariaDefinida(){
            $query = $this->db->query("SELECT dosis_diaria_definida FROM catalogo_de_medicamentos  where dosis_diaria_definida!='' group by dosis_diaria_definida");
            return $query->result();        
    }
    //--------------------------------------------
        //ALMACENAR UN MEDICAMENTO EN LA CONSULTA
    //--------------------------------------------

    public function validaMedicamento(){

        
            $nombre_generico = $this->input->post('nombre_generico');
            $forma_farmaceutica = $this->input->post('forma_farmaceutica');
            $concentracion = $this->input->post('concentracion');
            $presentacion = $this->input->post('presentacion');
            $dosis_diaria_definida = $this->input->post('dosis');
        

        $query = $this->db->query("SELECT * FROM catalogo_de_medicamentos  where nombre_generico='$nombre_generico' and forma_farmaceutica ='$forma_farmaceutica' and concentracion='$concentracion' and presentacion='$presentacion' and dosis_diaria_definida='$dosis_diaria_definida'");

        if($query->num_rows()==0){
            return true; //NO SE A REGISTRADO LA CURP
        }
        else{
            return false;// YA ESTA RESGISTRO UN PACIENTE CON ESA CURP
        }
    }

    public function agregarMedicamento()
    {
        $arrayD = array(
            'nombre_generico' => $this->input->post('nombre_generico'),
            'forma_farmaceutica' => $this->input->post('forma_farmaceutica'),
            'concentracion' => $this->input->post('concentracion'),
            'presentacion' => $this->input->post('presentacion'),
            'dosis_diaria_definida' => $this->input->post('dosis')
        );
        
        $this->db->insert('catalogo_de_medicamentos',$arrayD);
        if($this->db->affected_rows() > 0){
            return $this->db->insert_id();
        }else{
            //echo "incorrecto";
            return false;
        }
        
    }


//-------------------------------------------------------------------------------------------------------------------------
     public function cambiarEstatusDeCita ()
    {
        
        $id_medico = $this->input->post('id_medico');
        $id_paciente = $this->input->post('id_paciente');
        $hora = $this->input->post('hora');
        $fecha =       new DateTime($this->input->post('fecha'));
        $fecha= $fecha->format('Y-m-d');

        $data = array(
        'id_status' => 1
        );

        $this->db->where('id_medico', $id_medico);
        $this->db->where('id_paciente',$id_paciente);
        $this->db->where('hora',$hora);
        $this->db->where('fecha',$fecha);

        $this->db->update('cita', $data);
        if($this->db->affected_rows() > 0){
                    return true; //se actualizo el status
            }
            else{
                return false;//Ocurrio algun error   
        }
    }



    public function ObtenerCatalogoViaDeAdministracion(){
            $this->db->order_by('via_de_administracion', 'desc');
            $query = $this->db->get('via_de_administracion');
            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
        }

    /*public function getTratamientosAbiertosDelaConsulta($id_consulta=''){

            $query = $this->db->query("SELECT * FROM consulta_tratamiento_abierto trat where id_consulta='$id_consulta'");

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
        }*/
    public function getGenericos(){

            $query = $this->db->get('catalogo_de_medicamentos');
            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
        }

    public function getConsultasDelPaciente($id_paciente=''){


            $query = $this->db->query("select *from consulta inner join consulta_diagnostico using(id_consulta) inner join catalogo_de_diagnosticos on(diagnostico=CONSEC) inner join consulta_tratamiento using(id_consulta) inner join catalogo_de_medicamentos on(medicamento=id_medicamento) where id_paciente='$id_paciente' order by id_consulta desc");

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
        }


    public function getDiagnosticosDelaConsulta($id_consulta=''){

            $query = $this->db->query("SELECT * FROM consulta_diagnostico diag inner join catalogo_de_diagnosticos cat_d on(diag.diagnostico=cat_d.CONSEC) where id_consulta='$id_consulta'");

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
        }
//------------------------------------------------------------------------
    public function getDiagnosticosDelaConsultaAbierto($id_consulta=''){

            $query = $this->db->query("SELECT * FROM consulta inner join consulta_diagnostico_abierto using(id_consulta) where id_consulta='$id_consulta'");

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
        }
 //------------------------------------------------------------------------

    public function getDiagnosticosAbiertosDelaConsulta($id_consulta=''){

            $query = $this->db->query("SELECT * FROM consulta_diagnostico_abierto inner join consulta using(id_consulta) where id_consulta='$id_consulta'");

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
    }

    public function getTratamientosDelaConsulta($id_consulta=''){

            $query = $this->db->query("SELECT * FROM consulta_tratamiento trat inner join catalogo_de_medicamentos cat_m on(trat.medicamento=cat_m.id_medicamento) inner join via_de_administracion cat_via on (trat.via_de_administracion= cat_via.id_via_de_administracion) where id_consulta='$id_consulta'");

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
        }

    public function getTratamientosAbiertosDelaConsulta($id_consulta=''){

            $query = $this->db->query("SELECT * FROM consulta_tratamiento_abierto trat where id_consulta='$id_consulta'");

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
    }


    public function getEstudiosLaboratorio($id_consulta='')
    {
        $query = $this->db->query("SELECT * FROM consulta_laboratorio where id_consulta='$id_consulta'");

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
    }

    public function getEstudiosGabinete($id_consulta='')
    {
        $query = $this->db->query("SELECT * FROM consulta_gabinete where id_consulta='$id_consulta'");

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
    }
    public function getConsultasDelPacienteGroupByConsultaTabla($id_paciente=''){

            $query = $this->db->query("select * from consulta inner join consulta_diagnostico using(id_consulta) inner join catalogo_de_diagnosticos on(diagnostico=CONSEC) inner join consulta_tratamiento using(id_consulta) inner join catalogo_de_medicamentos on(medicamento=id_medicamento)  where id_paciente='$id_paciente' group by id_consulta order by fecha_consulta desc ");
            //"select * from consulta inner join consulta_diagnostico using(id_consulta) inner join catalogo_de_diagnosticos on(diagnostico=CONSEC) inner join consulta_tratamiento using(id_consulta) inner join catalogo_de_medicamentos on(medicamento=id_medicamento) where id_paciente='$id_paciente' group by id_consulta order by fecha_consulta desc

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
    }

        public function adjuntaExploracionFisicaDeLaConsulta($id_consulta=''){

            $query = $this->db->query("SELECT * FROM exploracion_fisica  inner join region_fisica_ext  using(id_region)  where id_consulta='$id_consulta'");

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
        }

    public function getConsultasDelPacienteGroupByConsulta($id_paciente=''){

            $query = $this->db->query("select * from consulta where id_paciente='$id_paciente' ");
            //"select * from consulta inner join consulta_diagnostico using(id_consulta) inner join catalogo_de_diagnosticos on(diagnostico=CONSEC) inner join consulta_tratamiento using(id_consulta) inner join catalogo_de_medicamentos on(medicamento=id_medicamento) where id_paciente='$id_paciente' group by id_consulta order by fecha_consulta desc

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
    }

    public function getConsultasAbiertasDelPacienteGroupByConsulta($id_paciente=''){

            $query = $this->db->query("select * from consulta inner join consulta_diagnostico_abierto using(id_consulta) inner join consulta_tratamiento_abierto using(id_consulta)  where id_paciente='$id_paciente' group by id_consulta order by fecha_consulta desc");

            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
        }



    public function getDiagnosticos(){

            $query = $this->db->get('catalogo_de_diagnosticos');
            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
        }

    public function getRegionesDelCuerpo(){

            $query = $this->db->get('region_fisica_ext');
            if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }
        }

    public function GuardarConsulta(){
        $arrayAtributos = array(
                'id_medico'         =>$this->input->post('medico'),
                'id_paciente'       =>$this->input->post('paciente'),
                'motivo'            =>$this->input->post('motivo'),
                'valoracion'        =>$this->input->post('valoracion'),
                'notas'             =>$this->input->post('nota'),
                'peso'              =>$this->input->post('peso'),
                'altura'                =>$this->input->post('altura'),
                'indice_de_masa_corp'   =>$this->input->post('masa_corporal'),
                'temperatura'           =>$this->input->post('temperatura'),
                'f_cardiaca'            =>$this->input->post('cardiaca'),
                'press_arterial'        =>$this->input->post('arterial'),
                'f_respiratoria'        =>$this->input->post('respira'),
                'escala_del_dolor'      =>$this->input->post('dolor'),
                'glucosa'               =>$this->input->post('glucosa'),
                'fecha_consulta'        =>date('Y-m-d H:i:s')
                );

            $this->db->insert('consulta',$arrayAtributos);

            if($this->db->affected_rows() > 0){
                return $this->db->insert_id();
            }else{
                //echo "incorrecto";
                return false;
            }
    }

    public function GuardarDiagnostico(){
        $arrayAtributos = array(
                'id_consulta'         =>$this->input->post('id_consulta'),
                'diagnostico'         =>$this->input->post('diagnostico'),
                'comentario'          =>$this->input->post('comentario')
                );

            $this->db->insert('consulta_diagnostico',$arrayAtributos);

            if($this->db->affected_rows() > 0){
                return true;
            }else{
                //echo "incorrecto";
                return false;
            }
    }
    public function GuardarEstudiosGabinete()
    {
        $arrayAtributos = array(
                'id_consulta'         =>$this->input->post('id_consulta'),
                'estudiosdegab'         =>$this->input->post('estudiosdegab')
                );

            $this->db->insert('consulta_gabinete',$arrayAtributos);

            if($this->db->affected_rows() > 0){
                return true;
            }else{
                //echo "incorrecto";
                return false;
            }
    }
    public function GuardarEstudiosLaboratorio()
    {
        $arrayAtributos = array(
                'id_consulta'         =>$this->input->post('id_consulta'),
                'estudiosdelab'         =>$this->input->post('estudiosdelab')
                );

            $this->db->insert('consulta_laboratorio',$arrayAtributos);

            if($this->db->affected_rows() > 0){
                return true;
            }else{
                //echo "incorrecto";
                return false;
            }
    }
    public function GuardarCosto()
    {
        $arrayAtributos = array(
                'idd_medico'=>$this->input->post('id_medico'),
                'id_paciente'=>$this->input->post('id_paciente'),
                'fecha_debe'=> date('Y-m-d'),
                'debe'         =>$this->input->post('cargo')
                );

            $this->db->insert('contabilidad',$arrayAtributos);

            if($this->db->affected_rows() > 0){
                return true;
            }else{
                //echo "incorrecto";
                return false;
            }
    }



    public function GuardarExploracionFisica(){
        $arrayAtributos = array(
                'id_consulta'         =>$this->input->post('id_consulta'),
                'id_region'         =>$this->input->post('id_region'),
                'nombre_de_la_zona'          =>$this->input->post('nombre_de_la_zona'),
                'observaciones'          =>$this->input->post('observaciones')
                );

            $this->db->insert('exploracion_fisica',$arrayAtributos);

            if($this->db->affected_rows() > 0){
                return true;
            }else{
                //echo "incorrecto";
                return false;
            }
    }



    public function getEstado($id_estado){
        $query = $this->db->query("select *from estados where clave_estado='$id_estado'");
        if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }

    }

    public function getMunicipio($id_estado,$id_municipio){
    $query = $this->db->query("select *from municipios where clave_estado='$id_estado' and clave_municipio='$id_municipio'");
        if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }

    }

    public function getLocalidad($id_estado,$id_municipio,$id_localidad){
    $query = $this->db->query("select *from localidades where clave_estado='$id_estado' and clave_municipio='$id_municipio' and clave_localidad='$id_localidad'");
        if($query->num_rows() > 0){
                return $query->result();
            }else{
                return false;
            }

    }

    //------------------------------------------
    public function GuardarDiagnosticoAbierto(){
        $arrayAtributos = array(
                'id_consulta'         =>$this->input->post('id_consulta'),
                'diagnostico'         =>$this->input->post('diagnostico'),
                'observacion'          =>$this->input->post('comentario')
                );

            $this->db->insert('consulta_diagnostico_abierto',$arrayAtributos);

            if($this->db->affected_rows() > 0){
                return true;
            }else{
                //echo "incorrecto";
                return false;
            }
    }

    public function GuardarTratamientoAbierto(){
    

    $arrayAtributos = array(
                    'id_consulta'                        =>$this->input->post('id_consulta'),
                    'medicamento'                        =>$this->input->post('medicamento'),
                    'descripcion_del_tratamiento'        =>$this->input->post('descripcion_del_tratamiento'),
                    'via_de_administracion'              =>$this->input->post('via_de_administracion'),
                    'indicaciones_grales'                =>$this->input->post('indicaciones_generales_al_paciente')
                    );
    $this->db->insert('consulta_tratamiento_abierto',$arrayAtributos);

    if($this->db->affected_rows() > 0){
            return true;
    }else{
            //echo "incorrecto";
            return false;
    }
    
}
//------------------------------------------

public function GuardarTratamiento(){

    
    if($this->input->post('estadoDeTratamiento')=='0') {


            $Inicio =       new DateTime($this->input->post('inicio_tratamiento'));
            $fechaInicio= $Inicio->format('Y-m-d');

            $Fin =       new DateTime($this->input->post('fin_tratamiento'));
            $fechaFin= $Fin->format('Y-m-d');

            $arrayAtributos = array(
                    'id_consulta'                        =>$this->input->post('id_consulta'),
                    'medicamento'                        =>$this->input->post('id_medicamento'),
                    'dosis_preescrita'                   =>$this->input->post('dosis_preescrita'),
                    'frec_de_la_dosis'                   =>$this->input->post('frec_de_la_dosis'),
                    'via_de_administracion'              =>$this->input->post('via_de_administracion'),
                    'inicio_tratamiento'                 =>$fechaInicio,
                    'fin_tratamiento'                    =>$fechaFin,
                    'indicaciones_generales_al_paciente' =>$this->input->post('indicaciones_generales_al_paciente')
                    );
        $this->db->insert('consulta_tratamiento',$arrayAtributos);

        if($this->db->affected_rows() > 0){
            return true;
        }else{
            //echo "incorrecto";
            return false;
        }

    }
    else{


        $arrayAtributos = array(
            'id_consulta'                        =>$this->input->post('id_consulta'),
            'medicamento'                        =>$this->input->post('id_medicamento'),
            'dosis_preescrita'                   =>$this->input->post('dosis_preescrita'),
            'frec_de_la_dosis'                   =>$this->input->post('frec_de_la_dosis'),
            'via_de_administracion'              =>$this->input->post('via_de_administracion'),
            'tiempo_indefinido'                  =>'1',
            'indicaciones_generales_al_paciente' =>$this->input->post('indicaciones_generales_al_paciente')
            );

        $this->db->insert('consulta_tratamiento',$arrayAtributos);

        if($this->db->affected_rows() > 0){
            return true;
        }else{
            //echo "incorrecto";
            return false;
        }
            
    }

    
}

}
?>
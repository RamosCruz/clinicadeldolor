<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_Historial extends CI_Model{
    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    
    
    
    function actualizarAntGinecoObst($id_exp,$menarquia,$duracion,$c_sangre,$frecuencia,$dolor,$secreciones,$sexual,$edad_inicio,$comp_sexuales,$metodo,$relaciones,$enfermedades,$gestaciones,$partos,$abortos,$cesareas,$ant_perinatales)
    
    {
            if ($menarquia!=null)
            {
                $arrayD = array(
                'id_exp' => $id_exp,   
                'menarquia' => $menarquia,
                'duracion' => $duracion,
                'cantidad_sangre' => $c_sangre,
                'frecuencia' => $frecuencia,
                'presencia_dolor' => $dolor,
                'otras_secreciones_vag' => $secreciones,
                'vida_sexual_activa' => $sexual,
                'edad_inicio_sexual' => $edad_inicio,
                'numero_companeros_sexuales' => $comp_sexuales,
                'metodo_anticonceptivo' => $metodo,
                'tipo_relaciones' => $relaciones,
                'enfermedades_trans_sex' => $enfermedades,
                'gestaciones' => $gestaciones,
                'partos' => $partos,
                'abortos' => $abortos,
                'cesareas' => $cesareas,
                'ant_perinatales_de_imp' => $ant_perinatales
                );

                $this->db->where('id_exp',$id_exp);
                $this->db->update('ant_gineco_obstetricos',$arrayD);
            }
        
    }
    function insertarAntGinecoObstID($id_expediente)
    {
        if ($id_expediente!=null)
            {
                $arrayD = array(
                'id_exp' => $id_expediente
                );

                $this->db->insert('ant_gineco_obstetricos',$arrayD);

            }
    }
    public function selAntGinecoObst($numExp = 'null')
    {
        $query = $this->db->query('SELECT * FROM ant_gineco_obstetricos WHERE id_exp="'.$numExp.'"');
        
        return $query->result();
    }
    
    function actualizarAnteHeredoFam($id_exp,$diabetes_mellitus,$hiper_sistemica,$obesidad,$neoplasias,$malformaciones,$alergias,$psiquiatricas,$neurologicas,$cardiovasculares,$broncopulmonares,$tiroideas,$renales,$osteoarticulares,$infectocontagiosas,$anotaciones)
    {
        
        $arrayA = array(
            'id_exp' => $id_exp,
            'diabetes_mellitus' => $diabetes_mellitus, 
            'hiper_sistemica' => $hiper_sistemica,
            'obesidad' => $obesidad,
            'neoplasias' =>  $neoplasias,
            'malformaciones' => $malformaciones,
            'alergias' => $alergias,
            'psiquiatricas' => $psiquiatricas,
            'neurologicas' => $neurologicas,
            'cardiovasculares' => $cardiovasculares,
            'broncopulmonares' => $broncopulmonares,
            'tiroideas' => $tiroideas,
            'renales' => $renales,
            'osteoarticulares' => $osteoarticulares,
            'infectocontagiosas' => $infectocontagiosas,
            'anotaciones' => $anotaciones
        );
        $this->db->where('id_exp',$id_exp);
        $this->db->update('ant_heredo_fam',$arrayA);
        
    }
    public function selAnteHeredoFam($numExp = 'null')
    {
        $query = $this->db->query('SELECT * FROM ant_heredo_fam WHERE id_exp="'.$numExp.'"');
        
        return $query->result();
    }
    
    function insertarAnteHeredoFamID($id_expediente)
    {
        if ($id_expediente!=null)
            {
                $arrayD = array(
                'id_exp' => $id_expediente
                );

                $this->db->insert('ant_heredo_fam',$arrayD);

            }
    }
    
    public function actualizarAntePersoPato($id_exp,$alergicos,$hospitalizaciones,$quirurgicos,$traumaticos,$transfusionales,$alcoholismo,$tabaquismo,$otras_sus,$exantema,$roseola,$rubeola,$sarampion,$varicela,$otras_pato_exant,$faringoamigdalitis,$fiebre_reumatica,$hepatitis,$parasitosis,$tifoidea,$transmision_sexual,$tuberculosis,$otras_pato_infecto,$diabetes_mellitus,$hipert_art_sis,$obesidad,$neoplasicas,$artritis_reumatoide,$enfermedad_de_gota,$enfer_psiquiatricas,$enfer_sist_nervio,$enfer_sist_cardiov,$enfer_sist_respir,$enfer_sist_gastroint,$enfer_sist_endocri,$enfer_sist_urin,$enfer_sist_musculoes,$enfer_sist_tegum,$otra_enfer_cron_degen,$observaciones)
    {
        $arrayC = array(
            'id_exp' => $id_exp,
            'alergicos' => $alergicos,
            'hospitalizaciones' => $hospitalizaciones,
            'quirurgicos' => $quirurgicos,
            'traumaticos' => $traumaticos,
            'transfusionales' => $transfusionales,
            'alcoholismo' => $alcoholismo,
            'tabaquismo' => $tabaquismo,
            'otras_sus' => $otras_sus,
            'exantema' => $exantema,
            'roseola' => $roseola,
            'rubeola' => $rubeola,
            'sarampion' => $sarampion,
            'varicela' => $varicela,
            'otras_pato_exant' => $otras_pato_exant,
            'faringoamigdalitis' => $faringoamigdalitis,
            'fiebre_reumatica' => $fiebre_reumatica,
            'hepatitis' => $hepatitis,
            'parasitosis' => $parasitosis,
            'tifoidea' => $tifoidea,
            'transmision_sexual' => $transmision_sexual,
            'tuberculosis' => $tuberculosis,
            'otras_pato_infecto' => $otras_pato_infecto,
            'diabetes_mellitus' => $diabetes_mellitus,
            'hipert_art_sis' => $hipert_art_sis,
            'obesidad' => $obesidad,
            'neoplasicas' => $neoplasicas,
            'artritis_reumatoide' => $artritis_reumatoide,
            'enfermedad_de_gota' => $enfermedad_de_gota,
            'enfer_psiquiatricas' => $enfer_psiquiatricas,
            'enfer_sist_nervio' => $enfer_sist_nervio,
            'enfer_sist_cardiov' => $enfer_sist_cardiov,
            'enfer_sist_respir' => $enfer_sist_respir,
            'enfer_sist_gastroint' => $enfer_sist_gastroint,
            'enfer_sist_endocri' => $enfer_sist_endocri,
            'enfer_sist_urin' => $enfer_sist_urin,
            'enfer_sist_musculoes' => $enfer_sist_musculoes,
            'enfer_sist_tegum' => $enfer_sist_tegum,
            'otra_enfer_cron_degen' => $otra_enfer_cron_degen,
            'observaciones' => $observaciones
        );
        $this->db->where('id_exp',$id_exp);
        $this->db->update('ant_person_patolo',$arrayC);
    }
    function insertarAntePersoPatoID($id_expediente)
    {
        if ($id_expediente!=null)
            {
                $arrayD = array(
                'id_exp' => $id_expediente
                );

                $this->db->insert('ant_person_patolo',$arrayD);

            }
    }
    public function selAntePersoPato($numExp = 'null')
    {
        $query = $this->db->query('SELECT * FROM ant_person_patolo WHERE id_exp="'.$numExp.'"');
        
        return $query->result();
    }
    public function actualizarAnteNoPersoPato($id_exp,$tabaquismo,$alcoholismo,$escolaridad,$vivienda,$higienicos,$ocupacion,$tiempo_libre,$inmunizaciones,$conciencia)
    {
        $arrayX = array(
            'tabaquismo' => $tabaquismo,
            'alcoholismo' => $alcoholismo,
            'escolaridad' => $escolaridad,
            'vivienda' => $vivienda,
            'higienicos' => $higienicos,
            'ocupacion' => $ocupacion,
            'tiempo_libre' => $tiempo_libre,
            'inmunizaciones' => $inmunizaciones,
            'conciencia' => $conciencia
        );
        $this->db->where('id_exp',$id_exp);
        $this->db->update('ant_person_no_patolo',$arrayX);
    }
    
    function insertarAnteNoPersoPatoID($id_expediente)
    {
        if ($id_expediente!=null)
            {
                $arrayD = array(
                'id_exp' => $id_expediente
                );

                $this->db->insert('ant_person_no_patolo',$arrayD);

            }
    }
    public function selAnteNoPersoPato($numExp = 'null')
    {
        $query = $this->db->query('SELECT * FROM ant_person_no_patolo WHERE id_exp="'.$numExp.'"');
        
        return $query->result();
    }
    
    public function subirConstancia ($id_exp,$nombre,$descripcion)
    {
        $arrayF = array(
            'id_exp' => $id_exp,
            'nombre_archivo' => $nombre,
            'descripcion' => $descripcion,
            'fecha_inclusion'=> date('Y-m-d H:i:s')
            );
        $this->db->insert('constancias',$arrayF);
    }
    public function mostrarImagenes($numExp)
    {
        $query = $this->db->query('SELECT * FROM constancias WHERE id_exp="'.$numExp.'" order by fecha_inclusion desc');
        
        return $query->result();
    }
    public function subirFotografia ($id_exp,$nombre,$descripcion)
    {
        $arrayL = array(
            'id_exp' => $id_exp,
            'nombre_archivo' => $nombre,
            'descripcion' => $descripcion,
            'fecha_inclusion'=> date('Y-m-d H:i:s')
            );
        $this->db->insert('fotografias',$arrayL);
    }
    public function mostrarFotografias($numExp)
    {
        $query = $this->db->query('SELECT * FROM fotografias WHERE id_exp="'.$numExp.'" order by fecha_inclusion desc');
        
        return $query->result();
    }
    public function eliminarForografia($nombre_archivo)
    {
        $this->db->where('nombre_archivo',$nombre_archivo);
        $this->db->delete('fotografias');
    }
    public function eliminarConstancia($nombre_archivo)
    {
        $this->db->where('nombre_archivo',$nombre_archivo);
        $this->db->delete('constancias');
    }

    public function constanciasDelPaciente ($curp = '')
    {
        $query = $this->db->query('SELECT id_exp, nombre_archivo, fecha_inclusion, descripcion FROM constancias INNER JOIN expediente ON expediente.id_expediente=constancias.id_exp WHERE expediente.id_paciente="'.$curp.'" order by fecha_inclusion desc;');
        
        return $query->result();
    }
    
    public function fotosgrafiasDelPaciente ($curp = '')
    {
        $query = $this->db->query('SELECT id_exp, nombre_archivo, fecha_inclusion, descripcion FROM fotografias INNER JOIN expediente ON expediente.id_expediente=fotografias.id_exp WHERE expediente.id_paciente="'.$curp.'" order by fecha_inclusion desc;');
        
        return $query->result();
    }
}
?>
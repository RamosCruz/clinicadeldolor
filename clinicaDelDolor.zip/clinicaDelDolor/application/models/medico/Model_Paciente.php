<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_Paciente extends CI_Model{
    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    public function selestadoCivil()
    {
        $query = $this->db->query('SELECT * FROM estadocivil');
        
        return $query->result();
    }
    
    public function seltipoSangre()
    {
        $query = $this->db->query('SELECT * FROM tiposangre');
        
        return $query->result();
    }
    
    public function selPaciente()
    {
        $query = $this->db->query('SELECT * FROM paciente order by fecha_c desc');
        
        return $query->result();
    }
    public function insertPaciente()
    {
        $date = new DateTime($this->input->post('fecha_nacimiento'));
        $fecha_n = $date->format('Y-m-d');

        
        $arrayD = array(
            'curp' => $this->input->post('curp'),
            'nombre' => $this->input->post('nombre'),
            'app' => $this->input->post('app'),
            'apm' => $this->input->post('apm'),
            'sexo' => $this->input->post('sexo'),
            'fecha_nacimiento' => $fecha_n,
            'alergia' => $this->input->post('alergia'),
            'estado_civil' => $this->input->post('estado_civil'),
            'tipo_sangre' => $this->input->post('tipo_sangre'),
            'estado' => $this->input->post('estado'),
            'fecha_c'=> date('Y-m-d H:i:s'),

            'estado_D'=>$this->input->post('estado_D'),
            'municipio' => $this->input->post('municipio'),
            'localidad' => $this->input->post('localidad'),
            'domicilio' => $this->input->post('domicilio'),
            'telefono' => $this->input->post('telefono')
        );
        
        
        $this->db->insert('paciente',$arrayD);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
            //echo "incorrecto";
			return false;
		}
    }
    public function listarPacientes()
    {
        $query = $this->db->query('SELECT * FROM paciente p,estadocivil e,tiposangre t, estados f where  p.tipo_sangre=t.idtiposangre and p.estado_civil=e.idestadocivil and p.estado=f.clave_estado order by fecha_c desc');
        return $query->result();
    }
    public function eliminarPaciente($curp)
    {
        $this->db->where('curp',$curp);
        $this->db->delete('paciente');
        redirect('medico/paciente');
    }
    public function editarPaciente($curp)
    {
        $query = $this->db->query("SELECT * FROM paciente WHERE curp='$curp'");
        return $query->result();
    }
    public function actualizarPaciente($curp,$nombre,$app,$apm,$fecha_nacimiento1,$alergia,$estado_civil,$tipo_sangre,$telefono,$domicilio,$colonia,$localidad,$estado,$sexo,$estado_D)
    {
        $date = new DateTime($fecha_nacimiento1);
        $fecha_nacimiento = $date->format('Y-m-d');
        $arrayD = array(
            'nombre' => $nombre,
            'app' => $app,
            'apm' => $apm,
            'fecha_nacimiento' => $fecha_nacimiento,
            'alergia' => $alergia,
            'estado_civil' => $estado_civil,
            'tipo_sangre' => $tipo_sangre,
            'telefono' => $telefono,
            'domicilio' => $domicilio,
            'municipio' => $colonia,
            'localidad' => $localidad,
            'estado' => $estado,
            'sexo' => $sexo,
            'estado_D'=>$estado_D
        );
        $this->db->where('curp',$curp);
        $this->db->update('paciente',$arrayD);
    }

    public function buscarPacienteLike($text)
    {
        $query = $this->db->query("SELECT * FROM paciente p,estadocivil e,tiposangre t, estados f , expediente x where p.curp=x.id_paciente and p.tipo_sangre=t.idtiposangre and p.estado_civil=e.idestadocivil and p.estado=f.clave_estado and nombre like '%$text%'");
         return $query->result();
    }
    public function selEstados()
    {
         $query = $this->db->query('SELECT * FROM estados');
        
        return $query->result();
    }
    
    public function verPaciente($curp)
    {
        $query = $this->db->query("SELECT * FROM paciente p,estadocivil e,tiposangre t, estados f where p.tipo_sangre=t.idtiposangre and p.estado_civil=e.idestadocivil and p.estado=f.clave_estado and curp='$curp'");
        return $query->result();
    }
    
    public function validaCURP(){

        $curp =$this->input->post('curp');

        $query = $this->db->query("select * from paciente where curp='$curp'");

        if($query->num_rows()==0){
            return true; //NO SE A REGISTRADO LA CURP
        }
        else{
            return false;// YA ESTA RESGISTRO UN PACIENTE CON ESA CURP
        }
    }
    
    public function getMunicipiosDelEstado ()
    {
        $id_estado = $this->input->post('id_estado');
		$query = $this->db->query("SELECT *FROM municipios where clave_estado='$id_estado' order by nombre_municipio asc");
	     
	     if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
    }
    
    public function getLocalidadesDelMunicipioDe(){
        $id_municipio = $this->input->post('id_municipio');
        $id_estado = $this->input->post('id_estado');
		$query = $this->db->query("SELECT * FROM localidades where clave_estado='$id_estado' and clave_municipio='$id_municipio' order by nombre asc");
	     
	     if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}

     //--------------------------------------------------
    public function obtenerPacienteConCurp($curp)
    {
        $query = $this->db->query("select ex.id_expediente,p.curp, p.nombre, p.sexo, p.app, p.apm, p.telefono,p.alergia,p.fecha_nacimiento, TIMESTAMPDIFF(YEAR, fecha_nacimiento, CURDATE()) AS edad, ec.estadocivil, t.tiposangre, domicilio,p.municipio,p.localidad,p.estado_D, es.estado as estado_nacimiento from paciente p inner join estadocivil  e on(p.estado_civil=e.idestadocivil) inner join tiposangre t on(p.tipo_sangre=t.idtiposangre) inner join estadocivil ec on(p.estado_civil=ec.idestadocivil) inner join estados es on(p.estado=es.clave_estado) inner join expediente ex on(p.curp=ex.id_paciente) where p.curp='$curp'"); 
        return $query->result();
    }
    public function getMunicipiosDelEstado1 ($estado)
    {
		$query = $this->db->query("SELECT * FROM municipios where clave_estado='$estado' order by nombre_municipio asc");
	     
	     if($query->num_rows() > 0){
			return $query->result();
		}else{
			return $query->result();
		}
    }
    public function getLocalidadesDelMunicipioDe1($municipio,$estado){
		$query = $this->db->query("SELECT *FROM localidades where clave_estado='$estado' and clave_municipio='$municipio' order by nombre asc");
	     
	     if($query->num_rows() > 0){
			return $query->result();
		}else{
			return $query->result();
		}
	}
    //--------------------------------------------------

}
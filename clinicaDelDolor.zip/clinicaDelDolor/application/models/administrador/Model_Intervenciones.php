<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_Intervenciones extends CI_Model{
    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    public function agregarIntervension()
    {
        $arrayD = array(
            'intervension' => $this->input->post('intervension'),
            'sugerencia' => $this->input->post('sugerencia'),
            'costo' => $this->input->post('costo')
        );
        $this->db->insert('intervension',$arrayD);
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }
    
    public function eliminarIntervencion()
    {
        $id_intervension = $this->input->get('id_intervension');
        $this->db->where('id_intervension', $id_intervension);
        $this->db->delete('intervension');
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }
    
    public function getIntervensiones()
    {
        $query = $this->db->query("SELECT * FROM intervension  order by intervension asc");
         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }
    public function getIntervensionID ()
    {
       $id_intervension = $this->input->get('id_intervension');
        $query = $this->db->query('SELECT * FROM intervension WHERE id_intervension="'.$id_intervension.'"');
        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        } 
    }


    public function actualizarIntervecion(){

        $id_intervencion =   $this->input->post('id_intervencion');
        $intervencion = $this->input->post('intervencion');
        $sugerencia =        $this->input->post('sugerencia');
        $costo =        $this->input->post('costo');

        $data = array(
        'intervension'    => $intervencion,
        'sugerencia'   =>$sugerencia,
        'costo'   =>$costo
        );

        $this->db->where('id_intervension', $id_intervencion);
        $this->db->update('intervension', $data);
        if($this->db->affected_rows() > 0){
                    return true; //se actualizo
            }
            else{
                return false;//Ocurrio algun error   
        }
    }

}
?>
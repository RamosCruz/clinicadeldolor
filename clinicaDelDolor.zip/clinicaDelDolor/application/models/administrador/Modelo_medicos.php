<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modelo_medicos extends CI_Model{
    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function getUser_Medico(){
         $id_user=$this->ion_auth->user()->row()->id;
         //echo $id_medico;

         $query = $this->db->query("SELECT *FROM  medico inner join honorario using(id_medico) inner join  users on(id_user=id) where id='$id_user'");
         
         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }    
    }

    public function getEspecialidades(){
         $query = $this->db->query("SELECT *FROM especialidad");
         
         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }

    public function getMunicipiosDelEstado ()
    {
        $id_estado = $this->input->post('id_estado');
        $query = $this->db->query("SELECT *FROM municipios where clave_estado='$id_estado' order by nombre_municipio asc");
         
         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }
    
    public function getLocalidadesDelMunicipioDe(){
        $id_municipio = $this->input->post('id_municipio');
        $id_estado = $this->input->post('id_estado');
        $query = $this->db->query("SELECT * FROM localidades where clave_estado='$id_estado' and clave_municipio='$id_municipio' order by nombre asc");
         
         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }

    


    public function getEstados(){
         $query = $this->db->query("SELECT *FROM estados");
         
         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }

    public function validaCURP(){

        $curp =$this->input->post('curp');

        $query = $this->db->query("select * from medico where id_medico='$curp'");

        if($query->num_rows()==0){
            return true; //NO SE A REGISTRADO LA CURP
        }
        else{
            return false;// YA ESTA RESGISTRO UN PACIENTE CON ESA CURP
        }
    }

    public function validaCorreoUnicoEnUsers(){

        $correo =$this->input->post('correo');

        $query = $this->db->query("select * from users where email='$correo'");

        if($query->num_rows()==0){
            return true; //NO SE A REGISTRADO EL CORREO
        }
        else{
            return false;// YA ESTA RESGISTRO UN CORREO CON LOS MISMO DATOS
        }
    }


    public function validaCorreoUnicoEnMedicos(){

        $correo =$this->input->post('correo');

        $query = $this->db->query("select * from medico where correo_electronico='$correo'");

        if($query->num_rows()==0){
            return true; //NO SE A REGISTRADO EL CORREO
        }
        else{
            return false;// YA ESTA RESGISTRO UN CORREO CON LOS MISMO DATOS
        }
    }

    public function actualizarMedico($curp,$nombre,$app,$apm,$sexo,$estado_nacimiento,$fecha_nacimiento,$cedula,$cedulae,$especialidad,$estado_domicilio,$listaDeMunicipios,$listadoDeLocalidades,$calle,$correo_elect,$telefono){
        $date = new DateTime($fecha_nacimiento);
        $fecha_nacimiento = $date->format('Y-m-d');
        $atributos = array(
            'nombre' => $nombre,
            'app' => $app,
            'apm' => $apm,
            'sexo' => $sexo,
            'estado_nace' => $estado_nacimiento,
            'fecha_nace'=>$fecha_nacimiento,
            'cedula' => $cedula,
            'cedulae' => $cedulae,
            'especialidad' => $especialidad,
            'estado' => $estado_domicilio,
            'municipio' => $listaDeMunicipios,
            'localidad' => $listadoDeLocalidades,
            'calle' => $calle,
            'correo_electronico' => $correo_elect,
            'telefono' => $telefono
         );

        $this->db->where('id_medico',$curp);
        $this->db->update('medico',$atributos);
    }

    public function setGroupUser($user_id){
        $atributos = array(
            'group_id'=>4
            );

        $this->db->where('user_id',$user_id);
        $this->db->update('users_groups',$atributos);


    }

    //--------------------------------------------------------
    public function actualizarHonorario(){

        $id_medico=$this->input->post('id_medico');
        $atributos = array(
            'honorario'=>$this->input->post('honorario')
            );

        $this->db->where('id_medico',$id_medico);
        $this->db->update('honorario',$atributos);
    }
    //--------------------------------------------------------



    public function setGroupUserSecretario($user_id){
        $atributos = array(
            'group_id'=>3
            );

        $this->db->where('user_id',$user_id);
        $this->db->update('users_groups',$atributos);


    }    



    
public function RegistrarNuevoMedico(){

        $date = new DateTime($this->input->post('fecha_nacimiento'));
        $fecha_nacimiento = $date->format('Y-m-d');

        $arrayAtributos = array(
            'id_medico'         =>$this->input->post('curp'),
            'nombre'            =>$this->input->post('nombre'),
            'app'               =>$this->input->post('app'),
            'apm'               =>$this->input->post('apm'),
            'sexo'              =>$this->input->post('sexo'),
            'estado_nace'       =>$this->input->post('estado_nacimiento'),
            'fecha_nace'        =>$fecha_nacimiento,
            'cedula'            =>$this->input->post('cedula'),
                'cedulae'           =>$this->input->post('cedulae'),
            'especialidad'      =>$this->input->post('especialidad'),
            'estado'            =>$this->input->post('estado_domicilio'),
            'municipio'         =>$this->input->post('listaDeMunicipios'),
            'localidad'         =>$this->input->post('listadoDeLocalidades'),
            'calle'             =>$this->input->post('calle'),
            'correo_electronico'=>$this->input->post('correo_elect'),
            'telefono'          =>$this->input->post('telefono'),
            //'precio_consulta'   =>$this->input->post('precio_consulta'),
            'id_user'           =>$this->input->post('id_user')
            );

        $this->db->insert('medico',$arrayAtributos);

        if($this->db->affected_rows() > 0){
            return true;
        }else{
            //echo "incorrecto";
            return false;
        }

}

public function RegistrarCostoConsulta($costoDeConsulta,$curp){
    $arrayAtributos = array(
            'id_medico'             =>$curp,
            'honorario'             =>$costoDeConsulta
            );

    $this->db->insert('honorario',$arrayAtributos);

         if($this->db->affected_rows() > 0){
                return true;
            }else{
                //echo "incorrecto";
                return false;
            }


}



    public function getMedicos()
    {
        $query = $this->db->query('SELECT m.id_medico, m.nombre,m.app,m.apm, m.cedula, e.especialidad,m.correo_electronico, m.telefono, h.honorario FROM medico m inner join especialidad e on(m.especialidad=e.id_especialidad) inner join honorario h using(id_medico)');
       if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }

    


    public function getMedico($curp)
    {
        $query = $this->db->query("SELECT * FROM medico WHERE id_medico='$curp'");
        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }
    
    
    ///////
    public function getMunicipiosDelEstado1 ($estado)
    {
        $query = $this->db->query("SELECT * FROM municipios where clave_estado='$estado' order by nombre_municipio asc");
         
         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return $query->result();
        }
    }
    public function getLocalidadesDelMunicipioDe1($municipio,$estado){
        $query = $this->db->query("SELECT *FROM localidades where clave_estado='$estado' and clave_municipio='$municipio' order by nombre asc");
         
         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return $query->result();
        }
    }


   }
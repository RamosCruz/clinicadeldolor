<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_Catalogo extends CI_Model{
    function __construct()
    {
        parent::__construct();
    }
    public function insertMedicamento()
    {
        $arrayD = array(
            'nombre_generico' => $this->input->post('nombre_generico'),
            'forma_farmaceutica' => $this->input->post('forma_farmaceutica'),
            'concentracion' => $this->input->post('concentracion'),
            'presentacion' => $this->input->post('presentacion')
        );
        
        $this->db->insert('catalogo_de_medicamentos',$arrayD);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
        
    }
    public function obtenerMedicamentosPorNombre()
    {
        $nombre_generico = $this->input->get('texto_buscar');


        $query = $this->db->query("SELECT id_medicamento, nombre_generico, forma_farmaceutica, concentracion, presentacion FROM catalogo_de_medicamentos where nombre_generico like '%$nombre_generico%'");
        
        if($query->num_rows() > 0){
               return $query->result();
            }
            else{
                return false;    
            }
    }
    public function eliminarMedicamentoPorID ()
    {
        $id_medicamento = $this->input->get('id_medicamento');
        
        $this->db->where('id_medicamento',$id_medicamento);
        $this->db->delete('catalogo_de_medicamentos');
        if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
    }
    public function editarMedicamentoPorID ()
    {
        $id_medicamento = $this->input->post('id_medicamento');
        
        
        $arrayD = array(
            'nombre_generico' => $this->input->post('nombre_generico'),
            'forma_farmaceutica' => $this->input->post('forma_farmaceutica'),
            'concentracion' => $this->input->post('concentracion'),
            'presentacion' => $this->input->post('presentacion')
        );
        
        
        $this->db->where('id_medicamento',$id_medicamento);
        $this->db->update('catalogo_de_medicamentos',$arrayD);
        if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
    }
    public function obtenerEspecialidades()
    {
        $query = $this->db->query("SELECT * FROM especialidad order by especialidad asc");
        
        if($query->num_rows() > 0){
               return $query->result();
            }
            else{
                return false;    
            }
    }
    public function eliminarEspecialidadPorID ()
    {
        $id_especialidad = $this->input->get('id_especialidad');
        
        $this->db->where('id_especialidad',$id_especialidad);
        $this->db->delete('especialidad');
        if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
    }
    public function agregarEspecialidad()
    {
        $arrayD = array(
            'especialidad' => $this->input->post('especialidad')
        );
        
        $this->db->insert('especialidad',$arrayD);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
    }

        public function obtenerPrecioConsulta()
    {
        $query = $this->db->query("SELECT * FROM preciosdecostos where id_precio=1");
        
        if($query->num_rows() > 0){
               return $query->result();
            }
            else{
                return false;    
            }
    }



        public function actualizarCostoDeConsulta ($costo)
    {

        $arrayD = array(
            'preciosDeConsulta' => $costo
        );
        
        
        $this->db->where('id_precio','1');
        $this->db->update('preciosdecostos',$arrayD);
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }



    public function actualizarEspecialidades(){

        $id_especialidad =   $this->input->post('id_especialidad');
        $especialidad = $this->input->post('especialidad');

        $data = array(
        'especialidad'    => $especialidad
        );

        $this->db->where('id_especialidad', $id_especialidad);
        $this->db->update('especialidad', $data);
        if($this->db->affected_rows() > 0){
                    return true; //se actualizo
            }
            else{
                return false;//Ocurrio algun error   
        }
    }

    
    public function actualizarEstudioLab(){

        $id_estudios_laboratorio =   $this->input->post('id_estudios_laboratorio');
        $estudios_laboratorio = $this->input->post('estudios_laboratorio');

        $data = array(
        'estudios_laboratorio'    => $estudios_laboratorio
        );

        $this->db->where('id_estudios_laboratorio', $id_estudios_laboratorio);
        $this->db->update('estudios_laboratorio', $data);
        if($this->db->affected_rows() > 0){
                    return true; //se actualizo
            }
            else{
                return false;//Ocurrio algun error   
        }
    }
    
    public function actualizarEstudioGab(){

        $id_estudios_de_gabinete =   $this->input->post('id_estudios_de_gabinete');
        $estudios_de_gabinete = $this->input->post('estudios_de_gabinete');

        $data = array(
        'estudios_de_gabinete'    => $estudios_de_gabinete
        );

        $this->db->where('id_estudios_de_gabinete', $id_estudios_de_gabinete);
        $this->db->update('estudios_de_gabinete', $data);
        if($this->db->affected_rows() > 0){
                    return true; //se actualizo
            }
            else{
                return false;//Ocurrio algun error   
        }
    }

}
?>
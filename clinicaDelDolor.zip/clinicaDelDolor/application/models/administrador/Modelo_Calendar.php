<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//MODELO
class Modelo_Calendar extends CI_Model { 

 public function __construct() {
      parent::__construct();
   }

    public function getFullCalendarTodas()
    {
        $query = $this->db->query("SELECT * FROM cita inner JOIN paciente ON (cita.id_paciente=paciente.curp)");
        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return array();
        }
    }
    public function getMedicosConCita()
    {
        $query = $this->db->query("SELECT DISTINCT id_medico FROM cita");
        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }
    public function nombreDelDoc($id_medico)
    {
        $query = $this->db->query("SELECT nombre FROM medico WHERE id_medico='".$id_medico."';");
        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }


}
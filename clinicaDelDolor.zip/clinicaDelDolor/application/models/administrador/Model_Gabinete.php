<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_Gabinete extends CI_Model{
    function __construct()
    {
        parent::__construct();
    }
    
    public function getEstudiosDeGabinete()
    {
        $query = $this->db->query('select * from estudios_de_gabinete');
        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        } 
    }
    
    public function eliminarEstudioPorID()
    {
        $id_estudios_de_gabinete = $this->input->get('id_estudios_de_gabinete');
        $this->db->where('id_estudios_de_gabinete', $id_estudios_de_gabinete);
        $this->db->delete('estudios_de_gabinete');
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }
    
    
    public function agregarEstudio()
    {
        $arrayD = array(
            'estudios_de_gabinete' => $this->input->post('estudios_de_gabinete')
        );
        $this->db->insert('estudios_de_gabinete',$arrayD);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
    }
}
?>
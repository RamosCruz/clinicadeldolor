<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_Laboratorio extends CI_Model{
    function __construct()
    {
        parent::__construct();
    }
    
    public function getAreasEstudio()
    {
        $query = $this->db->query("SELECT * FROM area_estudio_laboratorio");
         if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        }
    }
    
    public function getEstudiosDeLaboratorio ()
    {
       $id_area_estudio_laboratorio = $this->input->get('id_area_estudio_laboratorio');
        $query = $this->db->query('select * from estudios_laboratorio where id_area_estudio_laboratorio = "'.$id_area_estudio_laboratorio.'"');
        if($query->num_rows() > 0){
            return $query->result();
        }else{
            return false;
        } 
    }
    
    public function agregarAreaEstudio()
    {
        $arrayD = array(
            'area_estudio' => $this->input->post('area_estudio')
        );
        $this->db->insert('area_estudio_laboratorio',$arrayD);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
    }
    
    public function eliminarEstudioPorID()
    {
        $id_estudios_laboratorio = $this->input->get('id_estudios_laboratorio');
        $this->db->where('id_estudios_laboratorio', $id_estudios_laboratorio);
        $this->db->delete('estudios_laboratorio');
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }
    
    
    public function agregarEstudio()
    {
        $arrayD = array(
            'id_area_estudio_laboratorio' => $this->input->post('id_area_estudio_laboratorio'),
            'estudios_laboratorio' => $this->input->post('estudios_laboratorio')
        );
        $this->db->insert('estudios_laboratorio',$arrayD);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
    }
}
?>
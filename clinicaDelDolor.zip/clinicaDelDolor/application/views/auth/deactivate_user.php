<!--<h1><?php echo lang('deactivate_heading');?></h1>
<p><?php echo sprintf(lang('deactivate_subheading'), $user->username);?></p>

<?php echo form_open("auth/deactivate/".$user->id);?>

  <p>
  	<?php echo lang('deactivate_confirm_y_label', 'confirm');?>
    <input type="radio" name="confirm" value="yes" checked="checked" />
    <?php echo lang('deactivate_confirm_n_label', 'confirm');?>
    <input type="radio" name="confirm" value="no" />
  </p>

  <?php echo form_hidden($csrf); ?>
  <?php echo form_hidden(array('id'=>$user->id)); ?>

  <p><?php echo form_submit('submit', lang('deactivate_submit_btn'));?></p>

<?php echo form_close();?>-->
<br>
<br>
<br>
<div class="container">
  <hr>
    <div class="row">
        <div class="col-sm-offset-3 col-md-6">
            <p class="lead"><?php echo sprintf(lang('deactivate_subheading'), $user->username);?></p>

            <?php echo form_open("auth/deactivate/".$user->id, array('class' => 'form-horizontal'));?>

                <div class="checkbox">
                    <label>
                        <input type="radio" name="confirm" value="yes" checked="checked"> <?php echo $this->lang->line('deactivate_confirm_y_label');?>
                    </label>
                </div>

                <div class="checkbox">
                    <label>
                        <input type="radio" name="confirm" value="no"> <?php echo $this->lang->line('deactivate_confirm_n_label'); ?>
                    </label>
                </div>
                </br>


                <?php echo form_hidden($csrf); ?>
                <?php echo form_hidden(array('id'=>$user->id)); ?>

                <div class="form-group">
                    <div class="col-xs-12">
                        <?php echo anchor('auth', 'Regresar', array('class' => 'btn btn-info')); ?>
                        <?php echo form_submit(array('name' => 'submit', 'value' => 'Aceptar', 'class' => 'btn btn-success'));?>
                    </div>
                </div>

            <?php echo form_close();?>
        </div>
    </div>
</div>

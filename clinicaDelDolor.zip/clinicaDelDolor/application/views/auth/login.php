<!--VISTA -->
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Ingreso - Clinica Del Dolor</title>
<?php echo link_tag('assets/css/login/logotipo.png', 'shortcut icon', 'image/png');?>

<meta name="viewport" content="width=device-width, initial-scale=1">
     <!-- ---------------------------------CARGAMOS LAS LIBRERIAS NECESARIAS------------------------------------------ -->
    
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url("assets/css/login/estilo_login.css")?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/bootstrap.css")?>" rel="stylesheet" type="text/css">
    <script src="<?php echo base_url("assets/js/jquery.js")?>"></script>
    <script src="<?php echo base_url("assets/js/bootstrap.js")?>"></script>
    <script type="text/javascript">
      funcionInicial();
      var activo=0;
       function funcionInicial(){
        if(activo==0){
          <?php $this->ion_auth->logout();?>
        }

        
       }
</script>
    <!-- --------------------------------------------------------------------------- -->

</head>
<body id="fondo">


<div class="container well" id="circulo">
    <div class="row">
        <div class="col-xs-12">
            <img src="<?php echo base_url("assets/css/login/logotipo_grande.png")?>" class="img-responsive" id="avatar">
        </div>
    </div>
 
<!--<h1><?php echo lang('login_heading');?></h1>-->
<center>
<div><?php echo lang('login_subheading');?></div>

<div id="infoMessage"><?php echo $message;?></div>
</center>
<?php  
    $attr = array('class' => 'form-signin form-horizontal', 'role' => 'form', 'autocomplete'=>'on');
    echo form_open("auth/login",$attr);

?>

  <p>
    <!--<?php echo lang('login_identity_label', 'identity');?>-->
    <?php echo form_input($identity);?>
  </p>

  <p>
    <!--<?php echo lang('login_password_label', 'password');?>-->
    <?php echo form_input($password);?>
  </p>

  <p>
<?php
    $attr = array('class' => 'btn btn-primary btn-lg btn-block', 'type' => 'submit');  
    echo form_submit($attr, lang('login_submit_btn'));
?>
</p>


  <!--<p>
    <?php echo lang('login_remember_label', 'remember');?>
    <?php echo form_checkbox('remember', '1', FALSE, 'id="remember"');?>
  </p>-->

<div class="row">
    <div class="col-md-5">
        <div class="checkbox">
            <label>
                <?php echo form_checkbox('remember', '1', FALSE, 'id="remember"');?> Recu&eacute;rdame
            </label>
        </div>
    </div>
    <!--<div class="col-md-7">
        <p class="forgot"><a href="forgot_password">&iquest;Olvidaste tu contrase&ntilde;a?</a></p>
    </div>-->
</div>

<?php echo form_close();?>

<!--<p><a href="forgot_password"><?php echo lang('login_forgot_password');?></a></p>-->

 
</div>

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/fuente.css') ?>">
</body>
</html>
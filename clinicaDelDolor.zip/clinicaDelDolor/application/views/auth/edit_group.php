<!--<h1><?php echo lang('edit_group_heading');?></h1>
<p><?php echo lang('edit_group_subheading');?></p>

<div id="infoMessage"><?php echo $message;?></div>

<?php echo form_open(current_url());?>

      <p>
            <?php echo lang('edit_group_name_label', 'group_name');?> <br />
            <?php echo form_input($group_name);?>
      </p>

      <p>
            <?php echo lang('edit_group_desc_label', 'description');?> <br />
            <?php echo form_input($group_description);?>
      </p>

      <p><?php echo form_submit('submit', lang('edit_group_submit_btn'));?></p>

<?php echo form_close();?>-->
<br>
<br>
<br>
<div class="container">
    <?php echo anchor('auth', 'Regresar', array('class' => 'btn btn-info pull-right', 'style' => 'margin-top: 2%')); ?>
    <h1><?php echo lang('edit_group_heading'); ?></h1>
    <p class="lead"><?php echo lang('edit_group_subheading'); ?></p>
    <hr>
    <div class="row">
        <div class="col-md-12">
            <?php echo form_open(current_url(), array('class' => 'form-horizontal'));?>

                  <div class="form-group">
                        <?php echo form_label($this->lang->line('create_group_name_label'), 'group_name', array('class' => 'col-sm-4 control-label'));?>
                      <div class="col-sm-4">
                        <?php echo form_input($group_name, NULL, 'class="form-control"');?>
                        <?php echo form_error('group_name'); ?>
                      </div>
                  </div>

                  <div class="form-group">
                        <?php echo form_label($this->lang->line('edit_group_desc_label'), 'description', array('class' => 'col-sm-4 control-label'));?>
                      <div class="col-sm-4">
                        <?php echo form_input($group_description, NULL, 'class="form-control"');?>
                        <?php echo form_error('description'); ?>
                      </div>
                  </div>

                  <div class="form-group">
                      <div class="col-sm-offset-4 col-sm-8">
                            <?php echo form_submit(array('class' => 'btn btn-success btn-large', 'name' => 'submit', 'value' => 'Guardar'));?>
                      </div>
                  </div>

            <?php echo form_close();?>
        </div>
    </div>
</div>

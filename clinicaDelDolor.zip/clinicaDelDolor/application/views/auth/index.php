<br>
<br>
<br>


<?php if(!empty($message)) echo '<div id="infoMessage" class="alert alert-success"><div class="container">'.$message.'</div></div>';?>
<div class="container">
	<div class="col-md-12">

	<?php echo anchor('auth/create_user', lang('index_create_user_link'), array('id'=>'botonCrearSecretario','class' => 'btn btn-info pull-right', 'style' => 'margin-top: 2%')); ?>
	<!--<?php echo anchor('auth/create_group', lang('index_create_group_link'), array('class' => 'btn btn-default pull-right', 'style' => 'margin-top: 2%;margin-right:5px')); ?>-->
	
	<!--<h1><?php echo lang('index_heading');?></h1>
	<p class="lead">Listado de usuarios existentes en el sistema</p>-->
	<br>
	</div>
	<br>
	<br>

	<hr>
	<!--<div class="row">
		<div class="col-md-12">-->

	 <div class="panel panel-primary">
         
         	<div class="panel-heading">
	            <h3 class="panel-title">Listado de usuarios existentes en el sistema</h3>
	        </div>
	        
	        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        
                        <th><?php echo lang('index_fname_th');?></th>
                        <th><?php echo lang('index_email_th');?>/Usuario</th>
                        <th><?php echo lang('index_groups_th');?></th>
                        <th><?php echo lang('index_status_th');?></th>
                        <th><?php echo lang('index_action_th');?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($users as $user):?>
                        <tr>
                            
                            <td><?php echo $user->first_name.' '.$user->last_name;?></td>
                            <td><?php echo $user->email;?></td>
                            <td>
                                <?php foreach ($user->groups as $group):?>
                                    <!--<?php echo anchor("auth/edit_group/".$group->id, $group->description, array('class' => 'btn btn-primary btn-xs btn-group-user', 'data-toggle' => 'tooltip', 'data-placement' => 'bottom', 'title' => 'Click para editar grupo')) ;?><br />-->
                                    <?php echo $group->description;?><br />
                                <?php endforeach?>
                            </td>
                            <td><?php echo ($user->active) ? anchor("auth/deactivate/".$user->id, lang('index_active_link'), array('class' => 'btn btn-success btn-xs', 'data-toggle' => 'tooltip', 'data-placement' => 'bottom', 'title' => 'Click para desactivar cuenta')) : anchor("auth/activate/". $user->id, lang('index_inactive_link'), array('class' => 'btn btn-warning btn-xs', 'data-toggle' => 'tooltip', 'data-placement' => 'bottom', 'title' => 'Click para activar cuenta'));?></td>
                            <td><?php echo anchor("auth/edit_user/".$user->id, '<i class="glyphicon glyphicon-pencil"></i>', array('class' => 'btn btn-warning btn-xs', 'data-toggle' => 'tooltip', 'data-placement' => 'bottom', 'title' => 'Editar cuenta')) ;?></td>
                        </tr>
                    <?php endforeach;?>
                    </tbody>
                </table>
            </div>
		</div>
	</div>
		<!--</div>
	</div>-->
</div>

<script type="text/javascript">
$('#botonCrearSecretario').text('Crear usuario Secretario(a)');

</script>
<br>
<br>
<br>
<div class="container">
      <?php echo anchor('auth/', 'Regresar', array('class' => 'btn btn-info pull-right', 'style' => 'margin-top: 2%')); ?>
      <!--<h1><?php echo lang('edit_user_heading');?></h1>
      <p class="lead"><?php echo lang('edit_user_subheading');?></p>-->
      <br>
      <br>
      <br>

      <div class="row">
             <div class="col-md-8  col-md-offset-2">

            
             <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Editar datos del Usuario</h3>
              </div>
              <div class="panel-body">

                      <?php echo form_open(uri_string(), array('class' => 'form-horizontal'));?>

                        <div class="form-group">
                              <?php echo form_label('Username:', 'username', array('class' => 'col-sm-4 control-label'));?>
                            <div class="col-sm-4">
                              <?php echo form_input($username, NULL, 'class="form-control"');?>
                              <?php echo form_error('username'); ?>
                            </div>
                        </div>

                        <div class="form-group">
                              <?php echo form_label($this->lang->line('edit_user_fname_label'), 'first_name', array('class' => 'col-sm-4 control-label'));?>
                            <div class="col-sm-4">
                              <?php echo form_input($first_name, NULL, 'class="form-control"');?>
                              <?php echo form_error('first_name'); ?>
                            </div>
                        </div>

                        <div class="form-group">
                              <?php echo form_label($this->lang->line('edit_user_lname_label'), 'last_name', array('class' => 'col-sm-4 control-label'));?>
                              <div class="col-sm-4">
                                    <?php echo form_input($last_name, NULL, 'class="form-control"');?>
                                    <?php echo form_error('last_name'); ?>
                              </div>
                        </div>

                        <div class="form-group">
                              <?php echo form_label($this->lang->line('edit_user_email_label'), 'email', array('class' => 'col-sm-4 control-label'));?>
                              <div class="col-sm-4">
                                    <?php echo form_input($email, NULL, 'class="form-control"');?>
                                    <?php echo form_error('email'); ?>
                              </div>
                        </div>

                        <div class="form-group">
                              <?php echo form_label($this->lang->line('edit_user_phone_label'), 'phone', array('class' => 'col-sm-4 control-label'));?>
                              <div class="col-sm-4">
                                    <?php echo form_input($phone, NULL, 'class="form-control"');?>
                                    <?php echo form_error('phone'); ?>
                              </div>
                        </div>

                        <div class="form-group">
                              <?php echo form_label($this->lang->line('edit_user_password_label'), 'password', array('class' => 'col-sm-4 control-label'));?>
                              <div class="col-sm-4">
                                    <?php echo form_input($password, NULL, 'class="form-control"');?>
                                    <?php echo form_error('password'); ?>
                              </div>
                        </div>

                        <div class="form-group">
                              <?php echo form_label($this->lang->line('edit_user_password_confirm_label'), 'password_confirm', array('class' => 'col-sm-4 control-label'));?>
                              <div class="col-sm-4">
                                    <?php echo form_input($password_confirm, NULL, 'class="form-control"');?>
                                    <?php echo form_error('password_confirm'); ?>
                              </div>
                        </div>

                        <!--<div class="form-group">
                            <div class="col-sm-offset-4 col-sm-8">
                              <h3><?php echo $this->lang->line('edit_user_groups_heading');?></h3>
                              <?php foreach ($groups as $group):?>
                                <div class="checkbox">
                                <?php
                                  $gID=$group['id'];
                                  $checked = null;
                                  $item = null;
                                  foreach($currentGroups as $grp) {
                                    if ($gID == $grp->id) {
                                      $checked= ' checked="checked"';
                                    break;
                                    }
                                  }
                                ?>
                                  <label>
                                    <input type="checkbox" name="groups[]" value="<?php echo $group['id'];?>"<?php echo $checked;?>>
                                    <?php echo $group['description'];?>
                                  </label>
                                </div>
                              <?php endforeach?>
                            </div>
                        </div>-->

                            <?php echo form_hidden('id', $user->id);?>
                            <?php echo form_hidden($csrf); ?>

                        <div class="form-group">
                            <div class="col-sm-offset-4 col-sm-8">
                              <?php echo form_submit(array('name' => 'submit', 'value' => 'Guardar', 'class' => 'btn btn-success btn-large'));?></div>
                        </div>

                  <?php echo form_close();?>
                </div>
              </div>
            </div>
      </div>
</div>
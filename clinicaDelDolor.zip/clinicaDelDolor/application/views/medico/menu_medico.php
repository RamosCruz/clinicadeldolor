<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <!--a class="navbar-brand" href="#">Clinica del dolor</a-->
      <img src="<?php echo base_url('assets/img/logotipo.png');?>" alt="">
    </div>
    

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/medical-records(1).png');?>" alt=""> Agenda de citas <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('medico/Agenda/nuevaCita');?>">Nueva cita</a></li>
            <li><a href="<?php echo base_url('medico/Agenda/listarAgenda');?>">Administrar citas</a></li>
            <li><a href="<?php echo base_url('medico/Agenda/fullCalendar');?>">Calendario</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/pain.png');?>" alt=""> Pacientes <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('medico/paciente/nuevoPaciente');?>">Nuevo paciente</a></li>
            <li><a href="<?php echo base_url('medico/paciente'); ?>">Listar pacientes</a></li>
          </ul>
        </li>
        <li><a id="nuevaconsultaGeneral"><img src="<?php echo base_url('assets/img/surgeon.png');?>" alt=""> Consultas</a></li>
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/picture.png');?>" alt=""> Galeria de imagenes <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('medico/Categoria'); ?>">Categoria</a></li>
            <li><a href="<?php echo base_url('medico/Categoria/nueva_imagen'); ?>">Nueva imagen</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="<?php echo base_url('medico/Categoria/galeria'); ?>">Galeria</a></li>
          </ul>
        </li>

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/medical-history.png');?>" alt=""> Catálogos <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('medico/Medicamentos'); ?>">Médicamentos</a></li>
            <li><a href="<?php echo base_url('medico/Diagnosticos'); ?>">Diagnósticos</a></li>
          </ul>
        </li>
        
        
        
        
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/duplicate.png');?>" alt=""> Formatos <span class="caret"></span></a>
          <ul class="dropdown-menu">
             <li><a href="<?php echo base_url('medico/Formatos/NuevaNotaPreoperatoriayValoracionPreanestesica'); ?>">Nota Preoperatoria y Valoracion Preanestesica</a></li>
            <li><a href="<?php echo base_url('medico/Formatos/NuevaCartadeConsentimientoBajoInformacionSedacion'); ?>">Carta de Consentimiento Bajo Información Sedacion</a></li>
            <li><a href="<?php echo base_url('medico/Formatos/NuevaCartadeConsentimientoBajoInformacionAnestesiaRegional'); ?>">Carta de Consentimiento Bajo Información Anestesia Regional</a></li>
            <li><a href="<?php echo base_url('medico/Formatos/NuevaCartadeConsentimientoBajoInformacionAnestesiaGeneral'); ?>">Carta Consentimiento Bajo Información anestesia General</a></li>
            <li><a href="<?php echo base_url('medico/Formatos/receta'); ?>">Receta Medica</a></li>
            <!--<li><a href="<?php echo base_url('medico/Formatos/VerExpediente'); ?>">Imprimir Expediente Clínico</a></li>-->
          </ul>
        </li>

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/analytics.png');?>" alt=""> Reportes <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('medico/Reportes/Cuentas'); ?>">Cuentas</a></li>
            <li><a href="<?php echo base_url('medico/Reportes/Balance'); ?>">Balance de ingresos</a></li>
          </ul>
        </li>
        
      </ul>
      
      
      
      <ul class="nav navbar-nav navbar-right">
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/users.png');?>" alt="">
            <?php 

             $arrayDatos=explode(" ",$medico_logueado[0]->nombre);

            if($medico_logueado[0]->sexo!='H'){
               echo 'Dra. '.ucfirst(strtolower($arrayDatos[0]));
            }else{
               echo 'Dr. '.ucfirst(strtolower($arrayDatos[0]));
            }?>

             <span class="caret"></span></a>
          <ul class="dropdown-menu">                                                                                                                                                                                
            <li><a href="<?php echo base_url('Auth/logout');?>">Salir</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>



<!-- ------------------------------------MODAL BUSCAR------------------------------------ -->

<div id="modalConsultaGeneral" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header modal-header-primary">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-search"></i> Buscar Paciente</center></h2>
        
    </div>
    <div class="modal-body">
           <div class="panel panel-default">
        <div class="panel-body">
          
            <div class="col-lg-10">
            <form class="form-horizontal" role="form">
              
              <div class="form-group">
                <label for="ejemplo_email_3" class="col-lg-4  control-label">Nombre</label>
                <div class="col-lg-8 ">
                  <input type="text" class="form-control" name ="nombre" id="nombreAbuscar"
                         placeholder="Ingrese un nombre del paciente">
                </div>
              </div>
              
              <div class="form-group">
                <label for="ejemplo_password_3" class="col-lg-4  control-label">Apellido</label>
                <div class="col-lg-8 ">
                  <input type="text" class="form-control" name="apellido-p" id="apellidoAbuscar" 
                         placeholder="Ingresa un apellido del paciente">
                </div>
              </div>
              
              
            </form>
            
          </div>
          <div class="col-lg-2">
            <button type="submit" class="btn btn-primary" id="buscaPacCons1">Buscar</button>
          </div>
          
        </div>
      </div>
      
      <div class="panel panel-default">
        <div class="panel-body">
          
          <div class="col-lg-10">
            <form class="form-horizontal" role="form">
              
              <div class="form-group">
                <label for="ejemplo_email_3" class="col-lg-4  control-label">Número de Expediente</label>
                <div class="col-lg-8 ">
                  <input type="number" class="form-control " name="expediente" id="expedienteAbuscar"
                         placeholder="Ingresa un número de expediente">
                </div>
              </div>
             
             </form>
            
          </div>
          
          <div class="col-lg-2">
            <button type="submit" class="btn btn-primary" id="buscarExpedCons1">Buscar</button>
          </div>
          
        </div>
      </div>


      <div class="panel panel-default">
        <div class="panel-body">
             <div class="alert alert-danger" role="alert" style="display: none;">
             </div>

             <div class="table-responsive" id="conexion1">
                <div class="nuevaTabla" id="showdataconsulta1">
                </div>  
             </div>

        </div>
      </div>

    </div>
<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    <!-- <button type="button" id="btnSave" class="btn btn-primary">Save changes</button> -->
</div>
</div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<br>
<br>


<!-- ------------------------------------------------------------------------ -->










<script>

$('#nuevaconsultaGeneral').click(function(){
        
         $('#modalConsultaGeneral').modal('show');
        
    });    
    
    
 $('#buscaPacCons1').click(function(){

 //alert("Boton precionado:");
            var nombre = $('#nombreAbuscar').val();
            var apellido = $('#apellidoAbuscar').val();
            //alert("Boton precionado: nombre- "+nombre);

            var elemento_nombre_paciente=$('input[name=nombre]');
            var elemento_ap_paciente=$('input[name=apellido-p]');

              

            if(apellido==""&&nombre==""){
                elemento_nombre_paciente.focus();
            }
            else{
                mostrarResultadoBusquedaPorNombre1(nombre,apellido);
            }

});

        //--------------------------------------------------
$('#buscarExpedCons1').click(function(){

            var expediente = document.getElementById("expedienteAbuscar").value;

            if(expediente==""){
                 var elemento_num_exp=$('input[name=expediente]');
                 elemento_num_exp.focus();
            }
            else{
                mostrarResultadoBusquedaPorExpediente1(expediente);
            }

});

        //En este item se guarda temporalmente el id del paciente seleccionado
$('#showdataconsulta1').on('click', '.item-id-paciente', function(){
                    var id_paciente1 = $(this).attr('id-paciente');
                    var nombre = $(this).attr('nombre');
                    var ap_p = $(this).attr('ap-p');
                    var ap_m = $(this).attr('ap-m');

             location.href = '<?php echo base_url(); ?>medico/Consulta/nuevaConsulta/'+id_paciente1;
                    $('#modalConsulta').modal('hide');
});

function mostrarResultadoBusquedaPorExpediente1(numExpediente){
            $.ajax({//En este metodo falta repillar la consulta para que sea mas cercana a la respuesta
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/buscarExpediente',
               data:{id_expediente:numExpediente},
               dataType: 'json',
               success: function(data){

                if(data==false){

                        var html = '';
                        $('#showdataconsulta1').html(html);
                            
                        $('.alert-danger').html('No hay registros con la busqueda seleccionada!').fadeIn().delay(2000).fadeOut('slow');
              

                    }
                    else{

                var html = '';
                var i;
                                    //if(data!=false){
                                        html +='<table class="table table-condensed table-bordered table table-hover" style="margin-top: 20px;">'+
                                        '<thead>'+
                                        '<tr class="success">'+
                                            '<th>NÚM EXPEDIENTE</th>'+
                                            '<th>CURP</th>'+
                                            '<th>NOMBRE</th>'+
                                            '<th>APELLIDO PATERNO</th>'+
                                            '<th>SELECCIONAR</th>'+
                                        '</tr>'
                                        '</thead>'+
                                            '<tbody>';
                                        for(i=0; i<data.length; i++){
                                            html +='<tr>'+
                                            '<td>'+data[i].id_expediente+'</td>'+
                                            '<td>'+data[i].curp+'</td>'+
                                            '<td>'+data[i].nombre+'</td>'+
                                            '<td>'+data[i].apellido_p+'</td>'+
                                            '<td>'+
                                            '<center><a class="btn btn-default item-id-paciente"  id-paciente="'+data[i].id_paciente+'" '+'nombre="'+data[i].nombre+'" ap-p="'+data[i].apellido_p+'" '+'ap-m="'+data[i].apellido_m+'" ><i class="glyphicon glyphicon-ok"></i></a></center>'+
                                            '</td>'+
                                            '</tr>';
                                        }
                                        html +='</tbody>'+'</table>';
                                        
                                        $('#showdataconsulta1').html(html);
                                    }
                                },
                                error: function(){
                                    alert('Could not get Data from Database');
                                }
                            });
}



function mostrarResultadoBusquedaPorNombre1(nombre,apellido){
            $.ajax({//En este metodo falta repillar la consulta para que sea mas cercana a la respuesta
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/buscarPacienteLike',
               data:{nombre:nombre,apellido_p:apellido},
               dataType: 'json',
               success: function(data){

                if(data==false){

                        var html = '';
                        $('#showdataconsulta1').html(html);
                            
                        $('.alert-danger').html('No hay registros con la busqueda seleccionada!').fadeIn().delay(2000).fadeOut('slow');
              

                    }
                    else{

                                    var html = '';
                                    var i;
                                    
                                        html +='<table class="table  table-condensed table-bordered table table-hover" style="margin-top: 20px;">'+
                                        '<thead>'+
                                        '<tr class="success">'+
                                        '<td>NÚM EXPEDIENTE</td>'+
                                        '<td>CURP</td>'+
                                        '<td>NOMBRE</td>'+
                                        '<td>APELLIDO PATERNO</td>'+
                                        '<td>SELECCIONAR</td>'+
                                        '</tr>'+
                                        '</thead>';
                                        for(i=0; i<data.length; i++){
                                            html +='<tr>'+
                                            '<td>'+data[i].id_expediente+'</td>'+
                                            '<td>'+data[i].curp+'</td>'+
                                            '<td>'+data[i].nombre+'</td>'+
                                            '<td>'+data[i].apellido_p+'</td>'+
                                            '<td>'+
                                            '<center><a class="btn btn-default item-id-paciente"  id-paciente="'+data[i].id_paciente+'" '+'nombre="'+data[i].nombre+'" ap-p="'+data[i].apellido_p+'" '+'ap-m="'+data[i].apellido_m+'" ><i class="glyphicon glyphicon-ok"></i></a></center>'+
                                            '</td>'+
                                            '</tr>';
                                        }
                                        $('#showdataconsulta1').html(html);

                                    }
                                    
                                },
                                error: function(){
                                    alert('Could not get Data from Database');
                                }
                            });
}
    

</script>
<!--VERSIÓN DE HOSTING-->
<br>
<br>

<!-- -->



<div class="panel panel-primary">
 <div class="panel-heading">
   <h3 class="panel-title"> <?php  if(!empty($datos_de_la_cita)){ ?> Cita Registrada:  
                                                                                                Fecha: <?php echo $datos_de_la_cita[1]; ?>
                                                                                                Hora: <?php echo $datos_de_la_cita[0]; ?>
                                                                                                <?php } ?>
                                                                                              </h3>
   <h3 class="panel-title">Núm. de expediente: <?php echo $paciente[0]->id_expediente;?></h3> 
   <h3 class="panel-title">Paciente: <?php echo $paciente[0]->nombre;?> <?php echo $paciente[0]->app;?> <?php echo $paciente[0]->apm;?></h3> 
   <h3 class="panel-title">Edad: <?php echo $paciente[0]->edad;?> años </h3> 
 </div>
 <div class="panel-body">
   

    <div>


      <div>

        <!-- Nav tabs -->
        <ul class="nav nav-tabs" role="tablist">
          <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Consulta</a></li>
          <!--<li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Exploración fisica segmentada <span class="badge" id="numFisSeg"></span></a></li>-->
 <li role="presentation"><a href="#material" aria-controls="material" role="tab" data-toggle="tab">Material Didáctico</a></li>          
<li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Pagos <span class="badge" id="numInter"></span></a></li>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
                    <!-- Inicia pestaña de material didactico -->
          <div role="tabpanel" class="tab-pane" id="material">
             <div class="panel panel-default">
              <div class="panel-body">

                <div class="col-md-4">
                </div>

                <div class="col-md-2">
                </div>

                <div class="form-group col-md-6">
                           <div class="panel panel-primary " >
                                    <div class="panel-body">
                                      <div class="col-sm-12"><p align="justify"><font color="black">Realice un filtro o búsqueda de imagenes por categoría ó nombre de la imagen.</font></p>
                                          <hr style="color: #0056b2;" />

                                        <div class="col-md-6">
                                          <div class="form-group">
                                            <select class="form-control" name="categorias" id="comboCategorias" placeholder="Filtre las imagenes seleccionando una categoría " onchange="seleccionarCategoria(this.value);">
                                                  <option value="00">Seleccione una categoría</option>
                                                  <option value="0">Todas</option>
                                                   <?php
                                                    foreach ($categorias as $value)
                                                    {
                                                    ?>    
                                                    <option value="<?=$value -> id_categoria ?>"><?=$value -> categoria ?></option>
                                                    <?php    
                                                    }
                                                   ?>
                                               </select>
                                           </div>
                                       </div>



                                       <div class="col-md-6">
                                          <div class="form-group">

                                                    <input type="text" class="form-control" id="description1" name="description1" placeholder="Escriba el nombre de la imagen" required >
                                                    <button type="button" id="search" class="btn btn-primary btn-xs btn-block col-md-12"><span class="glyphicon glyphicon-search"></span>Buscar</button>
                                            </div>
                                      </div>
                                  </div>
                                    </div>
                            </div>
                </div>

            <div class="col-md-12">
                
                <div class="panel panel-primary" >
                    <div class="panel-heading">
                        <h3 class="panel-title" >Galeria</h3>
                    </div>
                    <div class="panel-body">
                        
                                <div class="container col-md-12">
                                    <div class="row" id="row_galeria">

                                                
                                  </div>
                                </div>
                            
                        <!--Fin galeria imagen-->
                        
                    </div>
                </div>
            </div>    
 
     

              </div>
            </div>
          </div>
          <div role="tabpanel" class="tab-pane active" id="home">

                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                  <li role="presentation" class="active"><a href="#NuevaConsulta" aria-controls="NuevaConsulta" role="tab" data-toggle="tab">Nueva Consulta</a></li>
                  <li role="presentation"><a href="#Estudios" aria-controls="Estudios" role="tab" data-toggle="tab">Registrar Estudios de Laboratorio o de Gabinete</a></li>
                  <li role="presentation"><a href="#RegistroDeConsultas" id="TapRegistroDeConsultas" aria-controls="RegistroDeConsultas" role="tab" data-toggle="tab">Consultas Registradas <span class="badge" id="numRegistroDeConsultas"></span></a></li> 
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">

                  
                  <div role="tabpanel" class="tab-pane active" id="NuevaConsulta">
                    
                    
                    <div class="panel panel-default"><!--       NUEVA CONSULTA DE ESTE PACIENTE    -->
                                        <div class="panel-body">
                                          <form class="form-horizontal" id="FormularioConsulta" autocomplete="off" action="<?php echo base_url('medico/Formatos/imprimirReceta'); ?>" target="_blank" method="post" >
                                            <div class="row">
                                            <div class="col-md-12">
                                              <div class="col-md-10">
                                              </div>
                                              <div class="col-md-2">
                                                
                                                <button type="submit" style="display: none;" id="ImprimirReceta" class="btn btn-info btn-lg">Imprimir Receta</button>
                                                
                                              </div>
                                            </div>
                                            </div>
                                            <!--<div class="row">

                                              <div class="col-md-8">
                                                Indique el tipo de formulario para generar el diagnóstico, asi como el plan de tratamiento para esta consulta:
                                              </div>
                                              <div class="col-md-4">
                                                        <label class="radio-inline">
                                                        <input type="radio" name="optradio" value='1' checked="checked">Abierto
                                                      </label>

                                                      <label class="radio-inline">
                                                        <input type="radio" name="optradio " value='2'>Cerrado
                                                      </label>
                                              </div>
                                            </div>-->

                                            <div class="row" id="tipoFormularioOculta">
                                                      <div class="col-md-7">
                                                        <p>
                                                        Indique el tipo de formulario para generar el diagnóstico, asi como el plan de tratamiento para esta consulta:
                                                        </p> 
                                                      </div>

                                                      <div class="col-md-5">
                                                        <label class="radio-inline">
                                                        <input type="radio" name="optradio" value='1' checked="checked">Abierto
                                                      </label>

                                                      <label class="radio-inline">
                                                        <input type="radio" name="optradio" value='2'>Cerrado
                                                      </label>
                                                      </div>


                                                    </div>
                                             
                                            <hr>

                                            <div class="row">

                                              <div class="col-md-6">

                                                <div class="form-group">
                                                    <div class="col-md-12">
                                                     <label class="control-label"><span class="camposNecesarios"><strong>*</strong></span>Motivo de consulta.</label>
                                                     <textarea type="text" class="form-control" id="motivo" name="motivo" style="height: 120px;" required></textarea>
                                                     <style type="text/css">
                                                     textarea {
                                                      max-width: 100%; 
                                                      max-height: 100%;
                                                    }
                                                    </style>
                                                  </div>
                                                </div>

                                                <div class="form-group">
                                                    <div class="col-md-12">
                                                     <label class="control-label"><span class="camposNecesarios"><strong>*</strong></span>Valoración.</label>
                                                     <textarea type="text" class="form-control" id="valoracion" name="valoracion" style="height: 110px;" required></textarea>
                                                     <style type="text/css">
                                                     textarea {
                                                      max-width: 100%; 
                                                      max-height: 100%;
                                                    }
                                                    </style>
                                                    </div>
                                                  </div>

                                              </div>

                                              <div class="col-md-6">
                                                <div class="panel panel-default">
                                                       <div class="panel-heading ">
                                                         <h3 class="panel-title">Signos vitales</h3>
                                                       </div>
                                                             <div class="panel-body">
                                                                  <div class="col-md-12"> 
                                                                    <div class="col-md-4">

                                                                        <div class="form-group">
                                                                          <div class="col-md-12">
                                                                           <label class="control-label"><span class="camposNecesarios"><strong>*</strong></span>Peso (kg).</label>
                                                                           <input type="number" class="form-control" id="peso" >
                                                                          </div>
                                                                        </div>
                                                                     </div>

                                                                     <div class="col-md-4">
                                                                      <div class="form-group">
                                                                        <div class="col-md-12">
                                                                         <label class="control-label"><span class="camposNecesarios">*</span>Altura (cm).</label>
                                                                         <input type="number" class="form-control" id="altura" >
                                                                        </div>
                                                                      </div>
                                                                    </div>

                                                                    <div class="col-md-4">   
                                                                      <div class="form-group">
                                                                        <div class="col-md-12">
                                                                         <label class="control-label">IMC</label>
                                                                         <input type="number" class="form-control" id="masa_corporal" disabled>
                                                                         <h3 class="label label-info" id="clasificacion"></h3>
                                                                        </div>
                                                                      </div>
                                                                    </div>

                                                                  </div>
                                                                <div class="col-md-12"> 
                                                                
                                                                     <div class="col-md-4">    
                                                                        <div class="form-group">
                                                                          <div class="col-md-12">
                                                                           <label class="control-label">Temperatura (*C).</label>
                                                                           <input type="number" class="form-control" id="temperatura">
                                                                         </div>
                                                                       </div>
                                                                     </div>

                                                                     <div class="col-md-4">
                                                                        <div class="form-group">
                                                                          <div class="col-md-12">
                                                                           <label class="control-label">F. cardiaca(lat/min).</label>
                                                                           <input  class="form-control" id="cardiaca">
                                                                          </div>
                                                                        </div>
                                                                     </div>

                                                                     <div class="col-md-4"> 
                                                                        <div class="form-group">
                                                                          <div class="col-md-12">
                                                                           <label class="control-label">Pres. arterial (mmHg).</label>
                                                                           <input  class="form-control" id="arterial">
                                                                          </div>
                                                                        </div>
                                                                      </div>

                                                                </div>      

                                                                <div class="col-md-12">

                                                                      <div class="col-md-4">
                                                                          <div class="form-group">
                                                                            <div class="col-md-12">
                                                                             <label class="control-label">F. resp (resp/min).</label>
                                                                             <input  class="form-control" id="respira">
                                                                            </div>
                                                                          </div>
                                                                      </div>

                                                                      <div class="col-md-4"> 
                                                                          <div class="form-group">
                                                                            <div class="col-md-12">
                                                                             <label class="control-label">Escala de dolor (1-10).</label>
                                                                             <input type="number" class="form-control" id="dolor" max="10" min="1">
                                                                            </div>
                                                                          </div>
                                                                       </div>

                                                                       <div class="col-md-4">
                                                                          <div class="form-group">
                                                                            <div class="col-md-12">
                                                                             <label class="control-label">Glucosa (mg/dL).</label>
                                                                             <input  class="form-control" id="glucosa">
                                                                            </div>
                                                                          </div>
                                                                       </div>
                                                                </div> 

                                                            </div>
                                                        </div>
                                                  
                                              </div>
                                            </div>

                                            <div class="row">

                                              <div class="col-md-6">
                                                

                                                <div class="panel panel-default">
                                                  <div class="panel-heading">
                                                    <span class="camposNecesarios"><strong>*</strong></span>
                                                    Diagnóstico
                                                    

                                                    <!--<div class="row">
                                                      <div class="col-md-7">
                                                        <h6>
                                                        Indique el tipo de formulario para generar el diagnóstico:
                                                        </h6> 
                                                      </div>

                                                      <div class="col-md-5">
                                                        <label class="radio-inline">
                                                        <input type="radio" name="optradio" value='1' checked="checked">Abierto
                                                      </label>

                                                      <label class="radio-inline">
                                                        <input type="radio" name="optradio" value='2'>Cerrado
                                                      </label>
                                                      </div>


                                                    </div>-->
                                                      
                                                      
                                                      <a disabled>
                                                      <h6 id="generar-diagnostico" name="generar-diagnostico">
                                                        <u>Generar Diagnóstico</u>
                                                      </h6>
                                                    </a>
                                                  </div>
                                                  <div class="panel-body">

                                                    <div class="form-group">
                                                      <div class="col-sm-12">
                                                        <textarea type="text" class="form-control" id="indicacionesDeLosdiagnosticos" name="indicacionesDeLosdiagnosticos" required style="height: 180px;"></textarea>
                                                        <style type="text/css">
                                                        #text2{
                                                          max-width: 100%; 
                                                          max-height: 100%;
                                                        }
                                                        </style>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div> 

                                                <div class="panel panel-default">
                                                  <div class="panel-heading">

                                                    <span class="camposNecesarios"><strong>*</strong></span>
                                                    Plan de tratamiento
                                                    

                                                    <!--<div class="row">
                                                      <div class="col-md-7">
                                                        <h6>
                                                        Indique el tipo de formulario para generar el plan de tratamiento:
                                                        </h6> 
                                                      </div>

                                                      <div class="col-md-5">
                                                        <label class="radio-inline">
                                                        <input type="radio" name="optradio" value='1' checked="checked">Abierto
                                                      </label>

                                                      <label class="radio-inline">
                                                        <input type="radio" name="optradio" value='2'>Cerrado
                                                      </label>
                                                      </div>


                                                    </div>-->
                                                      
                                                      
                                                      <a disabled>
                                                      <h6 id="generar-tratamiento" name="generar-tratamiento">
                                                        <u>Generar Tratamiento</u>
                                                      </h6>
                                                    </a>




                                                  </div>
                                                  <div class="panel-body">

                                                    <div class="form-group">
                                                      <div class="col-sm-12">
                                                        <textarea type="text" class="form-control" id="indicaciones_gral" name="indicaciones_gral" required style="height: 180px;"></textarea>
                                                        <style type="text/css">
                                                        #text2{
                                                          max-width: 100%; 
                                                          max-height: 100%;
                                                        }
                                                        </style>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div> 

                                                
                                              </div>
                                              <div class="col-md-6">
                                                <div class="row">
                                                  <div class="col-md-12">
                                                    <div class="panel panel-default ">
                                                      <div class="panel-heading">
                                                        <h3 class="panel-title"> Exploración física <span class="badge" id="numFisSeg"></span></h3>
                                                      </div>
                                                      <div class="panel-body">
                                                   <br>
                                                   <div class="col-md-4 col-md-offset-4">
                                                     <p class="bg-success">Click en la imagen para agregar observación</p>
                                                     <img src="<?php echo base_url('assets/img/1.png');?>" id="frontal" class="img-responsive">
                                                     <style>
                                                     #frontal{
                                                      background-size: contain;
                                                      background-repeat: no-repeat;
                                                    }
                                                    </style>

                                                    <script>
                                                    var x;
                                                    var y;
                                                    $(document).ready(function() {
                                                      $('#frontal').click(function() {
                                                       $('#exploracionfisicaFrontal').modal('show');   
                                                     });
                                                    });
                                                    </script>
                                                  </div>
                                                  <div class="col-md-12">

                                                  <div class="panel panel-default">

                                                    <div class="panel-body">

                                                      <div class="table-responsive" style="height: 207px;">
                                                        <table class="table table-striped">
                                                          <thead>
                                                            <th>Región</th>
                                                            <th>Nombre de la zona</th>
                                                            <th>Observación</th>
                                                            <center><th>Accion</th></center>
                                                          </thead>
                                                          <tbody id="tablaFisAnte">

                                                          </tbody>
                                                        </table>
                                                      </div>

                                                    </div>
                                                  </div>
                                                </div>
                                                  </div>

                                                </div>

                                              </div>

                                                  
                                              </div>
                                              </div>
                                            </div>

                                            <div class="form-group">
                                                  <div class="col-sm-12">
                                                   <label class="control-label">Otras observaciones.</label>
                                                   <textarea type="text" class="form-control" id="nota_GRAL" name="nota_GRAL" style="height: 70px;" ></textarea>
                                                   <style type="text/css">
                                                   #text3{
                                                    max-width: 100%; 
                                                    height: 150px;
                                                  }
                                                  </style>
                                                </div>
                                            </div>

                      <center>
                        <div class="form-group">
                          <div class="col-sm-12">
                           <input type="submit" id="CrearConsulta" class="btn btn-success btn-lg" value="Terminar consulta">
                         </div>
                       </div>
                      </center>
                      </form>
                      </div>

                      </div><!--  FIN DE NUEVA CONSULTA DE ESTE PACIENTE  -->

                  </div>
                  <div role="tabpanel" class="tab-pane" id="Estudios">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="col-sm-12">
                                <div class="panel panel-default">
                                  <div class="panel-body">
                                        <ul class="nav nav-tabs" role="tablist">
                                            <li role="presentation" class="active"><a href="#EstudioLab" aria-controls="EstudioLab" role="tab" data-toggle="tab">Estudios de Laboratorio</a></li>
                                            <li role="presentation"><a href="#EstudioGab" aria-controls="EstudioGab" role="tab" data-toggle="tab">Estudios de Gabinete</a></li>
                                        </ul>
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane active" id="EstudioLab">
                                                <div class="row">

                                                  <div class="col-md-6">
                                                    <br>
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Areas de estudio</label>
                                                        <select name="areas" id="areas" class="form-control"></select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Estudios de laboratorio</label>
                                                        <select multiple name="estudios" id="estudiosL" class="form-control" size="25"></select>
                                                    </div>
                                                  </div>

                                                    <div class="col-md-6">
                                                      <br>
                                                      <br>
                                                    <div class="panel panel-default">
                                                      <div class="panel-body">

                                                            <div>
                                                                <div class="form-group">
                                                                    <label for="exampleInputPassword1">Estudios de Laboratorio para Archivar <small>(Terminar consulta para guardar)</small></label>
                                                                    <textarea class="form-control" rows="50" id="estudiosArchL"></textarea>
                                                                </div>
                                                            </div>
                                                      </div>
                                                    </div>
                                                  </div>

                                                  
                                                    
                                                </div>
                                            </div>
                                            <div role="tabpanel" class="tab-pane" id="EstudioGab">
                                                 <div class="row">

                                                    <div class="col-md-6">
                                                      <br>
                                                    <div class="form-group">
                                                        <label for="exampleInputPassword1">Estudios de Gabinete</label>
                                                        <select multiple name="estudios" id="estudiosG" class="form-control" size="25"></select>
                                                    </div>
                                                  </div>
                                                  <div class="col-md-6">
                                                    <br>
                                                    <br>
                                                    <div class="panel panel-default">
                                                      <div class="panel-body">

                                                            <div>
                                                                <div class="form-group">
                                                                    <label for="exampleInputPassword1">Estudios de Gabinete para Archivar <small>(Terminar consulta para guardar)</small></label>
                                                                    <textarea class="form-control" rows="50" id="estudiosArchG"></textarea>
                                                                </div>
                                                            </div>
                                                      </div>
                                                    </div>
                                                  </div>

                                                </div>
                                            </div>
                                            <script>
                                                        window.onload = function()
                                                        {
                                                            buscarAreasLaboratorio();
                                                            estudioDeGabinete();
                                                        };
    
                                                        function buscarAreasLaboratorio()
                                                        {
                                                            $.ajax({
                                                                   type: 'ajax',
                                                                   method: 'get',
                                                                   async: false,
                                                                   url: '<?php echo base_url() ?>administrador/Laboratorio/getAreasEstudio',
                                                                   dataType: 'json',
                                                                   success: function(data){
                                                                        //alert(data);
                                                                        if(data==false){

                                                                            alert('No hay datos!');


                                                                        }
                                                                        else
                                                                        {
                                                                            for (i = 0; i < data.length; i++)
                                                                            { 
                                                                                 $('#areas').append( '<option value="'+data[i].id_area_estudio_laboratorio+'">'+data[i].area_estudio+'</option>' );
                                                                            }
                                                                            var optSele = ""+$('#areas option:selected').val();
                                                                            estudioDeLaboratorio(optSele);
                                                                        }


                                                                    },
                                                                    error: function(){
                                                                        alert('Error al conectar con la base de datos!');
                                                                    }
                                                                });
                                                            }
                                                        
                                                            var id_areas_lab;
                                                            /////Evento para obtener el ID de las Areas de Estudios de Laboratorio
                                                            $("#areas").change(function(){

                                                                id_areas_lab = ""+$(this).val();
                                                                //var area1 = $("#areas option[value='"+id_areas_lab+"']").text();
                                                                $('#estudiosL option').remove();
                                                                estudioDeLaboratorio(id_areas_lab);
                                                            });
                                                        
                                                            function estudioDeLaboratorio(id_areas_lab)
                                                            {
                                                                $.ajax({
                                                                       type: 'ajax',
                                                                       method: 'get',
                                                                       async: false,
                                                                       url: '<?php echo base_url() ?>administrador/Laboratorio/getEstudiosDeLaboratorio',
                                                                       data: {id_area_estudio_laboratorio:id_areas_lab},
                                                                       dataType: 'json',
                                                                       success: function(data){
                                                                            
                                                                            if(data==false){

                                                                                alert('No hay datos!');


                                                                            }
                                                                            else
                                                                            {
                                                                               for (i = 0; i < data.length; i++)
                                                                                { 
                                                                                     $('#estudiosL').append( '<option value="'+data[i].id_estudios_laboratorio+'" title="'+data[i].estudios_laboratorio+'">'+data[i].estudios_laboratorio+'</option>' );
                                                                                } 
                                                                            }


                                                                        },
                                                                        error: function(error){
                                                                            alert('Error al conectar con la base de datos!');
                                                                        }
                                                                    });
                                                                }
                                                                function estudioDeGabinete()
                                                                {
                                                                    $.ajax({
                                                                           type: 'ajax',
                                                                           method: 'get',
                                                                           async: false,
                                                                           url: '<?php echo base_url() ?>administrador/Gabinete/getEstudiosDeGabinete',
                                                                           dataType: 'json',
                                                                           success: function(data){
                                                                                //alert(data);
                                                                                if(data==false){

                                                                                    alert('No hay datos!');


                                                                                }
                                                                                else
                                                                                {
                                                                                    console.log(data);
                                                                                    for (i = 0; i < data.length; i++)
                                                                                    { 
                                                                                        $('#estudiosG').append( '<option value="'+data[i].id_estudios_de_gabinete+'" title="'+data[i].estudios_de_gabinete+'">'+data[i].estudios_de_gabinete+'</option>' );
                                                                                    }
                                                                                }


                                                                            },
                                                                            error: function(error){
                                                                                alert('Error al conectar con la base de datos!');
                                                                            }
                                                                        });
                                                                    }
                                                                var estudiosArchL="";
                                                                var estudiosArchG="";
                                                                $("#estudiosL").change(function(){
                                                                    
                                                                    estudiosArchL = $('#estudiosArchL').val();
                                                                    var estudiosLl = $("#estudiosL option[value='"+$('#estudiosL option:selected').val()+"']").text();
                                                                    
                                                                    estudiosArchL += "#"+estudiosLl+"\n     * Añada una descripción: \n\n";
                                                                    $('#estudiosArchL').val(estudiosArchL);
                                                                });
                                                
                                                                $("#estudiosG").change(function(){
                                                                    estudiosArchG = $('#estudiosArchG').val();
                                                                    var estudiosGg = $("#estudiosG option[value='"+$('#estudiosG option:selected').val()+"']").text();
                                                                    
                                                                    estudiosArchG += "#"+estudiosGg+"\n     *Añada una descripción: \n\n";
                                                                    $('#estudiosArchG').val(estudiosArchG);
                                                                });
                                                    </script>
                                        </div>
                                  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                  </div>

                  <div role="tabpanel" class="tab-pane" id="RegistroDeConsultas">
                    <div class="panel panel-default">

                      <div class="panel-body"id="panelConsultaPrincipal">
                      </div>
                      <div class="alert alert-info alert-dismissable sinConsultas" style="display: none;">
                      </div>
                    </div>

                  </div>
                  


                </div>


            
            
          </div>

<!-- inicio pestaña de exporacion fisica -->
<!--<div role="tabpanel" class="tab-pane" id="profile">
  <div class="col-md-12">
   <br>
   <div class="col-md-6">
     <p class="bg-success">Click en la imagen para agregar observación</p>
     <img src="<?php echo base_url('assets/img/1.png');?>" id="frontal" class="img-responsive">
     <style>
     #frontal{
      background-size: contain;
      background-repeat: no-repeat;
    }
    </style>

    <script>
    var x;
    var y;
    $(document).ready(function() {
      $('#frontal').click(function() {
       $('#exploracionfisicaFrontal').modal('show');   
     });
    });
    </script>
  </div>


  <div class="panel panel-default col-md-6">

    <div class="panel-body">

      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
            <th>Región</th>
            <th>Nombre de la zona</th>
            <th>Observación</th>
            <center><th>Accion</th></center>
          </thead>
          <tbody id="tablaFisAnte">

          </tbody>
        </table>
      </div>

    </div>
  </div>
</div>

</div>-->
<!-- fin pestaña de exporacion fisica -->

<!-- Inicia pestaña de intervenciones -->
          <div role="tabpanel" class="tab-pane" id="messages">
            <div class="panel panel-default">
              <div class="panel-body">
                 <hr>
                <center><h4>Costo de consulta: $<strong><?php echo $medico_logueado[0]->honorario?></strong>.00</h4></center>
                <hr>

                <div class="panel panel-default" id="panelCostoDeIntervenciones">
                  <div class="panel-heading">
                    <h3 class="panel-title">Seleccionar intervención</h3>
                  </div>
                  <div class="panel-body">


                    <div class="col-md-12">
                      <div class="col-md-8">
                        <div class="form-group">
                          <label for="estado" class="col-sm-4 control-label">Intervenciones</label>
                          <div class="col-sm-8">
                           <select class="form-control" name="intervencion" id="selectIntervencion" required>
                            <option></option>
                            <?php foreach($getIntervenciones as $value) { ?>
                            <option value="<?php echo $value->id_intervension; ?>"><?php echo $value->intervension; ?></option>
                            <?php } ?>
                          </select>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="estado" class="col-sm-4 control-label">Descripción de la intervención</label>
                        <div class="col-sm-8">
                         <input id="sugerencia" type="text" class="form-control" disabled>
                       </div>
                     </div>
                     <div class="form-group">
                      <label for="estado" class="col-sm-4 control-label">Costo</label>
                      <div class="col-sm-8">
                       <input id="costo" type="text" class="form-control" name="" disabled>
                     </div>
                   </div>
                 </div>
                 <div class="col-md-2">
                  <button type="button" class="btn btn-success" id="agregarIntervencion" ><span class="glyphicon glyphicon-plus" ></span>Agregar</button>
                </div>
                    </div>



                  </div>
                </div>
              <div class="col-md-offset-8">
                      <button type="button" class="btn btn-primary  btn-block" id="finalizarCargosDeLaConsulta" ><span class="glyphicon glyphicon-transfer" ></span>  Finalizar cargos y abonar a cuenta</button>
              </div>
              <br>

              <div class="alert alert-success" role="alert" style="display: none;">
              </div>
              <div class="alert alert-warning" role="alert" style="display: none;">
              </div>



              <div class="panel panel-default">
                <div class="panel-heading">
                  <h3 class="panel-title">Intervenciones agregadas</h3>
                </div>
                <div class="panel-body">
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <th>Intervensión</th>
                        <th>Descripción</th>
                        <th>Costo</th>
                        <center><th class="quitarAccion">Accion</th></center>
                      </thead>
                      <tbody id="tablaIntervenciones">

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

          </div>
          </div>

          </div>
<!-- finaliza pestaña de intervenciones -->
</div>


</div>


</div>

</form>   
</div>
</div>


<!-- -->


<div id="exploracionfisicaFrontal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><span class="glyphicon glyphicon-menu-down"></span> Describa la region del cuerpo</h4>
      </div>
      <div class="modal-body">
          <form class="form-horizontal">
              <div class="form-group">
                <label for="" class="col-sm-2 control-label">Región</label>
                <div class="col-sm-10">
                  <select class="form-control" name="region" id="region" required>
                    <option></option>
                    <?php foreach($getRegionesDelCuerpo as $value) { ?>
                    <option value="<?php echo $value->id_region; ?>"><?php echo $value->nombre_de_la_region; ?></option>
                    <?php } ?>
                </select>


                </div>
              </div>
              <div class="form-group">
                <label for="" class="col-sm-2 control-label">Nombre de la zona</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="nombre_zona" placeholder="Frente, Ojos, Boca, Abdomen, etc." required>
                </div>
              </div>
              <div class="form-group">
                   <label for="" class="col-sm-2 control-label">Descripción</label>
                   <div class="col-sm-10">
                      <textarea type="text" class="form-control" name="descripsionfisicaSeg1" id="descripsionRegion" placeholder="texto" required></textarea>
                    </div>
                    
                    <style type="text/css">
                    #descripsionRegion{
                    max-width: 100%; 
                    height: 150px;
                    }
                    </style>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <div class="col-sm-8">
                 
                </div> 
                <div class="col-sm-4">
                   <button type="button" class=" btn btn-default" data-dismiss="modal">Cancelar</button>
                  <button type="submit" id="agregarExploFisSegAnterior" class="btn btn-success">Agregar</button>
                </div>
              </div>
            </div>
          
      </div>
      <div class="modal-footer">
        
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- INICIO CODIGOS  -->
<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Eliminar</h4>
      </div>
      <div class="modal-body">
          Estas seguro de eliminar el registro?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
        <button type="button" id="btnDelete" class="btn btn-danger">Si</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="confirmacionDeGuardarConsultaModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header modal-header-danger">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Confirmación</h4>
      </div>
      <div class="modal-body">
          Estas seguro que deceas guardar los datos requisitados hasta el momento?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
        <button type="button" id="btnConfirmacion" class="btn btn-danger">Si, deceo terminar la consulta</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



<!--- -------FORMULARIO ABIERTO DE DIAGNÓSTICO------------- -->


<div id="ModalCrearDiagnosticoConFormularioAbierto" class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" style="overflow-y: scroll;"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header modal-header-success"> 
       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
       <h4 class="modal-tittle">Generar Diagnóstico</h4> 
     </div> 
     <div class="modal-body"> 
      <div class="panel panel-default">
        <div class="panel-body">
          <!-- ----------------------------------------- -->
          <div class="col-md-7">
            <div class="panel panel-default">
              <div class="panel-body">
                <!--    -->
                <div class="panel-body">

                  <form class="form-horizontal" id="formularioAbiertoDeDiagnosticosModalAbierto">
                    <div class="form-group">
                      <div class="col-sm-12">
                        <label class="control-label">Diagnóstico</label>
                        <div class="input-group   input-append">
                          <input type="text" class="form-control input-append"  type="text" name="diagnostico-abierto" id="diagnostico-abierto"   required>
                          <span class="input-group-addon add-on" id="BuscaDiagnosticoAbierto">
                            <i class="glyphicon glyphicon-search">
                            </i>
                          </span>
                        </div>


                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-sm-12">
                       <label class="control-label">Observación</label>
                       <textarea type="text" class="form-control" name="observaciones_grales_diagnostico-abierto" id="observaciones_grales_diagnostico-abierto" style="height: 158px;" required></textarea>
                       <style type="text/css">
                       textarea {
                        max-width: 100%; 
                        max-height: 100%;
                      }
                      </style>
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="col-md-12">
                      <center><button type="submit" id="btn-agregarDiagnosticoParaAlmacenar-abierto" name="btn-agregarDiagnosticoParaAlmacenar-abierto" class="btn btn-success btn-lg">Agregar diagnóstico a la lista <i class="glyphicon glyphicon-share-alt"></i></button></center>
                    </div>
                  </div>
                </form>
              </div>
              <!--    -->
            </div>
          </div>
        </div>
        <!-- ----------------------------------------- -->
        <div class="col-md-5">
          <div class="panel panel-default" style="height: 400px;">
            <div class="panel-body">
              <form class="form-horizontal" action="">
                <div class="form-group">
                  <div class="col-md-12" >
                    <div class="form-group">
                      <center>
                        <label class="control-label">Diagnósticos Formulados</label>
                      </center><!--style="height: 460px;"-->
                    </div>


                    <div class="alert alert-info alert-dismissable" style="display: none;">
                    </div>


                    <table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-general-diagnosticos-formulados-abierto">
                      <thead>
                        <tr>
                          <td><center>Diagnóstico</center></td>
                          <td><center>Acciones</center></td>
                        </tr>
                      </thead>
                      <tbody id="diagnosticosFormuladoHastaElMomento-abierto">

                      </tbody>
                    </table>

                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!-- ----------------------------------------- -->
      </div>
    </div>
  </div>
  <div class="modal-footer">
    <div class="col-md-12">
      <button type="button" id="btnFinalizarDiagnotico-abierto" class="btn btn-primary btn-lg">Finalizar agregado de Diagnósticos</button>
    </div>
  </div>
</div>
</div>
</div>

<!-- ------------------------------------------------------ -->




<script type="text/javascript">
    
//window.onload = cargarValores();
var id_doctor="<?php echo $medico_logueado[0]->id_medico;?>";
    
    
var objetoTemporalExploracionFisicaSegAnt =[]; 

$( "#agregarExploFisSegAnterior" ).click(function(){
        
        
        var region=$("#region option:selected").text();

        var id_region= $("#region").val();


        var nombre_zona = $( "#nombre_zona" ).val(); 
        var descripsionRegion = $( "#descripsionRegion" ).val();

       
        if(region.trim()!=""&&nombre_zona.trim()!=""&&descripsionRegion.trim()!=""){
           //alert("región: "+region+" id_region: "+id_region+" nombre_zona: "+nombre_zona+" descripción: "+descripsionRegion);
           var region_observacion={id_region:id_region,region:region,nombre_zona:nombre_zona, descripsionRegion:descripsionRegion};
          objetoTemporalExploracionFisicaSegAnt.push(region_observacion);

          //console.log(objetoTemporalExploracionFisicaSegAnt.length);
        $( "#nombre_zona" ).val('');
        $( "#descripsionRegion" ).val('');

        $('#exploracionfisicaFrontal').modal('hide');

        actualizarTabla1();
        return false;
        }
        
    });    
    
    
 
    
function actualizarTabla1()
{
    var html = '';
    for(var i=0; i<objetoTemporalExploracionFisicaSegAnt.length; i++){
    html +='<tr>'+
    '<td>'+objetoTemporalExploracionFisicaSegAnt[i].region+'</td>'+
    '<td>'+objetoTemporalExploracionFisicaSegAnt[i].nombre_zona+'</td>'+
    '<td>'+objetoTemporalExploracionFisicaSegAnt[i].descripsionRegion+'</td>'+
    '<td>'+
    '<center>'+
        '<a href="javascript:;" data="'+objetoTemporalExploracionFisicaSegAnt[i].nombre_zona+'"  class="btn btn-danger btn-xs item-id-delete1" title="Eliminar"><i class="glyphicon glyphicon-remove"></i></a>'+
    '<center>'+                                                                                
    '</td>'+
    '</tr>';
    }
    $('#tablaFisAnte').html(html);
    
    
    

    if(objetoTemporalExploracionFisicaSegAnt.length>0)
    {
        $('#numFisSeg').text(objetoTemporalExploracionFisicaSegAnt.length);
    }else
    {
       $('#numFisSeg').text(''); 
    }
    
} 
    
    
 <!--Eliminar intervension-->
    
    $('#tablaFisAnte').on('click', '.item-id-delete1', function(){
      var id_intervension = $(this).attr('data');
        
      $('#deleteModal').modal('show');
      //prevent previous handler - unbind()
      $('#btnDelete').unbind().click(function(){
        
          var id;
        for(var i = 0;i < objetoTemporalExploracionFisicaSegAnt.length; i++ )
        {
            id = objetoTemporalExploracionFisicaSegAnt[i].nombre_zona;
            if(id_intervension == id)
            {
                objetoTemporalExploracionFisicaSegAnt.splice(i, 1);
                actualizarTabla1();
                $('#deleteModal').modal('hide');
              //mostrarIntervensiones();
            }
        }
          
      });
    });   
    


var peso = 0;
var altura = 0;
var imc = 0;
var clasificacion = '';
$('#peso').change(function() {
    peso = $('#peso').val();
    
    imc = (peso/(altura*altura))*10000;
    $('#masa_corporal').val(imc);
    $('#clasificacion').text(clasificacionIMC(imc));
});

$('#altura').change(function() {
    altura = $('#altura').val();
    
    imc = (peso/(altura*altura))*10000;
    $('#masa_corporal').val(imc);
    $('#clasificacion').text(clasificacionIMC(imc));
});
    
function clasificacionIMC(im)
{
    if(im==Infinity)
    {
        return 'calculando...';
    }
    
    if(im<16)
    {
        return 'Infrapeso: Delgadez Severa';
    }
    if(im>=16 && im< 16.9)
    {
        return 'Infrapeso: Delgadez moderada';
    }
    if(im>=17 && im< 18.50)
    {
        return 'Infrapeso: Delgadez aceptable';
    }
    if(im>=18.5 && im< 25)
    {
        return 'Peso Normal';
    }
    if(im>=25 && im< 30)
    {
        return 'Sobrepeso';
    }
    if(im>=30 && im< 35)
    {
        return 'Obeso: Tipo I';
    }
    if(im>=35 && im< 40)
    {
        return 'Obeso: Tipo II';
    }
    if(im>40)
    {
        return 'Obeso: Tipo III';
    }else{
        return 'Calculando...';
    }
}    
    
function cargarValores()
    {
        var id_intervension = $( "#selectIntervencion option:selected" ).val();
        $.ajax({
                type: 'ajax',
                method: 'get',
                async: false,
                url: '<?php echo base_url() ?>administrador/intervenciones/getIntervensionID',
                data: {id_intervension:id_intervension},
                dataType: 'json',
                success: function(data)
                {
                    if(data.length>0){
                        var sugerencia= '';
                        var costo= '';
                        var i;
                        for(i=0; i<data.length; i++){
                            sugerencia = data[i].sugerencia;
                            costo = data[i].costo;
                            
                        }
                        $('#sugerencia').val(sugerencia);
                        $('#costo').val("$"+costo+".00");
                    }
                    else
                    {
                        var html = '';
                        $('#sugerencia').val(html);
                        $('#costo').val(html); 
                    }

                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
    }
    
    
    
    
    
    
    
    $( "#selectIntervencion" ).change(function() {
      cargarValores();
    });

    var objetoTemporalIntervenciones =[];
    var idtemporal;
    $( "#agregarIntervencion" ).click(function(){
        var id_intervension = $( "#selectIntervencion option:selected" ).val();
        var intervension = $( "#selectIntervencion option:selected" ).text();
        var sugerencia = $('#sugerencia').val();
        var costo = $('#costo').val(); 
        
        if(id_intervension.trim()!=""){
           for(var i = 0;i < objetoTemporalIntervenciones.length; i++ )
        {
            idtemporal = objetoTemporalIntervenciones[i].id_intervension;
        }
        
        if(idtemporal!=id_intervension)
        {
            objetoTemporalIntervenciones.push({id_intervension:id_intervension, intervension:intervension, sugerencia:sugerencia,costo:costo});
            $('.alert-success').html('Agregado.').fadeIn().delay(2000).fadeOut('slow');
            actualizarTabla();
        }else
        {
            $('.alert-warning').html('Ya agrego esta intervención.').fadeIn().delay(2000).fadeOut('slow');
        }
        }
       
    });
    
function actualizarTabla()
    {
        var html = '';
        for(var i=0; i<objetoTemporalIntervenciones.length; i++){
        html +='<tr>'+
        '<td>'+objetoTemporalIntervenciones[i].intervension+'</td>'+
        '<td>'+objetoTemporalIntervenciones[i].sugerencia+'</td>'+
        '<td>'+objetoTemporalIntervenciones[i].costo+'</td>';
        if(!estadoDeLaTablaCargos){
          html+='<td>'+
        '<center>'+
            '<a href="javascript:;" data="'+objetoTemporalIntervenciones[i].id_intervension+'"  class="btn btn-danger btn-xs item-id-delete" title="Eliminar"><i class="glyphicon glyphicon-remove"></i></a>'+
        '<center>'+                                                                                
        '</td></tr>';
        }
        else{
        html+='</tr>';
      }
        
        }

        if(objetoTemporalIntervenciones.length>0)
        {
            $('#numInter').text(objetoTemporalIntervenciones.length);
        }else
        {
           $('#numInter').text(''); 
        }
        $('#tablaIntervenciones').html(html);
    }
    
    <!--Eliminar intervension-->
    
    $('#tablaIntervenciones').on('click', '.item-id-delete', function(){
      var id_intervension = $(this).attr('data');
        
      $('#deleteModal').modal('show');
      //prevent previous handler - unbind()
      $('#btnDelete').unbind().click(function(){
        
          var id;
        for(var i = 0;i < objetoTemporalIntervenciones.length; i++ )
        {
            id = objetoTemporalIntervenciones[i].id_intervension;
            if(id_intervension == id)
            {
                objetoTemporalIntervenciones.splice(i, 1);
                actualizarTabla();
                $('#deleteModal').modal('hide');
              //mostrarIntervensiones();
            }
        }
          
      });
    });

</script>
<!--        FIN CODIGO            -->


<script type="text/javascript">

//------------------------------------------------------
var estadoDeLaTablaCargos=false;
$("#finalizarCargosDeLaConsulta").click(function(){
var precioConsulta = parseInt("<?php echo $medico_logueado[0]->honorario?>"); 
        //objetoTemporalIntervenciones[i].costo
        var intervenciones = 0;
        if (objetoTemporalIntervenciones.length>0){
            for (i = 0; i < objetoTemporalIntervenciones.length; i++) {
              var costoTempo=objetoTemporalIntervenciones[i].costo;
              var constoConvertido=costoTempo.replace("$", "");
              intervenciones = parseInt(intervenciones) + parseInt(constoConvertido);
              //alert(intervenciones);
            } 
        }
        var total = intervenciones + precioConsulta;

        if(total==600){
          swal({
            title: 'Deceas sólo añadir el precio de la consulta para realizar este cargo al paciente??',
            text: "$"+total+".00",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'De acuerdo'
          }).then(function () {

            insertarCostodeConsulta(total);

            
         
          $("#panelCostoDeIntervenciones").css("display", "none");
          $("#finalizarCargosDeLaConsulta").css("display", "none");
          estadoDeLaTablaCargos=true;
          actualizarTabla();
          $( "th" ).remove( ".quitarAccion" );
        }).catch(swal.noop);
          
          

        }
        else{
          swal({
            title: 'Cargo total',
            text: "$"+total+".00",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'De acuerdo'
          }).then(function () {
            insertarCostodeConsulta(total);

          
          $("#panelCostoDeIntervenciones").css("display", "none");
          $("#finalizarCargosDeLaConsulta").css("display", "none");
          estadoDeLaTablaCargos=true;
          actualizarTabla();
          $( "th" ).remove( ".quitarAccion" );
        }).catch(swal.noop);

          
        }
      
      
    });
//------------------------------------------------------
   

 $("FormularioConsulta").keypress(function(e) {
        if (e.which == 13) {
            return false;
        }
    });

$('#TapRegistroDeConsultas').click(function(){
  getConsultasDelPaciente();
});


$('#ImprimirReceta').click(function(){


  var datos=$('#FormularioConsulta');

  //alert("Preciono el boton: 1ra vez "+$('#FormularioConsulta').serialize());

  //if (arregloDemedicamentosSeleccionadosDelTratamiento.length>0) {


    var id_medico="<?php echo $medico_logueado[0]->id_medico;?>";
    datos.append('<input name="id_medico" value="'+id_medico+'" type=hidden>');

    var id_paciente="<?php echo $paciente[0]->curp;?>";
    datos.append('<input name="id_paciente" value="'+id_paciente+'" type=hidden>');

    datos.append('<input name="id_consulta" value="'+id_consulta+'" type=hidden>');
    //alert("Preciono el boton: 2da vez con tratamiento"+$('#FormularioConsulta').serialize());
    //return true;
  //}else{
    //alert("Necesita formular previamente un tratamiento!");
    //return false;
  //}
  
});


//------------------------------------------------------------
function obtenerTratamientosDeConsulta(id_consulta){
var tratamiento='';
$.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/Formatos/adjuntarTratamientos1/'+id_consulta,
               dataType: 'json',
               success: function(data){
                  //alert(data);
                  tratamiento= data;
                   
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
return tratamiento;


}

function obtenerDiagnosticosDeConsulta(id_consulta){
var diagnostico='';
      $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/Formatos/adjuntarDiagnosticos1/'+id_consulta,
               dataType: 'json',
               success: function(data){
                //alert(data);
                  diagnostico= data;
                   
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
      return diagnostico;

        }

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
function obtenerTratamientosDeConsultaAbierta(id_consulta){
var tratamiento="";
$.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/Formatos/adjuntarTratamientosAbiertos1/'+id_consulta,
               dataType: 'json',
               success: function(data){
                  //alert(data);
                  tratamiento= data;
                   
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
return tratamiento;


}

function obtenerDiagnosticosDeConsultaAbierta(id_consulta){
var diagnostico="";
      $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/Formatos/adjuntarDiagnosticosAbiertos1/'+id_consulta,
               dataType: 'json',
               success: function(data){
                  //alert(data);
                  diagnostico=data;
                   
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
      return diagnostico

        }
//------------------------------------------------------------




      function getConsultasDelPaciente(){
        var id_paciente="<?php echo $paciente[0]->curp;?>";
          $.ajax({
                   type: 'ajax',
                   method: 'post',
                   async: false,
                   url: '<?php echo base_url() ?>medico/Consulta/getConsultasDelPaciente',
                   data:{id_paciente:id_paciente},
                   dataType: 'json',
                   success: function(data){
                    var consultasCerradas = data.consultasCerradas;
                    var consultasAbiertas = data.consultasAbiertas; 
                    var arregloDeConsultas=[];

                    for(var i=0;i<consultasCerradas.length;i++){
                      var diagnostico=obtenerDiagnosticosDeConsulta(consultasCerradas[i].id_consulta);
                      var tratamiento=obtenerTratamientosDeConsulta(consultasCerradas[i].id_consulta);
                      //alert(diagnostico +" y "+tratamiento);

                      var consulta={id_consulta:consultasCerradas[i].id_consulta,fecha_consulta:consultasCerradas[i].fecha_consulta,motivo_consulta:consultasCerradas[i].motivo,diagnostico:diagnostico,tratamiento:tratamiento};
                      arregloDeConsultas.push(consulta);
                    }

                    for(var i=0;i<consultasAbiertas.length;i++){
                      var diagnostico=obtenerDiagnosticosDeConsultaAbierta(consultasAbiertas[i].id_consulta);//Te  falta crear las funciones ajax
                      var tratamiento=obtenerTratamientosDeConsultaAbierta(consultasAbiertas[i].id_consulta);
                      //alert(diagnostico +" y "+tratamiento);

                      var consulta={id_consulta:consultasAbiertas[i].id_consulta,fecha_consulta:consultasAbiertas[i].fecha_consulta,motivo_consulta:consultasAbiertas[i].motivo,diagnostico:diagnostico,tratamiento:tratamiento};
                      arregloDeConsultas.push(consulta);
                    }





                    var consultasOrdenadas = arregloDeConsultas.slice(0);
                    consultasOrdenadas.sort(function(a,b) {
                        return  b.id_consulta - a.id_consulta;
                    });

                    


                     var html = '<div class="form-group">'+
                                      '<div class="col-md-12">'+
                                        '<div class="col-md-10">'+
                                        '</div>'+
                                        '<div class="col-md-2">'+
                                        '</div>'+
                                      '</div>'+
                                      
                                      '<div class="col-md-12">'+
                                      '<br>'+
                                        '<div class="table-responsive" id="id_tablaConsultas">'+
                                        '</div>'+
                                      '</div>'+
                                    '</div>';

                            $('#panelConsultaPrincipal').html(html);
                        

                            //$('#panelConsultaPrincipal').html(html);
                        if(consultasOrdenadas.length!=0){


                        

                            html +='<table class="table table-condensed  table-responsive  table-hover  zebra-stripes">'+
                                                '<thead>'+
                                                '<tr>'+
                                                    //'<th>ID_C</th>'+
                                                    '<th><CENTER>FECHA</CENTER></th>'+
                                                    '<th><CENTER>MOTIVOS DE CONSULTA</CENTER></th>'+
                                                    '<th><CENTER>DIAGNÓSTICO</CENTER></th>'+
                                                    '<th><CENTER>TRATAMIENTO</CENTER></th>'+
                                                '</tr>'+
                                                '</thead>'+
                                                    '<tbody>';

                         

                                                    for(var i=0;i<consultasOrdenadas.length;i++){
                                                        var fecha=new Date(consultasOrdenadas[i].fecha_consulta);
                                                        var dia=fecha.getDate();
                                                        var mes=fecha.getMonth()+1;
                                                        var anio=fecha.getFullYear();

                                                        

                                                        html+='<tr><td>'+dia+"/"+mes+"/"+anio+'</td>'+
                                                        '<td>'+consultasOrdenadas[i].motivo_consulta+'</td>'+
                                                        '<td>'+consultasOrdenadas[i].diagnostico+'</td>'+
                                                        '<td>'+consultasOrdenadas[i].tratamiento+'</td>'+
                                                      '</tr>';

                                                    }


                                                html +='</tbody>'+'</table>';
                                                
                                                $('#id_tablaConsultas').html(html);
                                              }
                                              else{
                                                $('.sinConsultas').html('<center>El paciente no cuenta con consultas registradas!</center>').fadeIn().delay(3000).fadeOut('slow');
                                              }
                                              
                       
                    },
                    error: function(){
                        alert('Could not get Data from Database');
                    }
                });

        }

</script>

<link rel="stylesheet"  href="<?php echo base_url('assets/dataTables/css/dataTables.bootstrap.css');?>">       
<script src="<?php echo base_url('assets/dataTables/js/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo base_url('assets/dataTables/js/jquery.dataTableConf.js');?>"></script>
<script src="<?php echo base_url('assets/dataTables/js/dataTables.bootstrap.js');?>"></script>










<script type="text/javascript">

var id_consulta="";
  
    $('#CrearConsulta').click(function(){
        crearConsulta();
        return false;
    });

function insertarCostodeConsulta(total)
{
    var id_medico = '<?php echo $medico_logueado[0]->id_medico;?>';
    var id_paciente = '<?php echo $paciente[0]->curp;?>';
    $.ajax({
        type: 'ajax',
        method: 'post',
        async: false,
        url: '<?php echo base_url() ?>medico/Consulta/GuardarCosto',
        data:{id_medico:id_medico,id_paciente:id_paciente,cargo: total},
        dataType: 'json',
        success: function(response){

        if(response){
                              swal({
                                      title: "Cargo abonado exitosamente!",
                                      type: "success",
                                      timer: 2000,
                                      showConfirmButton: false
                                  }).catch(swal.noop);
        }
        else{
         $('.alert-danger').html('Ocurrio un problema al guardar el cargo!').fadeIn().delay(2000).fadeOut('slow');

        }

        },
        error: function(){
          alert('Could not get Data from Database');
        }
    });
}  

function crearConsulta ()
{

  //var dataString = $('#FormularioConsulta').serialize();

        //alert('Datos serializados: '+dataString);
      
      var motivo=$('#motivo').val();
      var valoracion=$('#valoracion').val();
      var medico="<?php echo $medico_logueado[0]->id_medico;?>";
      var paciente="<?php echo $paciente[0]->curp;?>";

      var nota=$('#nota_GRAL').val();

      var peso=$('#peso').val();
      var altura=$('#altura').val();
      var masa_corporal=$('#masa_corporal').val();
      var temperatura=$('#temperatura').val();
      var cardiaca=$('#cardiaca').val();
      var arterial=$('#arterial').val();
      var respira=$('#respira').val();
      var dolor=$('#dolor').val();
      var glucosa=$('#glucosa').val();

      var diagnosticoGral=$('#indicacionesDeLosdiagnosticos').val();
      var tratamientoGral=$('#indicaciones_gral').val();

      //alert("altura: "+altura+" peso: "+peso);
      if(motivo.trim()!="" && valoracion.trim()!=""&& diagnosticoGral.trim()!=""&& tratamientoGral.trim()!=""&& medico.trim()!=""&&paciente.trim()!=""&&peso.trim()!=""&&altura.trim()!=""&&id_consulta==""){
            //$('#confirmacionDeGuardarConsultaModal').modal('show');

            //$('#btnConfirmacion').unbind().click(function(){
            //$('#confirmacionDeGuardarConsultaModal').modal('hide');

               $.ajax({
                  type: 'ajax',
                 method: 'post',
                 async: false,
                 url: '<?php echo base_url() ?>medico/Consulta/GuardarConsulta',
                 data:{medico:medico, paciente:paciente, motivo:motivo, valoracion:valoracion, nota:nota, peso:peso, altura:altura, masa_corporal:masa_corporal, temperatura:temperatura, cardiaca:cardiaca, arterial:arterial, respira:respira, dolor:dolor, glucosa:glucosa},
                 dataType: 'json',
                 success: function(response){

                 //alert("LA RESPUESTA ES: "+response);
                 //limpiaCampos();
                 id_consulta=response.newIdconsulta;
                 //alert(id_consulta);
                   if(response.success){


                    //--------------------------------------------------------
                    var opcion=$('input:radio[name=optradio]:checked').val();
                    if(opcion==1){
                      insertarDiagnosticoAbierto(response.newIdconsulta);
                    }
                    else{
                      insertarDiagnostico(response.newIdconsulta);
                    }
                    //--------------------------------------------------------

                    var opcion=$('input:radio[name=optradio]:checked').val();
                    if(opcion==1){
                      insertarTratamientoAbierto(response.newIdconsulta);
                      
                    }
                    else{
                      insertarTratamiento(response.newIdconsulta);
                    }

                    //--------------------------------------------------------
                    
                      //insertarTratamiento(response.newIdconsulta);
                      //insertarDiagnostico(response.newIdconsulta);
                      
                      guardarEstudiosLaboratorio(response.newIdconsulta);
                      guardarEstudiosGabinete(response.newIdconsulta);
                      insertarExploracionFisica(response.newIdconsulta);
                      <?php if(!empty($datos_de_la_cita)){ ?>   
                        var id_paciente="<?php echo $paciente[0]->curp;?>";
                        var id_medico="<?php echo $medico_logueado[0]->id_medico;?>";
                        var hora="<?php echo $datos_de_la_cita[0]; ?>";
                        var fecha="<?php echo $datos_de_la_cita[1];?>";
                        cambiarEstatusDeCita(id_paciente,id_medico,hora,fecha);
                      <?php } ?>
                      //insertarCostodeConsulta(total);

                      

                    
                    
                    
                      swal({
                                      title: "Consulta guardada correctamente!",
                                      type: "success",
                                      timer: 2000,
                                      showConfirmButton: false
                                  }
                                  )
                       .catch(swal.noop);
                       $("#CrearConsulta").css("display", "none");
                       $("#tipoFormularioOculta").css("display", "none");
                       
                       $('#ImprimirReceta').show();

                       //location.href = '<?php echo base_url(); ?>medico/Consulta/nuevaConsulta/AACM690226MOCLBR05';
                       //setTimeout(location.reload(), 2000);

                       //location.reload();
                    }
                    else{
                     $('.alert-danger').html('Ocurrio un problema al guardar los datos de la consulta!').fadeIn().delay(2000).fadeOut('slow');
                     
                    }

                  },
                  error: function(){
                      alert('No se ha podido guardar la consulta');
                  }
              });

            

            //return false;
              
            //});
        
        
          return false;
        

      }
      else{

        swal({
                                      title: "Faltan campos necesarios del formulario",
                                      text:"Asegurate de rellenar todos los campos necesarios (*) para Finalizar la consulta!",
                                      type: "warning",
                                      timer: 5000,
                                      showConfirmButton: false
                                  }
                                  )
                       .catch(swal.noop);

      }

    }
//-------------------------------------------------
function cambiarEstatusDeCita(id_paciente,id_medico,hora,fecha){

        $.ajax({
          type: 'ajax',
          method: 'post',
          url: '<?php echo base_url() ?>medico/Consulta/cambiarEstatusDeCita',
          data: {id_paciente:id_paciente,id_medico:id_medico,hora:hora,fecha:fecha},
          async: false,
          dataType: 'json',
          success: function(response){
            //alert(response.success);
            if(response){
              //$('#editModal').modal('hide');
              swal({
                                      title: "La cita actualizo el status a cita atendida!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
              //mostrarCategorias();
            }else{
              alert('Error');
            }
          },
          error: function(){
            alert('Could not add data');
          }
        });
}
//-------------------------------------------------



 function insertarExploracionFisica(id_consulta){
  if(objetoTemporalExploracionFisicaSegAnt.length>0){
    for(var i=0;i<objetoTemporalExploracionFisicaSegAnt.length;i++){
        // objetoTemporalExploracionFisicaSegAnt.push({id_region:id_region,region:region,nombre_zona:nombre_zona, descripsionRegion:descripsionRegion});
          
        var id_consulta=id_consulta;
        var id_region=objetoTemporalExploracionFisicaSegAnt[i].id_region; 
        var nombre_de_la_zona=objetoTemporalExploracionFisicaSegAnt[i].nombre_zona;
        var observaciones=objetoTemporalExploracionFisicaSegAnt[i].descripsionRegion;

        //alert("DIAGNÓSTICO A INSERTAR: "+id_consulta+" "+diagnostico+" "+comentario);

         $.ajax({
                  type: 'ajax',
                 method: 'post',
                 async: false,
                 url: '<?php echo base_url() ?>medico/Consulta/GuardarExploracionFisica',
                 data:{id_consulta:id_consulta, id_region:id_region, nombre_de_la_zona:nombre_de_la_zona,observaciones:observaciones},
                 dataType: 'json',
                 success: function(response){

                 //alert("LA RESPUESTA ES: "+response);
                 //limpiaCampos();
                   if(response){



                       /*swal({
                                      title: "Exploracion fisica guardado con éxito",
                                      type: "success",
                                      timer: 2000,
                                      showConfirmButton: false
                                  }
                                  )
                       .catch(swal.noop);*/
                       //setTimeout(location.reload(), 2000);

                       //location.reload();
                    }
                    else{
                     $('.alert-danger').html('Ocurrio un problema al guardar los datos de exploración física debido a la conexión de internet, sin embargo se ha guardado el resto de la informacion!').fadeIn().delay(2000).fadeOut('slow');
                     
                    }

                  },
                  error: function(){
                      alert('Hubo un error al intentar guardar la sección de exploración físicas, sin embargo se prosigue a guardar la información restante de la consulta');
                  }
              });
    }
   
  }

  
}


 function insertarDiagnosticoAbierto(id_consulta){
  if(arregloDediagnosticosSeleccionadosAbiertos.length>0){
    for(var i=0;i<arregloDediagnosticosSeleccionadosAbiertos.length;i++){
        
        var id_consulta=id_consulta;
        var diagnostico=arregloDediagnosticosSeleccionadosAbiertos[i].diagnostico; 
        var comentario=arregloDediagnosticosSeleccionadosAbiertos[i].observaciones;
        //alert("DIAGNÓSTICO A INSERTAR: "+id_consulta+" "+diagnostico+" "+comentario);

         $.ajax({
                  type: 'ajax',
                 method: 'post',
                 async: false,
                 url: '<?php echo base_url() ?>medico/Consulta/GuardarDiagnosticoAbierto',
                 data:{id_consulta:id_consulta, diagnostico:diagnostico, comentario:comentario},
                 dataType: 'json',
                 success: function(response){

                 //alert("LA RESPUESTA ES: "+response);                 
                   if(response){
                    //Se guardó
                    }
                    else{
                     $('.alert-danger').html('Ocurrio un problema al guardar los datos de la consulta!').fadeIn().delay(2000).fadeOut('slow');
                     
                    }

                  },
                  error: function(){
                      alert('Could not get Data from Database');
                  }
              });
    }
   
  }

  
}

 function insertarDiagnostico(id_consulta){
  if(arregloDediagnosticosSeleccionados.length>0){
    for(var i=0;i<arregloDediagnosticosSeleccionados.length;i++){
        
        var id_consulta=id_consulta;
        var diagnostico=arregloDediagnosticosSeleccionados[i].id_diagnostico; 
        var comentario=arregloDediagnosticosSeleccionados[i].observaciones;
        //alert("DIAGNÓSTICO A INSERTAR: "+id_consulta+" "+diagnostico+" "+comentario);

         $.ajax({
                  type: 'ajax',
                 method: 'post',
                 async: false,
                 url: '<?php echo base_url() ?>medico/Consulta/GuardarDiagnostico',
                 data:{id_consulta:id_consulta, diagnostico:diagnostico, comentario:comentario},
                 dataType: 'json',
                 success: function(response){

                 //alert("LA RESPUESTA ES: "+response);
                 //limpiaCampos();
                   if(response){



                       /*swal({
                                      title: "Diagnostico guardado con éxito",
                                      type: "success",
                                      timer: 2000,
                                      showConfirmButton: false
                                  }
                                  )
                       .catch(swal.noop);*/
                       //setTimeout(location.reload(), 2000);

                       //location.reload();
                    }
                    else{
                     $('.alert-danger').html('Ocurrio un problema al guardar los datos de la consulta!').fadeIn().delay(2000).fadeOut('slow');
                     
                    }

                  },
                  error: function(){
                      alert('Could not get Data from Database');
                  }
              });
    }
   
  }

  
}

  function guardarEstudiosLaboratorio(id_consulta)
    {
      var estudiosArchL=$('#estudiosArchL').val();

      if(estudiosArchL.trim()!=""){
        $.ajax({
                  type: 'ajax',
                 method: 'post',
                 async: false,
                 url: '<?php echo base_url() ?>medico/Consulta/guardarEstudiosLaboratorio',
                 data:{id_consulta:id_consulta, estudiosdelab:estudiosArchL},
                 dataType: 'json',
                 success: function(response){

                 //alert("LA RESPUESTA ES: "+response);
                 //limpiaCampos();
                   if(response){



                       /*swal({
                                      title: "Diagnostico guardado con �xito",
                                      type: "success",
                                      timer: 2000,
                                      showConfirmButton: false
                                  }
                                  )
                       .catch(swal.noop);*/
                       //setTimeout(location.reload(), 2000);

                       //location.reload();
                    }
                    else{
                     $('.alert-danger').html('Ocurrio un problema al guardar los datos de la consulta!').fadeIn().delay(2000).fadeOut('slow');
                     
                    }

                  },
                  error: function(){
                      alert('Could not get Data from Database');
                  }
              });

      }
        
    }
    function guardarEstudiosGabinete(id_consulta)
    {
      var estudiosArchG=$('#estudiosArchG').val();
      if(estudiosArchG.trim()!=""){
        $.ajax({
                  type: 'ajax',
                 method: 'post',
                 async: false,
                 url: '<?php echo base_url() ?>medico/Consulta/guardarEstudiosGabinete',
                 data:{id_consulta:id_consulta, estudiosdegab:estudiosArchG},
                 dataType: 'json',
                 success: function(response){
                   if(response){



                       /*swal({
                                      title: "Diagnostico guardado con �xito",
                                      type: "success",
                                      timer: 2000,
                                      showConfirmButton: false
                                  }
                                  )
                       .catch(swal.noop);*/
                       //setTimeout(location.reload(), 2000);

                       //location.reload();
                    }
                    else{
                     $('.alert-danger').html('Ocurrio un problema al guardar los datos de la consulta!').fadeIn().delay(2000).fadeOut('slow');
                     
                    }

                  },
                  error: function(){
                      alert('Could not get Data from Database');
                  }
              });
      }
        
    }


 function insertarTratamientoAbierto(id_consulta){
    //var medicamento={medicamento:medicamento,dosis:dosis,frecuencia:frec_dosis,via_admin:via_adm,fecha_inicio:inicio_trat,fecha_termino:fin_trat,indicaciones:indicaciones_gral}
            
  if(arregloDemedicamentosSeleccionadosDelTratamientoAbierto.length>0){
    for(var i=0;i<arregloDemedicamentosSeleccionadosDelTratamientoAbierto.length;i++){
        
        var id_consulta=id_consulta;
        var medicamento=       arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].medicamento; 
        //var dosis_preescrita=     arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].dosis;
        var descripcion_del_tratamiento=     arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].frecuencia;
        var via_de_administracion=arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].via_adm;
        //var inicio_tratamiento=   arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].fecha_inicio;
        //var fin_tratamiento=      arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].fecha_termino;
        var indicaciones_generales_al_paciente=arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].indicaciones;
        //var estadoDeTratamiento=  arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].indeterminado;
        
        //alert("TRATAMIENTO A INSERTAR: "+estadoDeTratamiento);

         $.ajax({
                  type: 'ajax',
                 method: 'post',
                 async: false,
                 url: '<?php echo base_url() ?>medico/Consulta/GuardarTratamientoAbierto',
                 data:{id_consulta:id_consulta, medicamento:medicamento, descripcion_del_tratamiento:descripcion_del_tratamiento,via_de_administracion:via_de_administracion,indicaciones_generales_al_paciente:indicaciones_generales_al_paciente},
                 dataType: 'json',
                 success: function(response){

                   if(response){
                       //Se guardó
                    }
                    else{
                     $('.alert-danger').html('Ocurrio un problema al guardar los datos de la consulta!').fadeIn().delay(2000).fadeOut('slow');
                     
                    }

                  },
                  error: function(){
                      alert('Could not get Data from Database');
                  }
              });
    }
   
  }

  
}
  function insertarTratamiento(id_consulta){
    //var medicamento={medicamento:medicamento,dosis:dosis,frecuencia:frec_dosis,via_admin:via_adm,fecha_inicio:inicio_trat,fecha_termino:fin_trat,indicaciones:indicaciones_gral}
            
  if(arregloDemedicamentosSeleccionadosDelTratamiento.length>0){
    for(var i=0;i<arregloDemedicamentosSeleccionadosDelTratamiento.length;i++){
        
        var id_consulta=id_consulta;
        var id_medicamento=arregloDemedicamentosSeleccionadosDelTratamiento[i].id_medicamento; 
        var dosis_preescrita=arregloDemedicamentosSeleccionadosDelTratamiento[i].dosis;
        var frec_de_la_dosis=arregloDemedicamentosSeleccionadosDelTratamiento[i].frecuencia;
        var via_de_administracion=arregloDemedicamentosSeleccionadosDelTratamiento[i].id_via_adm;
        var inicio_tratamiento=arregloDemedicamentosSeleccionadosDelTratamiento[i].fecha_inicio;
        var fin_tratamiento=arregloDemedicamentosSeleccionadosDelTratamiento[i].fecha_termino;
        var indicaciones_generales_al_paciente=arregloDemedicamentosSeleccionadosDelTratamiento[i].indicaciones;
        var estadoDeTratamiento=arregloDemedicamentosSeleccionadosDelTratamiento[i].indeterminado;
        
        //alert("TRATAMIENTO A INSERTAR: "+estadoDeTratamiento);

         $.ajax({
                  type: 'ajax',
                 method: 'post',
                 async: false,
                 url: '<?php echo base_url() ?>medico/Consulta/GuardarTratamiento',
                 data:{id_consulta:id_consulta, id_medicamento:id_medicamento, dosis_preescrita:dosis_preescrita,frec_de_la_dosis:frec_de_la_dosis,via_de_administracion:via_de_administracion,estadoDeTratamiento:estadoDeTratamiento,inicio_tratamiento:inicio_tratamiento,fin_tratamiento:fin_tratamiento,indicaciones_generales_al_paciente:indicaciones_generales_al_paciente},
                 dataType: 'json',
                 success: function(response){

                 //alert("LA RESPUESTA ES: "+response);
                 //limpiaCampos();
                   if(response){
                       swal({
                                      title: "Consulta guardado con éxito",
                                      type: "success",
                                      timer: 2000,
                                      showConfirmButton: false
                                  }
                                  )
                       .catch(swal.noop);
                       //setTimeout(location.reload(), 2000);

                       //location.reload();
                    }
                    else{
                     $('.alert-danger').html('Ocurrio un problema al guardar los datos de la consulta!').fadeIn().delay(2000).fadeOut('slow');
                     
                    }

                  },
                  error: function(){
                      alert('Could not get Data from Database');
                  }
              });
    }
   
  }

  
}

    
        //...................................................

         function guardarEnListaDeMedicamentosUsados(id_medicamento,id_medico){
            //alert(categoria);

            $.ajax({
                type: 'ajax',
               method: 'post',
               async: false,
               url: '<?php echo base_url() ?>medico/medicamentos/insertarMedicamentoEnListaDeUsados',
               data:{id_medicamento:id_medicamento,id_medico:id_medico},
               dataType: 'json',
               success: function(response){

                 if(response){
                     swal({
                                    title: "Agregado a la lista!",
                                    type: "success",
                                    timer: 1800,
                                    showConfirmButton: false
                                }
                                )
                          .catch(swal.noop);
                  }
                  else{
                   $('.alert-danger').html('El medicamento no pudo ser insertado!').fadeIn().delay(2000).fadeOut('slow');
                   
                  }

                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });

        }
    //----------------------------------------------

</script>











<!--               MODAL EXPLORACION FISICA SEGMENTADA FRONTAL           -->
<!--<div id="exploracionfisicaFrontal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><span class="glyphicon glyphicon-menu-down"></span> Describa la region del cuerpo</h4>
      </div>
      <div class="modal-body">
        <form class="form-horizontal">
          <div class="form-group">
            <label for="" class="col-sm-2 control-label">Región</label>
            <div class="col-sm-10">
              <select class="form-control" name="region" id="region" required>
                getRegionesDelCuerpo
                
                <option value="Cabeza Anterior" style="background-image: url(../../../../assets/img/cabezaanterior.jpg); background-repeat:no-repeat; padding-left:25px;
                line-height:50px;
                margin-bottom:2px;">Cabeza Anterior</option>
                <option value="Cabeza Posterior" style="background-image: url(../../../../assets/img/cabezaposterior.png); background-repeat:no-repeat; padding-left:25px;
                line-height:50px;
                margin-bottom:2px;">Cabeza Posterior</option>
                <option value="Cabeza Lateral Derecha">Cabeza Lateral Derecha</option>
                <option value="Cabeza Lateral Izquierda">Cabeza Lateral Izquierda</option>
                <option value="Cuerpo Anterior">Cuerpo Anterior</option>
                <option value="Cuerpo Anterior">Cuerpo Posterior</option>
                <option value="Cuerpo Lateral Derecha">Cuerpo Lateral Derecha</option>
                <option value="Cuerpo Lateral Izquierda">Cuerpo Lateral Izquierda</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label for="" class="col-sm-2 control-label">Nombre de la zona</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="nombre_zona" placeholder="Frente, Ojos, Boca, Abdomen, etc." required>
            </div>
          </div>
          <div class="form-group">
           <label for="" class="col-sm-2 control-label">Descripción</label>
           <div class="col-sm-10">
            <textarea type="text" class="form-control" name="descripsionfisicaSeg1" id="descripsionRegion" placeholder="texto" required></textarea>
          </div>

          <style type="text/css">
          #descripsionRegion{
            max-width: 100%; 
            height: 150px;
          }
          </style>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      <button type="button" id="agregarExploFisSegAnterior" class="btn btn-success">Agregar</button>
    </div>
  </div>/.modal-content -->
<!--</div>/.modal-dialog -->
<!--</div>/.modal -->
<!--        :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::            -->



<!--               AREA DE DIAGNOSTICO            -->

<div id="ModalCrearDiagnostico" class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" style="overflow-y: scroll;"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header modal-header-success"> 
       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
       <h4 class="modal-tittle">Generar Diagnóstico</h4> 
     </div> 
     <div class="modal-body"> 
      <div class="panel panel-default">
        <div class="panel-body">
          <!-- ----------------------------------------- -->
          <div class="col-md-7">
            <div class="panel panel-default">
              <div class="panel-body">
                <!--    -->
                <div class="panel-body">

                  <form class="form-horizontal" id="formularioDeDiagnosticosModal">
                    <div class="form-group">
                      <div class="col-sm-12">
                        <label class="control-label">Diagnóstico</label>
                        <input type="hidden"   id="id-diagnostico" name="id-diagnostico"  required>
                        <input type="hidden"   id="clave" name="clave" required>
                        <input type="text" class="form-control"  id="diagnostico"  name="diagnostico" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-sm-12">
                       <label class="control-label">Observación</label>
                       <textarea type="text" class="form-control" name="observaciones_grales_diagnostico" id="observaciones_grales_diagnostico" style="height: 158px;" required></textarea>
                       <style type="text/css">
                       textarea {
                        max-width: 100%; 
                        max-height: 100%;
                      }
                      </style>
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="col-md-12">
                      <center><button type="submit" id="btn-agregarDiagnosticoParaAlmacenar" name="btn-agregarDiagnosticoParaAlmacenar" class="btn btn-success btn-lg">Agregar diagnóstico a la lista <i class="glyphicon glyphicon-share-alt"></i></button></center>
                    </div>
                  </div>
                </form>
              </div>
              <!--    -->
            </div>
          </div>
        </div>
        <!-- ----------------------------------------- -->
        <div class="col-md-5">
          <div class="panel panel-default" style="height: 400px;">
            <div class="panel-body">
              <form class="form-horizontal" action="">
                <div class="form-group">
                  <div class="col-md-12" >
                    <div class="form-group">
                      <center>
                        <label class="control-label">Diagnósticos Formulados</label>
                      </center><!--style="height: 460px;"-->
                    </div>


                    <div class="alert alert-info alert-dismissable" style="display: none;">
                    </div>


                    <table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-general-diagnosticos-formulados">
                      <thead>
                        <tr>
                          <td><center>Diagnóstico</center></td>
                          <td><center>Acciones</center></td>
                        </tr>
                      </thead>
                      <tbody id="diagnosticosFormuladoHastaElMomento">

                      </tbody>
                    </table>

                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!-- ----------------------------------------- -->
      </div>
    </div>
  </div>
  <div class="modal-footer">
    <div class="col-md-12">
      <button type="button" id="btnFinalizarDiagnotico" class="btn btn-primary btn-lg">Finalizar agregado de Diagnósticos</button>
    </div>
  </div>
</div>
</div>
</div>


<div id="ModalAgregarDiagnostico" class="modal fade" role="dialog"> 
        <div class="modal-dialog" >
            <div class="modal-content">
                <div class="modal-header modal-header-success"> 
                    <h4 class="modal-tittle">Diagnóstico</h4>
                </div> 
                    <div class="modal-body">
                      <div>
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#busquedaDiagnostico" aria-controls="profile" role="tab" data-toggle="tab">Buscar Diagnóstico</a></li>
                                <li role="presentation"><a href="#diagnosticos-mas-frecuentes-menu" aria-controls="home" role="tab" data-toggle="tab">Diagnósticos más frecuentes</a></li>
                                
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">

                                <!-- -->
                                <div role="tabpanel" class="tab-pane active"  id="busquedaDiagnostico">
                                     <div class="panel panel-default" style="height: 432px;">
                                        <div class="panel-body">


                                          <div class="row">
                                            <div class="col-md-8">
                                              <div class="panel panel-default">
                                              <div class="panel-body">
                                                <label class="control-label">Diagnóstico</label>
                                                <input type="hidden"   id="id-diagnostico1" name="id-diagnostico1"  required>

                                                <input type="hidden"   id="clave1" name="clave1"  required>
                                                <input type="text"  name="nombre-diagnostico-Escrito" id="nombre-diagnostico-Escrito" style="width:315px;" >
                                            </div>
                                          </div>

                                            </div>
                                            <div class="col-md-4">
                                              <div class="panel panel-default">
                                                <div class="panel-body">
                                                  <textarea type="text"  name="diagnosticoAlSerBuscado" class="form-control" id="diagnosticoAlSerBuscado"style="height: 320px"  required></textarea>
                                                    <style type="text/css">
                                                      textarea {
                                                        max-width: 100%;
                                                        max-height: 320px;
                                                        }
                                                    </style>
                                                  <br>
                                                  <button type="button" id="btn-diagnosticoAlSerBuscado" name="btn-diagnosticoAlSerBuscado" class="btn btn-success" title="Seleccionar como genérico"><span class="glyphicon glyphicon-share-alt"></span></button>
                                                
                                                </div>
                                              </div>
                                            </div>
                                          </div>


                                          
                                        </div>
                                    </div>
                                </div>
                                <!-- -->
                                <div role="tabpanel"  class="tab-pane" id="diagnosticos-mas-frecuentes-menu">
                                    <div class="panel panel-default"> <!-- style="height: 350px;" -->
                                        <div class="panel-body">
                                            <!--Inicio vista (1) -->
                                            <!--<div class="col-md-12">-->
                                                <div class="alert alert-danger" role="alert" style="display: none;">
                                                </div>
                                                <div class="table-responsive" id="conexionDiagnosticos">
                                                    <div class="nuevaTablaDiagnosticos" id="diagnosticosFrecuenciados">
                                                    </div>  
                                                </div>
                                            <!--</div>-->

                                            <!--Fin     vista (1) -->
                                        </div>
                                    </div>
                                </div>
                                
                                
                            </div>

                      </div>

                    </div>
            </div>
        </div>
</div>

<div id="deleteDiagnosticoModal" class="modal fade" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Eliminar</h4>
          </div>
          <div class="modal-body">
            Estas seguro de eliminar el diagnóstico?
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
            <button type="button" id="btnDeleteDiagnostico" class="btn btn-danger">Eliminar</button>
          </div>
        </div>
      </div>
</div>

    

<script type="text/javascript">
    var id_doctor="<?php echo $medico_logueado[0]->id_medico;?>";
    var arregloDediagnosticosSeleccionados=[];
    var arregloDediagnosticosSeleccionadosAbiertos=[];

    listarDiagnosticosUsadosPor(id_doctor);


    var options = {
      url: "<?php echo base_url('medico/Consulta/getDiagnosticos');?>",

      getValue: "nombre",
      placeholder: "Escriba el nombre de un diagnóstico ..",
      theme: "bootstrap",

      template: {
        type: "custom",
        //CONSEC
        //Clave
        //nombre
        method:function(value,item){

          return item.Clave+" - "+item.nombre;
        }
      },


      list: {
       
        maxNumberOfElements: 7,
        match: {
          enabled: true
        },

        onSelectItemEvent: function() {
          var id_d = $("#nombre-diagnostico-Escrito").getSelectedItemData().CONSEC;
          var clave = $("#nombre-diagnostico-Escrito").getSelectedItemData().Clave;
          var diagnostico = $("#nombre-diagnostico-Escrito").getSelectedItemData().nombre;


          var a=$("#id-diagnostico1").val(id_d).trigger("change");
          var b=$("#clave1").val(clave).trigger("change");

          $("#diagnosticoAlSerBuscado").val("("+clave.trim()+") "+diagnostico);
        }
      }
    };

    //LISTA DE EVENTOS
    $("#nombre-diagnostico-Escrito").easyAutocomplete(options);

    
    $('#btn-diagnosticoAlSerBuscado').click(function(){
      if($('#diagnosticoAlSerBuscado').val()!=""){

          var opcion=$('input:radio[name=optradio]:checked').val();
          if(opcion==1){
            //FORMULARIO DE DIAGNOSTICO ABIERTO
            //------------------------------------------------------
            //$('#id-diagnostico').val($('#id-diagnostico1').val());
            $('#diagnostico-abierto').val($('#diagnosticoAlSerBuscado').val());

            $('#id-diagnostico1').val("");
            $('#diagnosticoAlSerBuscado').val("");
            $('#nombre-diagnostico-Escrito').val("");
            $('#ModalAgregarDiagnostico').modal('hide');
            //-----------------------------------------------------
            
          }
          else{
            //FORMULARIO DE DIAGNOSTICO CERRADO
            //------------------------------------------------------
            $('#id-diagnostico').val($('#id-diagnostico1').val());
            $('#diagnostico').val($('#diagnosticoAlSerBuscado').val());

            $('#id-diagnostico1').val("");
            $('#diagnosticoAlSerBuscado').val("");
            $('#nombre-diagnostico-Escrito').val("");
            $('#ModalAgregarDiagnostico').modal('hide');
            //-----------------------------------------------------
          }


          

          }
    });

      $('#btn-agregarDiagnosticoParaAlmacenar-abierto').click(function(){

        //var id_diagnostico   = $('#id-diagnostico').val();
        //var clave            = $('#clave').val();
        var diagnostico      = $('#diagnostico-abierto').val();
        var observaciones    = $('#observaciones_grales_diagnostico-abierto').val();


        if(diagnostico.trim()!=""&&observaciones.trim()!=""){
            
            var diagnostico={diagnostico:diagnostico,observaciones:observaciones};

            arregloDediagnosticosSeleccionadosAbiertos.push(diagnostico);
            dibujaTablaDeDiagnosticosSeleccionadoAbierto();//<-------ojo

            $('#observaciones_grales_diagnostico-abierto').val("");
            $('#diagnostico-abierto').val("");
            $('#formularioAbiertoDeDiagnosticosModalAbierto').trigger("reset");
            return false;
        }
    });

    $('#btn-agregarDiagnosticoParaAlmacenar').click(function(){

        var id_diagnostico   = $('#id-diagnostico').val();
        var clave            = $('#clave').val();
        var diagnostico      = $('#diagnostico').val();
        var observaciones    = $('#observaciones_grales_diagnostico').val();


        if(id_diagnostico!=""&&diagnostico!=""&&observaciones!=""){
            
            var diagnostico={id_diagnostico:id_diagnostico,clave:clave,diagnostico:diagnostico,observaciones:observaciones};
            arregloDediagnosticosSeleccionados.push(diagnostico);
            dibujaTablaDeDiagnosticosSeleccionado();
                
            $('#formularioDeDiagnosticosModal').trigger("reset");
            return false;
        }
    });


    $('#generar-diagnostico').click(function(){
      
      var opcion=$('input:radio[name=optradio]:checked').val();
      if(opcion==1){
        $('#ModalCrearDiagnosticoConFormularioAbierto').modal('show');
      }
      else{
        limpiaCamposDeTratamiento();
         $('#ModalCrearDiagnostico').modal('show');
      }
    });


    $('#BuscaDiagnosticoAbierto').click(function(){
      $('#ModalAgregarDiagnostico').modal('show');
    });

    $('#diagnostico').click(function(){
      $('#ModalAgregarDiagnostico').modal('show');
    });

    $('#diagnosticosFrecuenciados').on('click', '.item-id-seleccionar-como-diagnostico', function(){
        
        var opcion=$('input:radio[name=optradio]:checked').val();
          if(opcion==1){
            //FORMULARIO DE DIAGNOSTICO ABIERTO
            //Recuperamos el diagnostico selecionado
            var variableClave               = $(this).attr('clave-diagnostico');
            var variableNombre              = $(this).attr('nombre-diagnostico');
            var variableId                  = $(this).attr('id-diagnostico');

            //Asignamos el medicamento a la vista porincipal 
            //$('#id-diagnostico').val(variableId);
            $('#diagnostico-abierto').val("("+variableClave.trim()+")"+" "+variableNombre.trim());
            //$('#clave').val(variableClave);
            //Cerramos el modal 
            $('#ModalAgregarDiagnostico').modal('hide');
            
          }
          else{
            //FORMULARIO DE DIAGNOSTICO CERRADO
            //Recuperamos el diagnostico selecionado
            var variableClave               = $(this).attr('clave-diagnostico');
            var variableNombre              = $(this).attr('nombre-diagnostico');
            var variableId                  = $(this).attr('id-diagnostico');

            //Asignamos el medicamento a la vista porincipal con todos los datos relevantes para su respectiva creacion!
            $('#id-diagnostico').val(variableId);
            $('#diagnostico').val("("+variableClave.trim()+")"+" "+variableNombre.trim());
            $('#clave').val(variableClave);
            //Cerramos el modal 
            $('#ModalAgregarDiagnostico').modal('hide');
          }

    });


    $('#diagnosticosFormuladoHastaElMomento-abierto').on('click', '.item-rangoAEliminarDeLosDiagnosticos-abierto', function(){

        var a=0;
        var b=0;

        a=$(this).attr('rangoAEliminarA'); 
        b=$(this).attr('rangoAEliminarB'); 

        $('#deleteDiagnosticoModal').modal('show');
        $('#btnDeleteDiagnostico').unbind().click(function(){
            arregloDediagnosticosSeleccionadosAbiertos.splice(a,b);
            dibujaTablaDeDiagnosticosSeleccionadoAbierto();
            $('#deleteDiagnosticoModal').modal('hide');
        });
    });


    $('#diagnosticosFormuladoHastaElMomento').on('click', '.item-rangoAEliminarDeLosDiagnosticos', function(){

        var a=0;
        var b=0;

        a=$(this).attr('rangoAEliminarA'); 
        b=$(this).attr('rangoAEliminarB'); 

        $('#deleteDiagnosticoModal').modal('show');
        $('#btnDeleteDiagnostico').unbind().click(function(){
            arregloDediagnosticosSeleccionados.splice(a,b);
            dibujaTablaDeDiagnosticosSeleccionado();
            $('#deleteDiagnosticoModal').modal('hide');
        });
    });


    $('#btnFinalizarDiagnotico').click(function(){

            //alert("precionado");
            //FORMULARIO DE DIAGNOSTICO CERRADO
                    var i=0;
                    var texto='\n';
                    var tam_max=arregloDediagnosticosSeleccionados.length;

                      for(i;i<arregloDediagnosticosSeleccionados.length;i++){

                    texto=texto+
                                " Diagnóstico: "             + arregloDediagnosticosSeleccionados[i].diagnostico+
                                " Observaciones: "           + arregloDediagnosticosSeleccionados[i].observaciones;   
                               
                            texto=texto+'\n\n';
                        }

                    
                    
                    //Obtenemos el tamaño de la tabla
                    var num_elementos=$("#tabla-general-diagnosticos-formulados tr").length;
                    if(num_elementos>1){
                      document.getElementById("indicacionesDeLosdiagnosticos").value=texto;
                        $('#ModalCrearDiagnostico').modal('hide');
                    }
                    else{
                        swal({
                            title: "No ha agregado al menos un diagnóstico a la lista!",
                            text: "Si decea salir sin fórmular un diagnóstico, puede precionar la (X) de la parte superior de la ventana!",
                            type: "warning",
                            timer: 2000,
                            showConfirmButton: false
                        }).catch(swal.noop);
                    }
            
          




    });


     $('#btnFinalizarDiagnotico-abierto').click(function(){
         //FORMULARIO DE DIAGNOSTICO ABIERTO
                    var i=0;
                    var texto='\n';
                    var tam_max=arregloDediagnosticosSeleccionadosAbiertos.length;

                      for(i;i<arregloDediagnosticosSeleccionadosAbiertos.length;i++){

                    texto=texto+
                                " Diagnóstico: "             + arregloDediagnosticosSeleccionadosAbiertos[i].diagnostico+
                                " Observaciones: "           + arregloDediagnosticosSeleccionadosAbiertos[i].observaciones;   
                               
                            texto=texto+'\n\n';
                        }

                    
                    
                    //Obtenemos el tamaño de la tabla
                    var num_elementos=$("#tabla-general-diagnosticos-formulados-abierto tr").length;
                    if(num_elementos>1){
                      document.getElementById("indicacionesDeLosdiagnosticos").value=texto;
                        $('#ModalCrearDiagnosticoConFormularioAbierto').modal('hide');
                    }
                    else{
                        swal({
                            title: "No ha agregado al menos un diagnóstico a la lista!",
                            text: "Si decea salir sin fórmular un diagnóstico, puede precionar la (X) de la parte superior de la ventana!",
                            type: "warning",
                            timer: 2000,
                            showConfirmButton: false
                        }).catch(swal.noop);
                    }
            
     });

      //EVENTOS PARA BLOUEAR LA ESCRITURA
    $("#indicacionesDeLosdiagnosticos").blur(function(){
            $(this).prop("readonly",""); 
      });

    $("#indicacionesDeLosdiagnosticos").focus(function(){
            $(this).prop("readonly","readonly"); 
      });

     //EVENTOS PARA BLOUEAR LA ESCRITURA
    $("#diagnostico").blur(function(){
            $(this).prop("readonly",""); 
      });

    $("#diagnostico").focus(function(){
            $(this).prop("readonly","readonly"); 
      });

            function dibujaTablaDeDiagnosticosSeleccionadoAbierto(){
                     if(arregloDediagnosticosSeleccionadosAbiertos.length==0){
                        var html = '';
                        $('#diagnosticosFormuladoHastaElMomento-abierto').html(html);
                    }
                    else{
                        var html = '';
                        var i;
                        var complemento;
                        for(i=0; i<arregloDediagnosticosSeleccionadosAbiertos.length; i++){
                            complemento=i+1;
                            var texto_hover=             " Diagnóstico: "             + arregloDediagnosticosSeleccionadosAbiertos[i].diagnostico.trim()+'\n'+
                                                       " Observaciones: "                + arregloDediagnosticosSeleccionadosAbiertos[i].observaciones.trim()+'\n';
                           
                           html +='<tr title="'+texto_hover+'">'+
                                        '<td>'+arregloDediagnosticosSeleccionadosAbiertos[i].diagnostico+'</td>'+
                                        '<td>'+
                                            '<center>'+
                                                '<a href="javascript:;" class="btn btn-default item-rangoAEliminarDeLosDiagnosticos-abierto" rangoAEliminarA="'+i+'" '+'rangoAEliminarB="'+complemento+'" style="color:RED" title="Eliminar el diagnóstico!"><i class="glyphicon glyphicon-remove"></i></a>'+
                                            '<center>'+                                                                                
                                        '</td>'+
                                    '</tr>';
                        }

                        $('#diagnosticosFormuladoHastaElMomento-abierto').html(html);

                        var filas=$("#tabla-general-diagnosticos-formulados-abierto tr").length;

                            if(filas>7){
                                $("#tabla-general-diagnosticos-formulados-abierto").css({'overflow-y':'scroll','height':'150px','width':'400px','display':'block'});
                            }
                        }
    }

    function dibujaTablaDeDiagnosticosSeleccionado(){
                     if(arregloDediagnosticosSeleccionados.length==0){
                        var html = '';
                        $('#diagnosticosFormuladoHastaElMomento').html(html);
                    }
                    else{
                        var html = '';
                        var i;
                        var complemento;
                        for(i=0; i<arregloDediagnosticosSeleccionados.length; i++){
                            complemento=i+1;
                            var texto_hover=             " Diagnóstico: "             + arregloDediagnosticosSeleccionados[i].diagnostico.trim()+'\n'+
                                                       " Observaciones: "                + arregloDediagnosticosSeleccionados[i].observaciones.trim()+'\n';
                           
                           html +='<tr title="'+texto_hover+'">'+
                                        '<td>'+arregloDediagnosticosSeleccionados[i].diagnostico+'</td>'+
                                        '<td>'+
                                            '<center>'+
                                                '<a href="javascript:;" class="btn btn-default item-rangoAEliminarDeLosDiagnosticos" rangoAEliminarA="'+i+'" '+'rangoAEliminarB="'+complemento+'" style="color:RED" title="Eliminar el diagnóstico!"><i class="glyphicon glyphicon-remove"></i></a>'+
                                            '<center>'+                                                                                
                                        '</td>'+
                                    '</tr>';
                        }

                        $('#diagnosticosFormuladoHastaElMomento').html(html);

                        var filas=$("#tabla-general-diagnosticos-formulados tr").length;

                            if(filas>7){
                                $("#tabla-general-diagnosticos-formulados").css({'overflow-y':'scroll','height':'150px','width':'400px','display':'block'});
                            }
                        }
    }

    function listarDiagnosticosUsadosPor(id_medico){

      $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/diagnosticos/listarDiagnosticosUsadosPor',
               data:{id_medico:id_medico},
               dataType: 'json',
               success: function(data){
                    //alert(data);
                    if(data==false){

                        var html = '';
                        $('#diagnosticosFrecuenciados').html(html);
                            
                        $('.alert-danger').html('Actualmente no cuenta con una lista de diagnósticos frecuentes!, para configurar puede ir a la opción de catálogos -> catálogos de diagnósticos y comenzar a agregar!').fadeIn().delay(6200).fadeOut('slow');
              

                    }
                    else{

                    var html = '';
                        var i;
                        html +='<table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-diagnosticos-frecuentes">'+
                                            '<thead>'+
                                            '<tr>'+
                                                '<th>CÓDIGO</th>'+
                                                '<th>DIAGNÓSTICO</th>'+
                                                '<th><center>ACCIONES</center></th>'+
                                            '</tr>'+
                                            '</thead>'+
                                                '<tbody>';
                                            for(i=0; i<data.length; i++){
                                                html +='<tr>'+
                                                '<td>'+data[i].clave+'</td>'+
                                                '<td>'+data[i].nombre+'</td>'+
                                                '<td>'+
                                                '<center>'+
                                                    '<a href="javascript:;"  nombre-diagnostico="'+data[i].nombre+'" '+' clave-diagnostico="'+data[i].clave+'"'+' id-diagnostico="'+data[i].id_diagnostico+'" class="btn btn-default item-id-seleccionar-como-diagnostico" style="color:GREEN" title="Elegir como diagnóstico"><i class="glyphicon glyphicon-share-alt"></i></a>'+
                                                '<center>'+                                                                              
                                                '</td>'+
                                                '</tr>';
                                            }
                                            html +='</tbody>'+'</table>';
                                            
                                            $('#diagnosticosFrecuenciados').html(html);

                                             //--CONTEMOS LAS FILAS PARA QUE APAREZCA EL SCROLL
                                            var filas=$("#tabla-diagnosticos-frecuentes tr").length;
                                            if(filas>5){

                                              $("#tabla-diagnosticos-frecuentes").css({'overflow-y':'scroll','height':'310px','display':'block'});
                                            }
                                          }
                  
                   
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });

        }



</script>

<!-- FIN AREA DE DIAGNOSTICO      -->



    <div id="ModalCrearTratamientoAbierto" class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" style="overflow-y: scroll;"> 
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header modal-header-success"> 
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-tittle">Tratamiento Médico</h4> 
                </div> 
                    <div class="modal-body"> 
                          <div class="panel panel-default">
                            <div class="panel-body">
                                <!-- ----------------------------------------- -->
                                <div class="col-md-7">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <!--    -->
                                            <div class="panel-body">
                                                
                                                <form class="form-horizontal" id="formularioDeTratamientoModalAbierto">

                                                                            
                                                                            
                                                                            <div class="form-group">
                                                                              
                                                                                <div class="col-sm-12">
                                                                                    <label class="control-label">Medicamento ó Genérico</label>
                                                                                    <div class="input-group   input-append">
                                                                                      <input type="text" class="form-control input-append"  type="text" name="medicamentoAbierto" id="medicamentoAbierto"  placeholder="Ingrese el nombre del medicamento ó genérico" required>
                                                                                      <span class="input-group-addon add-on" id="BuscaTratamientoAbierto">
                                                                                        <i class="glyphicon glyphicon-search">
                                                                                        </i>
                                                                                      </span>
                                                                                    </div>

                                                                                    
                                                                                     
                                                                                </div>
                                                                            </div>


                                                                            
                                                                            <div class="form-group">
                                                                                <div class="col-sm-12">
                                                                                    <label class="control-label">Indique la frecuencia de la dosis al día y la duración del tratamiento</label>
                                                                                    <textarea type="text" class="form-control" name="frec_dosis_abierto" id="frec_dosis_abierto" required></textarea>
                                                                                    <style type="text/css">
                                                                                         textarea {
                                                                                            max-width: 100%; 
                                                                                            max-height: 100%;
                                                                                        }
                                                                                    </style>

                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="form-group">
                                                                                <div class="col-sm-12">
                                                                                   <label class="control-label">Via de administración</label>
                                                                                   
                                                                                         <select class="form-control" name="via_de_admin_abierto" id="via_de_admin_abierto" required>
                                                                                          <option></option>
                                                                                            <?php foreach($viasDeAdministracion as $via) { ?>
                                                                                            <option value="<?php echo $via->via_de_administracion; ?>"><?php echo $via->via_de_administracion; ?></option>
                                                                                            <?php } ?>
                                                                                        </select>
                                                                                    
                                                                                </div>
                                                                            </div>
                                                                           
                                                                            
                                                                            <div class="form-group">
                                                                                <div class="col-sm-12">
                                                                                  
                                                                                   <label class="control-label">Indicaciones generales al paciente</label>
                                                                                    <textarea type="text" class="form-control" name="indicaciones_gralesAbierto" id="indicaciones_gralesAbierto"></textarea>
                                                                                    <style type="text/css">
                                                                                         textarea {
                                                                                            max-width: 100%; 
                                                                                            max-height: 100%;
                                                                                        }
                                                                                    </style>
                                                                                </div>
                                                                            </div>


                                                                            <div class="form-group">
                                                                                <div class="col-md-12">
                                                                                    <center><button type="submit" id="btn-agregarAlTratamientoParaAlmacenarAbierto" name="btn-agregarAlTratamientoParaAlmacenarAbierto" class="btn btn-success btn-lg">Agregar al tratamiento <i class="glyphicon glyphicon-share-alt"></i></button></center>
                                                                                </div>
                                                                            </div>
                                                </form>
                                            </div>
                                            <!--    -->
                                        </div>
                                    </div>
                                </div>
                                <!-- ----------------------------------------- -->
                                <div class="col-md-5">
                                        <div class="panel panel-default" style="height: 600px;">
                                            <div class="panel-body">
                                                <form class="form-horizontal" action="">
                                                    <div class="form-group">
                                                        <div class="col-md-12" style="height: 470px;">
                                                            <div class="form-group">
                                                                <center>
                                                                    <label class="control-label">Tratamiento Formulado</label>
                                                                </center><!--style="height: 460px;"-->
                                                            </div>

                                                            
                                                            <div class="alert alert-info alert-dismissable" style="display: none;">
                                                            </div>


                                                            <table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-general-tratamientos-formulados-abierto">
                                                                <thead>
                                                                    <tr>
                                                                        <td><center>Genérico</center></td>
                                                                        <td><center>Acciones</center></td>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="tratamientoFormuladoHastaElMomentoAbierto">
                                                                    
                                                                </tbody>
                                                            </table>
                                                                
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                </div>
                                <!-- ----------------------------------------- -->
                            </div>
                           </div>
                    </div>
                    <div class="modal-footer">
                            <div class="col-md-12">
                              <button type="button" id="btnFinalizarTratamientoAbierto" class="btn btn-primary btn-lg">Formular Tratamiento</button>
                            </div>
                    </div>
            </div>
        </div>
    </div>

<!--               AREA DE TRATAMIENTO            -->

    <div id="ModalCrearTratamiento" class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" style="overflow-y: scroll;"> 
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header modal-header-success"> 
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-tittle">Tratamiento Médico</h4> 
                </div> 
                    <div class="modal-body"> 
                          <div class="panel panel-default">
                            <div class="panel-body">
                                <!-- ----------------------------------------- -->
                                <div class="col-md-7">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <!--    -->
                                            <div class="panel-body">
                                                
                                                <form class="form-horizontal" id="formularioDeTratamientoModal">

                                                                            
                                                                            
                                                                            <div class="form-group">
                                                                              
                                                                                <div class="col-sm-12">
                                                                                    <label class="control-label">Medicamento ó Genérico</label>
                                                                                     <input type="hidden"   id="id-medicamento" name="id-medicamento"  required>
                                                                                     <input type="hidden"   id="forma_farmaceutica" name="forma_farmaceutica"  required>

                                                                                     <input type="text" class="form-control"  id="medicamento" name="medicamento" placeholder="Seleccione un medicamento" required>
                                                                                    
                                                                                     
                                                                                </div>
                                                                            </div>


                                                                            <div class="form-group">
                                                                                <div class="col-sm-12">
                                                                                   <label class="control-label">Dosis preescrita</label>

                                                                                     <select class="form-control" name="dosis" id="dosis"  required>
                                                                                            <option ></option>
                                                                                            <option value="1">1</option>
                                                                                            <option value="2">2</option>
                                                                                            <option value="3">3</option>
                                                                                            <option value="4">4</option>
                                                                                            <option value="5">5</option>
                                                                                            <option value="6">6</option>
                                                                                            <option value="7">7</option>
                                                                                            <option value="8">8</option>
                                                                                            <option value="9">9</option>
                                                                                            <option value="10">10</option>
                                                                                           
                                                                                        </select>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="form-group">
                                                                                <div class="col-sm-12">
                                                                                   <label class="control-label">Frecuencia de dosis al dia</label>
                                                                                    <input type="text" class="form-control" name="frec_dosis" id="frec_dosis" placeholder="Indique la frecuencia con la que se consumirá el tratamiento" required>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="form-group">
                                                                                <div class="col-sm-12">
                                                                                   <label class="control-label">Via de administración</label>
                                                                                   
                                                                                         <select class="form-control" name="via_de_admin" id="via_de_admin" required>
                                                                                          <option></option>
                                                                                            <?php foreach($viasDeAdministracion as $via) { ?>
                                                                                            <option value="<?php echo $via->id_via_de_administracion; ?>"><?php echo $via->via_de_administracion; ?></option>
                                                                                            <?php } ?>
                                                                                        </select>
                                                                                    
                                                                                </div>
                                                                            </div>
                                                                            <hr>
                                                                            <center>
                                                                              <label class="checkbox-inline"><input id="checkBoxTratamiento" type="checkbox" value="">Marque esta casilla si el tratamiento es indefinido</label>
                                                                            </center>
                                                                            
                                                                            <div class="col-md-12">
                                                                              
                                                                                <div class="col-md-6">
                                                                                   <label class="control-label">Inicio de tratamiento</label>
                                                                                   
                                                                                    <div class="input-group date  input-append" id="datetimepicker6">
                                                                                      <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="inicio_trat" id="inicio_trat"   required><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                                                                                    </div>

                                                                                    <script type="text/javascript">
                                                                                    $(function() {
                                                                                        var today = new Date();
                                                                                        $('#datetimepicker6').datetimepicker({
                                                                                            pickTime: false,
                                                                                            language: 'es-MX',
                                                                                            endDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()+7),
                                                                                            startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),


                                                                                        });



                                                                                    });

                                                                                    </script>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    
                                                                                    <label class="control-label">Fin de tratamiento</label>
                                                                                   
                                                                                    <div class="input-group date  input-append" id="datetimepicker5">
                                                                                      <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="fin_trat" id="fin_trat"   required><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"> </i></span> 
                                                                                    </div>

                                                                                    <script type="text/javascript">
                                                                                    $(function() {
                                                                                        var today = new Date();
                                                                                        $('#datetimepicker5').datetimepicker({
                                                                                            pickTime: false,
                                                                                            language: 'es-MX',
                                                                                            endDate: new Date(today.getFullYear(), today.getMonth()+6, today.getDate()),
                                                                                            startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),

                                                                                        });



                                                                                    });

                                                                                    </script>
                                                                                </div>
                                                                              
                                                                            </div>
                                                                            <hr>
                                                                            <div class="form-group">
                                                                                <div class="col-sm-12">
                                                                                  <hr>
                                                                                   <label class="control-label">Indicaciones generales al paciente</label>
                                                                                    <textarea type="text" class="form-control" name="indicaciones_grales" id="indicaciones_grales" required></textarea>
                                                                                    <style type="text/css">
                                                                                         textarea {
                                                                                            max-width: 100%; 
                                                                                            max-height: 100%;
                                                                                        }
                                                                                    </style>
                                                                                </div>
                                                                            </div>


                                                                            <div class="form-group">
                                                                                <div class="col-md-12">
                                                                                    <center><button type="submit" id="btn-agregarAlTratamientoParaAlmacenar" name="btn-agregarAlTratamientoParaAlmacenar" class="btn btn-success btn-lg">Agregar al tratamiento <i class="glyphicon glyphicon-share-alt"></i></button></center>
                                                                                </div>
                                                                            </div>
                                                </form>
                                            </div>
                                            <!--    -->
                                        </div>
                                    </div>
                                </div>
                                <!-- ----------------------------------------- -->
                                <div class="col-md-5">
                                        <div class="panel panel-default" style="height: 600px;">
                                            <div class="panel-body">
                                                <form class="form-horizontal" action="">
                                                    <div class="form-group">
                                                        <div class="col-md-12" style="height: 470px;">
                                                            <div class="form-group">
                                                                <center>
                                                                    <label class="control-label">Tratamiento Formulado</label>
                                                                </center><!--style="height: 460px;"-->
                                                            </div>

                                                            
                                                            <div class="alert alert-info alert-dismissable" style="display: none;">
                                                            </div>


                                                            <table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-general-tratamientos-formulados">
                                                                <thead>
                                                                    <tr>
                                                                        <td><center>Genérico</center></td>
                                                                        <td><center>Acciones</center></td>
                                                                    </tr>
                                                                </thead>
                                                                <tbody id="tratamientoFormuladoHastaElMomento">
                                                                    
                                                                </tbody>
                                                            </table>
                                                                
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                </div>
                                <!-- ----------------------------------------- -->
                            </div>
                           </div>
                    </div>
                    <div class="modal-footer">
                            <div class="col-md-12">
                              <button type="button" id="btnFinalizarTratamiento" class="btn btn-primary btn-lg">Formular Tratamiento</button>
                            </div>
                    </div>
            </div>
        </div>
    </div>

    <div id="ModalAgregarMedicamento" class="modal fade" role="dialog"> 
        <div class="modal-dialog" >
            <div class="modal-content">
                <div class="modal-header modal-header-success"> 
                    <h4 class="modal-tittle">Medicamentos</h4>
                </div> 
                    <div class="modal-body">
                      <div>
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs" role="tablist">
                               <li role="presentation" class="active"><a href="#nuevo-medicamento" role="tab" data-toggle="tab">Registrar</a></li>
                               <li role="presentation"><a href="#medicamentos-mas-frecuentes-menu" id="TapMedicamentosMasFrecuentes" role="tab" data-toggle="tab">Más usados</a></li>
                               <li role="presentation"><a href="#busquedaMedicamentos"  role="tab" data-toggle="tab">Buscar por nombre de genérico</a></li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">

                                <!-- -->
                                <div role="tabpanel"  class="tab-pane active" id="nuevo-medicamento">
                                    <div class="panel panel-default"> <!-- style="height: 350px;" -->
                                        <div class="panel-body">
                                            <!--Inicio vista (1) -->
                                            <!--<div class="col-md-12">-->
                                                <div class="alert alert-warning mensaje-registro-medicamento" role="alert" style="display: none;">
                                                </div>

                                               <div class="panel panel-default">
                                                  <div class="panel-body">
                                                    
                                                       <!--Inicio form 1 -->

                                                        <form action="" id="formularioAltaDeMedicamentos" method="post">
                                                            <div class="form-group">
                                                                <label for="nombregenerico">Medicamento</label>
                                                                <input type="text" class="form-control" id="RegistroNombreGenerico"  style="width:503px;" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="formafarmaceutica">Forma farmacéutica</label>
                                                                <input type="text" class="form-control" id="RegistroFormaFarmaceutica"  style="width:503px;" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="concentracion">Concentración</label>
                                                                <input type="text" class="form-control" id="RegistroConcentracion"  style="width:503px;" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="presentacion">Presentación</label>
                                                                <input type="text" class="form-control" id="RegistroPresentacion"   style="width:503px;" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="presentacion">Dosis diaria definida</label>
                                                                <input type="text" class="form-control" id="RegistroDosisDiariaDefinida"  style="width:503px;" required>
                                                            </div>


                                                            <div class="col-md-offset-5">
                                                              <button type="submit" id="RegistroAgregarMedicamento" class="btn btn-success control-label btn-lg">Agregar</button>
                                                            </div>
                                                        </form>

                                                        <!--Fin form 1 -->
                                                    </div>
                                                </div>
                                                
                                            <!--</div>-->

                                            <!--Fin     vista (1) -->
                                        </div>
                                    </div>
                                </div>
                                <!-- -->
                                <!-- -->
                                <div role="tabpanel"  class="tab-pane" id="medicamentos-mas-frecuentes-menu">
                                    <div class="panel panel-default"> <!-- style="height: 350px;" -->
                                        <div class="panel-body">
                                            <!--Inicio vista (1) -->
                                            <!--<div class="col-md-12">-->
                                                <div class="alert alert-danger" role="alert" style="display: none;">
                                                </div>
                                                <div class="table-responsive" id="conexionMedicamentos">
                                                    <div class="nuevaTablaMedicamentos" id="medicamentosFrecuenciados">
                                                    </div>  
                                                </div>
                                            <!--</div>-->

                                            <!--Fin     vista (1) -->
                                        </div>
                                    </div>
                                </div>
                                <!-- -->
                                 <!-- -->
                                <div role="tabpanel" class="tab-pane"  id="busquedaMedicamentos">
                                     <div class="panel panel-default" style="height: 432px;">
                                        <div class="panel-body">


                                          <div class="row">
                                            <div class="col-md-8">
                                              <div class="panel panel-default">
                                              <div class="panel-body">
                                                <label class="control-label">Genérico</label>
                                                <input type="hidden"   id="id-medicamento1" name="id-medicamento1"  required>
                                                <input type="hidden"   id="presentacion1" name="presentacion1"  required>
                                                <input type="hidden"   id="forma_farmaceutica1" name="forma_farmaceutica1"  required>
                                                <input type="hidden"   id="concentracion1" name="concentracion1"  required>
                                                <input type="text"  name="nombre-medicamento-Escrito" id="nombre-medicamento-Escrito" style="width:315px;" >
                                            </div>
                                          </div>

                                            </div>
                                            <div class="col-md-4">
                                              <div class="panel panel-default">
                                                <div class="panel-body">
                                                  <textarea type="text"  name="medicamentoAlSerBuscado" class="form-control" id="medicamentoAlSerBuscado"style="height: 320px" required></textarea>
                                                    <style type="text/css">
                                                      textarea {
                                                        max-width: 100%;
                                                        max-height: 320px;
                                                        }
                                                    </style>
                                                  <br>
                                                  <button type="button" id="btn-medicamentoAlSerBuscado" name="btn-medicamentoAlSerBuscado" class="btn btn-success" title="Seleccionar como genérico"><span class="glyphicon glyphicon-share-alt"></span></button>
                                                
                                                </div>
                                              </div>
                                            </div>
                                          </div>


                                          
                                        </div>
                                    </div>
                                </div>
                                <!-- -->
                                
                                
                            </div>

                      </div>

                    </div>
            </div>
        </div>
    </div>

    <div id="deleteMedicamentoModal" class="modal fade" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Eliminar</h4>
          </div>
          <div class="modal-body">
            Estas seguro de eliminar el medicamento del tratamiento?
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
            <button type="button" id="btnDeleteTratamiento" class="btn btn-danger">Eliminar</button>
          </div>
        </div>
      </div>
    </div>

    <script type="text/javascript">

    //$('.mensaje-registro-medicamento').html('<strong>Nota!</strong> En la parte inferior de este mensaje se enlistarán los nombres de los genéricos que haya solicitado para el tratamiento correspondiente!, si decea ver más informacion  basta con posicionar el cursor del ratón sobre una de los renglones de la tabla. Al terminar con el tratamiento precione el boton de "Formular Tratamiento" para resguardar la información.').fadeIn().delay(9000).fadeOut('slow');
    ///------------------------------------------------
      $('#RegistroAgregarMedicamento').click(function() {
        var medicamentoGenerico= $('#RegistroNombreGenerico').val();
        var forma_farmaceutica = $('#RegistroFormaFarmaceutica').val();
        var concentracion = $('#RegistroConcentracion').val();
        var presentacion = $('#RegistroPresentacion').val();
        var dosis = $('#RegistroDosisDiariaDefinida').val();
        
        if(medicamentoGenerico.trim() != '' && forma_farmaceutica.trim() != '' && concentracion.trim() != '' && presentacion.trim() != ''&&dosis.trim()!="")
        {
          validaMedicamento(medicamentoGenerico.trim(),forma_farmaceutica.trim(),concentracion.trim(),presentacion.trim(),dosis.trim());
          return false;
        }
    });

function RegistroInsertarMedicamento(medicamentoGenerico,forma_farmaceutica,concentracion,presentacion,dosis){
                              $.ajax({
                                   type: 'ajax',
                                   method: 'post',
                                   async: false,
                                   url: '<?php echo base_url() ?>medico/Consulta/agregarMedicamento',
                                   data:{nombre_generico:medicamentoGenerico,forma_farmaceutica:forma_farmaceutica,concentracion:concentracion,presentacion:presentacion,dosis:dosis},
                                   dataType: 'json',
                                   success: function(response){
                                     if(response.success){
                                                $('#ModalAgregarMedicamento').modal('hide');
                                                $('#formularioAltaDeMedicamentos')[0].reset();

                                                        guardarEnListaDeMedicamentosUsados(response.newIdmedicamento,id_doctor);
                                                //-----------------------------------
                                                        var variableIdMedicamentoSeleccionado               = response.newIdmedicamento;
                                                        var variableNombreDeMedicamentoGenericoSeleccionado = medicamentoGenerico;
                                                        var variableFormaFarmaceuticaSeleccionado           = forma_farmaceutica;
                                                        var variablePresentacionMedicamentoSeleccionado     = presentacion;
                                                        var variableConcentracionMedicamentoSeleccionado    = concentracion;
                                                        var variableDosisMedicamentoSeleccionado            = dosis;


                                                        var opcion=$('input:radio[name=optradio]:checked').val();
                                                              if(opcion==1){
                                                                 //Asignamos el medicamento a la vista principal con todos los datos relevantes para su respectiva creacion!
                                                                 //$('#id-medicamento').val(variableIdMedicamentoSeleccionado);
                                                                 $('#medicamentoAbierto').val(variableNombreDeMedicamentoGenericoSeleccionado +" ("+variableConcentracionMedicamentoSeleccionado+") "+variableFormaFarmaceuticaSeleccionado);
                                                            }
                                                            else{
                                                              //Asignamos el medicamento a la vista principal con todos los datos relevantes para su respectiva creacion!
                                                               $('#id-medicamento').val(variableIdMedicamentoSeleccionado);
                                                               $('#medicamento').val(variableNombreDeMedicamentoGenericoSeleccionado +" ("+variableConcentracionMedicamentoSeleccionado+") "+variableFormaFarmaceuticaSeleccionado);
                                                          }
                                                        

                                                //-----------------------------------
                                                
                                           
                                           
                                      }
                                      else{
                                       swal({
                                                          title: "Error!",
                                                          type: "warning",//,cambiar
                                                          text: "Revise los datos e intente de nuevo",
                                                          timer: 1800,
                                                          showConfirmButton: false
                                                      }
                                                      )
                                              .catch(swal.noop);

                                      }

                                    },
                                    error: function(){
                                        alert('Could not get Data from Database');
                                    }
                                });
}
    //------------VALIDA DATOS DEL MEDICAMENTO
     function validaMedicamento(medicamentoGenerico,forma_farmaceutica,concentracion,presentacion,dosis){
  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,                
                    url: '<?php echo base_url() ?>medico/Consulta/validaMedicamento',
                    data:{nombre_generico:medicamentoGenerico,forma_farmaceutica:forma_farmaceutica,concentracion:concentracion,presentacion:presentacion,dosis:dosis},
                    dataType: 'json',
                    success: function(response){

                        if(response){
                          //EL MEDICAMENTO AUN NO EXISTE EN EL SISTEMA
                            //return true;
                            RegistroInsertarMedicamento(medicamentoGenerico,forma_farmaceutica,concentracion,presentacion,dosis);
                            //return true;
                        }else{
                          swal({
                                                          title: "Advertencia!",
                                                          type: "warning",//,cambiar
                                                          text: "Ya existe un medicamento registrado con los mismo datos!, puede buscar el medicamento en la pestaña de búsqueda o bien seleccionarlo de su lista de medicamentos más usados ",
                                                          timer: 1800,
                                                          showConfirmButton: false
                                                      }
                                                      )
                                              .catch(swal.noop);
                          //return false;
                        }
                        //else{
                            //YA EXISTE UN MEDICAMENTO CON ESOS DATOS
                            //return false;
                        //}
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

  }


    ///-------------------------------------------------

        //EVENTOS PARA BLOUEAR LA ESCRITURA
        $("#medicamento").blur(function(){
                $(this).prop("readonly",""); 
          });

            $("#medicamento").focus(function(){
                $(this).prop("readonly","readonly"); 
          });

        //LISTA DESPLEGABLE PARA REGISTRAR UN GENÉRICO

        var optionsGenerico = {

              url: "<?php echo base_url('medico/Consulta/getGenericosOMedicamentos');?>",

              getValue: "nombre_generico",
              placeholder: "Escriba el nombre de un medicamento o genérico ..",
              theme: "bootstrap",

              template: {
                type: "custom",

                method:function(value,item){
                  var nombreGenerico=item.nombre_generico;
                  return nombreGenerico.trim();
                }
              },

              list: {
               
                //maxNumberOfElements: 7,
                match: {
                  enabled: true
                }
              }
            };

            $("#RegistroNombreGenerico").easyAutocomplete(optionsGenerico);
        //----------------------------------------------------------------------

        //LISTADO DE FORMA FARMACEUTICA
         var optionsForma = {

              url: "<?php echo base_url('medico/Consulta/getFormaFarmaceutica');?>",

              getValue: "forma_farmaceutica",
              placeholder: "Indique la forma farmacéutica",
              theme: "bootstrap",

              template: {
                type: "custom",

                method:function(value,item){
                  var forma_farmaceutica=item.forma_farmaceutica;
                  return forma_farmaceutica.trim();
                }
              },

              list: {
               
                //maxNumberOfElements: 7,
                match: {
                  enabled: true
                }
              }
            };

            $("#RegistroFormaFarmaceutica").easyAutocomplete(optionsForma);


        //LISTADO DE CONCENTRACIÓN
        var optionsConcentracion = {

                url: "<?php echo base_url('medico/Consulta/getConcentracion');?>",

                getValue: "concentracion",
                placeholder: "Escriba la concentración del medicamento o genérico",
                theme: "bootstrap",

                template: {
                  type: "custom",

                  method:function(value,item){
                    var concentracion=item.concentracion;
                    return concentracion.trim();
                  }
                },

                list: {
                 
                  //maxNumberOfElements: 7,
                  match: {
                    enabled: true
                  }
                }
              };

              $("#RegistroConcentracion").easyAutocomplete(optionsConcentracion);

        //LISTADO DE PRESENTACIÓN
        var optionsPresentacion = {

                  url: "<?php echo base_url('medico/Consulta/getPresentacion');?>",

                getValue: "presentacion",
                placeholder: "Indique la presentación del medicamento o genérico",
                theme: "bootstrap",

                template: {
                  type: "custom",

                  method:function(value,item){
                    var presentacion=item.presentacion;
                    return presentacion.trim();
                  }
                },

                list: {
                 
                  //maxNumberOfElements: 7,
                  match: {
                    enabled: true
                  }
                }
              };

              $("#RegistroPresentacion").easyAutocomplete(optionsPresentacion);


        //LISTADO DE DOSIS

                var optionsDosis = {

                  url: "<?php echo base_url('medico/Consulta/getDosisDiariaDefinida');?>",

              getValue: "dosis_diaria_definida",
              placeholder: "Indique la dosis diaria definida",
              theme: "bootstrap",

              template: {
                type: "custom",

                method:function(value,item){
                  var dosis_diaria_definida=item.dosis_diaria_definida;
                  return dosis_diaria_definida;
                }
              },

              list: {
               
                //maxNumberOfElements: 7,
                match: {
                  enabled: true
                }
              }
            };

            $("#RegistroDosisDiariaDefinida").easyAutocomplete(optionsDosis);





            setInterval(checkboxTratamiento, 1);

              function checkboxTratamiento(){

                if($('#checkBoxTratamiento').prop('checked')){
                  
                  $('#inicio_trat').val("");
                  $('#fin_trat').val("");

                  $('#inicio_trat').prop("disabled", true ); 
                  $('#fin_trat').prop("disabled", true ); 
                }
                else{
                  $('#inicio_trat').prop("disabled", false ); 
                  $('#fin_trat').prop("disabled", false ); 
                }

            }

    </script>


    <script type="text/javascript">

    //VARIABLES TEMPORALES
    var options = {
      url: "<?php echo base_url('medico/Consulta/getGenericos');?>",

      getValue: "nombre_generico",
      placeholder: "Escriba el nombre de un genérico ..",
      theme: "bootstrap",

      template: {
        type: "custom",

        method:function(value,item){
          var forma="";
          var concentra="";
          if(item.forma_farmaceutica.length>20){
            forma=item.forma_farmaceutica.substring(0,20)+" ...";

          }
          else{
            forma=item.forma_farmaceutica
          }

          if(item.concentracion.length>20){
            concentra=item.concentracion.substring(0,20)+" ...";

          }
          else{
            concentra=item.concentracion
          }


          return item.nombre_generico+" - "+forma+" ("+concentra+")";
        }
      },


      list: {
       
        //maxNumberOfElements: 7,
        match: {
          enabled: true
        },

        onSelectItemEvent: function() {
          var id_m = $("#nombre-medicamento-Escrito").getSelectedItemData().id_medicamento;
          var generico = $("#nombre-medicamento-Escrito").getSelectedItemData().nombre_generico;
          var presentacion = $("#nombre-medicamento-Escrito").getSelectedItemData().presentacion;
          var forma_farmaceutica = $("#nombre-medicamento-Escrito").getSelectedItemData().forma_farmaceutica;
          var concentracion = $("#nombre-medicamento-Escrito").getSelectedItemData().concentracion;

          var a=$("#id-medicamento1").val(id_m).trigger("change");
          var b=$("#presentacion1").val(presentacion).trigger("change");
          var c=$("#forma_farmaceutica1").val(forma_farmaceutica).trigger("change");
          var d=$("#concentracion1").val(concentracion).trigger("change");

          $("#medicamentoAlSerBuscado").val("-"+generico.trim()+" ("+d.val().trim()+") "+c.val().trim()).trigger("change");
        }
      }
    };
    
    var arregloDemedicamentosSeleccionadosDelTratamiento=[];
    var arregloDemedicamentosSeleccionadosDelTratamientoAbierto=[];
    //---------------------------------------------------------------------
      $('#TapMedicamentosMasFrecuentes').click(function(){
        //alert("Precionaste el botón frecuente");
        listarMedicamentosUsadosPor(id_doctor);
      });
    //-------------> > > 
    //---------------------------------------------------------------------


    //LISTA DE EVENTOS
    $("#nombre-medicamento-Escrito").easyAutocomplete(options);

    $('#btn-medicamentoAlSerBuscado').click(function(){
      if($('#medicamentoAlSerBuscado').val()!=""){

        var opcion=$('input:radio[name=optradio]:checked').val();
          if(opcion==1){
            //$('#id-medicamento').val($('#id-medicamento1').val());
            $('#medicamentoAbierto').val($('#medicamentoAlSerBuscado').val().trim());

            $('#id-medicamento1').val("");
            $('#medicamentoAlSerBuscado').val("");
            $('#nombre-medicamento-Escrito').val("");
            

            $('#ModalAgregarMedicamento').modal('hide');
        }
        else{
          $('#id-medicamento').val($('#id-medicamento1').val());
          $('#medicamento').val($('#medicamentoAlSerBuscado').val().trim());

          $('#id-medicamento1').val("");
          $('#medicamentoAlSerBuscado').val("");
          $('#nombre-medicamento-Escrito').val("");
          
          $('#ModalAgregarMedicamento').modal('hide');

      }

          


          }
    });

    $('#medicamentosFrecuenciados').on('click', '.item-seleccionar-como-parte-de-tratamiento', function(){
        //Recuperamos el diagnostico selecionado
        var variableIdMedicamentoSeleccionado               = $(this).attr('id-medicamento');
        var variableNombreDeMedicamentoGenericoSeleccionado = $(this).attr('nombre-generico');
        var variablePresentacionMedicamentoSeleccionado     = $(this).attr('presentacion');
        var variableFormaFarmaMedicamentoSeleccionado     = $(this).attr('forma-farmaceutica');  
        var variableConcentracionMedicamentoSeleccionado    = $(this).attr('concentracion'); 

        var opcion=$('input:radio[name=optradio]:checked').val();
          if(opcion==1){
            //Asignamos el medicamento a la vista porincipal con todos los datos relevantes para su respectiva creacion!
            //$('#id-medicamentoo-').val(variableIdMedicamentoSeleccionado);
            $('#medicamentoAbierto').val(variableNombreDeMedicamentoGenericoSeleccionado.trim() +" ("+variableConcentracionMedicamentoSeleccionado.trim()+") "+variableFormaFarmaMedicamentoSeleccionado.trim());
            //Cerramos el modal 
            $('#ModalAgregarMedicamento').modal('hide');
        }
        else{
            //Asignamos el medicamento a la vista porincipal con todos los datos relevantes para su respectiva creacion!
            $('#id-medicamento').val(variableIdMedicamentoSeleccionado);
            $('#medicamento').val(variableNombreDeMedicamentoGenericoSeleccionado.trim() +" ("+variableConcentracionMedicamentoSeleccionado.trim()+") "+variableFormaFarmaMedicamentoSeleccionado.trim());
            //Cerramos el modal 
            $('#ModalAgregarMedicamento').modal('hide');
        }
        
    });

    $('#medicamentosFrecuenciadosBusqueda').on('click', '.item-seleccionar-como-parte-de-tratamiento', function(){
          var variableIdMedicamentoSeleccionado               = $(this).attr('id-medicamento');
          var variableNombreDeMedicamentoGenericoSeleccionado = $(this).attr('nombre-generico');
          var variablePresentacionMedicamentoSeleccionado     = $(this).attr('presentacion'); 
          var variableConcentracionMedicamentoSeleccionado    = $(this).attr('concentracion'); 

          //Asignamos el medicamento a la vista porincipal con todos los datos relevantes para su respectiva creacion!
           $('#id-medicamento').val(variableIdMedicamentoSeleccionado);
          $('#medicamento').val(variableNombreDeMedicamentoGenericoSeleccionado);
          //Cerramos el modal 
          $('#ModalAgregarMedicamento').modal('hide');
      });


            $('#btn-agregarAlTratamientoParaAlmacenarAbierto').click(function(){

        //var id_medicamento   = $('#id-medicamento').val();
        var medicamento      = $('#medicamentoAbierto').val()+" ";
        //var num_dosis        = $('#dosis').val();//Falta contemplarla
        //var dosis            = $('select[name=dosis] option:selected').text();
        var frec_dosis       = $('#frec_dosis_abierto').val();
        //var via_adm          = $('select[name=via_de_admin] option:selected').text();
        var id_via_adm       = $('#via_de_admin_abierto').val();
        //alert(id_via_adm);
        //var num_via_adm      = $('#via_de_admin').val();//Falta contemplarla
        //var inicio_trat      = $('#inicio_trat').val();
        //var fin_trat         = $('#fin_trat').val();
        var indicaciones_gral= $('#indicaciones_gralesAbierto').val();
        if(indicaciones_gral.trim()==""){
          indicaciones_gral="Ninguno"
        }


        if(medicamento.trim()!=""&&frec_dosis.trim()!=""&&id_via_adm.trim()!=""){
            
          //var estadoIndeterminado='0';

          //if($('#checkBoxTratamiento').prop('checked')){
            //estadoIndeterminado='1';
          //}

            var medicamento={medicamento:medicamento,frecuencia:frec_dosis,via_adm:id_via_adm,indicaciones:indicaciones_gral}
            arregloDemedicamentosSeleccionadosDelTratamientoAbierto.push(medicamento);
            //alert(arregloDemedicamentosSeleccionadosDelTratamientoAbierto[0].via_adm);
            dibujaTablaDeTratamientoSeleccionadoAbierto();
                
            $('#formularioDeTratamientoModalAbierto').trigger("reset");
            return false;
        }
    });

    $('#btn-agregarAlTratamientoParaAlmacenar').click(function(){

        var id_medicamento   = $('#id-medicamento').val();
        var medicamento      = $('#medicamento').val()+" ";
        var num_dosis        = $('#dosis').val();//Falta contemplarla
        var dosis            = $('select[name=dosis] option:selected').text();
        var frec_dosis       = $('#frec_dosis').val();
        var via_adm          = $('select[name=via_de_admin] option:selected').text();
        var id_via_adm       = $('#via_de_admin').val();
        //var num_via_adm      = $('#via_de_admin').val();//Falta contemplarla
        var inicio_trat      = $('#inicio_trat').val();
        var fin_trat         = $('#fin_trat').val();
        var indicaciones_gral= $('#indicaciones_grales').val();


        if((id_medicamento!=""&&medicamento!=""&&dosis!=""&&frec_dosis!=""&&via_adm!=""&&indicaciones_gral!="")&&((inicio_trat!=""&&fin_trat!="")||($('#checkBoxTratamiento').prop('checked')))){
            
          var estadoIndeterminado='0';

          if($('#checkBoxTratamiento').prop('checked')){
            estadoIndeterminado='1';
          }

            var medicamento={id_medicamento:id_medicamento,medicamento:medicamento,dosis:dosis,frecuencia:frec_dosis,id_via_adm:id_via_adm,via_admin:via_adm,indeterminado:estadoIndeterminado,fecha_inicio:inicio_trat,fecha_termino:fin_trat,indicaciones:indicaciones_gral}
            arregloDemedicamentosSeleccionadosDelTratamiento.push(medicamento);
            dibujaTablaDeTratamientoSeleccionado();
                
            $('#formularioDeTratamientoModal').trigger("reset");
            return false;
        }
    });

    $('#btnFinalizarTratamientoAbierto').click(function(){
        var i=0;
        var texto='\n';
        var tam_max=arregloDemedicamentosSeleccionadosDelTratamientoAbierto.length;

          for(i;i<arregloDemedicamentosSeleccionadosDelTratamientoAbierto.length;i++){

            

              texto=texto+" - Medicamento ó Genérico: "             + arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].medicamento+
                        
                   " -Frecuencia y duracíon del tratamiento: "                 + arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].frecuencia+
                   " -Via de administración: "      + arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].via_adm+
                   " -Indicaciones generales: "            + arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].indicaciones;

            

            
                   
                texto=texto+'\n\n';
            }

        
        
        //Obtenemos el tamaño de la tabla
        var num_elementos=$("#tabla-general-tratamientos-formulados-abierto tr").length;
        if(num_elementos>1){
          document.getElementById("indicaciones_gral").value=texto;
            $('#ModalCrearTratamientoAbierto').modal('hide');
        }
        else{
            swal({
                title: "No ha agregado genéricos a la lista del tratamiento!",
                text: "Si decea salir sin formular el tratamiento, puede precionar la (X) de la parte superior de la ventana!",
                type: "warning",
                timer: 2000,
                showConfirmButton: false
            }).catch(swal.noop);
        }
    });

    $('#btnFinalizarTratamiento').click(function(){
        var i=0;
        var texto='\n';
        var tam_max=arregloDemedicamentosSeleccionadosDelTratamiento.length;

          for(i;i<arregloDemedicamentosSeleccionadosDelTratamiento.length;i++){

            if(arregloDemedicamentosSeleccionadosDelTratamiento[i].indeterminado){

              texto=texto+" - Medicamento ó Genérico: "             + arregloDemedicamentosSeleccionadosDelTratamiento[i].medicamento+
                        " -Dosis: "                 + arregloDemedicamentosSeleccionadosDelTratamiento[i].dosis+
                   " -Frecuencia: "                 + arregloDemedicamentosSeleccionadosDelTratamiento[i].frecuencia+
                   " -Via de administración: "      + arregloDemedicamentosSeleccionadosDelTratamiento[i].via_admin+
                   " -Tratamiento indeterminado"    + 
            " -Indicaciones generales: "            + arregloDemedicamentosSeleccionadosDelTratamiento[i].indicaciones;

            }
            else{

              texto=texto+" - Genérico: "             + arregloDemedicamentosSeleccionadosDelTratamiento[i].medicamento+
                        " -Dosis: "                 + arregloDemedicamentosSeleccionadosDelTratamiento[i].dosis+
                   " -Frecuencia: "                 + arregloDemedicamentosSeleccionadosDelTratamiento[i].frecuencia+
                   " -Via de administración: "      + arregloDemedicamentosSeleccionadosDelTratamiento[i].via_admin+
                   " -Fecha de inicio: "            + arregloDemedicamentosSeleccionadosDelTratamiento[i].fecha_inicio+ 
                   " -Fecha de término: "           + arregloDemedicamentosSeleccionadosDelTratamiento[i].fecha_termino+
            " -Indicaciones generales: "            + arregloDemedicamentosSeleccionadosDelTratamiento[i].indicaciones;

            }

            
                   
                texto=texto+'\n\n';
            }

        
        
        //Obtenemos el tamaño de la tabla
        var num_elementos=$("#tabla-general-tratamientos-formulados tr").length;
        if(num_elementos>1){
          document.getElementById("indicaciones_gral").value=texto;
            $('#ModalCrearTratamiento').modal('hide');
        }
        else{
            swal({
                title: "No ha agregado genéricos a la lista del tratamiento!",
                text: "Si decea salir sin formular el tratamiento, puede precionar la (X) de la parte superior de la ventana!",
                type: "warning",
                timer: 2000,
                showConfirmButton: false
            }).catch(swal.noop);
        }
    });


        $('#tratamientoFormuladoHastaElMomentoAbierto').on('click', '.item-rangoAEliminarDelTratamiento', function(){
      
            var a=0;
            var b=0;

            a=$(this).attr('rangoAEliminarA'); 
            b=$(this).attr('rangoAEliminarB'); 

            $('#deleteMedicamentoModal').modal('show');
            $('#btnDeleteTratamiento').unbind().click(function(){
              //alert("Eliminando");
                arregloDemedicamentosSeleccionadosDelTratamientoAbierto.splice(a,b);
                dibujaTablaDeTratamientoSeleccionadoAbierto();
                $('#deleteMedicamentoModal').modal('hide');
            });
        });



    $('#tratamientoFormuladoHastaElMomento').on('click', '.item-rangoAEliminarDelTratamiento', function(){
      
        var a=0;
        var b=0;

        a=$(this).attr('rangoAEliminarA'); 
        b=$(this).attr('rangoAEliminarB'); 

        $('#deleteMedicamentoModal').modal('show');
        $('#btnDeleteTratamiento').unbind().click(function(){
          //alert("Eliminando");
            arregloDemedicamentosSeleccionadosDelTratamiento.splice(a,b);
            dibujaTablaDeTratamientoSeleccionado();
            $('#deleteMedicamentoModal').modal('hide');
        });
    });

    $('#generar-tratamiento').click(function(){

      var opcion=$('input:radio[name=optradio]:checked').val();
                if(opcion==1){
                  //TRATAMIENTO ABIERTO
                  //limpiaCamposDeTratamiento();
                  $('#ModalCrearTratamientoAbierto').modal('show');
                  //if($("#tabla-general-tratamientos-formulados tr").length==1){
                   //$('.alert-info').html('<p align="justify"><strong>Nota!</strong> En la parte inferior de este mensaje se enlistarán los nombres de los genéricos que haya solicitado para el tratamiento correspondiente!, si decea ver más informacion  basta con posicionar el cursor del ratón sobre una de los renglones de la tabla. Al terminar con el tratamiento precione el boton de "Formular Tratamiento" para resguardar la información.</p>').fadeIn().delay(9000).fadeOut('slow');
                  //}
              }
              else{
                //TRATAMIENTO CERRADO
                limpiaCamposDeTratamiento();
                $('#ModalCrearTratamiento').modal('show');
                if($("#tabla-general-tratamientos-formulados tr").length==1){
                 $('.alert-info').html('<p align="justify"><strong>Nota!</strong> En la parte inferior de este mensaje se enlistarán los nombres de los genéricos que haya solicitado para el tratamiento correspondiente!, si decea ver más informacion  basta con posicionar el cursor del ratón sobre una de los renglones de la tabla. Al terminar con el tratamiento precione el boton de "Formular Tratamiento" para resguardar la información.</p>').fadeIn().delay(9000).fadeOut('slow');
                }
            }

      
    });

    $('#medicamento').click(function(){
      $('#ModalAgregarMedicamento').modal('show');
      $('.mensaje-registro-medicamento').html('<p align="justify">En la parte inferior de este mensaje se presenta un formulario para registrar un medicamento, con la finalidad de emplearlo como parte de un tratamiento.<p/><p align="justify"> <strong>Nota:</strong> Una vez registrado el medicamento, ya no será necesario volver a llenar los campos para añadir éste tratamiento en consultas posteriores, ya que sólo bastará con seleccionarlo de su lista de medicamentos más usados localizado en esta vista, en la pestaña "Más usados".</p>').fadeIn();
    });

    $('#BuscaTratamientoAbierto').click(function(){
      $('#ModalAgregarMedicamento').modal('show');
      $('.mensaje-registro-medicamento').html('<p align="justify">En la parte inferior de este mensaje se presenta un formulario para registrar un medicamento, con la finalidad de emplearlo como parte de un tratamiento.<p/><p align="justify"> <strong>Nota:</strong> Una vez registrado el medicamento, ya no será necesario volver a llenar los campos para añadir éste tratamiento en consultas posteriores, ya que sólo bastará con seleccionarlo de su lista de medicamentos más usados localizado en esta vista, en la pestaña "Más usados".</p>').fadeIn();
    });

    //EVENTOS PARA BLOUEAR LA ESCRITURA
    $("#indicaciones_gral").blur(function(){
            $(this).prop("readonly",""); 
      });

        $("#indicaciones_gral").focus(function(){
            $(this).prop("readonly","readonly"); 
      });



    //LISTA DE FUNCIONES
    function listarMedicamentosUsadosPor(id_medico){
      $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/medicamentos/listarMedicamentosUsadosPor',
               data:{id_medico:id_medico},
               dataType: 'json',
               success: function(data){
                    if(data==false){

                        var html = '';
                        $('#medicamentosFrecuenciados').html(html);
                            
                        $('.alert-danger').html('Actualmente no cuenta con una lista de medicamentos usados!').fadeIn().delay(2200).fadeOut('slow');
              

                    }
                    else{

                    var html = '';
                        var i;
                        html +='<table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-medicamentos-usados">'+
                                            '<thead>'+
                                            '<tr>'+
                                                '<th>GENÉRICO</th>'+
                                                '<th>PRESENTACIÓN</th>'+
                                                '<th><CENTER>FORMA FARMACÉUTICA</CENTER></th>'+
                                                '<th><CENTER>CONC.</CENTER></th>'+
                                                '<th><center>ACCIONES</center></th>'+
                                            '</tr>'+
                                            '</thead>'+
                                                '<tbody>';
                                            for(i=0; i<data.length; i++){
                                                html +='<tr>'+
                                                '<td>'+data[i].nombre_generico+'</td>'+
                                                '<td>'+data[i].presentacion+'</td>'+
                                                '<td>'+data[i].forma_farmaceutica+'</td>'+
                                                '<td>'+data[i].concentracion+'</td>'+
                                                '<td>'+
                                                '<center>'+
                                                    //'<a href="javascript:;" data="'+data[i].id_medicamento+'" type="button" class="btn btn-default item-id-edit" style="color:#29A9CC" title="Editar Categoría"><i class="glyphicon glyphicon-pencil"></i></a>'+
                                                    '<a href="javascript:;" id-medicamento="'+data[i].id_medicamento+'" '+'nombre-generico="'+data[i].nombre_generico+'" '+'forma-farmaceutica="'+data[i].forma_farmaceutica+'" '+'presentacion="'+data[i].presentacion+'" concentracion="'+data[i].concentracion+'" class="btn btn-default item-seleccionar-como-parte-de-tratamiento" style="color:GREEN" title="Seleccionar como genérico"><i class="glyphicon glyphicon-share-alt"></i></a>'+
                                                '<center>'+                                                                              
                                                '</td>'+
                                                '</tr>';
                                            }
                                            html +='</tbody>'+'</table>';
                                            
                                            $('#medicamentosFrecuenciados').html(html);

                                             //--CONTEMOS LAS FILAS PARA QUE APAREZCA EL SCROLL
                                            var filas=$("#tabla-medicamentos-usados tr").length;
                                            if(filas>4){

                                              //$("#tabla-general tr").css({'display':'inline-table'});
                                              //$("#estatico").css({'width':'500px',});

                                              $("#tabla-medicamentos-usados").css({'overflow-y':'scroll','height':'380px','display':'block'});
                                              //alert("El total de filas es mayor a: "+filas);
                                            }
                                          }
                           
                  
                   
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });

        }

    function limpiaCamposDeTratamiento(){
        $('#medicamento').val("");
        $('#dosis').val("");
        $('#frec_dosis').val("");
        $('#via_de_admin').val("");
        $('#inicio_trat').val("");
        $('#fin_trat').val("");
        $('#indicaciones_gral').val("");
     }

    function dibujaTablaDeTratamientoSeleccionadoAbierto(){
                     if(arregloDemedicamentosSeleccionadosDelTratamientoAbierto.length==0){
                        var html = '';
                        $('#tratamientoFormuladoHastaElMomentoAbierto').html(html);
                    }
                    else{
                        var html = '';
                        var i;
                        var complemento;
                        for(i=0; i<arregloDemedicamentosSeleccionadosDelTratamientoAbierto.length; i++){
                            complemento=i+1;
                            var texto_hover=" - Medicamento ó Genérico: "             + arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].medicamento+'\n'+
                                                       " Frecuencia y tiempo del tratamiento: "                 + arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].frecuencia+'\n'+
                                                       " Via de administración: "      + arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].via_adm+'\n'+
                                                       " Indicaciones generales: "           + arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].indicaciones+'\n';
                           
                           html +='<tr title="'+texto_hover+'">'+
                                        '<td>'+arregloDemedicamentosSeleccionadosDelTratamientoAbierto[i].medicamento+'</td>'+
                                        '<td>'+
                                            '<center>'+
                                                '<a href="javascript:;" class="btn btn-default item-rangoAEliminarDelTratamiento" rangoAEliminarA="'+i+'" '+'rangoAEliminarB="'+complemento+'" style="color:RED" title="Eliminar el medicamento ó genérico del tratamiento!"><i class="glyphicon glyphicon-remove"></i></a>'+
                                            '<center>'+                                                                                
                                        '</td>'+
                                    '</tr>';
                        }

                        $('#tratamientoFormuladoHastaElMomentoAbierto').html(html);

                        var filas=$("#tabla-general-tratamientos-formulados-abierto tr").length;

                            if(filas>7){
                                $("#tabla-general-tratamientos-formulados-abierto").css({'overflow-y':'scroll','height':'150px','width':'400px','display':'block'});
                            }
                        }
    }

    function dibujaTablaDeTratamientoSeleccionado(){
                     if(arregloDemedicamentosSeleccionadosDelTratamiento.length==0){
                        var html = '';
                        $('#tratamientoFormuladoHastaElMomento').html(html);
                    }
                    else{
                        var html = '';
                        var i;
                        var complemento;
                        for(i=0; i<arregloDemedicamentosSeleccionadosDelTratamiento.length; i++){
                            complemento=i+1;
                            var texto_hover=" - Genérico: "             + arregloDemedicamentosSeleccionadosDelTratamiento[i].medicamento+'\n'+
                                                            " Dosis: "                 + arregloDemedicamentosSeleccionadosDelTratamiento[i].dosis+'\n'+
                                                       " Frecuencia: "                 + arregloDemedicamentosSeleccionadosDelTratamiento[i].frecuencia+'\n'+
                                                       " Via de administración: "      + arregloDemedicamentosSeleccionadosDelTratamiento[i].via_admin+'\n'+
                                                       " Fecha de inicio: "            + arregloDemedicamentosSeleccionadosDelTratamiento[i].fecha_inicio+'\n'+
                                                       " Fecha de término: "           + arregloDemedicamentosSeleccionadosDelTratamiento[i].fecha_termino+'\n';
                           
                           html +='<tr title="'+texto_hover+'">'+
                                        '<td>'+arregloDemedicamentosSeleccionadosDelTratamiento[i].medicamento+'</td>'+
                                        '<td>'+
                                            '<center>'+
                                                '<a href="javascript:;" class="btn btn-default item-rangoAEliminarDelTratamiento" rangoAEliminarA="'+i+'" '+'rangoAEliminarB="'+complemento+'" style="color:RED" title="Eliminar el genérico del tratamiento!"><i class="glyphicon glyphicon-remove"></i></a>'+
                                            '<center>'+                                                                                
                                        '</td>'+
                                    '</tr>';
                        }

                        $('#tratamientoFormuladoHastaElMomento').html(html);

                        var filas=$("#tabla-general-tratamientos-formulados tr").length;

                            if(filas>7){
                                $("#tabla-general-tratamientos-formulados").css({'overflow-y':'scroll','height':'150px','width':'400px','display':'block'});
                            }
                        }
    }



    </script>


<!--              FIN AREA DE TRATAMIENTO         -->


<!-- Creates the bootstrap modal where the image will appear -->
<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <center><h1 id="prev" class="btn btn-default glyphicon glyphicon-chevron-left"></h1><img src="" id="imagepreview" style="width: auto; max-width:70%; max-height:70%; height:auto;  margin-top:2%;"><h1 id="next" class="btn btn-default glyphicon glyphicon-chevron-right"></h1><br><h1 id="closeModal" class="btn btn-default glyphicon glyphicon-remove"></h1></center>
</div>

<script> 
    
    
    function seleccionarCategoria(id_categoria){

        if(id_categoria!=""){
            if(id_categoria==0){
                todas();
            }
            else{
                porCategoria(id_categoria);
            }
        }

    }

    
    $('#search').click(function(){
        
        var busqueda=$('#description1').val();
        if(busqueda!=""){
            busquedaTodasDesc($('#description1').val());
        }
        
       
           
        
    });
    
    
    var arreglo;
    var ima;
    var index;
    var id_m = "<?php echo $medico_logueado[0]->id_medico;?>";
    $.ajax({
        type: 'ajax',
        method: 'get',
        async: false,
        url: '<?php echo base_url() ?>medico/categoria/getImg',
        data: {id_medico:id_m},
        dataType: 'json',
        success: function(data){
            arreglo = data;
            //console.log(arreglo);
            //todas(arreglo);
        },
        error: function(){
            alert('1 Could not get Data from Database');
        }
        });
    function todas()
    {
        var meses = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
        var html = '';
        var fecha;
        for (i = 0; i < arreglo.length; i++) 
        {
            
            var nombreArchivo= arreglo[i].nombreArchivo;
            var descripcion = arreglo[i].descripcion;
            var fecha_creacion = arreglo[i].fecha_creacion;
            //fecha_creacion in SQL DATETIME format ("yyyy-mm-dd hh:mm:ss")
            var sqlDateArr1 = fecha_creacion.split("-");
            var sYear = sqlDateArr1[0];
            var sMonth = (Number(sqlDateArr1[1]) - 1).toString();
            var sqlDateArr2 = sqlDateArr1[2].split(" ");
            var sDay = sqlDateArr2[0];
            var sqlDateArr3 = sqlDateArr2[1].split(":");
            var sHour = sqlDateArr3[0];
            var sMinute = sqlDateArr3[1];
            var sqlDateArr4 = sqlDateArr3[2].split(".");
            var sSecond = sqlDateArr4[0];
            fecha = new Date(sYear,sMonth,sDay,sHour,sMinute,sSecond);
            html += 
            '<div class="col-md-2"><div class="thumbnail"><img onclick="verImagen(&#39;'+nombreArchivo+'&#39;);" src="<?php echo base_url("uploads/galeria/");?>'+nombreArchivo+'" style="width:auto; height: 100px;"><div class="caption" >'+'<center><h4 style="color:#AA7182">'+descripcion+'</h4></center></div></div></div>';
        }
        
        //console.log("Base: " + fecha_creacion);
        //console.log("JavaScript: "+fecha);
        $('#row_galeria').html(html);
    }
    
    function porCategoria(cat)
    {
        var meses = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
        var html = '';
        var fecha;
        for (i = 0; i < arreglo.length; i++) 
        {
            
            if(arreglo[i].id_categoria == cat)
            {
                var nombreArchivo= arreglo[i].nombreArchivo;
                var descripcion = arreglo[i].descripcion;
                var fecha_creacion = arreglo[i].fecha_creacion;
                //fecha_creacion in SQL DATETIME format ("yyyy-mm-dd hh:mm:ss")
                var sqlDateArr1 = fecha_creacion.split("-");
                var sYear = sqlDateArr1[0];
                var sMonth = (Number(sqlDateArr1[1]) - 1).toString();
                var sqlDateArr2 = sqlDateArr1[2].split(" ");
                var sDay = sqlDateArr2[0];
                var sqlDateArr3 = sqlDateArr2[1].split(":");
                var sHour = sqlDateArr3[0];
                var sMinute = sqlDateArr3[1];
                var sqlDateArr4 = sqlDateArr3[2].split(".");
                var sSecond = sqlDateArr4[0];
                fecha = new Date(sYear,sMonth,sDay,sHour,sMinute,sSecond);
                html += 
                '<div class="col-md-2"><div class="thumbnail"><img onclick="verImagen(&#39;'+nombreArchivo+'&#39;);" src="<?php echo base_url("uploads/galeria/");?>'+nombreArchivo+'" style="width:auto; height: 100px;"><div class="caption" >'+'<center><h4 style="color:#AA7182">'+descripcion+'</h4></center></div></div></div>';
            }
        }
        
        //console.log("Base: " + fecha_creacion);
        //console.log("JavaScript: "+fecha);
        $('#row_galeria').html(html);
    }
    function busquedaTodasDesc(desc)
    {
        var meses = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
        var html = '';
        var fecha;
        for (i = 0; i < arreglo.length; i++) 
        {
           var descripcion = arreglo[i].descripcion;
            if (descripcion.indexOf(desc) > -1) 
            { 
                var nombreArchivo= arreglo[i].nombreArchivo;
                var descripcion = arreglo[i].descripcion;
                var fecha_creacion = arreglo[i].fecha_creacion;
                //fecha_creacion in SQL DATETIME format ("yyyy-mm-dd hh:mm:ss")
                var sqlDateArr1 = fecha_creacion.split("-");
                var sYear = sqlDateArr1[0];
                var sMonth = (Number(sqlDateArr1[1]) - 1).toString();
                var sqlDateArr2 = sqlDateArr1[2].split(" ");
                var sDay = sqlDateArr2[0];
                var sqlDateArr3 = sqlDateArr2[1].split(":");
                var sHour = sqlDateArr3[0];
                var sMinute = sqlDateArr3[1];
                var sqlDateArr4 = sqlDateArr3[2].split(".");
                var sSecond = sqlDateArr4[0];
                fecha = new Date(sYear,sMonth,sDay,sHour,sMinute,sSecond);
                html += 
                '<div class="col-md-2"><div class="thumbnail"><img onclick="verImagen(&#39;'+nombreArchivo+'&#39;);" src="<?php echo base_url("uploads/galeria/");?>'+nombreArchivo+'" style="width:auto; height: 100px;"><div class="caption" >'+'<center><h4 style="color:#AA7182">'+descripcion+'</h4></center></div></div></div>';
            }
        }
        
        //console.log("Base: " + fecha_creacion);
        //console.log("JavaScript: "+fecha);
        $('#row_galeria').html(html);
    }
    function busquedaCatDesc(cat, desc)
    {
        var meses = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
        var html = '';
        var fecha;
        for (i = 0; i < arreglo.length; i++) 
        {
            
            if(arreglo[i].id_categoria == cat)
            {
               var descripcion = arreglo[i].descripcion;
                if (descripcion.indexOf(desc) > -1) 
                { 
                    var nombreArchivo= arreglo[i].nombreArchivo;
                    var descripcion = arreglo[i].descripcion;
                    var fecha_creacion = arreglo[i].fecha_creacion;
                    //fecha_creacion in SQL DATETIME format ("yyyy-mm-dd hh:mm:ss")
                    var sqlDateArr1 = fecha_creacion.split("-");
                    var sYear = sqlDateArr1[0];
                    var sMonth = (Number(sqlDateArr1[1]) - 1).toString();
                    var sqlDateArr2 = sqlDateArr1[2].split(" ");
                    var sDay = sqlDateArr2[0];
                    var sqlDateArr3 = sqlDateArr2[1].split(":");
                    var sHour = sqlDateArr3[0];
                    var sMinute = sqlDateArr3[1];
                    var sqlDateArr4 = sqlDateArr3[2].split(".");
                    var sSecond = sqlDateArr4[0];
                    fecha = new Date(sYear,sMonth,sDay,sHour,sMinute,sSecond);
                    html += 
                    '<div class="col-md-2"><div class="thumbnail"><img onclick="verImagen(&#39;'+nombreArchivo+'&#39;);" src="<?php echo base_url("uploads/galeria/");?>'+nombreArchivo+'" style="width:auto; height: 100px;"><div class="caption" >'+'<center><h4 style="color:#AA7182">'+descripcion+'<a class="glyphicon glyphicon-trash" href="../categoria/eliminarImagen/'+nombreArchivo+'"></a></h4></center></div></div></div>';
                }
                    
            }
        }
        
        //console.log("Base: " + fecha_creacion);
        //console.log("JavaScript: "+fecha);
        $('#row_galeria').html(html);
    }
    
    function verImagen(img)
    {
        ima =img;
        $('#imagepreview').attr('src',"<?php echo base_url('uploads/galeria/');?>"+img );
        $('#imagemodal').modal('show');
    }
    $('#closeModal').click(function(){
        $('#imagemodal').modal('hide');
    });
    $('#prev').click(function(){
        for(var i = 0; i<arreglo.length; i++)
        {
            if(arreglo[i].nombreArchivo == ima)
            {
                index = i;
            }
        }
        index -= 1;
        if(index<0)
        {
            index = arreglo.length-1;
        }
        $('#imagepreview').attr('src',"<?php echo base_url('uploads/galeria/');?>"+arreglo[index].nombreArchivo );
        ima = arreglo[index].nombreArchivo;
    });
    $('#next').click(function(){
        for(var i = 0; i<arreglo.length; i++)
        {
            if(arreglo[i].nombreArchivo == ima)
            {
                index = i;
            }
        }
        index += 1;
        if(index == arreglo.length)
        {
            index = 0;
        }
        $('#imagepreview').attr('src',"<?php echo base_url('uploads/galeria/');?>"+arreglo[index].nombreArchivo );
        ima = arreglo[index].nombreArchivo;
    });
    
</script>

<style type="text/css">
.camposNecesarios{
  color: red;/*tengo que hacer que solo cambie este color del texto para que no se pinte lo demas de rojo*/
}
</style>
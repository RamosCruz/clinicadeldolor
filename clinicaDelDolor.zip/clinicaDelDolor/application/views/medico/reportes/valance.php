<script src="<?php echo base_url('assets/js/Chart.bundle.js');?>"></script>
<script src="<?php echo base_url('assets/js/Chart.bundle.min.js');?>"></script>
<br>

<div class="col-sm-10 col-sm-offset-1">
    <center>
      <h1><strong>Balance de Ingresos</strong></h1>
    </center>
    <br>
    
    
    <div class="panel-group" id="accordion">
        <div class="panel panel-default">
            <div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse1">
                <div class="col-md-offset-1"><h3 style="color:#AF81C9">1. <strong style="color:#336699">Sumatoria de ingresos en un periodo</strong></h3></div>
            </div>
            <div id="collapse1" class="panel-collapse collapse in">
                <div class="panel-body">
                    <center>
                        <div class="form-inline">
                          <div class="form-group">
                            <label for="precioConsulta">Fecha inicio:</label>
                            <div class="input-group date  input-append" id="datetimepicker4">
                              <input type="text" class="form-control input-append" data-format="yyyy-MM-dd" type="text" name="fecha_inicio" id="fecha_inicio" required><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                          </div>


                          <script type="text/javascript">
                          $(function() {
                              var today = new Date();
                              $('#datetimepicker4').datetimepicker({
                                pickTime: false,
                                language: 'es-MX',
                                endDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
                                startDate: new Date(today.getFullYear()-90, today.getMonth(), today.getDate()),

                            });});
                          </script>
                      </div>
                      <div class="form-group">
                        <label for="precioConsulta">Fecha término:</label>
                        <div class="input-group date  input-append" id="datetimepicker5">
                          <input type="text" class="form-control input-append" data-format="yyyy-MM-dd" type="text" name="fecha_termino" id="fecha_termino" required><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                      </div>


                      <script type="text/javascript">
                      $(function() {
                          var today = new Date();
                          $('#datetimepicker5').datetimepicker({
                            pickTime: false,
                            language: 'es-MX',
                            endDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
                            startDate: new Date(today.getFullYear()-90, today.getMonth(), today.getDate()),

                        });});
                      </script>
                  </div>

                  <div class="form-group">
                    <button class="btn btn-success" id="consultaValance">Consultar</button>
                </div>
            </div>


        </center>


        <div class="table-responsive">
          <table class="table table-striped table-bordered table table-hover" style="margin-top: 20px;">
              <thead>


                  <tr>

                     <th><center>Forma de pago</center></th>
                     <th><center>Monto</center></th>
                     <th><center>Subtotal</center></th>
                 </tr>
             </thead>
             <tbody id="contenidoTabla">

             </tbody>

         </table>
     </div>
 </div>
</div>

</div>

<div class="panel panel-default">
    <div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse2">
        <div class="col-md-offset-1"><h3 style="color:#AF81C9">2. <strong style="color:#336699">Gráfica de ganancias en un periodo</strong></h3></div>
    </div>


    <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">
            <!-- --------------- -->
            <div class="col-sm-10 col-sm-offset-1">
                <div id="remplazo">
                    
                </div>
                
            </div>
            <!-- --------------- -->
        </div>
    </div>
</div>







</div>

</div>


<!---->


<script>

var labels=[];
var datas=[];
var arregloCompleto;

$('#consultaValance').click(function(){
    arregloCompleto = null;
    var fecha_inicio = $('#fecha_inicio').val();
    var fecha_termino = $('#fecha_termino').val();
    var id_medico = '<?php echo $medico_logueado[0]->id_medico;?>';
    $.ajax({
        type: 'ajax',
        method: 'get',
        async: false,
        url: '<?php echo base_url() ?>medico/Reportes/valanceMedico',
        data:{id_medico:id_medico,fecha_inicio:fecha_inicio,fecha_termino:fecha_termino},
        dataType: 'json',
        success: function(data){



            arregloCompleto = data.Ganancias;
            data=data.BalanceGral;
            var base_url= "<?php echo base_url(); ?>";
            var total = 0;
            var totalFinal=0;
            var tarjeta=0;
            var efectivo=0;
            var convenio=0;
            var adeudo=0;
            var html = '';
            for (i = 0; i < data.length; i++) {

                if(data[i].formapago==0){
                    adeudo= adeudo+parseInt(data[i].debe);
                }

                if(data[i].formapago==1)
                {
                 efectivo = efectivo + parseInt(data[i].haber);
             }
             else if(data[i].formapago==2)
             {
                tarjeta = tarjeta + parseInt(data[i].haber);
            }else if(data[i].formapago==3)
            {
                convenio = convenio + parseInt(data[i].haber);
            }
            total = efectivo+tarjeta+convenio;
        }
        if(total>0)
        {

            html +='<tr>'+
            '<td><center><img src="'+base_url+'assets/img/formaPagoo1.png'+'" alt="">  Efectivo</center></td>'+
            '<td><center>$'+efectivo+'.00</center></td>'+
            '<td rowspan="3" style="vertical-align:middle" align="center">$'+total+'.00</td></tr>';
            html +='<tr>'+
            '<td><center><img src="'+base_url+'assets/img/formaPagoo2.png'+'" alt="">Vouchers: <b><u>';

            for (i = 0; i < data.length; i++) {
                if(data[i].formapago == 2)
                {
                    html +="<p>"+ data[i].boucher+"</p>";
                }
            } 
            html+='</u></b></center></td>'+
            '<td style="vertical-align:middle"><center>$'+tarjeta+'.00</center></td></tr>';
            html +='<tr>'+
            '<td><center><img src="'+base_url+'assets/img/formaPagoo3.png'+'" alt="">  Convenio</center></td>'+
            '<td><center>$'+convenio+'.00</center></td>'+
            '</tr>';
            totalFinal=total+adeudo;

            html+='<tr>'+
            '<td colspan="2"><center>Pagos sin cobrar</center></td>'+

            '<td><center>$'+adeudo+'.00</center></td>'+

            '</tr>'+

            '<td colspan="2"><center><h3><strong>Total</strong></h3></center></td>'+
            '<td><center><h3>$<strong>'+totalFinal+'</strong>.00</h3></center></td>'+
            '</tr>';

        }
        $('#contenidoTabla').html(html);

        $('#remplazo').html("");

        var vacio='<canvas id="myChart" width="auto" height="auto"></canvas>';

        $('#remplazo').html(vacio);

        labelsArray(arregloCompleto);
    },
    error: function(){
      alert('Could not get Data from Database');
  }
});
});

    function labelsArray (arregloCompleto)
    {
        labels=[];
        for (i = 0; i < arregloCompleto.length; i++) {
            if(labels.length==0){
              labels.push(arregloCompleto[i].fecha_haber);  
            }
            
            for (j = 0; j < labels.length; j++) {
                if(labels.indexOf(arregloCompleto[i].fecha_haber) < 0)
                {
                   labels.push(arregloCompleto[i].fecha_haber);
                }
            } 
        } 
        console.log(labels);
        datasArray();
    }
    
    function datasArray()
    {
        suma = 0;
        for (i = 0; i < labels.length; i++) {
            var suma = 0;
            for (j = 0; j < arregloCompleto.length; j++) {
                if(arregloCompleto[j].fecha_haber == labels[i])
                {
                    suma = suma + parseInt(arregloCompleto[j].haber);
                }
            }
            datas.push(suma);
        } 
        console.log(datas);
        
        
        
        var ctx = document.getElementById("myChart").getContext('2d');
        var chart = new Chart(ctx, {
        // The type of chart we want to create
        type: 'line',

        // The data for our dataset
        data: {
        labels: labels,
        datasets: [{
            label: "Ingreso del día",
            borderColor: 'rgb(21, 230, 0)',
            backgroundColor: 'rgb(198, 255, 192)',
            data: datas,
        }]
        },

        // Configuration options go here
        options: {}
        }
        );
    }
</script>
<!--<h4 style="color:#AF81C9">1. <small style="color:#54D1F1">Antecedentes Gineco-Obstetricos</small></h4>-->
               
            <form  role="form" id="myForm" method="post" action="../../historial/guardarAnteGineObs">
                
                   
                       
                   
                <input value="<?php echo $verPaciente[0]->curp; ?>" type="hidden" name="curp">
                <input value="<?php echo $ant_gin_obs[0]->id_exp; ?>" type="hidden" name="id_exp">
                <?php foreach ($ant_gin_obs as $value)
                   { ?>

            <div class="row">
                        <div class="col-md-6">
                <div class="form-group">
                        <div class="panel panel-info">
                          <div class="panel-heading">Características de la menstruación</div>
                          <div class="panel-body">
                           
                           
                           <div class="form-group">
                                <label for="alergia" class="control-label">Menarquia</label>
                                 <div>
                                 <?php 
                                    $class = array('class' => 'menarquia', 'required'=> 'true');
                                    if($value->menarquia=='Si'){
                                    echo '<label class="radio-inline">'.form_radio('menarquia', 'Si',TRUE,$class).'Si</label>';
                                    echo '<label class="radio-inline">'.form_radio('menarquia', 'No',FALSE,$class).'No</label>';
                                    }else{
                                        if ($value->menarquia=='No')
                                        {
                                            echo '<label class="radio-inline">'.form_radio('menarquia', 'Si',FALSE,$class).'Si</label>';
                                            echo '<label class="radio-inline">'.form_radio('menarquia', 'No',TRUE,$class).'No</label>'; 
                                        }
                                        else
                                        {
                                            echo '<label class="radio-inline">'.form_radio('menarquia', 'Si',FALSE,$class).'Si</label>';
                                            echo '<label class="radio-inline">'.form_radio('menarquia', 'No',FALSE,$class).'No</label>';
                                        }
                                    }
                                ?>
                                 </div>
                            </div>
                           
                            <div class="form-group">
                                <label for="alergia" class="control-label">Duración</label>
                                    <input type="number" class="form-control" id="exampleInputEmail1" placeholder="Dias" name="duracion" min="4" required value="<?php echo $value->duracion; ?>">
                                    
                            </div>
                            
                            <div class="form-group">
                                <label for="alergia" class="control-label">Cantidad de sangre</label>
                                 <div>
                                     <?php 
                                        $class = array('class' => 'sangrado_paciente', 'required'=> 'true');
                                        if($value->cantidad_sangre=='Abundante'){
                                            echo '<label class="radio-inline">'.form_radio('c_sangre', 'Abundante',TRUE,$class).'Abundante</label>';
                                            echo '<label class="radio-inline">'.form_radio('c_sangre', 'Normal',FALSE,$class).'Normal</label>';
                                            echo '<label class="radio-inline">'.form_radio('c_sangre', 'Escasa',FALSE,$class).'Escasa</label>';
                                        }else{
                                            if ($value->cantidad_sangre=='Normal')
                                            {
                                                echo '<label class="radio-inline">'.form_radio('c_sangre', 'Abundante',FALSE,$class).'Abundante</label>';
                                                echo '<label class="radio-inline">'.form_radio('c_sangre', 'Normal',TRUE,$class).'Normal</label>';
                                                echo '<label class="radio-inline">'.form_radio('c_sangre', 'Escasa',FALSE,$class).'Escasa</label>';
                                            }else{
                                                if ($value->cantidad_sangre=='Escasa')
                                                {
                                                echo '<label class="radio-inline">'.form_radio('c_sangre', 'Abundante',FALSE,$class).'Abundante</label>';
                                                echo '<label class="radio-inline">'.form_radio('c_sangre', 'Normal',FALSE,$class).'Normal</label>';
                                                echo '<label class="radio-inline">'.form_radio('c_sangre', 'Escasa',TRUE,$class).'Escasa</label>'; 
                                                }
                                                else
                                                {
                                                echo '<label class="radio-inline">'.form_radio('c_sangre', 'Abundante',FALSE,$class).'Abundante</label>';
                                                echo '<label class="radio-inline">'.form_radio('c_sangre', 'Normal',FALSE,$class).'Normal</label>';
                                                echo '<label class="radio-inline">'.form_radio('c_sangre', 'Escasa',FALSE,$class).'Escasa</label>';   
                                                }
                                            }
                                        }
                                    ?>
                                 </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="alergia" class="control-label">Frecuencia</label>
                                 <div>
                                     
                                     
                         <?php 
                            $class = array('class' => 'frecuencia_paciente', 'required'=> 'true');
                            if($value->frecuencia=='Poligomenorrea'){
                                echo '<label class="radio-inline">'.form_radio('frecuencia', 'Poligomenorrea',TRUE,$class).'Poligomenorrea</label>';
                                echo '<label class="radio-inline">'.form_radio('frecuencia', 'Oligomenorrea',FALSE,$class).'Oligomenorrea</label>';
                                echo '<label class="radio-inline">'.form_radio('frecuencia', 'Amenorrea',FALSE,$class).'Amenorrea</label>';
                            }else{
                                if ($value->frecuencia=='Oligomenorrea')
                                {
                                    echo '<label class="radio-inline">'.form_radio('frecuencia', 'Poligomenorrea',FALSE,$class).'Poligomenorrea</label>';
                                    echo '<label class="radio-inline">'.form_radio('frecuencia', 'Oligomenorrea',TRUE,$class).'Oligomenorrea</label>';
                                    echo '<label class="radio-inline">'.form_radio('frecuencia', 'Amenorrea',FALSE,$class).'Amenorrea</label>';
                                }else{
                                    if ($value->frecuencia=='Oligomenorrea')
                                    {
                                    echo '<label class="radio-inline">'.form_radio('frecuencia', 'Poligomenorrea',FALSE,$class).'Poligomenorrea</label>';
                                    echo '<label class="radio-inline">'.form_radio('frecuencia', 'Oligomenorrea',FALSE,$class).'Oligomenorrea</label>';
                                    echo '<label class="radio-inline">'.form_radio('frecuencia', 'Amenorrea',TRUE,$class).'Amenorrea</label>'; 
                                    }
                                    else
                                    {
                                    echo '<label class="radio-inline">'.form_radio('frecuencia', 'Poligomenorrea',FALSE,$class).'Poligomenorrea</label>';
                                    echo '<label class="radio-inline">'.form_radio('frecuencia', 'Oligomenorrea',FALSE,$class).'Oligomenorrea</label>';
                                    echo '<label class="radio-inline">'.form_radio('frecuencia', 'Amenorrea',FALSE,$class).'Amenorrea</label>';   
                                    }
                                }
                            }
                        ?>
                                 </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="alergia" class="control-label">Presencia del dolor</label>
                                 <div>
                                     <?php 
                                        $class = array('class' => 'presencia_paciente', 'required'=> 'true');
                                        if($value->presencia_dolor=='Si'){
                                        echo '<label class="radio-inline">'.form_radio('dolor', 'Si',TRUE,$class).'Si</label>';
                                        echo '<label class="radio-inline">'.form_radio('dolor', 'No',FALSE,$class).'No</label>';
                                        }else{
                                            if ($value->presencia_dolor=='No')
                                            {
                                                echo '<label class="radio-inline">'.form_radio('dolor', 'Si',FALSE,$class).'Si</label>';
                                                echo '<label class="radio-inline">'.form_radio('dolor', 'No',TRUE,$class).'No</label>'; 
                                            }
                                            else
                                            {
                                                echo '<label class="radio-inline">'.form_radio('dolor', 'Si',FALSE,$class).'Si</label>';
                                                echo '<label class="radio-inline">'.form_radio('dolor', 'No',FALSE,$class).'No</label>';
                                            }
                                        }
                                    ?>
                                 </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="alergia" class="control-label">Presencia de otras secresiones vaginales</label>
                                 <div>
                                     <textarea class="form-control" rows="3" name="secreciones"><?php echo $value->otras_secreciones_vag; ?></textarea>
                                 </div>
                                 <style type="text/css">
                                     textarea {
                                        max-width: 100%; 
                                        max-height: 100%;
                                    }
                                </style>
                            </div>
                            
                        </div>
                    </div>
             </div>
         </div>
                          
           <div class="col-md-6">               
            <div class="form-group">
                        <div class="panel panel-info">
                          <div class="panel-heading">Actividad sexual</div>
                          <div class="panel-body">
                             
                              <div class="form-group">
                                <label for="alergia" class="control-label">Vida sexual activa</label>
                                 <div>
                                     <?php 
                                        $class = array('class' => 'sexual_paciente', 'required'=> 'true');
                                        if($value->vida_sexual_activa=='Si'){
                                        echo '<label class="radio-inline">'.form_radio('sexual', 'Si',TRUE,$class).'Si</label>';
                                        echo '<label class="radio-inline">'.form_radio('sexual', 'No',FALSE,$class).'No</label>';
                                        }else{
                                            if ($value->vida_sexual_activa=='No')
                                            {
                                                echo '<label class="radio-inline">'.form_radio('sexual', 'Si',FALSE,$class).'Si</label>';
                                                echo '<label class="radio-inline">'.form_radio('sexual', 'No',TRUE,$class).'No</label>'; 
                                            }
                                            else
                                            {
                                                echo '<label class="radio-inline">'.form_radio('sexual', 'Si',FALSE,$class).'Si</label>';
                                                echo '<label class="radio-inline">'.form_radio('sexual', 'No',FALSE,$class).'No</label>';
                                            }
                                        }
                                    ?>
                                 </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="control-label" for="exampleInputEmail1">Edad a la que inició vida sexual activa</label>
                                    <div>
                                        <input value="<?php echo $value->edad_inicio_sexual;?>" type="number" class="form-control" id="exampleInputEmail1" placeholder="Años" name="edad_inicio" min="10" required>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="control-label" for="exampleInputEmail1">Número de compañeros sexuales</label>
                                    <div>
                                        <input value="<?php echo $value->numero_companeros_sexuales;?>" type="number" required class="form-control" id="exampleInputEmail1" placeholder="Personas" name="comp_sexuales" min="0">
                                    </div>
                                </div>
                                
                                 <div class="form-group">
                                    <label for="exampleInputPassword1">Método anticonceptivo</label>
                                    <input value="<?php echo $value->metodo_anticonceptivo;?>" type="text" class="form-control" name="metodo" id="exampleInputPassword1" placeholder="Anticonceptivos">
                                  </div>
                                  
                                  
                                <div class="form-group">
                                    <label for="alergia" class="control-label">Relaciones</label>
                                     <div>
                                        
                        <?php 
                            $class = array('class' => 'relaciones_paciente', 'required'=> 'true');
                            if($value->tipo_relaciones=='Heterosexual'){
                                echo '<label class="radio-inline">'.form_radio('relaciones', 'Heterosexual',TRUE,$class).'Heterosexual</label>';
                                echo '<label class="radio-inline">'.form_radio('relaciones', 'Homosexual',FALSE,$class).'Homosexual</label>';
                                echo '<label class="radio-inline">'.form_radio('relaciones', 'Bisexual',FALSE,$class).'Bisexual</label>';
                            }else{
                                if ($value->tipo_relaciones=='Homosexual')
                                {
                                    echo '<label class="radio-inline">'.form_radio('relaciones', 'Heterosexual',FALSE,$class).'Heterosexual</label>';
                                    echo '<label class="radio-inline">'.form_radio('relaciones', 'Homosexual',TRUE,$class).'Homosexual</label>';
                                    echo '<label class="radio-inline">'.form_radio('relaciones', 'Bisexual',FALSE,$class).'Bisexual</label>';
                                }else{
                                    if ($value->tipo_relaciones=='Bisexual')
                                    {
                                    echo '<label class="radio-inline">'.form_radio('relaciones', 'Heterosexual',FALSE,$class).'Heterosexual</label>';
                                    echo '<label class="radio-inline">'.form_radio('relaciones', 'Homosexual',FALSE,$class).'Homosexual</label>';
                                    echo '<label class="radio-inline">'.form_radio('relaciones', 'Bisexual',TRUE,$class).'Bisexual</label>'; 
                                    }
                                    else
                                    {
                                    echo '<label class="radio-inline">'.form_radio('relaciones', 'Heterosexual',FALSE,$class).'Heterosexual</label>';
                                    echo '<label class="radio-inline">'.form_radio('relaciones', 'Homosexual',FALSE,$class).'Homosexual</label>';
                                    echo '<label class="radio-inline">'.form_radio('relaciones', 'Bisexual',FALSE,$class).'Bisexual</label>';   
                                    }
                                }
                            }
                        ?>
                                     </div>
                                </div>
                                
                                <div class="form-group">
                                <label for="alergia" class="control-label">Enfermedades de transmisión sexual</label>
                                 <div>
                                     <textarea class="form-control" rows="3" name="enfermedades"><?php echo $value->enfermedades_trans_sex;?></textarea>
                                 </div>
                                 <style type="text/css">
                                     textarea {
                                        max-width: 100%; 
                                        max-height: 100%;
                                    }
                                </style>
                            </div>
                                
                          </div>
                        </div>
            </div> 
        </div>
    </div>
    
        <div class="col-md-12">
             <div class="form-group">
                        <div class="panel panel-info">
                          <div class="panel-heading">Información de embarazos previos</div>
                          <div class="panel-body">

                            <div class="row">

                                <div class="col-md-3">
                                    <div class="form-group">
                                    <label class="control-label" for="exampleInputEmail1">Gestaciones</label>
                                    <div>
                                        <input value="<?php echo $value->gestaciones;?>" type="number" class="form-control" id="exampleInputEmail1" placeholder="Indique el núm. de gestaciones" name="gestaciones" min="0" required>
                                    </div>
                                  </div>
                                </div>

                                <div class="col-md-3">
                                     <div class="form-group">
                                    <label class="control-label" for="exampleInputEmail1">Partos</label>
                                    <div>
                                        <input value="<?php echo $value->partos;?>" type="number" class="form-control" id="exampleInputEmail1" placeholder="Indique el núm. de  partos" name="partos" min="0" required>
                                    </div>
                                  </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                    <label class="control-label" for="exampleInputEmail1">Abortos</label>
                                    <div>
                                        <input value="<?php echo $value->abortos;?>" type="number" class="form-control" id="exampleInputEmail1" placeholder="Indique el núm. de  abortos" name="abortos" min="0"  required>
                                    </div>
                                  </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                    <label class="control-label" for="exampleInputEmail1">Cesáreas</label>
                                    <div>
                                        <input value="<?php echo $value->cesareas;?>" type="number" class="form-control" id="exampleInputEmail1" placeholder="Indique el núm. de cesáreas" name="cesareas" min="0"  required>
                                    </div>
                                  </div>
                                </div>

                            </div>
                                  
                                  
                                  
                                 
                                  
                                  
                                  
                                  
                                  
                                  <div class="form-group">
                                    <label for="alergia" class="control-label">Antecedentes perinatales de importancia</label>
                                     <div>
                                         <textarea class="form-control" rows="3" name="ant_perinatales"><?php echo $value->ant_perinatales_de_imp;?></textarea>
                                     </div>
                                     <style type="text/css">
                                         textarea {
                                            max-width: 100%; 
                                            max-height: 100%;
                                        }
                                    </style>
                                </div>
                                  
                          </div>
                        </div>
            </div>
                
            </div>
            <div class="row">
<div class="col-md-4">
</div>

<div class="col-md-4">
            <button type="submit" class="btn btn-success btn-block">Guardar</button>
        </div>

        </div>
                
                <?php } ?>
            </form>
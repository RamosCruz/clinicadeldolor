<!--<h4 style="color:#AF81C9">5. <small style="color:#54D1F1">Constancias</small></h4>-->

<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">Subir constancia</h3>
  </div>
  <div class="panel-body">
     <?php if (isset($error))
     {
         echo $error;
     }?>
      <form action="../../historial/constancias" method="post" enctype="multipart/form-data">
          <input value="<?php echo $verPaciente[0]->curp; ?>" type="hidden" name="curp">
          <input value="<?php echo $expediente[0]->id_expediente; ?>" type="hidden" name="id_exp">
          <div class="row">
                        <div class="col-md-4">
           <div class="form-group">
            <label for="exampleInputEmail1">Descripción.</label>
            <input type="text" class="form-control" name="descripcion" placeholder="Tutilo del archivo" required>
          </div>
        </div>

<div class="col-md-4">
            <div class="form-group">
            <label for="exampleInputfile1">Adjuntar un archivo.</label>
            <input type="file" name="userfile" id="exampleInputfile1" required accept="image/jpeg,image/jpg,image/png,image/gif">
          </div>
        </div>

        <div class="col-md-4">
          
          <button type="submit" class="btn btn-primary btn-block">Cargar</button>
        </div>
      </div>
      </form>
  </div>
</div>


<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">Carpeta</h3>
  </div>
  <div class="panel-body">
        

    

    <div class="row">
       <?php foreach ($mostrarImagenes as $val)
{ ?> 
        <div class="col-md-4">
          <div class="thumbnail">
              <img src="<?php echo base_url('uploads/constancias/'.$val->nombre_archivo);?>" style="width:auto; height: 100px;">
              <div class="caption">
               <?php
                          $date = new DateTime($val->fecha_inclusion);
                            $fecha_i = $date->format('d/m/Y - g:i A');
                          ?>
                <h4 style="color:#FF7182"><?php echo $val->descripcion; ?>  <small style="color:#FFAE5D"><?php echo $fecha_i ?></small></h4>
              </div>
            <a class="btn btn-info glyphicon glyphicon-print" href="<?php echo base_url('uploads/constancias/'.$val->nombre_archivo);?>"> Imprimir</a>
            <a class="btn btn-danger glyphicon glyphicon-trash" href="../../historial/eliminarConsta/<?php echo $val->nombre_archivo;?>/<?php echo $verPaciente[0]->curp; ?>"> Eliminar</a>
          </div>
        </div>
        <?php } ?>  
    </div>
  
    
  </div>
</div>
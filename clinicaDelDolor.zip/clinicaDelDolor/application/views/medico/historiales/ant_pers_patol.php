<!--<h4 style="color:#AF81C9">3. <small style="color:#54D1F1">Antecedentes Personales Patológicos
</small></h4>-->


<form  role="form" id="myForm" method="post" action="../../historial/guardarAntePersoPato">

    <input value="<?php echo $verPaciente[0]->curp; ?>" type="hidden" name="curp">
    <input value="<?php echo $expediente[0]->id_expediente; ?>" type="hidden" name="id_exp">

<div class="col-md-12">
                <div class="form-group">
    <div class="panel panel-default">
        <div class="panel-body">
            <div class="col-md-3">
                <div class="table-responsive">
                    <table class="table table-striped">
                       <thead>
                           <th colspan="2"><center>Generales</center></th>
                       </thead>
                       <tbody>
                        <tr>
                            <td><br>Alérgicos<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->alergicos;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="alergicos[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="alergicos[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="alergicos[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Hospitalizaciones<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->hospitalizaciones;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="hospitalizaciones[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="hospitalizaciones[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="hospitalizaciones[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Quirúrgicos<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->quirurgicos;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="quirurgicos[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="quirurgicos[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="quirurgicos[]">';
                                            }
                                        }
                                        ?>

                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Traumáticos<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->traumaticos;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="traumaticos[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="traumaticos[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="traumaticos[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Transfusionales<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->transfusionales;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="transfusionales[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="transfusionales[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="transfusionales[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="table-responsive">
                <table class="table table-striped">
                   <thead>
                       <th colspan="2"><center>Adicciones</center></th>
                   </thead>
                   <tbody>
                    <tr>
                        <td><br>Alcoholismo<br></td>
                        <td>
                            <center>
                                <label class="checkbox-inline">

                                    <?php 
                                    $db = $ant_person_patolo[0]->alcoholismo;
                                    $aux = array("1");
                                    $aux2 = array("");
                                    echo '<input type="checkbox" value="0" name="alcoholismo[]" checked hidden="">';  
                                    $result = json_decode($db);
                                    for($j = 0; $j < count($aux); $j++)
                                    {
                                        for ($i = 1; $i < count($result); $i++)
                                        {

                                            if ($aux[$j] == $result[$i])
                                            {
                                                $aux2[$j] = $result[$i];
                                            }
                                        }
                                    }
                                    for ($x = 1; $x < 2; $x++)
                                    {
                                        if ($aux2[$x-1] != "")
                                        {
                                            echo '<input type="checkbox" value="'.$x.'" name="alcoholismo[]" checked>';
                                        }
                                        else
                                        {
                                            echo '<input type="checkbox" value="'.$x.'" name="alcoholismo[]">';
                                        }
                                    }
                                    ?>
                                </label>
                            </center>
                        </td>
                    </tr>
                    <tr>
                        <td><br>Tabaquismo<br></td>
                        <td>
                            <center>
                                <label class="checkbox-inline">

                                 <?php 
                                 $db = $ant_person_patolo[0]->tabaquismo;
                                 $aux = array("1");
                                 $aux2 = array("");
                                 echo '<input type="checkbox" value="0" name="tabaquismo[]" checked hidden="">';  
                                 $result = json_decode($db);
                                 for($j = 0; $j < count($aux); $j++)
                                 {
                                    for ($i = 1; $i < count($result); $i++)
                                    {

                                        if ($aux[$j] == $result[$i])
                                        {
                                            $aux2[$j] = $result[$i];
                                        }
                                    }
                                }
                                for ($x = 1; $x < 2; $x++)
                                {
                                    if ($aux2[$x-1] != "")
                                    {
                                        echo '<input type="checkbox" value="'.$x.'" name="tabaquismo[]" checked>';
                                    }
                                    else
                                    {
                                        echo '<input type="checkbox" value="'.$x.'" name="tabaquismo[]">';
                                    }
                                }
                                ?>
                            </label>
                        </center>
                    </td>
                </tr>
                <tr>
                    <td><br>Otras sustancias psicoactivas<br></td>
                    <td>
                        <center>
                            <label class="checkbox-inline">

                                <?php 
                                $db = $ant_person_patolo[0]->otras_sus;
                                $aux = array("1");
                                $aux2 = array("");
                                echo '<input type="checkbox" value="0" name="otras_sus[]" checked hidden="">';  
                                $result = json_decode($db);
                                for($j = 0; $j < count($aux); $j++)
                                {
                                    for ($i = 1; $i < count($result); $i++)
                                    {

                                        if ($aux[$j] == $result[$i])
                                        {
                                            $aux2[$j] = $result[$i];
                                        }
                                    }
                                }
                                for ($x = 1; $x < 2; $x++)
                                {
                                    if ($aux2[$x-1] != "")
                                    {
                                        echo '<input type="checkbox" value="'.$x.'" name="otras_sus[]" checked>';
                                    }
                                    else
                                    {
                                        echo '<input type="checkbox" value="'.$x.'" name="otras_sus[]">';
                                    }
                                }
                                ?>
                            </label>
                        </center>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
            </div>
            <div class="col-md-3">
                <div class="table-responsive">
                    <table class="table table-striped">
                       <thead>
                           <th colspan="2"><center>Patologias exantemáticas</center></th>
                       </thead>
                       <tbody>
                        <tr>
                            <td><br>Exantema súbito<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->exantema;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="exantema[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="exantema[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="exantema[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Roséola escarlatina<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->roseola;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="roseola[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="roseola[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="roseola[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Rubéola<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->rubeola;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="rubeola[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="rubeola[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="rubeola[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Sarampión<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->sarampion;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="sarampion[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="sarampion[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="sarampion[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Varicela<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->varicela;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="varicela[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="varicela[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="varicela[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Otra patología exantemática<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->otras_pato_exant;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="otras_pato_exant[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="otras_pato_exant[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="otras_pato_exant[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            </div>
            <div class="col-md-3">
                <div class="table-responsive">
                    <table class="table table-striped">
                       <thead>
                           <th colspan="2"><center>Patologías Infectocontagiosas</center></th>
                       </thead>
                       <tbody>
                        <tr>
                            <td><br>Faringoamigdalitis<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->faringoamigdalitis;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="faringoamigdalitis[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="faringoamigdalitis[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="faringoamigdalitis[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Fiebre Reumática<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->fiebre_reumatica;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="fiebre_reumatica[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="fiebre_reumatica[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="fiebre_reumatica[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Hepatitis<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->hepatitis;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="hepatitis[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="hepatitis[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="hepatitis[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Parasitosis<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->parasitosis;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="parasitosis[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="parasitosis[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="parasitosis[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Tifoidea<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->tifoidea;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="tifoidea[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="tifoidea[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="tifoidea[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Transmision sexual<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->transmision_sexual;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="transmision_sexual[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="transmision_sexual[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="transmision_sexual[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Tuberculosis<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->tuberculosis;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="tuberculosis[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="tuberculosis[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="tuberculosis[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Otra patología infectocontagiosa<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->otras_pato_infecto;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="otras_pato_infecto[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="otras_pato_infecto[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="otras_pato_infecto[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            </div>
            <div class="col-md-3">
                <div class="table-responsive">
                    <table class="table table-striped">
                       <thead>
                           <th colspan="2"><center>Patologías Crónico-Degenerativas</center></th>
                       </thead>
                       <tbody>
                        <tr>
                            <td><br>Diabetes Mellitus<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->diabetes_mellitus;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="diabetes_mellitus[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="diabetes_mellitus[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="diabetes_mellitus[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Hipertensión Arterial Sistémica<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->hipert_art_sis;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="hipert_art_sis[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="hipert_art_sis[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="hipert_art_sis[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Obesidad<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->obesidad;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="obesidad[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="obesidad[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="obesidad[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Neoplásicas<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">


                                        <?php 
                                        $db = $ant_person_patolo[0]->neoplasicas;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="neoplasicas[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="neoplasicas[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="neoplasicas[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Artritis Reumatoide<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->artritis_reumatoide;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="artritis_reumatoide[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="artritis_reumatoide[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="artritis_reumatoide[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Enfermedad de Gota<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->enfermedad_de_gota;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="enfermedad_de_gota[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfermedad_de_gota[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfermedad_de_gota[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Enfermedades psiquiatricas<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->enfer_psiquiatricas;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="enfer_psiquiatricas[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_psiquiatricas[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_psiquiatricas[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Enfermedades del sistema nervioso<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->enfer_sist_nervio;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="enfer_sist_nervio[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_nervio[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_nervio[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Enfermedades del sistema cardiovascular<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->enfer_sist_cardiov;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="enfer_sist_cardiov[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_cardiov[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_cardiov[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Enfermedades del sistema respiratorio<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->enfer_sist_respir;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="enfer_sist_respir[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_respir[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_respir[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Enfermedades del sistema gastrointestinal<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->enfer_sist_gastroint;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="enfer_sist_gastroint[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_gastroint[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_gastroint[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Enfermedades del sistema endocrino<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->enfer_sist_endocri;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="enfer_sist_endocri[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_endocri[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_endocri[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Enfermedades del sistema urinario<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->enfer_sist_urin;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="enfer_sist_urin[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_urin[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_urin[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Enfermedades del sistema musculoesquelético<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->enfer_sist_musculoes;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="enfer_sist_musculoes[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_musculoes[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_musculoes[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Enfermedades del sistema tegumentario<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->enfer_sist_tegum;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="enfer_sist_tegum[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_tegum[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="enfer_sist_tegum[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                        <tr>
                            <td><br>Otra enfermedad crónico-degenerativa<br></td>
                            <td>
                                <center>
                                    <label class="checkbox-inline">

                                        <?php 
                                        $db = $ant_person_patolo[0]->otra_enfer_cron_degen;
                                        $aux = array("1");
                                        $aux2 = array("");
                                        echo '<input type="checkbox" value="0" name="otra_enfer_cron_degen[]" checked hidden="">';  
                                        $result = json_decode($db);
                                        for($j = 0; $j < count($aux); $j++)
                                        {
                                            for ($i = 1; $i < count($result); $i++)
                                            {

                                                if ($aux[$j] == $result[$i])
                                                {
                                                    $aux2[$j] = $result[$i];
                                                }
                                            }
                                        }
                                        for ($x = 1; $x < 2; $x++)
                                        {
                                            if ($aux2[$x-1] != "")
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="otra_enfer_cron_degen[]" checked>';
                                            }
                                            else
                                            {
                                                echo '<input type="checkbox" value="'.$x.'" name="otra_enfer_cron_degen[]">';
                                            }
                                        }
                                        ?>
                                    </label>
                                </center>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            </div>
            <div class="col-md-12">
                <label for="alergia" class="control-label">Observaciones</label>
                <div>
                 <textarea class="form-control" rows="3" name="observaciones"><?php echo $ant_person_patolo[0]->observaciones; ?></textarea>
             </div>
             <style type="text/css">
             textarea {
                max-width: 100%; 
                max-height: 100%;
            }
            </style>
            </div>

        </div>
    </div>
    </div>
</div>
<div class="row">
<div class="col-md-4">
</div>

<div class="col-md-4">
            <button type="submit" class="btn btn-success btn-block">Guardar</button>
        </div>

        </div>
</form>
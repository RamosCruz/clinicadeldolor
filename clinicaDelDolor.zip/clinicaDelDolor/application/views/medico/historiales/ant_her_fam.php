<!--<h4 style="color:#AF81C9">2. <small style="color:#54D1F1">Antecedentes Heredo-Familiares</small></h4>-->

<form id="myForm1" action="../../historial/guardarAnteHeredoFam" method="post" class="form-horizontal">
  <input value="<?php echo $verPaciente[0]->curp; ?>" type="hidden" name="curp">
  <input value="<?php echo $expediente[0]->id_expediente; ?>" type="hidden" name="id_exp">


                        <div class="col-md-12">
                <div class="form-group">

  <div class="panel panel-default">
      <div class="panel-body">
        <div class="table-responsive">
            <table class="table">
                <thead>

                    <th></th>
                    <th><center>Padre</center></th>
                    <th><center>Madre</center></th>
                    <th><center>Abuelos paternos</center></th>
                    <th><center>Abuelos maternos</center></th>
                    <th><center>Hermanos</center></th>
                </thead>
                <tbody>

                    <tr>
                        <td><br>Diabetes Mellitus<br></td>
                        <?php 
                        $db= $ant_heredo_fam[0]->diabetes_mellitus;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" id="inlineCheckbox1" value="0" name="diabetes_mellitus[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="diabetes_mellitus[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="diabetes_mellitus[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>

                    <tr>
                        <td><br>Hipertensión Arterial Sistémica<br></td>


                        <?php 
                        $db = $ant_heredo_fam[0]->hiper_sistemica;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="hiper_sistemica[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="hiper_sistemica[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="hiper_sistemica[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>

                    <tr>
                        <td><br>Obesidad<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->obesidad;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="obesidad[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="obesidad[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="obesidad[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>

                    </tr>


                    <tr>
                        <td><br>Neoplasias<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->neoplasias;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="neoplasias[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="neoplasias[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="neoplasias[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>



                    <tr>
                        <td><br>Malformaciones hereditarias / congénitas<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->malformaciones;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="malformaciones[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="malformaciones[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="malformaciones[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>



                    <tr>
                        <td><br>Alergias<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->alergias;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="alergias[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="alergias[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="alergias[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>


                    <tr>
                        <td><br>Enfermedades psiquiatricas<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->psiquiatricas;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="psiquiatricas[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="psiquiatricas[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="psiquiatricas[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>


                    <tr>
                        <td><br>Enfermedades neurológicas<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->neurologicas;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="neurologicas[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="neurologicas[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="neurologicas[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>


                    <tr>
                        <td><br>Enfermedades cardiovasculares<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->cardiovasculares;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="cardiovasculares[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="cardiovasculares[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="cardiovasculares[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>


                    <tr>
                        <td><br>Enfermedades broncopulmonares<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->broncopulmonares;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="broncopulmonares[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="broncopulmonares[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="broncopulmonares[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>


                    <tr>
                        <td><br>Enfermedades tiroideas<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->tiroideas;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="tiroideas[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="tiroideas[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="tiroideas[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>


                    <tr>
                        <td><br>Enfermedades renales<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->renales;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="renales[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="renales[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="renales[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>

                    <tr>
                        <td><br>Enfermedades osteoarticulares<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->osteoarticulares;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="osteoarticulares[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="osteoarticulares[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="osteoarticulares[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>



                    <tr>
                        <td><br>Enfermedades infectocontagiosas<br></td>

                        <?php 
                        $db = $ant_heredo_fam[0]->infectocontagiosas;
                        $aux = array("1","2","3","4","5");
                        $aux2 = array("","","","","");
                        echo '<input type="checkbox" value="0" name="infectocontagiosas[]" checked hidden="">';  
                        $result = json_decode($db);
                        for($j = 0; $j < count($aux); $j++)
                        {
                            for ($i = 1; $i < count($result); $i++)
                            {

                                if ($aux[$j] == $result[$i])
                                {
                                    $aux2[$j] = $result[$i];
                                }
                            }
                        }
                        for ($x = 1; $x < 6; $x++)
                        {
                            if ($aux2[$x-1] != "")
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="infectocontagiosas[]" checked>
                                </label></center>
                                </td>';
                            }
                            else
                            {
                                echo '<td>
                                <center><label class="checkbox-inline">
                                <input type="checkbox" value="'.$x.'" name="infectocontagiosas[]">
                                </label></center>
                                </td>';
                            }
                        }
                        ?>
                    </tr>






                </tbody>
            </table>
        </div>
        <div class="form-group">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <label for="alergia" class="control-label">Anotaciones</label>
                <div>
                   <textarea class="form-control" rows="3" name="anotaciones"><?php echo $ant_heredo_fam[0]->anotaciones; ?></textarea>
               </div>
               <style type="text/css">
               textarea {
                max-width: 100%; 
                max-height: 100%;
            }
            </style>
        </div>
        <div class="col-md-1"></div>


    </div>

</div>
</div>
</div>
</div>

<div class="row">
    <div class="col-md-4">
    </div>

    <div class="col-md-4">
        <button type="submit" class="btn btn-success btn-block">Guardar</button>
    </div>

</div>


</form>
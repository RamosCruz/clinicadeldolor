<!--<h4 style="color:#AF81C9">4. <small style="color:#54D1F1">Antecedentes Personales no Patológicos
</small></h4>-->

<form  role="form" id="myForm" method="post" action="../../historial/guardarAntePersoNoPato">
    
<div class="col-md-12">
                <div class="form-group">
    <div class="panel panel-default">
      <div class="panel-body">
        <input value="<?php echo $verPaciente[0]->curp; ?>" type="hidden" name="curp">
        <input value="<?php echo $ant_person_no_patolo[0]->id_exp; ?>" type="hidden" name="id_exp">
            <?php foreach ($ant_person_no_patolo as $value)
                   { ?>

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="alergia" class="control-label">Tabaquismo</label>
                         <div>
                             
                             <?php 
                                    $class = array('class' => 'tabaquismo', 'required'=> 'true');
                                    if($value->tabaquismo=='Si'){
                                    echo '<label class="radio-inline">'.form_radio('tabaquismo', 'Si',TRUE,$class).'Si</label>';
                                    echo '<label class="radio-inline">'.form_radio('tabaquismo', 'No',FALSE,$class).'No</label>';
                                    }else{
                                        if ($value->tabaquismo=='No')
                                        {
                                            echo '<label class="radio-inline">'.form_radio('tabaquismo', 'Si',FALSE,$class).'Si</label>';
                                            echo '<label class="radio-inline">'.form_radio('tabaquismo', 'No',TRUE,$class).'No</label>'; 
                                        }
                                        else
                                        {
                                            echo '<label class="radio-inline">'.form_radio('tabaquismo', 'Si',FALSE,$class).'Si</label>';
                                            echo '<label class="radio-inline">'.form_radio('tabaquismo', 'No',FALSE,$class).'No</label>';
                                        }
                                    }
                                ?>
                             
                         </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="alergia" class="control-label">Alcoholismo</label>
                         <div>
                             
                              <?php 
                                    $class = array('class' => 'alcoholismo', 'required'=> 'true');
                                    if($value->alcoholismo=='Si'){
                                    echo '<label class="radio-inline">'.form_radio('alcoholismo', 'Si',TRUE,$class).'Si</label>';
                                    echo '<label class="radio-inline">'.form_radio('alcoholismo', 'No',FALSE,$class).'No</label>';
                                    }else{
                                        if ($value->alcoholismo=='No')
                                        {
                                            echo '<label class="radio-inline">'.form_radio('alcoholismo', 'Si',FALSE,$class).'Si</label>';
                                            echo '<label class="radio-inline">'.form_radio('alcoholismo', 'No',TRUE,$class).'No</label>'; 
                                        }
                                        else
                                        {
                                            echo '<label class="radio-inline">'.form_radio('alcoholismo', 'Si',FALSE,$class).'Si</label>';
                                            echo '<label class="radio-inline">'.form_radio('alcoholismo', 'No',FALSE,$class).'No</label>';
                                        }
                                    }
                                ?>
                         </div>
                    </div>
                </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label for="exampleInputPassword1">Escolaridad</label>
                    <input type="text" class="form-control" name="escolaridad" placeholder="Primaria" value="<?php echo $value->escolaridad;?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Tipo de vivienda</label>
                    <textarea  class="form-control" name="vivienda" placeholder="Describa"><?php echo $value->vivienda;?></textarea>
                    <style type="text/css">
                     textarea {
                        max-width: 100%; 
                        max-height: 100%;
                    }
                    </style>
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Habitos higienicos.</label>
                    <textarea  class="form-control" name="higienicos" placeholder="Describa"><?php echo $value->higienicos;?></textarea>
                    <style type="text/css">
                     textarea {
                        max-width: 100%; 
                        max-height: 100%;
                    }
                    </style>
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Ocupacion actual</label>
                    <input type="text" class="form-control" name="ocupacion" placeholder="Obrero" value="<?php echo $value->ocupacion;?>">
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Uso de tiempo libre</label>
                    <input type="text" class="form-control" name="tiempo_libre" placeholder="Ejercicio" value="<?php echo $value->tiempo_libre;?>">
                </div>


            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="alergia" class="control-label">Inmunizaciones</label>
                     <div>
                         
                         <?php 
                                    $class = array('class' => 'inmunizaciones', 'required'=> 'true');
                                    if($value->inmunizaciones=='Si'){
                                    echo '<label class="radio-inline">'.form_radio('inmunizaciones', 'Si',TRUE,$class).'Si</label>';
                                    echo '<label class="radio-inline">'.form_radio('inmunizaciones', 'No',FALSE,$class).'No</label>';
                                    }else{
                                        if ($value->inmunizaciones=='No')
                                        {
                                            echo '<label class="radio-inline">'.form_radio('inmunizaciones', 'Si',FALSE,$class).'Si</label>';
                                            echo '<label class="radio-inline">'.form_radio('inmunizaciones', 'No',TRUE,$class).'No</label>'; 
                                        }
                                        else
                                        {
                                            echo '<label class="radio-inline">'.form_radio('inmunizaciones', 'Si',FALSE,$class).'Si</label>';
                                            echo '<label class="radio-inline">'.form_radio('inmunizaciones', 'No',FALSE,$class).'No</label>';
                                        }
                                    }
                                ?>
                     </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="alergia" class="control-label">Conciencia de enfermedad</label>
                     <div>
                         <?php 
                                    $class = array('class' => 'conciencia', 'required'=> 'true');
                                    if($value->conciencia=='Si'){
                                    echo '<label class="radio-inline">'.form_radio('conciencia', 'Si',TRUE,$class).'Si</label>';
                                    echo '<label class="radio-inline">'.form_radio('conciencia', 'No',FALSE,$class).'No</label>';
                                    }else{
                                        if ($value->conciencia=='No')
                                        {
                                            echo '<label class="radio-inline">'.form_radio('conciencia', 'Si',FALSE,$class).'Si</label>';
                                            echo '<label class="radio-inline">'.form_radio('conciencia', 'No',TRUE,$class).'No</label>'; 
                                        }
                                        else
                                        {
                                            echo '<label class="radio-inline">'.form_radio('conciencia', 'Si',FALSE,$class).'Si</label>';
                                            echo '<label class="radio-inline">'.form_radio('conciencia', 'No',FALSE,$class).'No</label>';
                                        }
                                    }
                                ?>
                     </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<?php } ?>
<div class="row">
<div class="col-md-4">
</div>

<div class="col-md-4">
            <button type="submit" class="btn btn-success btn-block">Guardar</button>
        </div>

        </div>
</form>
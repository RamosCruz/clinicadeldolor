<hr>
<hr>
 <div class="page-header">
</div>
<div class="container">
 <div class="row">
     <div class="col-md-12" >
         <!-- --------------ALERT------------------------- -->
        
         <div class="panel panel-primary class" >
            <div class="panel-heading">
                <h3 class="panel-title" >CATÁLOGO DE MEDICAMENTOS</h3>
            </div>
            <div class="panel-body">
                <div class="row">

                  <div div class="col-md-12">
                    <!--              1ER PANEL                            -->
                    <div class="col-md-6">

                      
                      <div class="panel panel-success class" >
                        <div class="panel-heading">
                          <h1 class="panel-title" >Buscar medicamento</h1>
                        </div>
                        <div class="panel-body">
                          <div class="row">
                            <!--                     FORMULARIO DE BUSQUEDA                                 -->
                            <div class="col-md-12">
                              <!-- <form class="form-horizontal"  id="formularioGuardarmedicamentos"  method="post" action=""> -->
                                <div class="col-md-8">
                                  <!-- <div class="form-group"> -->
                                    <div class="col-sm-4">
                                      <label for="categoria" class="control-label">Nombre</label>
                                    </div>
                                    <div class="col-sm-8">
                                      <input type="text" title="Se requiere un nombre de medicamento a buscar!" class="form-control" id="nombre-medicamento" placeholder="Ejem: Ibuprofeno" name="nombre-medicamento" required />
                                    </div>
                                  <!-- </div> -->
                                </div>

                                <div class="col-md-4">
                                  <!-- <div class="form-group"> -->
                                    <div class="col-sm-offset-2 col-sm-10">
                                      <button type="submit" id="btn-buscarMedicamento" name="btn-buscarMedicamento" class="btn btn-success btn-md btn-block"><span class="glyphicon  glyphicon-search"></span> Buscar</button>
                                    </div>
                                  <!-- </div> -->
                                </div>
                              <!-- </form> -->
                            </div>
                            <!--                     FIN FORMULARIO DE BUSQUEDA                                 -->

                          </div>
                        </div>
                      </div>


                       <!--         RESULTADOS DE LA BUSQUEDA               -->
                            <div class="col-md-12">
                              <!-- <div class="alert alert-danger" role="alert" style="display: none;">
                              </div>
                              <div class="alert alert-success" role="alert" style="display: none;">
                              </div>-->
                              <div class="table-responsive" id="conexion">
                                <div class="nuevaTabla" id="showdata">
                                </div>  
                              </div>

                            </div>
                            <!--         FIN RESULTADOS DE LA BUSQUEDA               -->
                          


                    

                    </div>
                    <!--              FIN 1ER PANEL                         -->


                    <div div class="col-md-6">

                      <div class="panel panel-success class">
                        <div class="panel-heading">
                          <h1 class="panel-title" >Medicamentos más usados</h1>
                        </div>

                        <div class="panel-body">
                          <div class="row">
                             <div class="col-md-12">
                              <div class="alert alert-danger" role="alert" style="display: none;">
                              </div>
                              <div class="alert alert-success" role="alert" style="display: none;">
                              </div>
                              <div class="table-responsive" id="conexion">
                                <div class="nuevaTabla" id="medicamentosUsados">
                                </div>  
                              </div>

                            </div>
                          </div>
                        </div>
                      </div>

                    </div>


                  </div>




                </div>
                <!--<hr>-->
            </div>
         </div>
        <!----------------------------------------- -->
     </div>
 </div>
</div>




<!-- ------------------------------------MODAL ELIMINAR------------------------------------ -->
<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Eliminar</h4>
      </div>
      <div class="modal-body">
          Estas seguro de eliminar el registro?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="button" id="btnDelete" class="btn btn-danger">Eliminar</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--        :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::            -->








<!----------------EVENTOS JAVASCRIPT------------------------- -->
<script>
var id_medico="<?php echo $medico_logueado[0]->id_medico;?>" 
listarMedicamentosUsadosPor(id_medico);



//---------------------------
 $('#btn-buscarMedicamento').click(function(){
            //var expediente = document.getElementById("nombre-medicamento").value;
            var nombre_medicamento=$('input[name=nombre-medicamento]');
            //alert(nombre_medicamento);
            if(nombre_medicamento.val()==''){
              nombre_medicamento.focus();
            }else{
                  mostrarResultadoBusquedaPorMedicamento(nombre_medicamento.val());
                  $('#nombre-medicamento').val("");
                //alert(nombre_medicamento);
            }
  });


 //PETICION VERIFICA E INGRESA A  TABLA DE MEDICAMENTOS MÁS USADOS
    $('#showdata').on('click', '.item-id-anadir-a-lista', function(){
      var id_medicamento = $(this).attr('data');
      //var id_medico="REHE930212HOCYRR03";//Este sera temporalmente mientras agregamos a usuarios 
      //alert(id_medicamento);
      if(id_medico!=null){
        ValidaMedicamento(id_medicamento,id_medico);
      }

      
    });


  //BOTON ELIMINAR

   $('#medicamentosUsados').on('click', '.item-id-eliminar-de-la-lista', function(){
      var id_medicamento = $(this).attr('id-medicamento');
      var id_medico = $(this).attr('id-medico');

      $('#deleteModal').modal('show');
      //prevent previous handler - unbind()
      $('#btnDelete').unbind().click(function(){
        $.ajax({
          type: 'ajax',
          method: 'get',
          async: false,
          url: '<?php echo base_url() ?>medico/medicamentos/eliminarMedicamentoUsadoPor',
          data:{id_medicamento:id_medicamento,id_medico:id_medico},
          dataType: 'json',
          success: function(response){
            if(response.success){
              $('#deleteModal').modal('hide');
              $('.alert-success').html('La categoría ha sido eliminada con éxito!').fadeIn().delay(1000).fadeOut('slow');
              listarMedicamentosUsadosPor(id_medico);
            }else{
              alert('Error');
            }
          },
          error: function(){
            alert('Error deleting');
          }
        });
      });
    });


              //---------------------------------------------


            function ValidaMedicamento(id_medicamento,id_medico){
            $.ajax({
                type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/medicamentos/validarMedicamentoEnListaDeUsado',
               data:{id_medicamento:id_medicamento,id_medico:id_medico},
               dataType: 'json',
               success: function(data){
               //alert("LA RESPUESTA ES: "+data);

               if(data){
                  guardarEnListaDeMedicamentosUsados(id_medicamento,id_medico);
                  listarMedicamentosUsadosPor(id_medico);
                  //Despues tiene que listar los medicamentos de ese medico en la otra tabla dinamica
                }
                else{
                  swal({
                                    title: "No agregado",
                                    text: "Ya existe ese medicamento en la lista!",
                                    type: "warning",
                                    timer: 2000,
                                    showConfirmButton: false
                                }
                                )
                          .catch(swal.noop);
                }

                


                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
        }

        //...................................................

         function guardarEnListaDeMedicamentosUsados(id_medicamento,id_medico){
            //alert(categoria);

            $.ajax({
                type: 'ajax',
               method: 'post',
               async: false,
               url: '<?php echo base_url() ?>medico/medicamentos/insertarMedicamentoEnListaDeUsados',
               data:{id_medicamento:id_medicamento,id_medico:id_medico},
               dataType: 'json',
               success: function(response){

                 if(response){
                     swal({
                                    title: "Agregado a la lista!",
                                    type: "success",
                                    timer: 1800,
                                    showConfirmButton: false
                                }
                                )
                          .catch(swal.noop);
                  }
                  else{
                   $('.alert-danger').html('El medicamento no pudo ser insertado!').fadeIn().delay(2000).fadeOut('slow');
                   
                  }

                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });

        }
    //----------------------------------------------

    function listarMedicamentosUsadosPor(id_medico){
        //alert("Mira el medico: "+id_medico);
      $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/medicamentos/listarMedicamentosUsadosPor',
               data:{id_medico:id_medico},
               dataType: 'json',
               success: function(data){
                    //alert("Resultado: "+data);
                    if(data==false){

                        var html = '';
                        $('#medicamentosUsados').html(html);
                            
                        $('.alert-danger').html('Actualmente no cuenta con una lista de medicamentos usados!').fadeIn().delay(2200).fadeOut('slow');
              

                    }
                    else{

                    var html = '';
                        var i;
                        html +='<table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-medicamentos-usados">'+
                                            '<thead>'+
                                            '<tr>'+
                                                '<th>MEDICAMENTO</th>'+
                                                '<th>PRESENTACIÓN</th>'+
                                                '<th>CONCENTRACIÓN</th>'+
                                                '<th><center>ACCIONES</center></th>'+
                                            '</tr>'+
                                            '</thead>'+
                                                '<tbody>';
                                            for(i=0; i<data.length; i++){
                                                html +='<tr>'+
                                                '<td>'+data[i].nombre_generico+'</td>'+
                                                '<td>'+data[i].presentacion+'</td>'+
                                                '<td>'+data[i].concentracion+'</td>'+
                                                '<td>'+
                                                '<center>'+
                                                    //'<a href="javascript:;" data="'+data[i].id_medicamento+'" type="button" class="btn btn-default item-id-edit" style="color:#29A9CC" title="Editar Categoría"><i class="glyphicon glyphicon-pencil"></i></a>'+
                                                    '<a href="javascript:;" id-medicamento="'+data[i].id_medicamento+'" '+'id-medico="'+data[i].id_medico+'" class="btn btn-default item-id-eliminar-de-la-lista" style="color:RED" title="Eliminar de la lista"><i class="glyphicon glyphicon-remove"></i></a>'+
                                                '<center>'+                                                                              
                                                '</td>'+
                                                '</tr>';
                                            }
                                            html +='</tbody>'+'</table>';
                                            
                                            $('#medicamentosUsados').html(html);

                                             //--CONTEMOS LAS FILAS PARA QUE APAREZCA EL SCROLL
                                            var filas=$("#tabla-medicamentos-usados tr").length;
                                            if(filas>5){

                                              //$("#tabla-general tr").css({'display':'inline-table'});
                                              //$("#estatico").css({'width':'500px',});

                                              $("#tabla-medicamentos-usados").css({'overflow-y':'scroll','height':'500px','display':'block'});
                                              //alert("El total de filas es mayor a: "+filas);
                                            }
                                          }
                           

                  
                   
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });

        }







    //-................................................................


    function mostrarResultadoBusquedaPorMedicamento(nombre_medicamento){
      $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/medicamentos/getMedicamentosCon',
               data:{nombre_generico:nombre_medicamento},
               dataType: 'json',
               success: function(data){ 

                //alert(data);

                     if(data==false){

                        var html = '';
                        $('#showdata').html(html);
                            
                        $('.alert-danger').html('No hay registros con la busqueda seleccionada!').fadeIn().delay(1000).fadeOut('slow');
              

                    }
                    else{

                    var html = '';
                        var i;
                        html +='<table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-general">'+
                                            '<thead>'+
                                            '<tr>'+
                                                '<th>MEDICAMENTO</th>'+
                                                '<th>PRESENTACIÓN</th>'+
                                                '<th>CONCENTRACIÓN</th>'+
                                                '<th><center>ACCIONES</center></th>'+
                                            '</tr>'+
                                            '</thead>'+
                                                '<tbody>';
                                            for(i=0; i<data.length; i++){
                                                html +='<tr>'+
                                                '<td>'+data[i].nombre_generico+'</td>'+
                                                '<td>'+data[i].presentacion+'</td>'+
                                                '<td>'+data[i].concentracion+'</td>'+
                                                '<td>'+
                                                '<center>'+
                                                    //'<a href="javascript:;" data="'+data[i].id_medicamento+'" type="button" class="btn btn-default item-id-edit" style="color:#29A9CC" title="Editar Categoría"><i class="glyphicon glyphicon-pencil"></i></a>'+
                                                    '<a href="javascript:;"  data="'+data[i].id_medicamento+'" class="btn btn-default item-id-anadir-a-lista" style="color:GREEN" title="Añadir a lista de medicamentos más usados"><i class="glyphicon glyphicon-share-alt"></i></a>'+
                                                '<center>'+                                                                                
                                                '</td>'+
                                                '</tr>';
                                            }
                                            html +='</tbody>'+'</table>';
                                            
                                            $('#showdata').html(html);

                                            //--CONTEMOS LAS FILAS PARA QUE APAREZCA EL SCROLL
                                            var filas=$("#tabla-general tr").length;
                                            if(filas>5){

                                              //$("#tabla-general tr").css({'display':'inline-table'});
                                              //$("#estatico").css({'width':'500px',});

                                              $("#tabla-general").css({'overflow-y':'scroll','height':'400px','display':'block'});
                                              //alert("El total de filas es mayor a: "+filas);
                                            }
                                            




                        }
                      },
                                error: function(){
                                    alert('Could not get Data from Database');
                                }
                            });
}        
           



    
</script>

<!-- --------------------------------------------------------- -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinica del Dolor</title>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>" ></script>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap-theme.min.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">
    <script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js');?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.js');?>"></script>
    <script src="<?php echo base_url('assets/js/curp.js');?>"></script>
    <script src="<?php echo base_url('assets/js/digitos_estados.js');?>"></script>
    
     <!-- --------------------------------- LIBRERIAS DE SWEETALERT------------------------------------------ -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/sweetalert2/sweetalert2.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/sweetalert2/sweetalert2.min.css') ?>">
    <script type="text/javascript" src="<?php echo base_url('assets/sweetalert2/sweetalert2.js');?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/sweetalert2/sweetalert2.min.js');?>"></script>

    <!-- --------------------------------- LIBRERIAS DE DATETIMEPICKER------------------------------------------ -->
    <link href="<?php echo base_url("assets/datepicker/css/bootstrap-datepicker.css")?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/datepicker/css/bootstrap-datetimepicker.min.css")?>" rel="stylesheet">



    <script type="text/javascript" src="<?php echo base_url('assets/datepicker/js/bootstrap-datetimepicker.min.js');?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/datepicker/js/bootstrap-datepicker.min.js');?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/datepicker/js/bootstrap-datepicker.es.min.js');?>"></script>
    
</head>
<body>

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Clinica del dolor</a>
    </div>
    

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/medical-records(1).png');?>" alt=""> Agenda de citas <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('medico/Agenda/nuevaCita');?>">Nueva cita</a></li>
            <li><a href="<?php echo base_url('medico/Agenda/listarAgenda');?>">Listar citas</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/pain.png');?>" alt=""> Pacientes <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('medico/paciente/nuevoPaciente');?>">Nuevo paciente</a></li>
            <li><a href="<?php echo base_url('medico/paciente'); ?>">Listar pacientes</a></li>
          </ul>
        </li>
        <li><a href="#"><img src="<?php echo base_url('assets/img/surgeon.png');?>" alt=""> Nueva Consulta</a></li>
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/picture.png');?>" alt=""> Galeria de imagenes <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Categoria</a></li>
            <li><a href="#">Nueva imagen</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Galeria</a></li>
          </ul>
        </li>
        
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/medical-history.png');?>" alt=""> Reportes <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Consultas registradas en un periodo</a></li>
            <li><a href="#">Pacientes regristrados en un periodo</a></li>
          </ul>
        </li>
        
      </ul>
      
      
      
      <ul class="nav navbar-nav navbar-right">
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/users.png');?>" alt=""> Usuario <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Salir</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>






    <div class="container">
 <div class="row">
     <div class="col-md-12" >
         <!----------------ALERT------------------------- -->
         <div class="alert alert-success" style="display: none;">
         </div>

         <!--<a class="btn btn-default" href="<?php echo base_url('medico/agenda/listarAgenda');?>">Regresar</a><hr>-->
         
                    <div class="col-md-2">
                    </div>
                    <div class="col-md-8">
                        <div class="panel panel-primary class">
                        <div class="panel-heading">
                            <h3 class="panel-title" >REGISTRAR NUEVA CITA</h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">

                        <!-- --------------------EL FORMULARIO DE CITAS-------------------------- -->
                        <form class="form-horizontal" id="formularioGuardarCita" method="post" action="">
                            <!-- ------------------ -->
                            <div class='col-sm-12'>

                                <div class="form-group">
                                    <div class='col-sm-2'>
                                        <label for="fecha-cita" class="control-label" style="color:#336699">*Fecha</label>
                                    </div>
                                    <div class="col-sm-10">

                                            <div class="input-group date  input-append" id="datetimepicker4">
                                              <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="fecha-cita" id="fecha-cita"   required><span class="input-group-addon add-on"><i class=""></i></span>
                                            </div>

                                        <script type="text/javascript">
                                        $(function() {
                                            var today = new Date();
                                            $('#datetimepicker4').datetimepicker({
                                                pickTime: false,
                                                language: 'es-MX',
                                                endDate: new Date(today.getFullYear(), today.getMonth()+2, today.getDate()),
                                                startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
                                                
                                            });



                                        });

                                        </script>

                                    </div>
                                </div>
                            </div>
                            <!-- ----------------- -->
                            <div class='col-sm-12'>
                                <div class="form-group">
                                    <div class='col-sm-2'>
                                        <label for="hora-cita" class="control-label" style="color:#336699">*Hora</label>
                                    </div>
                                    <div class='col-sm-10'>
                                            <select class="form-control" name="hora-cita" id="hora-cita" required>
                                               <?php for ($i = 0; $i <count($horario); $i++){ ?>
                                                <option value="<?php echo $horario[$i]; ?>"><?php echo $horario[$i]; ?></option>
                                                <?php } ?>
                                            </select>

                                        
                                       
                                    </div>
                                </div>
                            </div>
                            <!-- ----------------- -->
                            <div class='col-sm-12'>
                                <div class="form-group">
                                    <div class='col-sm-2'>
                                        <label  for="paciente" class="control-label" style="color:#336699">*Paciente</label>
                                    </div>
                                    <div class="col-sm-8">
                                         <input type="hidden" class="form-control"  name="id-nombre-paciente" id="id-nombre-paciente"  required>
                                        <input type="text" class="form-control"  name="nombre-paciente" id="nombre-paciente"   required >
                                    </div>
                                    <div class='col-sm-2'>
                                        <button type="button" class="btn btn-primary" id="btnBuscar"><span class="glyphicon glyphicon-search"></span></button>
                                    </div>

                                </div>
                            </div>

                            <div class='col-sm-12'>
                                <div class="form-group">
                                    <div class="col-sm-2">
                                        <label for="estado" class="control-label" style="color:#336699">*Médico</label>
                                    </div>
                                    <div class="col-sm-10">
                                        <select class="form-control" name="id-medico" id="id-medico" required>
                                            <?php foreach($medicos as $medico) { ?>
                                            <option value="<?php echo $medico->id_medico; ?>">DR. <?php echo $medico->nombre; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class='col-sm-12'>
                                <div class="form-group">
                                    <div class='col-sm-2'>
                                        <label for="app" class="col-sm-2 control-label" style="color:#336699">Nota</label>
                                    </div>
                                    <div class="col-sm-10">
                                        <textarea class="form-control" rows="3" name="nota" id="nota" max="255"></textarea>
                                        <style type="text/css">
                                        textarea {
                                            max-width: 100%; 
                                            max-height: 100%;
                                        }
                                        </style>
                                    </div>
                                </div>
                            </div>
                            <div class='col-sm-12'>
                            <div class="form-group">
                                    <div class='col-sm-2'>
                                    </div>
                                    
                                    <div class='col-sm-8'>
                                            <div class='col-sm-6'>
                                                <button type="button" id="btn-registraCita" class="btn btn-primary col-sm-12 col-xs-12"><span class="glyphicon glyphicon-ok"></span> Registrar</button>
                                            </div>

                                            <div class='col-sm-6'>
                                                <a href="<?php echo base_url('medico/agenda');?>" type="button" class="btn btn-success col-sm-12 col-xs-12"><span class="glyphicon glyphicon-remove"></span> Cancelar</a>
                                            </div>
                                    </div>

                                     <div class='col-sm-2'>
                                    </div>
                            </div>
                            </div>

                        </form>
                        </div>
                        </div>
                        </div>

                        <!-- --------------------FIN FORMULARIO CITAS-------------------------- -->

                    </div>

                <!--</div>
                <hr>
            </div>
        </div>-->
        <!----------------------------------------- -->
    </div>
</div>
</div>




<!-- ------------------------------------MODAL BUSCAR------------------------------------ -->

<div id="myModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header modal-header-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-search"></i> Buscar Paciente</center></h2>
        
    </div>
    <div class="modal-body">
           <div class="panel panel-default">
        <div class="panel-body">
          
            <div class="col-lg-10">
            <form class="form-horizontal" role="form">
              
              <div class="form-group">
                <label for="ejemplo_email_3" class="col-lg-4  control-label">Nombre</label>
                <div class="col-lg-8 ">
                  <input type="text" class="form-control" name ="nombre" id="nombreAbuscar"
                         placeholder="Ingrese un nombre del paciente">
                </div>
              </div>
              
              <div class="form-group">
                <label for="ejemplo_password_3" class="col-lg-4  control-label">Apellido</label>
                <div class="col-lg-8 ">
                  <input type="text" class="form-control" name="apellido-p" id="apellidoAbuscar" 
                         placeholder="Ingresa un apellido del paciente">
                </div>
              </div>
              
              
            </form>
            
          </div>
          <div class="col-lg-2">
            <button type="submit" class="btn btn-success" id="btn-buscarPaciente">Buscar</button>
          </div>
          
        </div>
      </div>
      
      <div class="panel panel-default">
        <div class="panel-body">
          
          <div class="col-lg-10">
            <form class="form-horizontal" role="form">
              
              <div class="form-group">
                <label for="ejemplo_email_3" class="col-lg-4  control-label">Número de Expediente</label>
                <div class="col-lg-8 ">
                  <input type="number" class="form-control " name="expediente" id="expedienteAbuscar"
                         placeholder="Ingresa un número de expediente">
                </div>
              </div>
             
             </form>
            
          </div>
          
          <div class="col-lg-2">
            <button type="submit" class="btn btn-success" id="btn-buscarExpediente">Buscar</button>
          </div>
          
        </div>
      </div>


      <div class="panel panel-default">
        <div class="panel-body">
             <div class="alert alert-danger" role="alert" style="display: none;">
             </div>

             <div class="table-responsive" id="conexion">
                <div class="nuevaTabla" id="showdata">
                </div>  
             </div>

        </div>
      </div>

    </div>
<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    <!-- <button type="button" id="btnSave" class="btn btn-primary">Save changes</button> -->
</div>
</div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!-- ------------------------------------------------------------------------ -->



<script>


function rellenaDatos(){
    //En esta funcion nos interesa marcar el elemento que se habia prevamente seleccionado por el usuario y es a traves de esta manera que se logra
    
      var hora     = $('#hora-cita').val("");
      var doctor   = $('#id-medico').val("");
    //window.open("http://www.google.com/")
}

window.onload = rellenaDatos;

 //PETICION VERIFICA E INGRESA A  LA NUEVA CITA
    $('#btn-registraCita').click(function(){
     
      var fecha    = $('input[name=fecha-cita]').val();
      var hora     = $('select[name=hora-cita] option:selected').text();
      var doctor   = $('select[name=id-medico').val();
      var paciente = $('input[name=id-nombre-paciente]').val();
      var nota     = $('#nota').val();

      
      if(fecha!="" && hora!="" && doctor!="" && paciente!=""){
        //alert (nota+" "+fecha+" "+hora+" "+doctor+" "+paciente);
        ValidaHoraDeMedicoEnCita(fecha,hora,doctor,paciente,nota);

      }


      
    });


    function ValidaHoraDeMedicoEnCita(fecha,hora,id_doctor,id_paciente,nota){
             //alert("validando hora de medico en cita");
            $.ajax({
                type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/ValidaHoraDelMedico',
               data:{fecha:fecha,hora:hora,id_doctor:id_doctor,id_paciente:id_paciente},
               dataType: 'json',
               success: function(data){
               //alert("LA RESPUESTA ES: "+data);

               if(data){
                //agendarCita();
                ValidaHoraDePacienteEnCita(fecha,hora,id_doctor,id_paciente,nota);
                //location.reload();
                }
                else{



                  swal({
                                    title: "Cita no agendada",
                                    text: "El médico solicitado ya cuenta con una cita a esa hora!, porfavor modifique la hora para poder agendarla!",
                                    type: "warning",
                                    showConfirmButton: true
                                }
                                )
                     .catch(swal.noop);;

                                         $('select[name=hora-cita]').focus();
                }
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
        }


    function ValidaHoraDePacienteEnCita(fecha,hora,id_doctor,id_paciente,nota){
            alert("validando hora de paciente en cita");
            $.ajax({
                type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/ValidaHoraDelPaciente',
               data:{fecha:fecha,hora:hora,id_doctor:id_doctor,id_paciente:id_paciente},
               dataType: 'json',
               success: function(data){
               //alert("LA RESPUESTA ES: "+data);

               if(data){
                ValidaFechaDePacienteEnCita(fecha,hora,id_doctor,id_paciente,nota);
                //agendarCita();
                //location.reload();
                }
                else{
                  swal({
                                    title: "Cita no agendada",
                                    text: "El paciente ya tiene una cita reservada a esa hora!, porfavor modifique la hora para poder agendarla!",
                                    type: "warning",
                                    showConfirmButton: true
                                }
                                )
                     .catch(swal.noop);;

                                         $('select[name=hora-cita]').focus();
                }
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
        }

        function ValidaFechaDePacienteEnCita(fecha,hora,id_doctor,id_paciente,nota){
            //alert("validando fecha de paciente en cita");
            $.ajax({
                type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/ValidaFechaDelPaciente',
               data:{fecha:fecha,hora:hora,id_doctor:id_doctor,id_paciente:id_paciente},
               dataType: 'json',
               success: function(data){
               //alert("LA RESPUESTA ES: "+data);

               if(data){
                ValidaFechaDeMedicoEnCita(fecha,hora,id_doctor,id_paciente,nota)
                //agendarCita();
                //location.reload();
                }
                else{
                  swal({
                                    title: "Cita no agendada",
                                    text: "El paciente ya tiene una cita reservada con esa fecha!, porfavor modifique la fecha para poder agendarla!",
                                    type: "warning",
                                    showConfirmButton: true
                                }
                                )
                     .catch(swal.noop);;
                                         $('select[name=fecha-cita]').focus();
                }
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
        }


        function ValidaFechaDeMedicoEnCita(fecha,hora,id_doctor,id_paciente,nota){
            //alert("validando fecha de medico en cita");
            $.ajax({
                type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/ValidaFechaDelMedico',
               data:{fecha:fecha,hora:hora,id_doctor:id_doctor,id_paciente:id_paciente},
               dataType: 'json',
               success: function(data){
               //alert("LA RESPUESTA ES: "+data);

               if(data){
                agendarCita(fecha,hora,id_doctor,id_paciente,nota);
                //location.reload();
                }
                else{
                  swal({
                                    title: "Cita no agendada",
                                    text: "El Médico solicitado ya tiene una cita reservada con esa fecha!, porfavor modifique la fecha para poder agendarla!",
                                    type: "warning",
                                    showConfirmButton: true
                                }
                                )
                     .catch(swal.noop);;

                                         $('select[name=fecha-cita]').focus();
                }
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
        }

         //...................................................

         function agendarCita(fecha,hora,id_doctor,id_paciente,nota){
            //var data=$('#formularioGuardarCita').serialize();
              //alert("Agendando cita");
             $.ajax({
                type: 'ajax',
               method: 'post',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/agendarCita',
               data:{fecha:fecha,hora:hora,id_medico:id_doctor,id_paciente:id_paciente,nota:nota},
               dataType: 'json',
               success: function(response){

               //alert("LA RESPUESTA ES: "+response);
                 if(response){
                     swal({
                                    title: "Cita Agenda!",
                                    type: "success",
                                    timer: 1800,
                                    showConfirmButton: false
                                }
                                )
                     .catch(swal.noop);
                  }
                  else{
                   $('.alert-danger').html('La cita no pudo ser agendada!').fadeIn().delay(2000).fadeOut('slow');
                   
                  }

                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });

           

        }


$(function(){

    $("#nombre-paciente").hover(function() {
        $( "#btnBuscar" ).fadeOut( 200 );//Salida
        $( "#btnBuscar" ).fadeIn( 200 );//entrada
    });


        $("#nombre-paciente").blur(function(){
            $(this).prop("readonly",""); 
        });

        $("#nombre-paciente").focus(function(){
            $(this).prop("readonly","readonly"); 
        });

//EVENTOS PARA EL CAMPO FECHA


    $("#fecha-cita").hover(function() {
        $( ".input-group-addon" ).fadeOut( 200 );//Salida
        $( ".input-group-addon" ).fadeIn( 200 );//entrada
    });


        $("#fecha-cita").blur(function(){
            $(this).prop("readonly",""); 
        });

        $("#fecha-cita").focus(function(){
            $(this).prop("readonly","readonly"); 
        });




        //Buscar
        $('#btnBuscar').click(function(){
            $('#myModal').modal('show');
        });

        //--------------------------------------
        $('#btn-buscarPaciente').click(function(){

            var nombre = document.getElementById("nombreAbuscar").value;
            var apellido = document.getElementById("apellidoAbuscar").value;

            var elemento_nombre_paciente=$('input[name=nombre]');
            var elemento_ap_paciente=$('input[name=apellido-p]');

              

            if(apellido==""&&nombre==""){
                elemento_nombre_paciente.focus();
            }
            else{
                mostrarResultadoBusquedaPorNombre(nombre,apellido);
            }

        });
        //--------------------------------------------------
        $('#btn-buscarExpediente').click(function(){

            var expediente = document.getElementById("expedienteAbuscar").value;

            if(expediente==""){
                 var elemento_num_exp=$('input[name=expediente]');
                 elemento_num_exp.focus();
            }
            else{
                mostrarResultadoBusquedaPorExpediente(expediente);
            }

        });

        //En este item se guarda temporalmente el id del paciente seleccionado
        $('#showdata').on('click', '.item-id-paciente', function(){
                    var id_paciente1 = $(this).attr('id-paciente');
                    var nombre = $(this).attr('nombre');
                    var ap_p = $(this).attr('ap-p');
                    var ap_m = $(this).attr('ap-m');

                    //id_paciente=id_paciente1;
                    //Falta agregar el apellido materno
                    document.getElementById("id-nombre-paciente").value=id_paciente1;
                    document.getElementById("nombre-paciente").value=nombre+" "+ap_p;
                    //alert(id);
                    $('#myModal').modal('hide');
        });

function mostrarResultadoBusquedaPorExpediente(numExpediente){
            $.ajax({//En este metodo falta repillar la consulta para que sea mas cercana a la respuesta
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/buscarExpediente',
               data:{id_expediente:numExpediente},
               dataType: 'json',
               success: function(data){

                if(data==false){

                        var html = '';
                        $('#showdata').html(html);
                            
                        $('.alert-danger').html('No hay registros con la busqueda seleccionada!').fadeIn().delay(2000).fadeOut('slow');
              

                    }
                    else{

                var html = '';
                var i;
                                    //if(data!=false){
                                        html +='<table class="table table-condensed table-bordered table table-hover" style="margin-top: 20px;">'+
                                        '<thead>'+
                                        '<tr class="success">'+
                                            '<th>NÚM EXPEDIENTE</th>'+
                                            '<th>NOMBRE</th>'+
                                            '<th>APELLIDO PATERNO</th>'+
                                            '<th>SELECCIONAR</th>'+
                                        '</tr>'
                                        '</thead>'+
                                            '<tbody>';
                                        for(i=0; i<data.length; i++){
                                            html +='<tr>'+
                                            '<td>'+data[i].id_expediente+'</td>'+
                                            '<td>'+data[i].nombre+'</td>'+
                                            '<td>'+data[i].apellido_p+'</td>'+
                                            '<td>'+
                                            '<center><a class="btn btn-default item-id-paciente"  id-paciente="'+data[i].id_paciente+'" '+'nombre="'+data[i].nombre+'" ap-p="'+data[i].apellido_p+'" '+'ap-m="'+data[i].apellido_m+'" ><i class="glyphicon glyphicon-ok"></i></a></center>'+
                                            '</td>'+
                                            '</tr>';
                                        }
                                        html +='</tbody>'+'</table>';
                                        
                                        $('#showdata').html(html);
                                    }
                                },
                                error: function(){
                                    alert('Could not get Data from Database');
                                }
                            });
}



function mostrarResultadoBusquedaPorNombre(nombre,apellido){
            $.ajax({//En este metodo falta repillar la consulta para que sea mas cercana a la respuesta
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/buscarPacienteLike',
               data:{nombre:nombre,apellido_p:apellido},
               dataType: 'json',
               success: function(data){

                if(data==false){

                        var html = '';
                        $('#showdata').html(html);
                            
                        $('.alert-danger').html('No hay registros con la busqueda seleccionada!').fadeIn().delay(2000).fadeOut('slow');
              

                    }
                    else{

                                    var html = '';
                                    var i;
                                    
                                        html +='<table class="table  table-condensed table-bordered table table-hover" style="margin-top: 20px;">'+
                                        '<thead>'+
                                        '<tr class="success">'+
                                        '<td>NÚM EXPEDIENTE</td>'+
                                        '<td>NOMBRE</td>'+
                                        '<td>APELLIDO PATERNO</td>'+
                                        '<td>SELECCIONAR</td>'+
                                        '</tr>'+
                                        '</thead>';
                                        for(i=0; i<data.length; i++){
                                            html +='<tr>'+
                                            '<td>'+data[i].id_expediente+'</td>'+
                                            '<td>'+data[i].nombre+'</td>'+
                                            '<td>'+data[i].apellido_p+'</td>'+
                                            '<td>'+
                                            '<center><a class="btn btn-default item-id-paciente"  id-paciente="'+data[i].id_paciente+'" '+'nombre="'+data[i].nombre+'" ap-p="'+data[i].apellido_p+'" '+'ap-m="'+data[i].apellido_m+'" ><i class="glyphicon glyphicon-ok"></i></a></center>'+
                                            '</td>'+
                                            '</tr>';
                                        }
                                        $('#showdata').html(html);

                                    }
                                    
                                },
                                error: function(){
                                    alert('Could not get Data from Database');
                                }
                            });
}


});
</script>




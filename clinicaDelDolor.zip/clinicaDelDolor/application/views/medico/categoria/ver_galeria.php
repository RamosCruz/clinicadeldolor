<br><br>


<div class="container">
 <div class="row">
     <div class="col-md-12" >
         <!----------------------------------------- -->
           <div class="form-horizontal">
            <div class="form-group">
                <!--label for="inputEmail3" class="col-sm-2 control-label">Filtrar por:</label>
                <div class="col-md-4">
                      <select class="form-control" name="selec_categoria" required>
                      <option value=""></option>
                     <?php foreach($categorias as $value) { ?>
                      <option value="<?php echo $value->id_categoria; ?>"><?php echo $value->categoria; ?></option>
                      <?php } ?>
                    </select>
                </div-->
                <a href="nueva_imagen" class="btn btn-success text-right"><span class="glyphicon glyphicon-plus"></span>Nueva imagen</a>
                
              </div>
         </div>
              <br>
         <div class="panel panel-primary" >
            <div class="panel-heading">
                <h3 class="panel-title" >Galeria</h3>
                <div class="form-inline">

                   <div class="form-group">

                    
                        <label class="sr-only" for="exampleInputAmount">Categoria</label>
                        <div class="input-group ">
                           <select class="form-control " name="categorias" id="categorias" onchange="obtenerImagenes();">
                              <option>Seleccione una categoría</option>
                              <option value="0">Todas</option>
                               <?php
                                foreach ($categorias as $value)
                                {
                                ?>    
                                <option value="<?=$value -> id_categoria ?>"><?=$value -> categoria ?></option>
                            <?php    
                                }
                               ?>
                           </select>
                        </div>
                    

                    </div>
                
                    <div class="form-group">
                        <label class="sr-only" for="exampleInputAmount">Descripcion</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="description1" placeholder="Descripción de la imagen">
                        </div>
                    </div>
                    <button class="btn btn-default" id="search"><span class="glyphicon glyphicon-search"></span>Buscar</button>
                

                </div>
            </div>
            <div class="panel-body">
                
                        <div class="container col-md-12">
                            <div class="row" id="row_galeria">

                                        
                          </div>
                        </div>
                    
                <!--Fin galeria imagen-->
                
            </div>
         </div>
        <!----------------------------------------- -->
     </div>
 </div>
</div>



<!-- Creates the bootstrap modal where the image will appear -->
<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <center><h1 id="prev" class="btn btn-default glyphicon glyphicon-chevron-left"></h1><img src="" id="imagepreview" style="width: auto; max-width:70%; max-height:70%; height:auto;  margin-top:2%;"><h1 id="next" class="btn btn-default glyphicon glyphicon-chevron-right"></h1><br><h1 id="closeModal" class="btn btn-default glyphicon glyphicon-remove"></h1></center>
</div>

<script> 
    
    
    function obtenerImagenes(){
         var categoria = $('#categorias option:selected').val();

        if(categoria == 0)
        {
            if($('#description1').val() == "")
            {
                todas();
            }else
            {
               busquedaTodasDesc($('#categorias option:selected').val(),$('#description1').val());
            }
        }else
        {
            if($('#description1').val() == "")
            {
                porCategoria($('#categorias option:selected').val());
            }else
            {
                busquedaCatDesc($('#categorias option:selected').val(),$('#description1').val());
            }
        }

    }
    
    $('#search').click(function(){
       obtenerImagenes();
        
    });
    
    
    var arreglo;
    var ima;
    var index;
    var id_m = "<?php echo $medico_logueado[0]->id_medico;?>";
    $.ajax({
        type: 'ajax',
        method: 'get',
        async: false,
        url: '<?php echo base_url() ?>medico/categoria/getImg',
        data: {id_medico:id_m},
        dataType: 'json',
        success: function(data){
            arreglo = data;
            //console.log(arreglo);
            todas(arreglo);
        },
        error: function(){
            alert('1 Could not get Data from Database');
        }
        });
    function todas()
    {
        var meses = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
        var html = '';
        var fecha;
        for (i = 0; i < arreglo.length; i++) 
        {
            
            var nombreArchivo= arreglo[i].nombreArchivo;
            var descripcion = arreglo[i].descripcion;
            var fecha_creacion = arreglo[i].fecha_creacion;
            //fecha_creacion in SQL DATETIME format ("yyyy-mm-dd hh:mm:ss")
            var sqlDateArr1 = fecha_creacion.split("-");
            var sYear = sqlDateArr1[0];
            var sMonth = (Number(sqlDateArr1[1]) - 1).toString();
            var sqlDateArr2 = sqlDateArr1[2].split(" ");
            var sDay = sqlDateArr2[0];
            var sqlDateArr3 = sqlDateArr2[1].split(":");
            var sHour = sqlDateArr3[0];
            var sMinute = sqlDateArr3[1];
            var sqlDateArr4 = sqlDateArr3[2].split(".");
            var sSecond = sqlDateArr4[0];
            fecha = new Date(sYear,sMonth,sDay,sHour,sMinute,sSecond);
            html += 
            '<div class="col-md-2"><div class="thumbnail"><img onclick="verImagen(&#39;'+nombreArchivo+'&#39;);" src="<?php echo base_url("uploads/galeria/");?>'+nombreArchivo+'" style="width:auto; height: 100px;"><div class="caption" >'+fecha.getDate() + " de " + meses[fecha.getMonth()] + " de " + fecha.getFullYear()+" "+fecha.getHours()+":"+fecha.getMinutes()+" hrs"+'<h4 style="color:#AA7182">'+descripcion+'<a class="glyphicon glyphicon-trash" href="../categoria/eliminarImagen/'+nombreArchivo+'"></a></h4></div></div></div>';
        }
        
        //console.log("Base: " + fecha_creacion);
        //console.log("JavaScript: "+fecha);
        $('#row_galeria').html(html);
    }
    
    function porCategoria(cat)
    {
        var meses = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
        var html = '';
        var fecha;
        for (i = 0; i < arreglo.length; i++) 
        {
            
            if(arreglo[i].id_categoria == cat)
            {
                var nombreArchivo= arreglo[i].nombreArchivo;
                var descripcion = arreglo[i].descripcion;
                var fecha_creacion = arreglo[i].fecha_creacion;
                //fecha_creacion in SQL DATETIME format ("yyyy-mm-dd hh:mm:ss")
                var sqlDateArr1 = fecha_creacion.split("-");
                var sYear = sqlDateArr1[0];
                var sMonth = (Number(sqlDateArr1[1]) - 1).toString();
                var sqlDateArr2 = sqlDateArr1[2].split(" ");
                var sDay = sqlDateArr2[0];
                var sqlDateArr3 = sqlDateArr2[1].split(":");
                var sHour = sqlDateArr3[0];
                var sMinute = sqlDateArr3[1];
                var sqlDateArr4 = sqlDateArr3[2].split(".");
                var sSecond = sqlDateArr4[0];
                fecha = new Date(sYear,sMonth,sDay,sHour,sMinute,sSecond);
                html += 
                '<div class="col-md-2"><div class="thumbnail"><img onclick="verImagen(&#39;'+nombreArchivo+'&#39;);" src="<?php echo base_url("uploads/galeria/");?>'+nombreArchivo+'" style="width:auto; height: 100px;"><div class="caption" >'+fecha.getDate() + " de " + meses[fecha.getMonth()] + " de " + fecha.getFullYear()+" "+fecha.getHours()+":"+fecha.getMinutes()+" hrs"+'<h4 style="color:#AA7182">'+descripcion+'<a class="glyphicon glyphicon-trash" href="../categoria/eliminarImagen/'+nombreArchivo+'"></a></h4></div></div></div>';
            }
        }
        
        //console.log("Base: " + fecha_creacion);
        //console.log("JavaScript: "+fecha);
        $('#row_galeria').html(html);
    }
    function busquedaTodasDesc(cat, desc)
    {
        var desc=desc.toLowerCase();
        var meses = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
        var html = '';
        var fecha;
        for (i = 0; i < arreglo.length; i++) 
        {
           var descripcion = arreglo[i].descripcion;

           descripcion=descripcion.toLowerCase();

            if (descripcion.indexOf(desc) > -1) 
            { 
                var nombreArchivo= arreglo[i].nombreArchivo;
                var descripcion = arreglo[i].descripcion;
                var fecha_creacion = arreglo[i].fecha_creacion;
                //fecha_creacion in SQL DATETIME format ("yyyy-mm-dd hh:mm:ss")
                var sqlDateArr1 = fecha_creacion.split("-");
                var sYear = sqlDateArr1[0];
                var sMonth = (Number(sqlDateArr1[1]) - 1).toString();
                var sqlDateArr2 = sqlDateArr1[2].split(" ");
                var sDay = sqlDateArr2[0];
                var sqlDateArr3 = sqlDateArr2[1].split(":");
                var sHour = sqlDateArr3[0];
                var sMinute = sqlDateArr3[1];
                var sqlDateArr4 = sqlDateArr3[2].split(".");
                var sSecond = sqlDateArr4[0];
                fecha = new Date(sYear,sMonth,sDay,sHour,sMinute,sSecond);
                html += 
                '<div class="col-md-2"><div class="thumbnail"><img onclick="verImagen(&#39;'+nombreArchivo+'&#39;);" src="<?php echo base_url("uploads/galeria/");?>'+nombreArchivo+'" style="width:auto; height: 100px;"><div class="caption" >'+fecha.getDate() + " de " + meses[fecha.getMonth()] + " de " + fecha.getFullYear()+" "+fecha.getHours()+":"+fecha.getMinutes()+" hrs"+'<h4 style="color:#AA7182">'+descripcion+'<a class="glyphicon glyphicon-trash" href="../categoria/eliminarImagen/'+nombreArchivo+'"></a></h4></div></div></div>';
            }
        }
        
        //console.log("Base: " + fecha_creacion);
        //console.log("JavaScript: "+fecha);
        $('#row_galeria').html(html);
    }
    function busquedaCatDesc(cat, desc)
    {
        var desc=desc.toLowerCase();
        var meses = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
        var html = '';
        var fecha;
        for (i = 0; i < arreglo.length; i++) 
        {
            
            if(arreglo[i].id_categoria == cat)
            {
               var descripcion = arreglo[i].descripcion;
               descripcion=descripcion.toLowerCase();
                if (descripcion.indexOf(desc) > -1) 
                { 
                    var nombreArchivo= arreglo[i].nombreArchivo;
                    var descripcion = arreglo[i].descripcion;
                    var fecha_creacion = arreglo[i].fecha_creacion;
                    //fecha_creacion in SQL DATETIME format ("yyyy-mm-dd hh:mm:ss")
                    var sqlDateArr1 = fecha_creacion.split("-");
                    var sYear = sqlDateArr1[0];
                    var sMonth = (Number(sqlDateArr1[1]) - 1).toString();
                    var sqlDateArr2 = sqlDateArr1[2].split(" ");
                    var sDay = sqlDateArr2[0];
                    var sqlDateArr3 = sqlDateArr2[1].split(":");
                    var sHour = sqlDateArr3[0];
                    var sMinute = sqlDateArr3[1];
                    var sqlDateArr4 = sqlDateArr3[2].split(".");
                    var sSecond = sqlDateArr4[0];
                    fecha = new Date(sYear,sMonth,sDay,sHour,sMinute,sSecond);
                    html += 
                    '<div class="col-md-2"><div class="thumbnail"><img onclick="verImagen(&#39;'+nombreArchivo+'&#39;);" src="<?php echo base_url("uploads/galeria/");?>'+nombreArchivo+'" style="width:auto; height: 100px;"><div class="caption" >'+fecha.getDate() + " de " + meses[fecha.getMonth()] + " de " + fecha.getFullYear()+" "+fecha.getHours()+":"+fecha.getMinutes()+" hrs"+'<h4 style="color:#AA7182">'+descripcion+'<a class="glyphicon glyphicon-trash" href="../categoria/eliminarImagen/'+nombreArchivo+'"></a></h4></div></div></div>';
                }
                    
            }
        }
        
        //console.log("Base: " + fecha_creacion);
        //console.log("JavaScript: "+fecha);
        $('#row_galeria').html(html);
    }
    
    function verImagen(img)
    {
        ima =img;
        $('#imagepreview').attr('src',"<?php echo base_url('uploads/galeria/');?>"+img );
        $('#imagemodal').modal('show');
    }
    $('#closeModal').click(function(){
        $('#imagemodal').modal('hide');
    });
    $('#prev').click(function(){
        for(var i = 0; i<arreglo.length; i++)
        {
            if(arreglo[i].nombreArchivo == ima)
            {
                index = i;
            }
        }
        index -= 1;
        if(index<0)
        {
            index = arreglo.length-1;
        }
        $('#imagepreview').attr('src',"<?php echo base_url('uploads/galeria/');?>"+arreglo[index].nombreArchivo );
        ima = arreglo[index].nombreArchivo;
    });
    $('#next').click(function(){
        for(var i = 0; i<arreglo.length; i++)
        {
            if(arreglo[i].nombreArchivo == ima)
            {
                index = i;
            }
        }
        index += 1;
        if(index == arreglo.length)
        {
            index = 0;
        }
        $('#imagepreview').attr('src',"<?php echo base_url('uploads/galeria/');?>"+arreglo[index].nombreArchivo );
        ima = arreglo[index].nombreArchivo;
    });
    
</script>
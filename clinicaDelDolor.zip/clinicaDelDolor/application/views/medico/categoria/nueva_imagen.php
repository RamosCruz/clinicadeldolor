<br><br><hr>


<div class="container">
 <div class="row">
     <div class="col-md-12" >
         <!----------------------------------------- -->
        
         <div class="panel panel-primary class" >
            <div class="panel-heading">
                <h3 class="panel-title" >Nueva imagen</h3>
            </div>
            <div class="panel-body">
                <div class="panel panel-default" >
                    <div class="panel-body">
                      <div class="col-md-8 col-md-offset-2">
                           <form class="form-horizontal" method="post" action="../Categoria/cargarImagen" enctype="multipart/form-data">
                            <div class="form-group"> 
                               <div class="col-sm-3 control-label"></div>
                               <div class="col-sm-9">
                                   <input type="hidden" class="form-control" value="<?php echo $medico_logueado[0]->id_medico;?>" name="id_medico">
                               </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-3 control-label">Nombre imagen.</label>
                                <div class="col-sm-9">
                                  <input type="text" class="form-control" id="inputEmail3" placeholder="Nombre" required name="nombreImg">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputfile1" class="col-sm-3 control-label">Adjuntar un archivo.</label>
                                <div class="col-sm-9">
                                    <input type="file" name="userfile" required accept="image/jpeg,image/jpg,image/png,image/gif">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-3 control-label">Asignar categoria.</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="selec_categoria" required>
                                     <?php foreach($categorias as $value) { ?>
                                      <option value="<?php echo $value->id_categoria; ?>"><?php echo $value->categoria; ?></option>
                                      <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success btn-lg"><span class="glyphicon glyphicon-plus"></span>Agregar imagen</button>
                        </form>
                        </div>
                    </div>
                 </div>
            
             </div>
         </div>
     </div>
    </div>
</div>

<hr>
<hr>
 <div class="page-header">
  <h1 style="color:#AF81C9"></h1>
</div>
<div class="container">
 <div class="row">
     <div class="col-md-12" >
         <!----------------ALERT------------------------- -->
        
         <div class="panel panel-primary class" style="height: 550px;">
            <div class="panel-heading">
                <h3 class="panel-title" >CATÁLOGO DE CATEGORÍAS</h3>
            </div>
            <div class="panel-body">
                <div class="row">

                    <div class="col-md-2">

                    </div>

                    <div class="col-md-8">

                        <!-- --------------------EL FORMULARIO DE NUEVA CATEGORIA-------------------------- -->
                              <div class="panel panel-success class">
                                
                                    <div class="panel-heading">
                                        <h1 class="panel-title" >Nueva categoría</h1>
                                    </div>
                                    
                                    <div class="panel-body">
                                             <div class="row">
                                                <form class="form-horizontal"  id="formularioGuardarCategoria"  method="post" action="">
                                                    <div class="col-md-8">
                                                                 <div class="form-group">
                                                                    <div class="col-sm-2">
                                                                        <label for="categoria" class="control-label">Categoría</label>
                                                                    </div>
                                                                    <div class="col-sm-10">
                                                                        <input type="text" title="Se requiere un nombre de una categoría de imagen!" class="form-control" id="nombre-categoria" placeholder="Ej: Cuerpo Humano" name="nombre-categoria" required />
                                                                    </div>
                                                                 </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <div class="col-sm-offset-2 col-sm-10">
                                                                        <button type="submit" id="btn-agregarCategoria" name="btn-agregarCategoria" class="btn btn-success btn-md btn-block"><span class="glyphicon  glyphicon-ok"></span> Agregar</button>
                                                                    </div>
                                                                </div>
                                                    </div>
                                                </form>
                                             </div>
                                    </div>
                                    
                                <!-- -->
                                <!-- <br> -->
                                <!-- -->
                                </div>
                                  <div class="alert alert-danger" role="alert" style="display: none;">
                                  </div>

                                  <div class="alert alert-success" role="alert" style="display: none;">
  		                            </div>


                                <div class="table-responsive" id="conexion">
                                    <div class="nuevaTabla" id="showdata">
                                         
                                    </div>  
                                </div>
                            

                                
                             

                        <!-- --------------------FIN FORMULARIO CITAS-------------------------- -->

                    </div>

                    <div class="col-md-2">

                    </div>

                </div>
                <hr>
            </div>
         </div>
        <!----------------------------------------- -->
     </div>
 </div>
</div>





<!-- ------------------------------------MODAL ELIMINAR------------------------------------ -->
<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Eliminar</h4>
      </div>
      <div class="modal-body">
        	Estas seguro de eliminar el registro?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="button" id="btnDelete" class="btn btn-danger">Eliminar</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--        :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::            -->



<!-- ------------------------------------MODAL ACTUALIZAR------------------------------------ -->
<div id="editModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Editar Categoría</h4>
      </div>
      <div class="modal-body">
           <form id="formActualizarCategoria" action="" method="post" class="form-horizontal">
            <input type="hidden" name="id-categoria-model" value="0">
            <div class="form-group">
              <label for="name" class="label-control col-md-4">Nombre de categoría</label>
              <div class="col-md-8">
                <input type="text" name="nombre-categoria-model" class="form-control" required>
              </div>
            </div>
            <div class="col-sm-12">
              <div class="col-sm-2"></div>

             <div class="form-group">
              <button type="submit" id="btnSalvarCambios" class="btn btn-primary col-sm-8">Actualizar</button>
             </div>
           </div>
          </form>
          <br>
        
         
      </div>
      <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->








<!----------------EVENTOS JAVASCRIPT------------------------- -->
<script>
mostrarCategorias();

   $('#showdata').on('click', '.item-id-delete', function(){
      var id_categoria = $(this).attr('data');

      $('#deleteModal').modal('show');
      //prevent previous handler - unbind()
      $('#btnDelete').unbind().click(function(){
        $.ajax({
          type: 'ajax',
          method: 'get',
          async: false,
          url: '<?php echo base_url() ?>medico/categoria/eliminarCategoria',
          data:{id_categoria:id_categoria},
          dataType: 'json',
          success: function(response){
            if(response.success){
              $('#deleteModal').modal('hide');
              $('.alert-success').html('La categoría ha sido eliminada con éxito!').fadeIn().delay(1000).fadeOut('slow');
              mostrarCategorias();
            }else{
              alert('Error');
            }
          },
          error: function(){
            swal(
              'Alto!',
              'Esta categoria es usada en la galeria!',
              'warning'
            )
              $('#deleteModal').modal('hide');
          }
        });
      });
    });

//---------------------------

   //PETICION ACTUALIZAR
   $('#btnSalvarCambios').click(function(){
      var url = '<?php echo base_url() ?>medico/categoria/actualizarCategoria';
      var data = $('#formActualizarCategoria').serialize();
      //alert(url);
     
      //validate form
      var categoria = $('input[name=nombre-categoria-model]');
     
      var result = '';
      if(categoria.val()==''){
        categoria.parent().parent().addClass('has-error');
      }else{
        categoria.parent().parent().removeClass('has-error');
        result +='1';
      }

       //alert(data);

      if(result=='1'){
        $.ajax({
          type: 'ajax',
          method: 'post',
          url: url,
          data: data,
          async: false,
          dataType: 'json',
          success: function(response){
            //alert(response.success);
            if(response.success){
              $('#editModal').modal('hide');
              $('.alert-success').html('Categoría actualizada con éxito!').fadeIn().delay(1000).fadeOut('slow');
              mostrarCategorias();
            }else{
              alert('Error');
            }
          },
          error: function(){
            alert('Could not add data');
          }
        });
      }
    });




   //PETICION EDITAR
    $('#showdata').on('click', '.item-id-edit', function(){
      var id_categoria = $(this).attr('data');
      $('#editModal').modal('show');
      $.ajax({
        type: 'ajax',
        method: 'get',
        url: '<?php echo base_url() ?>medico/categoria/editarCategoria',
        data: {id_categoria: id_categoria},
        async: false,
        dataType: 'json',
        success: function(data){
          $('input[name=id-categoria-model]').val(data.id_categoria);
          $('input[name=nombre-categoria-model]').val(data.categoria);
          
        },
        error: function(){
          alert('Could not Edit Data');
        }
      });
    });





//AGREGAR CATEGORIA
            $('#btn-agregarCategoria').click(function(){
                var nuevacategoria=$('#nombre-categoria').val();
                

                var data = $('#formularioGuardarCategoria').serialize(); 
                if(nuevacategoria!=""){
                  ingresaCategoria(nuevacategoria);
                };
            });

        //...................................................

         function ingresaCategoria(categoria){
            //alert(categoria);
            var id_mmedic = "<?php echo $medico_logueado[0]->id_medico?>";
            $.ajax({
                type: 'ajax',
               method: 'post',
               async: false,
               url: '<?php echo base_url() ?>medico/categoria/insertarCategoria',
               data:{categoria:categoria,id_mmedic:id_mmedic},
               dataType: 'json',
               success: function(response){

                 if(response){
                     swal({
                                    title: "Categoria Agregada!",
                                    type: "success",
                                    timer: 1800,
                                    showConfirmButton: false
                                }
                                );
                  }
                  else{
                   //alert("no se pudo insertar!"); 
                   $('.alert-danger').html('La categoria no pudo ser insertada').fadeIn().delay(2000).fadeOut('slow');
                   
                  }

                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });

        }
      //...............................................................
      function mostrarCategorias(){
      var id_mmedic = "<?php echo $medico_logueado[0]->id_medico?>";
      $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/categoria/getCategorias',
               data:{id_mmedic:id_mmedic},
               dataType: 'json',
                success: function(data){
                    //alert(data);

                     if(data==false){
                        //alert(data);
                        var html = '';
                        $('#showdata').html(html);
                            
                        $('.alert-success').html('No hay registros en el catálogo de CATEGORÍAS!').fadeIn().delay(1000).fadeOut('slow');
              

                    }
                    else{

                    var html = '';
                        var i;
                        html +='<table class="table table-bordered table-responsive  table-hover  table-condensed" id="tabla-general">'+
                                            '<thead>'+
                                            '<tr class="success">'+
                                                '<th style="width: 500px;">CATEGORÍA</th>'+
                                                '<th style="width: 215px;"><center>ACCIONES</center></th>'+
                                            '</tr>'+
                                            '</thead>'+
                                                '<tbody>';
                                            for(i=0; i<data.length; i++){
                                                html +='<tr>'+
                                                '<td>'+data[i].categoria+'</td>'+
                                                '<td>'+
                                                '<center>'+
                                                    '<a href="javascript:;" data="'+data[i].id_categoria+'" type="button" class="btn btn-default item-id-edit" style="color:#29A9CC" title="Editar Categoría"><i class="glyphicon glyphicon-pencil"></i></a>'+
                                                    '<a href="javascript:;" data="'+data[i].id_categoria+'"  class="btn btn-default item-id-delete" style="color:RED" title="Eliminar Categoría"><i class="glyphicon glyphicon-remove"></i></a>'+
                                                '<center>'+                                                                                
                                                '</td>'+
                                                '</tr>';
                                            }
                                            html +='</tbody>'+'</table>';
                                            
                                            $('#showdata').html(html);

                                            //--CONTEMOS LAS FILAS PARA QUE APAREZCA EL SCROLL
                                            var filas=$("#tabla-general tr").length;
                                            if(filas>7){

                                              //$("#tabla-general tr").css({'display':'inline-table'});
                                              //$("#estatico").css({'width':'500px',});

                                              $("#tabla-general").css({'overflow-y':'scroll','height':'300px','display':'block'});
                                              //alert("El total de filas es mayor a: "+filas);
                                            }



                                            

                    

                  }
                   
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });

        }


            
           



    
</script>

<!-- --------------------------------------------------------- -->
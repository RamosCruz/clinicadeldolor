<br>
<hr>
<div class="col-md-offset-6">
	<form class="form-inline" method="post" action="<?php echo base_url('medico/Formatos/ImprimirExpediente');?>" target="_blank">
		<div class="form-group">
			<input type="text" class="form-control" style="visibility:hidden" name="curp" value="<?php echo $verPaciente[0]->curp; ?>" placeholder="CURP">
			<a href="../" type="button" class="btn btn-info">Regresar</a>
			<button  type="submit" class="btn btn-success">Imprimir Expediente Clínico</button>		    	
		</div>
	</form>
</div>



<hr>
<div class="panel panel-primary">
	<div class="panel-heading">
		<div class="row">
			<div class="col-md-2" >
				
					
				
				<center>
					<?php if($fotoDelPaciente!=false){?>
							<img id="fotoDelPacienteActivo" src="<?php echo $fotoDelPaciente[0]->foto?>" class="img-circle"  width="130" height="130" style="background-color:white;">
					<?php } 
					elseif ($verPaciente[0]->sexo=='M'){?>
							<img id="fotoDelPacienteActivo" src="<?php echo base_url('assets/img/perfil_m.ico');?>" class="img-circle"  width="130" height="130" style="background-color:white;">
					<?php }
					else{ ?>
						<img id="fotoDelPacienteActivo" src="<?php echo base_url('assets/img/perfil_h.ico');?>" class="img-circle"  width="130" height="130" style="background-color:white;">
					<?php } ?>
				</center>
				
				
				
			</div>
			<div class="col-md-4">
				<br>
				<h3><strong><?php echo $verPaciente[0]->nombre." ".$verPaciente[0]->app." ".$verPaciente[0]->apm."  ";?></strong></h3>
				<strong style="color:#54D1F1"><?php echo $verPaciente[0]->curp; ?></strong>


				
			</div>

			<div class="col-md-6">
				<div class="row">	

					<div class="col-md-6">

					</div>
					<div class="col-md-6">
						<?php
						$date = new DateTime($expediente[0]->fecha_creacion);
						$fecha_c = $date->format('d/m/Y');
						?>
						<h4>
							Fecha de registro: <strong><?php echo $fecha_c ?></strong>
						</h4>
						<h4>
							Núm. de expediente: <strong><?php echo $expediente[0]->id_expediente;?></strong>
						</h4>

					</div>

				</div>
			</div>

			


		</div>
	</div>
	<div class="panel-body">

		<div class="row">
			<div class="col-md-4">
				<h4 style="color:#336699"><small style="color:#999999">Grupo sanguineo: </small><strong><?php echo $verPaciente[0]->tipoSangre; ?></strong></h4>
			</div>
			<div class="col-md-4">
				<h4 style="color:#336699"><small style="color:#999999">Telefono: </small><strong><?php echo $verPaciente[0]->telefono; ?></strong></h4>
			</div>
			<div class="col-md-4">
				<!--<h4 style="color:#336699"><small style="color:#999999">Domicilio: </small><strong><p id="domicilioPaciente"></p></strong></h4>-->
  <h4 style="color:#336699"><small style="color:#999999">Estado civil: </small><strong><?php echo $verPaciente[0]->estadoCivil; ?></strong></h4>
			</div>
		</div>


		<div class="row">
			<div class="col-md-4">
				<h4 style="color:#336699"><small style="color:#999999">Fecha de Nacimiento: </small><strong><?php
$date = new DateTime($verPaciente[0]->fecha_nacimiento);
						$fecha_nace = $date->format('d/m/Y');

						echo $fecha_nace;?>
</strong></h4>
			</div>
			<div class="col-md-4">
				<h4 style="color:#336699"><small style="color:#999999">Alergia: </small><strong><?php echo $verPaciente[0]->alergia; ?></strong></h4>
			</div>
			<div class="col-md-4">
				
			</div>
		</div>
		<hr>

      <!--<div class="panel panel-info">
          <div class="panel-heading">
            <h3 class="panel-title">Signos vitales</h3>
          </div>
          <div class="panel-body">
            .....
          </div>
      </div>-->

      <!-- Nav tabs -->
      <div>

      	<ul class="nav nav-tabs" role="tablist">
          	<li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab"><h4 style="color:#AF81C9"><strong>Antecedentes</strong></h4></a></li>
			<li role="presentation"><a href="#fotografiasHome" aria-controls="fotografiasHome" role="tab" data-toggle="tab"><h4 style="color:#AF81C9"><strong>Fotografía</strong></h4></a></li>          
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
        	<div role="tabpanel" class="tab-pane active" id="home">
        		<div class="panel panel-default">
		      	<div class="panel-body">

		      		<!-- -->
		      		<div class="panel-group" id="accordion">

		      			<div class="panel panel-default">
		      				<div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse1">
		      					<div class="col-md-offset-1"><h4 style="color:#AF81C9">1. <strong style="color:#336699">Antecedentes Gineco-Obstetricos</strong></h4></div>
		      				</div>
		      					<div id="collapse1" class="panel-collapse collapse in">
		      						<div class="panel-body">
		      							<!-- --------------- -->
		      							<?php
		      							if ($verPaciente[0]->sexo=='M')
		      							{
		      								$this->load->view($a);
		      							}
		      							else
		      							{
		      								echo '<center><h4 style="color:#AF81C9"><strong style="color:#54D1F1">No aplica.</strong></h4></center>';
		      							}
		      							?>
		      							<!-- --------------- -->
		      						</div>
		      					</div>
		      			</div>

		      				<div class="panel panel-default">
		      							<div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse2">
		      								<div class="col-md-offset-1"><h4 style="color:#AF81C9">2. <strong style="color:#336699">Antecedentes Heredo-Familiares</strong></h4></div>
					      				</div>
		      								
		      							
		      						<div id="collapse2" class="panel-collapse collapse">
		      							<div class="panel-body">
		      								<!-- --------------- -->
		      								<?php 
					                            $this->load->view($b);
					                        ?>
		      								<!-- --------------- -->
		      							</div>
		      						</div>
		      					</div>


		      						<div class="panel panel-default">
		      							<div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse3">
					      					<div class="col-md-offset-1"><h4 style="color:#AF81C9">3. <strong style="color:#336699">Antecedentes Personales Patológicos</strong></h4></div>
					      				</div>
		      										
		      									

		      								<div id="collapse3" class="panel-collapse collapse">
		      									<div class="panel-body">
		      									<!-- --------------- -->
		      									<?php 
						                            $this->load->view($c);
						                        ?>
		      									<!-- --------------- -->
		      									</div>
		      								</div>
		      							</div>

		      							<div class="panel panel-default">
		      								<div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse4">
					      					<div class="col-md-offset-1"><h4 style="color:#AF81C9">4. <strong style="color:#336699">Antecedentes Personales no Patológicos</strong></h4></div>
					      				</div>
		      											
		      										
		      									<div id="collapse4" class="panel-collapse collapse">
		      										<div class="panel-body">
			      									<!-- --------------- -->
			      									<?php 
							                            $this->load->view($d);
							                        ?>
			      									<!-- --------------- -->
		      										</div>
		      									</div>
		      								</div>

		      								<div class="panel panel-default">
		      									<div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse5">
					      							<div class="col-md-offset-1"><h4 style="color:#AF81C9">5. <strong style="color:#336699">Fotografías </strong></h4></div>
					      						</div>
		      												
		      										
		      										<div id="collapse5" class="panel-collapse collapse">
		      											<div class="panel-body">
		      												<!-- --------------- -->
					      									<?php 
									                            $this->load->view($f);
									                        ?>
					      									<!-- --------------- -->
		      											</div>
		      										</div>
		      									</div>

		      									<div class="panel panel-default">
		      										<div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse6">
					      						
					      							<div class="col-md-offset-1"><h4 style="color:#AF81C9">6. <strong style="color:#336699">Constancias y/o Anexos</strong></h4></div>
					      				</div>
		      													
		      											
		      											<div id="collapse6" class="panel-collapse collapse">
		      												<div class="panel-body">
		      												<!-- --------------- -->
					      									<?php 
									                            $this->load->view($e);
									                        ?>
					      									<!-- --------------- -->
		      												</div>
		      											</div>
		      										</div>

		      									</div>
		          	<!-- -->



		            </div>
		        </div>
        	</div>

        	<div role="tabpanel" class="tab-pane" id="fotografiasHome">
            
            <div class="panel panel-default">
            	<!--- AÑADIR FOTOGRAFIA DEL PACIENTE MEDIANTE LA CAMARA O SELECCIONANDO UN ARCHIVO -->
            	<!-- Nav tabs -->
                <div class="row">
<div class="col-md-8 col-md-offset-2"><br>
							<div class="alert alert-warning mensaje-registro-medicamento" role="alert">
		                  		<p align="justify"><strong>Importante: </strong> Para el uso adecuado de la cámara web es importante mencionar que será necesario utilizar cualquiera de los siguientes navegadores: <strong>Firefox</strong>, <strong>Google Chrome</strong> u <strong>Opera.</strong> </p>
		                  		<p align="justify"><strong>Pasos para capturar la fotografía de perfil del paciente</strong></p>
		                  		<p align="justify">1.- Active la cámara web precionando el  icono  de "cámara color azul"</p>
		                  		<p align="justify">2.- Para capturar la foto del paciente bastará con precionar el botón "Capturar" </p>
		                  		<p align="justify">3.- Para guardar/actualizar la foto de perfil del paciente bastará con precionar el icono de "disket"  </p>
		                  		<p align="justify">4.- Para apagar la cámara web precione el  icono  de "cámara color roja"</p>
		                  		<br>
		                  		<p align="justify"><strong>Nota! </strong> Si el paciente ya cuenta con una foto de perfil ésta será actualizada en automático cada ves que se precione el icono de  "disket" </p>
		                  		<center>
								<h3>
									<span style="color:blue" class="glyphicon glyphicon-camera eventoHover" id="iniciaCamara" title="Precione este icono para activar la cámara web" ></span>
									<span style="color:red" class="glyphicon glyphicon-camera eventoHover" id="apagarCamara" title="Precione este icono para desactivar la cámara web" ></span>
									<span style="color:green" class="glyphicon glyphicon-floppy-disk eventoHover" id="guardarFoto" title="Precione este icono para guardar la imagen" ></span>
								</h3>
							</center>
		                  	</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-8 col-md-offset-2">
                            <div class="col-md-12">
                                <center><div class="col-md-6">
                                    <div>
                                        <div id="webcam" class="fotografia">
                                            <!--<span class="marca">tutoriales.com</span>-->
                                            <button type="button" id="obturador" class="btn btn-info btn-block">Capturar</button>
                                        </div>

                                    </div>


                                </div></center>
                                <center><div class="col-md-6">
                                    <div>
                                        <div id="say-cheese-snapshots" class="fotografia">
                                            <!--<span class="marca">Snapshots</span>-->

                                        </div>
                                    </div>


                                    </div></center>
                            </div>
						</div>
					</div>

            	<!--- ---------------------------------------------------------------------------- -->
             </div>
           </div>
        </div>

      </div>
        

      
      
      
       
       
</div>





    <script type="text/javascript">
    //window.onload = getDomicilio();
    

    
       

    
    

   
       function getDomicilio(){
	var curp="<?php echo $verPaciente[0]->curp;?>";
      $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/paciente/obtenerDomicilioDelPaciente',
               data:{id_paciente:curp},
               dataType: 'json',
               success: function(data){

               	
               	$("#domicilioPaciente").text(data);
                   //alert(data)

                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });

        }

</script>

<!-- ------------------------------------------------------------------ -->
<!-- ------------------------------------------------------------------ -->
<style type="text/css">
		span.eventoHover {
  background: white;
  border-radius: 0.8em;
  -moz-border-radius: 0.8em;
  -webkit-border-radius: 0.8em;
  color: #ffffff;
  display: inline-block;
  font-weight: bold;
  line-height: 1.4em;
  margin-right: 15px;
  text-align: center;
  width: 1.4em; 
  opacity: .5;
}

		span.eventoHover:hover, span.eventoHover:active {background: black; opacity: 1;}

        #content{
            margin: 0 auto;
            width: 1000px;
            position: relative;

        }

        .fotografia{
            width: auto;
            height: 310px;
            border: 20px solid #333;
            background: #eee;
            -webkit-border-radius: 20px;
            -moz-border-radius: 20px;
            border-radius: 20px;
            position: relative;
            margin-top: 50px;
            margin-bottom: 50px;

        }

        .marca {
            z-index: 2;
            position: absolute;
            color: #eee;
            font-size: 10px;
            bottom: -16px;
            left: 152px;

        }

       


    </style>


    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>-->
    <script src="<?php echo base_url() ?>assets/say-cheese-master/say-cheese.js"></script>
    <script type="text/javascript">
  


    var navegador=null;
    $('#apagarCamara').hide();

 $(document).ready(function(){
    if (navigator.userAgent.indexOf('Mac OS X') != -1) {
        // Mac
	if ($.browser.opera) { $('html').addClass('opera'); }
	if ($.browser.webkit) { $('html').addClass('webkit'); }
	if ($.browser.mozilla) { $('html').addClass('mozilla'); }
	if (/camino/.test(navigator.userAgent.toLowerCase())){ $('html').addClass('camino'); }
	if (/chrome/.test(navigator.userAgent.toLowerCase())) { $('html').addClass('chrome'); }
	if (navigator && navigator.platform && navigator.platform.match(/^(iPad|iPod|iPhone)$/)) { $('html').addClass('apple'); }
	if (navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1) { $('html').addClass('safari'); }
    } else {
        // Not Mac
	if ($.browser.opera) { $('html').addClass('opera-pc'); }
	if ($.browser.webkit) { $('html').addClass('webkit-pc'); }
	if ($.browser.mozilla) { $('html').addClass('mozilla-pc'); navegador="mozilla";}
	if (document.all && document.addEventListener) { $('html').addClass('ie9'); }
	if (/chrome/.test(navigator.userAgent.toLowerCase())) { $('html').addClass('chrome-pc'); }
	if (navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1) { $('html').addClass('safari-pc'); }
    }

    if(navegador!=null){
    	$('#apagarCamara').show();
    }
});


       var img=null;
       var sayCheese = new SayCheese('#webcam',{snapshots: true});

      
       
       sayCheese.on('snapshot', function(snapshot){
           img = document.createElement('img');

           $(img).on('load', function(){
               $('#say-cheese-snapshots').html(img);
           });
           img.src = snapshot.toDataURL('image/png');
       });
       //-----------------------------------------------------------
        $('#guardarFoto').click(function(){
        	var src = img.src;
        	var id_paciente="<?php echo $verPaciente[0]->curp; ?>";
         var data = {
         	id_paciente:id_paciente,
             src: src
         }

          guardaFoto(data);

         });

        function guardaFoto(data){
         $.ajax({
         	type: 'ajax',
         	async: false,
             dataType: 'json',
             url: '<?php echo base_url() ?>medico/webcam/validaPacienteConFoto',
             data: data,
             type: 'post',
             dataType: 'json',
             sucess: function(respuesta) {
             	if(respuesta==false){
             	}else{
             		alert("Este paciente ya tiene una foto");
             	}
             }
         });
         location.reload();
        }
        //-----------------Cuando capturas la imagen---------------------------------------------
       $('#obturador').click(function(){
           sayCheese.takeSnapshot(320,270);
           return false;
       });
       var camaraPrendida=false;
       //--------------------------------------------------------------
       $('#iniciaCamara').click(function(){
       	if(camaraPrendida==false){
       		sayCheese.start();
       		camaraPrendida=true;
       	}
        	
        });
       //-------------------------------------------------------------
       $('#apagarCamara').click(function(){
        	sayCheese.stop();
        	$( "video" ).remove();
        	camaraPrendida=false;
        });
       //--------------------------------------------------------------

       
</script>

<!-- ------------------------------------------------------------------ -->
















<script>
	$(function(){
		showAllEmployee();

		//Add New
		$('#btnAdd').click(function(){
			$('#myModal').modal('show');
			$('#myModal').find('.modal-title').text('Antecedentes Gineco-Obstetricos');
			$('#myForm').attr('action', '<?php echo base_url() ?>medico/historial/guardarAnteGineObs');
		});
        
        $('#btnAdd1').click(function(){
			$('#myModal1').modal('show');
			$('#myModal1').find('.modal-title').text('Antecedentes Gineco-Obstetricos');
			$('#myForm1').attr('action', '<?php echo base_url() ?>medico/historial/guardarAnteHeredoFam');
		});


		$('#btnSave').click(function(){
			var url = $('#myForm').attr('action');
			var data = $('#myForm').serialize();
			//validate form
			var menarquia = $('input[name=menarquia]');
			var duracion = $('input[name=duracion]');
            var cantidad_sangre = $('input[name=c_sangre]');
            var frecuencia = $('input[name=frecuencia]');
            var presencia_dolor = $('input[name=dolor]');
            var otras_secreciones_vag = $('input[name=secreciones]');
            var vida_sexual_activa = $('input[name=sexual]');
            var edad_inicio_sexual = $('input[name=edad_inicio]');
            var numero_companeros_sexuales = $('input[name=comp_sexuales]');
            var metodo_anticonceptivo = $('input[name=metodo]');
            var tipo_relaciones = $('input[name=relaciones]');
            var enfermedades_trans_sex = $('input[name=enfermedades]');
            var gestaciones = $('input[name=gestaciones]');
            var partos = $('input[name=partos]');
            var abortos = $('input[name=abortos]');
            var cesareas = $('input[name=cesareas]');
            var ant_perinatales_de_imp = $('textarea[name=ant_perinatales]');
			var result = '';
            
			if(menarquia.val()==''){
				menarquia.parent().parent().addClass('has-error');
			}else{
				menarquia.parent().parent().removeClass('has-error');
				result +='1';
			}
			if(duracion.val()==''){
				duracion.parent().parent().addClass('has-error');
			}else{
				duracion.parent().parent().removeClass('has-error');
				result +='2';
			}
            if(cantidad_sangre.val()==''){
				cantidad_sangre.parent().parent().addClass('has-error');
			}else{
				cantidad_sangre.parent().parent().removeClass('has-error');
				result +='3';
			}
            if(frecuencia.val()==''){
				frecuencia.parent().parent().addClass('has-error');
			}else{
				frecuencia.parent().parent().removeClass('has-error');
				result +='4';
			}
            if(presencia_dolor.val()==''){
				presencia_dolor.parent().parent().addClass('has-error');
			}else{
				presencia_dolor.parent().parent().removeClass('has-error');
				result +='5';
			}
            if(otras_secreciones_vag.val()==''){
				otras_secreciones_vag.parent().parent().addClass('has-error');
			}else{
				otras_secreciones_vag.parent().parent().removeClass('has-error');
				result +='6';
			}
            if(vida_sexual_activa.val()==''){
				vida_sexual_activa.parent().parent().addClass('has-error');
			}else{
				vida_sexual_activa.parent().parent().removeClass('has-error');
				result +='7';
			}
            if(edad_inicio_sexual.val()==''){
				edad_inicio_sexual.parent().parent().addClass('has-error');
			}else{
				edad_inicio_sexual.parent().parent().removeClass('has-error');
				result +='8';
			}
            if(numero_companeros_sexuales.val()==''){
				numero_companeros_sexuales.parent().parent().addClass('has-error');
			}else{
				numero_companeros_sexuales.parent().parent().removeClass('has-error');
				result +='9';
			}
            if(metodo_anticonceptivo.val()==''){
				metodo_anticonceptivo.parent().parent().addClass('has-error');
			}else{
				metodo_anticonceptivo.parent().parent().removeClass('has-error');
				result +='0';
			}
            if(tipo_relaciones.val()==''){
				tipo_relaciones.parent().parent().addClass('has-error');
			}else{
				tipo_relaciones.parent().parent().removeClass('has-error');
				result +='1';
			}
            if(enfermedades_trans_sex.val()==''){
				enfermedades_trans_sex.parent().parent().addClass('has-error');
			}else{
				enfermedades_trans_sex.parent().parent().removeClass('has-error');
				result +='2';
			}
            if(gestaciones.val()==''){
				gestaciones.parent().parent().addClass('has-error');
			}else{
				gestaciones.parent().parent().removeClass('has-error');
				result +='3';
			}
            if(partos.val()==''){
				partos.parent().parent().addClass('has-error');
			}else{
				partos.parent().parent().removeClass('has-error');
				result +='4';
			}
            if(abortos.val()==''){
				abortos.parent().parent().addClass('has-error');
			}else{
				abortos.parent().parent().removeClass('has-error');
				result +='5';
			}
            if(cesareas.val()==''){
				cesareas.parent().parent().addClass('has-error');
			}else{
				cesareas.parent().parent().removeClass('has-error');
				result +='6';
			}
            if(ant_perinatales_de_imp.val()==''){
				ant_perinatales_de_imp.parent().parent().addClass('has-error');
			}else{
				ant_perinatales_de_imp.parent().parent().removeClass('has-error');
				result +='7';
			}
			if(result=='12345678901234567'){
				$.ajax({
					type: 'ajax',
					method: 'post',
					url: $('#myForm').attr('action'),
					data: $('#myForm').serialize(),
					async: false,
					dataType: 'json',
					success: function(response){
						if(response.success){
							$('#myModal').modal('hide');
							$('#myForm')[0].reset();
							if(response.type=='add'){
								var type = 'added'
							}else if(response.type=='update'){
								var type ="updated"
							}
							$('.alert-success').html('El historial se ha guardado satisfactoriamente.').fadeIn().delay(4000).fadeOut('slow');
						}else{
							alert('Error');
						}
					},
					error: function(){
						alert('Could not add data');
					}
				});
			}
		});
        
        
        $('#btnSave1').click(function(){
			var url = $('#myForm1').attr('action');
			var data = $('#myForm1').serialize();
			//validate form
			var result = '1';
			if(result=='1'){
				$.ajax({
					type: 'ajax',
					method: 'post',
					url: $('#myForm1').attr('action'),
					data: $('#myForm1').serialize(),
					async: false,
					dataType: 'json',
					success: function(response){
						if(response.success){
							$('#myModal1').modal('hide');
							$('#myForm1')[0].reset();
							if(response.type=='add'){
								var type = 'added'
							}else if(response.type=='update'){
								var type ="updated"
							}
							$('.alert-success').html('El historial se ha guardado satisfactoriamente.').fadeIn().delay(4000).fadeOut('slow');
						}else{
							alert('Error');
						}
					},
					error: function(){
						alert('Could not add data');
					}
				});
			}
		});
        
		//edit
		$('#showdata').on('click', '.item-edit', function(){
			var id = $(this).attr('data');
			$('#myModal').modal('show');
			$('#myModal').find('.modal-title').text('Edit Employee');
			$('#myForm').attr('action', '<?php echo base_url() ?>employee/updateEmployee');
			$.ajax({
				type: 'ajax',
				method: 'get',
				url: '<?php echo base_url() ?>employee/editEmployee',
				data: {id: id},
				async: false,
				dataType: 'json',
				success: function(data){
					$('input[name=txtEmployeeName]').val(data.employee_name);
					$('textarea[name=txtAddress]').val(data.address);
					$('input[name=txtId]').val(data.id);
				},
				error: function(){
					alert('Could not Edit Data');
				}
			});
		});

		//delete- 
		
//--------------------------------------
		$('#showdata').on('click', '.item-delete', function(){
			var id = $(this).attr('data');
			$('#deleteModal').modal('show');
			//prevent previous handler - unbind()
			$('#btnDelete').unbind().click(function(){
				$.ajax({
					type: 'ajax',
					method: 'get',
					async: false,
					url: '<?php echo base_url() ?>employee/deleteEmployee',
					data:{id:id},
					dataType: 'json',
					success: function(response){
						if(response.success){
							$('#deleteModal').modal('hide');
							$('.alert-success').html('Employee Deleted successfully').fadeIn().delay(4000).fadeOut('slow');
							showAllEmployee();
						}else{
							alert('Error');
						}
					},
					error: function(){
						alert('Error deleting');
					}
				});
			});
		});



		//function
		function showAllEmployee(){
			$.ajax({
				type: 'ajax',
				url: '<?php echo base_url() ?>medico/historial/guardarAnteGineObs',
				async: false,
				dataType: 'json',
				success: function(data){
				},
				error: function(){
				}
			});
		}
	});
</script>
<br><br><br>
      <div class="panel panel-primary">
         
         <div class="panel-heading">
            <h3 class="panel-title">Pacientes</h3>
          </div>
          <div class="panel-body">
          
       <div class="table-responsive">
        <table  id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
         <thead>
            <tr>
                <th>C.U.R.P.</th>
                <th>Nombre</th>
                <th>Apellido paterno</th>
                <th>Apellido materno</th>
                <th>Grupo sanguineo</th>
                <th>Teléfono</th>
                <th><center>Acciones</center></th>
            </tr>
        </thead>
         <tfoot>
            <tr>
                <th>C.U.R.P.</th>
                <th>Nombre</th>
                <th>Apellido paterno</th>
                <th>Apellido materno</th>
                <th>Grupo sanguineo</th>
                <th>Teléfono</th>
                <th style="width:125px;"><center>Acciones</center></th>
            </tr>
        </tfoot>
         <tbody>
             <?php foreach($listarPacientes as $value) { ?>
                <tr>
                    <td><?php echo $value->curp; ?></td>
                    <td><?php echo $value->nombre; ?></td>
                    <td><?php echo $value->app; ?></td>
                    <td><?php echo $value->apm; ?></td>
                    <td><?php echo $value->tipoSangre; ?></td>
                    <td><?php echo $value->telefono; ?></td>
                    <td>
                       <center>
                        <!--a href="<?php echo base_url('medico/paciente/eliminar/').$value->curp;?>" class="btn btn-default glyphicon glyphicon-trash"></a-->
                        <a href="<?php echo base_url('medico/paciente/editar/').$value->curp;?>"class="btn btn-default btn-xs glyphicon glyphicon-pencil" title="Editar datos del paciente"></a>
                        
                        <?php 
                        $si = 0;
                        foreach ($listarExpedientes as $valuex)
                        {
                            if ($value->curp == $valuex->id_paciente)
                            { 
                                ++$si;
                            }
                        } 
                        if ($si == 1)
                        {?>
                           <a href="<?php echo base_url('medico/paciente/verExpediente/').$value->curp;?>" class="btn btn-primary btn-xs" title="Ver expediente"><p class="glyphicon glyphicon-share-alt"></p> Expediente</a> 
                        <?php }else { ?>
                            <a href="<?php echo base_url('medico/paciente/crearExpediente/').$value->curp;?>"class="btn btn-primary btn-xs" title="Crear expediente"> <p class="glyphicon glyphicon-th-list"></p> Crear Expediente</a>
                       <?php }
                        ?>   
                        </center>
                    </td>
                </tr> 
             <?php } ?>
         </tbody>
        </table>
        </div>
    </div>
            </div>
            
<link rel="stylesheet"  href="<?php echo base_url('assets/dataTables/css/dataTables.bootstrap.css');?>">       
<!--<script src="<?php echo base_url('assets/dataTables/js/jquery-1.12.4.js');?>"></script>-->
<script src="<?php echo base_url('assets/dataTables/js/jquery.dataTables.min.js');?>"></script>
<script src="<?php echo base_url('assets/dataTables/js/jquery.dataTableConf.js');?>"></script>
<script src="<?php echo base_url('assets/dataTables/js/dataTables.bootstrap.js');?>"></script>
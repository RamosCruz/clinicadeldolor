<hr>
<hr>
<script type="text/javascript" src="<?php echo base_url("assets/js/iniciaSesionGoogle.js");?>"></script>
<script type="text/javascript" async defer src="https://apis.google.com/js/api.js"
    onload="this.onload=function(){};handleClientLoad()"
    onreadystatechange="if (this.readyState === 'complete') this.onload()">
</script>
 <div class="page-header">
  <h1 style="color:#AF81C9"></h1>
</div>
<div class="container">
 <div class="row">
     <div class="col-md-12" >
         <!----------------ALERT------------------------- -->
         <div class="alert alert-success" style="display: none;">
         </div>

         <!--<a class="btn btn-default" href="<?php echo base_url('medico/agenda/listarAgenda');?>">Regresar</a><hr>-->
         
                    <div class="col-md-3">
                    </div>
                    <div class="col-md-6">
                        <div class="panel panel-primary class">
                        <div class="panel-heading">
                            <h3 class="panel-title" >REGISTRAR NUEVA CITA</h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">

                        <!-- --------------------EL FORMULARIO DE CITAS-------------------------- -->
                        <form class="form-horizontal"  method="post" action="" id="formularioGuardarCita" >
                            <!-- ------------------ -->
                            
                            <div class='col-sm-12'>
                              <div class='col-sm-12'>

                                  <div class="form-group">
                                      <div class='col-sm-2'>
                                          <label for="fecha-cita" class="control-label" style="color:#336699">*Fecha</label>
                                      </div>
                                      <div class="col-sm-4">

                                              <div class="input-group date  input-append" id="datetimepicker4">
                                                <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="fecha-cita" id="fecha-cita"   required><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                                              </div>

                                          <script type="text/javascript">
                                          $(function() {
                                              var today = new Date();
                                              $('#datetimepicker4').datetimepicker({
                                                  pickTime: false,
                                                  language: 'es-MX',
                                                  endDate: new Date(today.getFullYear(), today.getMonth()+2, today.getDate()),
                                                  startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
                                                  
                                              });



                                          });

                                          </script>

                                      </div>
                                      <div class='col-sm-2'>
                                        <center><label for="hora-cita" class="control-label" style="color:#336699">*Hora</label>
                                      </center>
                                      </div>
                                      <div class='col-sm-4'>
                                               <select class="form-control" name="hora-cita" id="hora-cita" required>
                                                  <?php for ($i = 0; $i <count($horario); $i++){ ?>
                                                  <option value="<?php echo $horario[$i]; ?>"><?php echo $horario[$i]; ?></option>
                                                  <?php } ?>
                                              </select>
                                      </div>
                                  </div>
                              </div>

                              <div class='col-sm-12'>
                                  <div class="form-group">
                                      <div class='col-sm-2'>
                                          <label  for="paciente" class="control-label" style="color:#336699">*Paciente</label>
                                      </div>
                                      <div class="col-sm-10">
                                           <input type="hidden" class="form-control"  name="id-nombre-paciente" id="id-nombre-paciente"  required>
                                          <input type="text" class="form-control"  name="nombre-paciente" id="nombre-paciente"   required >
                                      </div>
                                      <!--<div class='col-sm-2'>
                                          <button type="button" class="btn btn-primary" id="btnBuscar"><span class="glyphicon glyphicon-search"></span></button>
                                      </div>-->

                                  </div>
                              </div>

                              <div class='col-sm-12'>
                                  <div class="form-group">
                                      <div class="col-sm-2">
                                          <label for="estado" class="control-label" style="color:#336699">*Médico</label>
                                      </div>
                                      <div class="col-sm-10">
                                          <select class="form-control" name="id-medico" id="id-medico" required>

                                              <?php if($this->ion_auth->in_group('medico')){?>
                                                         <option value="<?php echo $medico_logueado[0]->id_medico;?>" >DR. <?php echo $medico_logueado[0]->nombre;?> <?php echo $medico_logueado[0]->app;?> <?php echo $medico_logueado[0]->apm;?> </option>
                                              <?php  }
                                                    else{
                                                          foreach($medicos as $medico) { ?>
                                                          <option></option>
                                                          <option value="<?php echo $medico->id_medico; ?>">DR. <?php echo $medico->nombre; ?></option>
                                                          <?php } 

                                                     } ?>
                                          </select>
                                      </div>
                                  </div>
                              </div>

                              <div class='col-sm-12'>
                                  <div class="form-group">
                                      <div class='col-sm-2'>
                                          <label for="app" class="col-sm-2 control-label" style="color:#336699">Nota</label>
                                      </div>
                                      <div class="col-sm-10">
                                          <textarea class="form-control" rows="3" name="nota" id="nota" max="255"></textarea>
                                          <style type="text/css">
                                          textarea {
                                              max-width: 100%; 
                                              max-height: 100%;
                                          }
                                          </style>
                                      </div>
                                  </div>
                              </div>

                              <div class='col-sm-12'>
                              <div class="form-group">
                                      <div class='col-sm-2'>
                                      </div>
                                      
                                      <div class='col-sm-8'>
                                              <div class='col-sm-6'>
                                                  <button  id="btn-registraCita"  class="btn btn-primary col-sm-12 col-xs-12"><span class="glyphicon glyphicon-ok"></span> Registrar</button>
                                              </div>

                                              <div class='col-sm-6'>
                                                  <a href="<?php echo base_url('medico/agenda');?>" type="button" class="btn btn-success col-sm-12 col-xs-12"><span class="glyphicon glyphicon-remove"></span> Cancelar</a>
                                              </div>
                                      </div>

                                       <div class='col-sm-2'>
                                      </div>
                              </div>
                              </div>
                            </div>


                        </form>
                        </div>
                        </div>
                        </div>

                        <!-- --------------------FIN FORMULARIO CITAS-------------------------- -->

                    </div>

                <!--</div>
                <hr>
            </div>
        </div>-->
        <!----------------------------------------- -->
    </div>
</div>
</div>




<!-- ------------------------------------MODAL BUSCAR------------------------------------ -->

<div id="myModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header modal-header-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-search"></i> Buscar Paciente</center></h2>
        
    </div>
    <div class="modal-body">
           <div class="panel panel-default">
        <div class="panel-body">
          
            <div class="col-lg-10">
            <form class="form-horizontal" role="form">
              
              <div class="form-group">
                <label for="ejemplo_email_3" class="col-lg-4  control-label">Nombre</label>
                <div class="col-lg-8 ">
                  <input type="text" class="form-control" name ="nombre" id="nombreAbuscarK"
                         placeholder="Ingrese un nombre del paciente">
                </div>
              </div>
              
              <div class="form-group">
                <label for="ejemplo_password_3" class="col-lg-4  control-label">Apellido</label>
                <div class="col-lg-8 ">
                  <input type="text" class="form-control" name="apellido-p" id="apellidoAbuscarK" 
                         placeholder="Ingresa un apellido del paciente">
                </div>
              </div>
              
              
            </form>
            
          </div>
          <div class="col-lg-2">
            <button type="submit" class="btn btn-success" id="btn-buscarPaciente">Buscar</button>
          </div>
          
        </div>
      </div>
      
      <div class="panel panel-default">
        <div class="panel-body">
          
          <div class="col-lg-10">
            <form class="form-horizontal" role="form">
              
              <div class="form-group">
                <label for="ejemplo_email_3" class="col-lg-4  control-label">Número de Expediente</label>
                <div class="col-lg-8 ">
                  <input type="number" class="form-control " name="expediente" id="expedienteAbuscarK"
                         placeholder="Ingresa un número de expediente">
                </div>
              </div>
             
             </form>
            
          </div>
          
          <div class="col-lg-2">
            <button type="submit" class="btn btn-success" id="btn-buscarExpediente">Buscar</button>
          </div>
          
        </div>
      </div>


      <div class="panel panel-default">
        <div class="panel-body">
             <div class="alert alert-danger" role="alert" style="display: none;">
             </div>

             <div class="table-responsive" id="conexion">
                <div class="nuevaTabla" id="showdata">
                </div>  
             </div>

        </div>
      </div>

    </div>
<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    <!-- <button type="button" id="btnSave" class="btn btn-primary">Save changes</button> -->
</div>
</div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<br>
<br>


<!-- ------------------------------------------------------------------------ -->



<script>

function limpiaCampos(){
    //En esta funcion nos interesa marcar el elemento que se habia prevamente seleccionado por el usuario y es a traves de esta manera que se logra
    
      var hora     = $('#hora-cita').val("");
      var fecha    = $('input[name=fecha-cita]').val("");
      //var doctor   = $('#id-medico').val("");
      var paciente = $('#nombre-paciente').val("");
      var nota     = $('#nota').val("");
    //window.open("http://www.google.com/")
}

window.onload = limpiaCampos;

 //PETICION VERIFICA E INGRESA A  LA NUEVA CITA
    $('#btn-registraCita').click(function(){
     
      var fecha    = $('input[name=fecha-cita]').val();
      var hora     = $('select[name=hora-cita] option:selected').text();
      var doctor   = $('select[name=id-medico] option:selected').text();
      var id_doctor= $('#id-medico').val();
      var paciente = $('input[name=id-nombre-paciente]').val();
      var nota     = $('#nota').val();
      
        

      
      if(fecha!="" && hora!="" && doctor!="" && paciente!=""){
        //alert (nota+" "+fecha+" "+hora+" "+doctor+" "+paciente);
        
        
        validaDisponibilidadEnLaAgendaDelMedico(fecha,hora,id_doctor,paciente,nota);
        return false;
      }

    });


    function validaDisponibilidadEnLaAgendaDelMedico(fecha,hora,id_doctor,id_paciente,nota){
             //alert("validando la disponibilidad en la agenda del medico: "+fecha+" "+hora+" "+id_doctor+" "+id_paciente+" "+nota);
            $.ajax({
                type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/validaDisponibilidadEnLaAgendaDelMedico',
               data:{fecha:fecha,hora:hora,id_doctor:id_doctor,id_paciente:id_paciente},
               dataType: 'json',
               success: function(data){

               if(data){
                //alert("true");
                validaCitaRepetida(fecha,hora,id_doctor,id_paciente,nota);
                }
                else{



                  swal({
                                    title: "Cita no agendada",
                                    text: "El médico solicitado ya cuenta con una cita a esa hora!, porfavor modifique la hora o fecha para poder agendarla!",
                                    type: "warning",
                                    showConfirmButton: true
                                }
                                )
                     .catch(swal.noop);;

                                         $('select[name=hora-cita]').focus();
                }
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
          //return false;
        }


  function validaCitaRepetida(fecha,hora,id_doctor,id_paciente,nota){
            //alert("validando fecha de paciente en cita");
            $.ajax({
                type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/validaCitaRepetida',
               data:{fecha:fecha,hora:hora,id_doctor:id_doctor,id_paciente:id_paciente},
               dataType: 'json',
               success: function(data){
               //alert("LA RESPUESTA ES: "+data);

               if(data){
                validaDisponibilidadEnLasCitasDelPaciente(fecha,hora,id_doctor,id_paciente,nota)
                //agendarCita();
                //location.reload();
                }
                else{
                  swal({
                                    title: "Esta cita ya fue registrada anteriomente",
                                    text: "El paciente ya tiene la cita reservada!",
                                    type: "warning",
                                    showConfirmButton: true
                                }
                                )
                     .catch(swal.noop);;
                                         $('select[name=fecha-cita]').focus();
                }
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
          //return false;
        }


    function validaDisponibilidadEnLasCitasDelPaciente(fecha,hora,id_doctor,id_paciente,nota){
            //alert("validando hora de paciente en cita");
            $.ajax({
                type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/validaDisponibilidadEnLasCitasDelPaciente',
               data:{fecha:fecha,hora:hora,id_doctor:id_doctor,id_paciente:id_paciente},
               dataType: 'json',
               success: function(data){
               //alert("LA RESPUESTA ES: "+data);

               if(data){
                agendarCita();
                
                }
                else{
                  swal({
                                    title: "Cita no agendada",
                                    text: "El paciente ya tiene una cita reservada a esa hora y fecha por otro médico!, porfavor modifique la hora o fecha para poder agendarla!",
                                    type: "warning",
                                    showConfirmButton: true
                                }
                                )
                     .catch(swal.noop);;

                                         $('select[name=hora-cita]').focus();
                }
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
          //return false;
        }

         //...................................................

         function agendarCita(fecha,hora,id_doctor,id_paciente,nota){
            var data=$('#formularioGuardarCita').serialize();
            var summary = "Cita: "+$('input[name="nombre-paciente"]').val();
            var description = $('textarea[name="nota"]').val();
            var id_medico = $('select[name="id-medico"] option:selected').val();
            var hora = $('select[name="hora-cita"] option:selected').text();
            var fechaInicio = $('input[name="fecha-cita"]').val();
            var dia = fechaInicio.split("-")[0];
            var mes = fechaInicio.split("-")[1];
            var ano = fechaInicio.split("-")[2];
            var paciente = $('input[name=id-nombre-paciente]').val();
            var nuevaFecha = ano+"-"+mes+"-"+dia;
            var fecha    = $('input[name=fecha-cita]').val();

            ////////////////sumar una hora ///////////////
            var hours = parseInt(hora.split(":")[0])+1;
            var minutes = hora.split(":")[1];
            if (hours == 24) {
                hours = 0;
            }
            var horaStrinfg = "";
            if(hours <10)
            {
                horaStrinfg = "0"+hours.toString();
            }else{
                horaStrinfg = hours.toString();
            }
            /////////////////////////////////
            var masUnahora = horaStrinfg+':'+minutes;

            var start_dateTime = nuevaFecha+'T'+hora+':00-05:00';
            var end_dateTime = nuevaFecha+'T'+masUnahora+':00-05:00';
            listUpcomingEvents(summary,description,start_dateTime,end_dateTime,fecha,hora,id_medico,paciente);
            //alert(data);
            //alert("Agendando cita con datos: "+fecha+" "+hora+" "+id_doctor+" "+id_paciente+" "+nota);
             $.ajax({
                type: 'ajax',
               method: 'post',
               async: false,
               url: '<?php echo base_url() ?>medico/Agenda/agendarCita',
               data:data,
               dataType: 'json',
               success: function(response){

               //alert("LA RESPUESTA ES: "+response);
               limpiaCampos();
               
                 if(response){
                    
                     swal({
                                    title: "Cita agendada correctamente!",
                                    type: "success",
                                    timer: 2000,
                                    showConfirmButton: false
                                }
                                )
                     .catch(swal.noop);
                     //setTimeout(location.reload(), 2000);

                     //location.reload();
                  }
                  else{
                   $('.alert-danger').html('La cita no pudo ser agendada!').fadeIn().delay(2000).fadeOut('slow');
                   
                  }

                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });

           //return false;

        }


$(function(){

    /*$("#nombre-paciente").hover(function() {
        $( "#btnBuscar" ).fadeOut( 200 );//Salida
        $( "#btnBuscar" ).fadeIn( 200 );//entrada
    });*/


    	$("#nombre-paciente").blur(function(){
            $(this).prop("readonly",""); 
	    });

        $("#nombre-paciente").focus(function(){
            $(this).prop("readonly","readonly"); 
	    });

//EVENTOS PARA EL CAMPO FECHA


   /* $("#fecha-cita").hover(function() {
        $( ".input-group-addon" ).fadeOut( 200 );//Salida
        $( ".input-group-addon" ).fadeIn( 200 );//entrada
    });*/


        $("#fecha-cita").blur(function(){
            $(this).prop("readonly",""); 
            //$('.input-group-addon').focus();
        });

        $("#fecha-cita").focus(function(){
            $(this).prop("readonly","readonly"); 
            //$('.input-group-addon').focus();
        });


        //$('#myModal').modal('show');




		//Buscar
		$('#nombre-paciente').click(function(){
			$('#myModal').modal('show');
        });

        //--------------------------------------
        $('#btn-buscarPaciente').click(function(){

            var nombre = document.getElementById("nombreAbuscarK").value;
            var apellido = document.getElementById("apellidoAbuscarK").value;

            var elemento_nombre_paciente=$('input[name=nombre]');
            var elemento_ap_paciente=$('input[name=apellido-p]');

              

            if(apellido==""&&nombre==""){
                elemento_nombre_paciente.focus();
            }
            else{
                mostrarResultadoBusquedaPorNombre(nombre,apellido);
            }

        });
        //--------------------------------------------------
        $('#btn-buscarExpediente').click(function(){

            var expediente = $("#expedienteAbuscarK").val();

            if(expediente==""){
                 var elemento_num_exp=$('input[name=expediente]');
                 elemento_num_exp.focus();
            }
            else{
                mostrarResultadoBusquedaPorExpediente(expediente);
            }

        });

        //En este item se guarda temporalmente el id del paciente seleccionado
        $('#showdata').on('click', '.item-id-paciente', function(){
                    var id_paciente1 = $(this).attr('id-paciente');
                    var nombre = $(this).attr('nombre');
                    var ap_p = $(this).attr('ap-p');
                    var ap_m = $(this).attr('ap-m');

                    //id_paciente=id_paciente1;
                    //Falta agregar el apellido materno
                    document.getElementById("id-nombre-paciente").value=id_paciente1;
                    document.getElementById("nombre-paciente").value=nombre+" "+ap_p;
                    //alert(id);
                    $('#myModal').modal('hide');
        });

function mostrarResultadoBusquedaPorExpediente(numExpediente){
			$.ajax({//En este metodo falta repillar la consulta para que sea mas cercana a la respuesta
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/buscarExpediente',
               data:{id_expediente:numExpediente},
               dataType: 'json',
               success: function(data){

                if(data==false){

                        var html = '';
                        $('#showdata').html(html);
                            
                        $('.alert-danger').html('No hay registros con la busqueda seleccionada!').fadeIn().delay(2000).fadeOut('slow');
              

                    }
                    else{

                var html = '';
                var i;
                                    //if(data!=false){
                                         html +='<table class="table table-condensed table-bordered table table-hover" style="margin-top: 20px;">'+
                                        '<thead>'+
                                        '<tr class="success">'+
                                            '<th>NÚM EXPEDIENTE</th>'+
                                            '<th>CURP</th>'+
                                            '<th>NOMBRE</th>'+
                                            '<th>APELLIDO PATERNO</th>'+
                                            '<th>SELECCIONAR</th>'+
                                        '</tr>'
                                        '</thead>'+
                                            '<tbody>';
                                       for(i=0; i<data.length; i++){
                                            html +='<tr>'+
                                            '<td>'+data[i].id_expediente+'</td>'+
                                            '<td>'+data[i].curp+'</td>'+
                                            '<td>'+data[i].nombre+'</td>'+
                                            '<td>'+data[i].apellido_p+'</td>'+
                                            '<td>'+
                                            '<center><a class="btn btn-default item-id-paciente"  id-paciente="'+data[i].id_paciente+'" '+'nombre="'+data[i].nombre+'" ap-p="'+data[i].apellido_p+'" '+'ap-m="'+data[i].apellido_m+'" ><i class="glyphicon glyphicon-ok"></i></a></center>'+
                                            '</td>'+
                                            '</tr>';
                                        }
                                        html +='</tbody>'+'</table>';
                                        
                                        $('#showdata').html(html);
                                    }
                                },
                                error: function(){
                                    alert('Could not get Data from Database');
                                }
                            });
}



function mostrarResultadoBusquedaPorNombre(nombre,apellido){
			$.ajax({//En este metodo falta repillar la consulta para que sea mas cercana a la respuesta
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>medico/agenda/buscarPacienteLike',
               data:{nombre:nombre,apellido_p:apellido},
               dataType: 'json',
               success: function(data){

                if(data==false){

                        var html = '';
                        $('#showdata').html(html);
                            
                        $('.alert-danger').html('No hay registros con la busqueda seleccionada!').fadeIn().delay(2000).fadeOut('slow');
              

                    }
                    else{

                                    var html = '';
                                    var i;
                                    
                                        html +='<table class="table  table-condensed table-bordered table table-hover" style="margin-top: 20px;">'+
                                        '<thead>'+
                                        '<tr class="success">'+
                                        '<td>NÚM EXPEDIENTE</td>'+
                                        '<td>CURP</td>'+
                                        '<td>NOMBRE</td>'+
                                        '<td>APELLIDO PATERNO</td>'+
                                        '<td>SELECCIONAR</td>'+
                                        '</tr>'+
                                        '</thead>';
                                       for(i=0; i<data.length; i++){
                                            html +='<tr>'+
                                            '<td>'+data[i].id_expediente+'</td>'+
                                            '<td>'+data[i].curp+'</td>'+
                                            '<td>'+data[i].nombre+'</td>'+
                                            '<td>'+data[i].apellido_p+'</td>'+
                                            '<td>'+
                                            '<center><a class="btn btn-default item-id-paciente"  id-paciente="'+data[i].id_paciente+'" '+'nombre="'+data[i].nombre+'" ap-p="'+data[i].apellido_p+'" '+'ap-m="'+data[i].apellido_m+'" ><i class="glyphicon glyphicon-ok"></i></a></center>'+
                                            '</td>'+
                                            '</tr>';
                                        }
                                        $('#showdata').html(html);

                                    }
                                    
                                },
                                error: function(){
                                    alert('Could not get Data from Database');
                                }
                            });
}


});
    
    
    
    function actualizarIdGoogle(fecha,hora,id_medico,id_paciente,idEventgoogle){
        //alert(fecha+' '+hora+' '+id_medico+' '+id_paciente+' '+idEventgoogle);
                $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>medico/agenda/actualizarIdGoogle",
                    data: {fecha:fecha,hora:hora,id_medico:id_medico,id_paciente:id_paciente,idEventgoogle:idEventgoogle},
                    dataType: 'json',
                    success: function(response){
                        if(response.success){
                          swal({
                                      title: "Cita Actualizada por Id del evento google!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);


                        }
                        else{
                            $('.alert-warning').html('No se pudo actualizar la fecha, favor de rectificar los datos!').fadeIn().delay(1000).fadeOut('slow');
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

}
</script>
<script>
    var CLIENT_ID = '864684357201-vt5jg4fqhpid9enjh94gi8avtc2188tj.apps.googleusercontent.com';

// Array of API discovery doc URLs for APIs used by the quickstart
var DISCOVERY_DOCS = ["https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest"];

// Authorization scopes required by the API; multiple scopes can be
// included, separated by spaces.
var SCOPES = "https://www.googleapis.com/auth/calendar";

function handleAuthClick(event) {
    gapi.auth2.getAuthInstance().signIn();
  }


function listUpcomingEvents(summary,description,start_dateTime,end_dateTime,fecha,hora,id_medico,id_paciente) {
    
    var idEvent = "";
        if (isSignedIn) {
            var event = {
                      "summary": summary,
                      "description": description,
                      "start": {
                        "dateTime": start_dateTime
                      },
                      "end": {
                        "dateTime": end_dateTime
                      },
                      "attendees": [
                                   {"email": "<?php echo $medico_logueado[0]->correo_electronico;?>"}
                                   ]
                    };
            console.log(event);
            var request = gapi.client.calendar.events.insert({
              'calendarId': 'clinicadeldolor2017@gmail.com',
              'sendNotifications': true,
              'resource': event
            });

            request.execute(function(event) {
              idEvent = event.id;
              actualizarIdGoogle(fecha,hora,id_medico,id_paciente,idEvent)
            });
        } else {
          alert('Inicia Sesion');
        }
}


var isSignedIn;
function initClient() {
        gapi.client.init({
          discoveryDocs: DISCOVERY_DOCS,
          clientId: CLIENT_ID,
          scope: SCOPES
        }).then(function () {
          // Handle the initial sign-in state.
          isSignedIn = gapi.auth2.getAuthInstance().isSignedIn.get();
        });
      }


function handleClientLoad() {
        gapi.load('client:auth2', initClient);
      }


</script>
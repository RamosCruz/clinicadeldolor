<br><br><br>
<script type="text/javascript" src="<?php echo base_url("assets/js/iniciaSesionGoogle.js");?>"></script>
<link href='<?php echo base_url("assets/fullcalendar/fullcalendar.min.css");?>' rel='stylesheet' />
<link href='<?php echo base_url("assets/fullcalendar/fullcalendar.print.min.css");?>' rel='stylesheet' media='print' />
<script src='<?php echo base_url("assets/fullcalendar/lib/moment.min.js");?>'></script>
<script src='<?php echo base_url("assets/fullcalendar/fullcalendar.min.js");?>'></script>
<script src='<?php echo base_url("assets/fullcalendar/gcal.js");?>'></script>
<script src='<?php echo base_url("assets/fullcalendar/locale-all.js");?>'></script>

<script type="text/javascript" async defer src="https://apis.google.com/js/api.js"
    onload="this.onload=function(){};handleClientLoad()"
    onreadystatechange="if (this.readyState === 'complete') this.onload()">
</script>

<script>


	$(document).ready(function() {
        handleClientLoad();
        var citas =<?php echo json_encode($citas); ?>;
		console.log(citas);
		$('#calendar').fullCalendar({
            locale: 'es',
            
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay,listWeek'
			},
			navLinks: true, // can click day/week names to navigate views
			
			eventLimit: true, // allow "more" link when too many events
			events: citas,
            eventColor: '#04B404'
		});
		
	});

</script>
<style>


	#calendar {
		max-width: 900px;
		margin: 0 auto;
        font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
	}

</style>
   <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="text-left col-md-6">
                <button class="btn btn-success" id="authorize-button" style="display: none;" title="Para ver los calendarios es necesario iniciar sesión con Google">Activar calendario</button>
                <button class="btn btn-danger" id="signout-button" style="display: none;" title="No podra ver los calendarios si cierra la sesión ">Cerrar calendario</button>
            </div>
            <div class="text-right col-md-6">
                <a href="<?php echo base_url('medico/Agenda/nuevaCita');?>" class="btn btn-success">Nueva cita</a></div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div id='calendar'></div>
        </div>
        <div class="col-md-8 col-md-offset-2">
            <pre style="display: none;" id="content"></pre>
        </div>
    </div>
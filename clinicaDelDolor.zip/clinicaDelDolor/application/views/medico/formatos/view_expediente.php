<br><br><hr>
<h1>Expediente</h1>


<form class="form-inline" method="post" action="<?php echo base_url('medico/Formatos/ImprimirExpediente');?>" target="_blank">
    <div class="form-group">
        <label for="">Imprimir expediente de:</label>
        <input type="text" class="form-control" name="curp" placeholder="CURP">
        <button  type="submit" class="btn btn-success">Imprimir</button>
    </div>
</form>
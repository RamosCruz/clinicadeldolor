<br><br><hr>
<center>
<div class="row">
    <h1>Nota Preoperatoria y Valoración Preanestesica</h1>

    <form action="<?php echo base_url('medico/Formatos/imprimirNotaPreoperatoriayValoracionPreanestesicaPDF'); ?>" target="_blank" method="post">
    <p>Hoja 1</p>
    <div class="panel panel-primary" style="width:850px; ">
      <div class="panel-body">
            <table>
                <tr>
                    <td style="width:250px; padding: 10px;" align="center">
                       <div class="form-inline">
                           <i>Doctor:<div class="form-group has-error"><input type="text" placeholder="" name="campo1" style="width:250px;" required class="form-control"></div></i><br><i>Cedula: <div class="form-group has-error"><input class="form-control" type="number" placeholder="" name="campo2" required></div></i>
                        </div>
                    </td>
                    
                    <td rowspan="2" style="width:300px;  padding: 10px;" align="center">
                       <div class="form-inline">
                           <p>Paciente: <div class="form-group has-error"><input class="form-control" type="text" placeholder="" name="campo3" style="width:250px;" required></div></p>
                        <p>Edad: <div class="form-group has-error"><input type="number" name="campo4" placeholder="" required class="form-control" style="width:60px;"></div></p>
                            <p>Sexo:
                               <div class="form-group has-error">
                                <select name="campo5" id="" required class="form-control">
                                    <option value="Hombre">Hombre</option>
                                    <option value="Mujer">Mujer</option>
                                </select>
                                </div>
                            </p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td style="width:250px; padding: 10px;" align="center">
                        <h4><b>NOTA PREOPERATORIA Y VALORACIÓN PREANESTESICA</b></h4>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <h6><b>NOTA PREOPERATORIA</b></h6>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                       <div class="form-inline">
                          <div class="form-group has-error">
                            Fecha:
                            <div class="input-group date  input-append" id="datetimepicker4">
                              <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="campo6" id="exampleInputName2" required style="width:100px;"><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                            </div>

                            <script type="text/javascript">
                            $(function() {
                                var today = new Date();
                                $('#datetimepicker4').datetimepicker({
                                    pickTime: false,
                                    language: 'es-MX',
                                    endDate: new Date(today.getFullYear()+4, today.getMonth(), today.getDate()),
                                    startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),

                                });



                            });

                            </script>

                          </div>
                          <div class="form-group has-error">
                               Hora:
                               <div class="input-group date  input-append" id="datetimepicker5">
                                  <input type="text" class="form-control input-append"  data-format="hh:mm" type="text" name="campo7" id="exampleInputName2" required style="width:70px;" ><span class="input-group-addon add-on"><i class="glyphicon glyphicon-time"></i></span>
                                </div>
                            
                                <script type="text/javascript">
                                $(function() {
                                    var today = new Date();
                                    $('#datetimepicker5').datetimepicker({
                                        pickDate: false,
                                        pickTime: true,
                                        language: 'es-MX',
                                        endDate: new Date(today.getFullYear()+4, today.getMonth(), today.getDate()),
                                        startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),

                                    });



                                });

                                </script>
                            </div>
                            <div class="form-group has-error">
                                Edad:
                                <input class="form-control" type="number" name="campo8" required placeholder="" style="width:60px;">
                            </div>
                            <div class="form-group has-error">
                                Sexo:
                                <select name="campo9" id="" required class="form-control">
                                    <option value="Hombre">Hombre</option>
                                    <option value="Mujer">Mujer</option>
                                </select>
                            </div>
                          
                        </div>
                        <div class="form-inline">
                            <div class="form-group has-error">
                                Fecha cirugía:
                                <div class="input-group date  input-append" id="datetimepicker6">
                                  <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="campo10" id="exampleInputName2" required style="width:100px;"><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                                </div>

                                <script type="text/javascript">
                                $(function() {
                                    var today = new Date();
                                    $('#datetimepicker6').datetimepicker({
                                        pickTime: false,
                                        language: 'es-MX',
                                        endDate: new Date(today.getFullYear()+4, today.getMonth(), today.getDate()),
                                        startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),

                                    });



                                });

                                </script>
                            </div>
                            <div class="form-group has-error">
                                Diagnostico:
                                <input class="form-control" type="text" name="campo11" required placeholder="" style="width:470px;">
                            </div>
                            <div class="form-group has-error">
                                Plan quirúrgico: 
                                <input class="form-control" type="text" name="campo12" required placeholder="" style="width:676px;">
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:100px; vertical-align: top; text-align:left;">
                        <p>Tipo de intervención quirúrgica</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo13" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:100px; vertical-align: top; text-align:left;">
                        <p>Cuidados y plan terapéutico pre-operatorios</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo14" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                
                <tr>
                    <td colspan="2" >
                        <div class="form-inline">
                            <div class="form-group has-error">
                                Estado preoperatorio: 
                                <label class="radio-inline">
                                  Bueno&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="campo15" id="inlineRadio1" value="Bueno">
                                </label>
                                <label class="radio-inline">
                                  Delicado&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="campo15" id="inlineRadio2" value="Delicado">
                                </label>
                                <label class="radio-inline">
                                  Grave&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="campo15" id="inlineRadio3" value="Grave">
                                </label>
                            </div>
                        </div>
                        <div class="form-inline">
                            <div class="form-group has-error">
                                Pronóstico:
                                <input class="form-control" type="text" name="campo16" required placeholder="" style="width:325px;">
                            </div>
                            <div class="form-group has-error">
                                <label class="radio-inline">
                                  Tabaquismo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="campo17" id="inlineRadio1" value="Tabaquismo">
                                </label>
                                <label class="radio-inline">
                                  Alcoholismo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="campo17" id="inlineRadio2" value="Alcoholismo">
                                </label>
                                <label class="radio-inline">
                                  Otras adicciones&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="campo17" id="inlineRadio3" value="Otrasadicciones">
                                </label>
                            </div>
                        </div>
                        
                        <div class="form-inline">
                            <div class="form-group has-error">
                                Nombre completo de quien elaboró la nota:
                                <input class="form-control" type="text" name="campo18" required placeholder="" style="width:520px;">
                                
                            </div>
                            <div class="form-group">
                                Firma:&nbsp;________________________
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <h6><b>VALORACIÓN PREANESTESICA</b></h6>
                    </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:100px; vertical-align: top; text-align:left;">
                         <div class="form-inline">
                            <div class="form-group has-error">
                                Fecha:
                                <div class="input-group date  input-append" id="datetimepicker7">
                                  <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="campo19" id="exampleInputName2" required style="width:100px;"><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                                </div>

                                <script type="text/javascript">
                                $(function() {
                                    var today = new Date();
                                    $('#datetimepicker7').datetimepicker({
                                        pickTime: false,
                                        language: 'es-MX',
                                        endDate: new Date(today.getFullYear()+4, today.getMonth(), today.getDate()),
                                        startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),

                                    });



                                });

                                </script>
                             </div>
                        </div>
                        <p>Diagnóstico preoperatorio</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo20" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:70px; vertical-align: top; text-align:left;">
                        <p>Cirugía propuesta</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo21" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:70px; vertical-align: top; text-align:left;">
                        <p>Padecimiento actual</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo22" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:70px; vertical-align: top; text-align:left;">
                        <p>Estado físico</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo23" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:100px; vertical-align: top; text-align:left;">
                       <div class="form-inline">
                            <div class="form-group has-error">
                                Alergias:
                                <input class="form-control" type="text" name="campo24" required placeholder="" style="width:716px;">
                           </div>
                       </div>
                       <div class="form-inline">
                            <div class="form-group has-error">
                                F.C.:
                                <input class="form-control" type="number" name="campo25" required placeholder="" style="width:100px;">
                                
                           </div>
                           <div class="form-group has-error">
                               F.R.:
                               <input class="form-control" type="number" name="campo26" required placeholder="" style="width:100px;">
                           </div>
                           <div class="form-group has-error">
                               Temp.:
                               <input class="form-control" type="number" name="campo27" required placeholder="" style="width:100px;">
                           </div>
                           <div class="form-group has-error">
                               Talla:
                               <input class="form-control" type="number" name="campo28" required placeholder="" style="width:100px;">
                           </div>
                           <div class="form-group has-error">
                               Peso:
                               <input class="form-control" type="number" name="campo29" required placeholder="" style="width:100px;">
                           </div>
                       </div>
                        
                        <p>Antecedentes personales patológicos:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo40" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:180px; vertical-align: top; text-align:left;">
                        <p>Medicamentos:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo41" required placeholder="" ></textarea></div>
                        <p>Medicación preanestésica:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo42" required placeholder="" ></textarea></div>
                        <p>Ultimo alimento:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo43" required placeholder="" ></textarea></div>
                   </td>
                </tr>
            </table>
      </div>
    </div>



    <p>Hoja 2</p>
    <div class="panel panel-primary" style="width:850px; height:1355px;">
      <div class="panel-body">
          <table>
                <tr>
                   <td colspan="2" style="height:118px; vertical-align: top; text-align:left;">
                        <p>Laboratorios:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo44" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:118px; vertical-align: top; text-align:left;">
                        <p>Rayos X:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo45" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:118px; vertical-align: top; text-align:left;">
                        <p>EKG:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo46" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:118px; vertical-align: top; text-align:left;">
                        <p>Anestesias previas:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo47" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:118px; vertical-align: top; text-align:left;">
                        <p>Vía aérea:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo48" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:118px; vertical-align: top; text-align:left;">
                        <p>Campos pulmonares:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo49" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:118px; vertical-align: top; text-align:left;">
                        <p>Área cardíaca:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo50" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:118px; vertical-align: top; text-align:left;">
                        <p>Otros:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo51" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:118px; vertical-align: top; text-align:left;">
                        <p>Plan anestésico:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo52" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:118px; vertical-align: top; text-align:left;">
                        <p>Riesgo quirúrgico:</p>
                       <div class="form-group has-error"><textarea class="form-control" type="text" name="campo53" required placeholder="" ></textarea></div>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:118px; vertical-align: bottom; text-align:left;">
                       <div class="form-inline">
                            <div class="form-group has-error" style="font-size:10px">
                                Nombre completo de quien elaboró la valoración:<input class="form-control" type="text" name="campo54" required placeholder="" style="width:300px;">
                           </div>
                           <div class="form-group" style="font-size:10px">
                               Firma: _________________________________
                           </div>
                       </div>
                   </td>
                </tr>
            </table>
      
      </div>
    </div>
    <style>@page {
         margin: 0;
         padding:0;
        }
        table{
            width:792px;
            margin: 10px;
            border: 2px solid #0086b3;
        }
        th, td {
            border: 1px solid #0086b3;
            color: #00ace6;
            padding:10px;
        }</style>
        <button title="Imprimir PDF" type="submit" class="btn btn-success">Imprimir</button>
    </form>
</div>
</center>
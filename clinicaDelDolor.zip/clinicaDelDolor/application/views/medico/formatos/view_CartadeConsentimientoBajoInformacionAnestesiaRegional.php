<br><br><hr>
<center>
<div class="row">
    <h1>Carta de Consentimiento Bajo Información Anestesia Regional</h1>

    <form action="<?php echo base_url('medico/Formatos/imprimirCartadeConsentimientoBajoInformacionAnestesiaRegional'); ?>" target="_blank" method="post">
    <p>Hoja 1</p>
    <div class="panel panel-primary" style="width:850px; ">
      <div class="panel-body">
            <table>
                <tr>
                    <td style="width:250px; padding: 10px;" align="center">
                        <div class="form-inline">
                            <i>Doctor:<div class="form-group has-error"><input type="text" placeholder="" name="campo1" style="width:250px;" required class="form-control"><div class="form-group has-error"></i><br><i>Cedula: <div class="form-group has-error"><input class="form-control" type="number" placeholder="" name="campo2" required></div></i>
                        </div>
                    </td>
                    
                    <td rowspan="2" style="width:300px;  padding: 10px;" align="center">
                        <div class="form-inline">
                            <p>Paciente: <div class="form-group has-error"><input class="form-control" type="text" placeholder="" name="campo3" style="width:250px;" required></div></p>
                        <p>Edad: <div class="form-group has-error"><input type="number" name="campo4" placeholder="" required class="form-control" style="width:60px;"></div></p>
                            <p>Sexo:
                               <div class="form-group has-error">
                                <select name="campo5" id="" required class="form-control">
                                    <option value="Hombre">Hombre</option>
                                    <option value="Mujer">Mujer</option>
                                </select>
                                </div>
                            </p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td style="width:250px; padding: 10px;" align="center">
                        <b><h4>CARTA DE CONSENTIMIENTO BAJO INFORMACION ANESTESIA REGIONAL</h4></b>
                    </td>
                </tr>
                
                
                
                
                
                
                <tr>
                    <td colspan="2" align="right" id="1">
                        
                        <div class="form-inline">
                            <div class="form-group has-error">
                            Oaxaca, Oaxaca de Juarez a
                            <div class="input-group date  input-append" id="datetimepicker4">
                              <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="campo6" id="exampleInputName2" required style="width:100px;"><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                            </div>

                            <script type="text/javascript">
                            $(function() {
                                var today = new Date();
                                $('#datetimepicker4').datetimepicker({
                                    pickTime: false,
                                    language: 'es-MX',
                                    endDate: new Date(today.getFullYear()+4, today.getMonth(), today.getDate()),
                                    startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),

                                });



                            });

                            </script>

                          </div>
                          <div class="form-group has-error">
                              <div class="input-group date  input-append" id="datetimepicker5">
                                  <input type="text" class="form-control input-append"  data-format="hh:mm" type="text" name="campo7" id="exampleInputName2" required style="width:70px;" ><span class="input-group-addon add-on"><i class="glyphicon glyphicon-time"></i></span>
                                </div>
                            
                                <script type="text/javascript">
                                $(function() {
                                    var today = new Date();
                                    $('#datetimepicker5').datetimepicker({
                                        pickDate: false,
                                        pickTime: true,
                                        language: 'es-MX',
                                        endDate: new Date(today.getFullYear()+4, today.getMonth(), today.getDate()),
                                        startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),

                                    });



                                });

                                </script>
                                hrs.
                          </div>
                        </div>
                        
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="justify" id="2">
                        <p style="font-size:15px">
                            <div class="form-inline">
                            Nombre del Paciente:<div class="form-group has-error"><input type="text" name="campo8" placeholder="" required class="form-control" style="width:300px;"> </div>
                            </div>
                        </p>
                        <br>
                        <p style="font-size:15px">
                           <div class="form-inline">
                            El que suscribe la presente, con el con carácter de Paciente ( ) Familiar Responsable y/o Representante Legal del Paciente ( ) de manera libre y en plena conciencia, autorizo al (a la) Doctor(a) <div class="form-group has-error"><input type="text" name="campo9" placeholder="" required class="form-control" style="width:300px;"> </div> a que me (le) proporcione (al paciente) anestesia loco-regional, durante el procedimiento médico y/o quirúrgico que el Dr(a). <div class="form-group has-error"><input type="text" name="campo10" placeholder="" required class="form-control" style="width:300px;"></div> me (le) practicará (al paciente) y a quien de forma expresa he autorizado para tal efecto con la plena conciencia de la naturaleza, riesgos y beneficios de del citado procedimiento, las alternativas de tratamiento, las probabilidades de éxito, los eventos adversos que pudieran presentarse, así como las consecuencias de no someterse (someterse el paciente) al mismo.
                            </div>
                            
                        </p>
                        
                        <br>
                        <p style="font-size:15px">
                            Bajo ese entendimiento, reconozco que el médico anestesiólogo arriba citado, me ha explicado la información que a continuación se detalla y que contiene entre otros aspectos, la naturaleza del plan de anestésico propuesto y los riesgos inherentes; información que he comprendido y acepto en plena conciencia.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>1. Descripción del plan anestésico propuesto.</b></p>
                        <p style="font-size:15px">
                            La anestesia loco-regional constituye en la  inyección, con la ayuda de agujas especiales, y por medio de diferentes técnicas, de medicamentos llamados anestésicos locales, en la proximidad de un nervio o de la columna vertebral, consiguiendo así que no se sienta ningún tipo de dolor en la región donde se realizará la intervención quirúrgica. Es prácticamente un acto anestésico completo que requiere la misma preparación, precaución y vigilancia que en la anestesia general.
                        </p>
                        <br><br>
                        <p style="font-size:15px">
                            El anestesiólogo es el responsable de realizar y controlar todo el proceso de la anestesia loco-regional de principio a fin, así como de tratar todas las posibles complicaciones que pudieran surgir.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Mediante diferentes métodos clínicos y monitores, se controlan y vigilan los signos vitales(presión arterial, electrocardiograma, frecuencia respiratoria), además de la cantidad de oxígeno de la sangre, la función cerebral, bióxido de carbono exhalado y otros, con lo que se mantiene una vigilancia permanente durante todo el acto anestésico y se consigue la máxima seguridad.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>2. Objetivos del procedimiento anestésico.</b></p>
                        <p style="font-size:15px">
                            El propósito principal de la anestesia loco-regional es permitir la realización de una intervención quirúrgica sin dolor. Esto se consigue produciendo insensibilidad en la zona a operar, que permanecerá "dormida" (anestesiada). A diferencia de la Anestesia General, el paciente permanece consiente y despierto, o sedado, pero sin sentir ningún dolor.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>3. Alternativas razonables al plan anestésico propuesto.</b></p>
                        <p style="font-size:15px">
                            En los casos en los que la anestesia loco-regional no sea posible, o no se consiga por razones técnicas, puede ser necesario realizar anestesia general.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>4. Riesgos.</b></p>
                        <p style="font-size:15px">
                           Los riesgos de una anestesia loco-regional son pocos frecuentes, pero como en todo procedimiento médico se pueden presentar, en condiciones normales y de forma inevitable, una serie de complicaciones que podrían requerir tratamientos complementarios tanto médicos como quirúrgicos. Son riesgos aceptados de acuerdo a la experiencia y el estado actual de la ciencia médica. Estos son:
                        </p>
                        <br>
                    </td>
                <tr>
            </table>
      </div>
    </div>



    <p>Hoja 2</p>
    <div class="panel panel-primary" style="width:850px;">
      <div class="panel-body">
          <table>
                <tr>
                    <td colspan="2" align="justify" id="3">
                        <p style="font-size:15px">
                            A) En ocasiones  excepcionales, como consecuencia de la dificultad que se encuentre para colocar el anestésico en un punto concreto, la anestesia administrada pasa rápidamente a la sangre o al sistema nervioso, produciéndose un efecto parecido al de la anestesia general, pero que puede verse acompañado de complicaciones graves, como alteración de la tensión arterial, alteraciones cardiacas, respiratorias, pérdida de la conciencia, temblores intensos y convulsiones. Normalmente estas complicaciones se solucionan, pero en ocasiones puede ser que obliguen a no realizar el procedimiento médico y/o quirúrgico, o bien realizarlo bajo anestesia general.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            B) Después de administrar una anestesia  loco-regional a nivel de la columna vertebral (anestesia peridural o subaracnoidea) pueden surgir molestias tales como dolor de cabeza o de espalda, que normalmente desaparecen en los días posteriores y que en raras ocasiones necesitan tratamiento médico.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            C) Después de administrar una anestesia loco-regional en la proximidad de un nervio, pueden surgir molestias, como alteraciones en la sensibilidad de la zona, con entumecimiento u hormigueo. Entre otras ocasiones pueden aparecer alteraciones motoras con dificultad para realizar movimientos preciosos, todo esto, generalmente es pasajero.
                        </p>
                        <br>
                         <p style="font-size:15px">
                            D) Después de administrar una anestesia loco-regional pueden aparecer diferentes síntomas, como descenso de la presión arterial, aumento de la frecuencia cardiaca, dificultad respiratoria, agitación, mareo, náusea, vómito, temblores, que en general son considerados como molestias, llegando, en muy pocos casos, a ser complicaciones. 
                        </p>
                        <br>
                         <p style="font-size:15px">
                            E) La administración de soluciones y medicamentos que sean impredecibles durante la anestesia, pueden reproducir reacciones alérgicas que pueden llegar a ser graves. No se recomienda la práctica sistemática de pruebas alérgicas a los fármacos que vayan a emplearse durante la anestesia, ya que dichas pruebas no están libres de riesgos, ni aun siendo su resultado negativo, garantizan que no se produzcan reacciones adversas durante el procedimiento anestésico.
                        </p>
                        <br>
                        
                        <p style="font-size:15px">
                            <b>5. Riesgos en función del estado clínico del paciente.</b>
                        </p>
                        <br>
                        
                        <p style="font-size:15px">
                            Todo el acto quirúrgico lleva implícitas una serie de complicaciones comunes y potencialmente serias que podrían requerir tratamientos complementarios; tanto médicos como quirúrgicos. Dependiendo el estado clínico del paciente y la existencia de otras patologías, como diabetes, cardiopatía, hipertensión, anemia, edad avanzada, obesidad, el riesgo anestésico puede ser mayor o aparecer complicaciones que pudieran aumentar el traslado del paciente a una unidad de cuidados intensivos, provocar lesiones graves al paciente o inclusive, la muerte.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Comprendo que la práctica de la medicina no es una ciencia exacta, por lo que reconozco que no se me ha asegurado ni garantizado que los resultados del evento anestésico y del procedimiento médico/quirúrgico que se me(le) practicarán (al paciente), necesariamente alcancen los beneficios esperados y que pueden presentarse imprevistos que varíen el(los) citado(os) procedimiento(s); por consiguiente ante cualquier complicación o efecto adverso durante el procedimiento anestésico propuesto, especialmente ante una urgencia médica, autorizo y solicito al médico anestesiólogo y al médico tratante al principio de este documento citados y/o a quienes ellos designen conjunta o separadamente, a que realicen los procedimientos médico(s) y/o quirúrgico(s) que consideren necesarios en ejercicio de su juicio y experiencia profesional, para la protección de mi(la) salud(del paciente), en la inteligencia que la extensión de esta autorización también será aplicada a cualquier condición que requiera de procedimientos médicos y/o quirúrgicos que sea desconocida por los facultativos y surja durante procedimiento médico/quirúrgico-anestésico autorizado.
                        </p>
                        <br>
                        <p style="font-size:15px">
                           <div class="form-inline">
                            Declaro que el médico anestesiólogo Dr(a). <div class="form-group has-error"><input type="text" name="campo11" placeholder="" required class="form-control" style="width:300px;"></div> me ha explicado que es conveniente/necesario, en mi(la) situación(del paciente), que durante el procedimiento de sedación al que seré (será) sometido (el paciente), me (le) administrarán diferentes fármacos, lo cual en plena conciencia autorizo.
                            </div>
                        </p>
                        <br>
                        <p style="font-size:15px">
                           
                            Entendiendo el contenido de este documento y conforme con el mismo, lo firmo en ciudad de Oaxaca en la fecha arriba anotada.
                        </p>
                        <br>
                        <br>
                        <br>
                    </td>
                </tr>  
                <tr>
                    <td align="center" id="4">
                        <p>_________________________________________</p>
                        <p>Firma del Paciente</p>
                    </td>
                    <td align="center" id="5">
                        <p>____________________________________________________</p>
                        <p>Nombre y Firma del Familiar Responsable y/o Representante legal del Paciente</p>
                    </td>
               </tr>
            </table>
      
      </div>
    </div>
    <style>@page {
         margin: 0;
         padding:0;
        }
        table{
            width:792px;
            margin: 10px;
            border: 2px solid #0086b3;
        }
        th, td {
            border: 1px solid #0086b3;
            color: #00ace6;
            padding:15px;
        }
        #1{
            border-bottom: 0;
        }
        #2{
            border-top: 0;
        }
        
        #3{
            border-bottom: 0;
        }
        #4{
            border-top: 0;
            border-right: 0;
        }
        #5{
            border-top: 0;
            border-left: 0;
        }
        
        </style>
        <button title="Imprimir PDF" type="submit" class="btn btn-success">Imprimir</button>
    </form>
</div>
</center>

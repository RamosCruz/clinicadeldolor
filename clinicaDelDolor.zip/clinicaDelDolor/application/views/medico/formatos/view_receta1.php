<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css');?>">
<br><br>

    <div class="row">
    <h1>Nueva receta médica.</h1>
    <form action="<?php echo base_url('medico/Formatos/imprimirReceta2'); ?>" target="_blank" method="post">
        <div class="panel panel-primary" style="width:850px; ">
            <div class="panel-body">
                <header class="clearfix">
                    <div id="logo">
                        <img src="<?php echo base_url('assets/img/logotipo.png');?>">
                    </div>
                    <div id="company">
                        <h2 class="name">Clinica del Dolor - Oaxaca</h2>
                        <div>Mario Pérez Ramírez 122, Colonia Reforma, Oaxaca</div>
                        <div>(951) 132 91 53</div>
                        <div><a href="mailto:victorscasti@hotmail.com">victorscasti@hotmail.com</a></div>
                    </div>
                </header>
                <main>
                    <div id="details" class="clearfix">
                        <div id="client">
                            <div class="to">Expedido a:</div>
                            <div class="form-inline">
                                <input type="text" placeholder="Nombre del paciente" name="campo1" style="width:250px;" required class="form-control"><br>
                                <input class="form-control" type="text" placeholder="Direccion" name="campo2" required>
                                <br>
                                <input class="form-control" type="number" placeholder="Telefono" name="campo3" required>
                            </div>
                            
                        </div>
                        <div id="invoice">
                            <h1>Receta Médica</h1>
                            <div class="date">Fecha de expedición: <?php echo date("d/m/y");?></div>
                        </div>
                    </div>
                    
                    
                    <div class="form-inline">
                         <textarea class="form-control" rows="10" cols="110" name="campo4">
                        </textarea>
                    </div> 


                    <br>
                    <br>
                    <div>
                        <p style="margin:-0% 0;" align="center">______________________________________________</p>
                        <h4 style="margin:-0.5% 0;" align="center">Dr. <?php echo $medico_logueado[0]->nombre." ".$medico_logueado[0]->app." ".$medico_logueado[0]->apm;?></h4> <input type="hidden" name="campo5" value="<?php echo $medico_logueado[0]->nombre." ".$medico_logueado[0]->app." ".$medico_logueado[0]->apm;?>">
                        <p style="margin:-0.5% 0;" align="center"><strong>Cedula: <?php echo $medico_logueado[0]->cedula;?></strong></p>
                        <input type="hidden" name="campo6" value="<?php echo $medico_logueado[0]->cedula;?>">
                        <p style="margin:-0.5% 0;" align="center">Sello y firma del medico</p>
                    </div>
                </main>
                </div>
            </div>
            <button title="Imprimir PDF" type="submit" class="btn btn-success">Imprimir</button>
        </form>
    </div> 
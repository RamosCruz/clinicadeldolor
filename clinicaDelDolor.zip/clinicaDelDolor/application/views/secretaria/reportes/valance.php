<script src="<?php echo base_url('assets/js/Chart.bundle.js');?>"></script>
<script src="<?php echo base_url('assets/js/Chart.bundle.min.js');?>"></script>
<br>
<br>

<div class="col-sm-10 col-sm-offset-1">
    <h1>Ingresos</h1>
    <div class="form-inline">
      <div class="form-group">
          <label for="selectDoc">Seleccionar Doctor:</label>
          <select name="selectDoctor" id="selectDoctor" class="form-control"></select>
      </div>
      <div class="form-group">
        <label for="precioConsulta">Fecha inicio:</label>
        <div class="input-group date  input-append" id="datetimepicker4">
          <input type="text" class="form-control input-append" data-format="yyyy-MM-dd" type="text" name="fecha_inicio" id="fecha_inicio" required style="width: auto;"><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
        </div>


        <script type="text/javascript">
        $(function() {
          var today = new Date();
          $('#datetimepicker4').datetimepicker({
            pickTime: false,
            language: 'es-MX',
            endDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
            startDate: new Date(today.getFullYear()-90, today.getMonth(), today.getDate()),

          });});
        </script>
      </div>
      <div class="form-group">
        <label for="precioConsulta">Fecha termino:</label>
        <div class="input-group date  input-append" id="datetimepicker5">
          <input type="text" class="form-control input-append" data-format="yyyy-MM-dd" type="text" name="fecha_termino" id="fecha_termino" required style="width: auto;"><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
        </div>


        <script type="text/javascript">
        $(function() {
          var today = new Date();
          $('#datetimepicker5').datetimepicker({
            pickTime: false,
            language: 'es-MX',
            endDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
            startDate: new Date(today.getFullYear()-90, today.getMonth(), today.getDate()),

          });});
        </script>
      </div>

        <div class="form-group">
            <button class="btn btn-success" id="consultaValance">Consultar</button>
        </div>
    </div>

    
     <div class="table-responsive">
          <table class="table table-striped table-bordered table table-hover" style="margin-top: 20px;">
              <thead>
                  <tr>
                   <th><center>Forma de pago</center></th>
                   <th><center>Monto</center></th>
                    <th><center>Total</center></th>
                  </tr>
                </thead>
              <tbody id="contenidoTabla">
                  
              </tbody>
              
          </table>
        </div>
    
</div>

<div class="col-sm-8 col-sm-offset-2">
    <canvas id="myChart" width="auto" height="auto"></canvas>
</div>
<script>

    var labels=[];
    var datas=[];
    var arregloCompleto;
    $.ajax({
            type: 'ajax',
            method: 'get',
            async: false,
            url: '<?php echo base_url() ?>secretaria/Reportes/medicosConCuenta',
            data:{},
            dataType: 'json',
            success: function(data){

                for (i = 0; i < data.length; i++) {
                     $("#selectDoctor").append("<option value=" + data[i].idd_medico + ">Dr. " + data[i].nombreMedico + "</option>");
                }
            },
            error: function(){
              alert('Could not get Data from Database');
            }
            });
    
    
    
    
    $('#consultaValance').click(function(){
        arregloCompleto = null;
        var fecha_inicio = $('#fecha_inicio').val();
        var fecha_termino = $('#fecha_termino').val();
        var id_medico = $('#selectDoctor option:selected').val();
        $.ajax({
            type: 'ajax',
            method: 'get',
            async: false,
            url: '<?php echo base_url() ?>secretaria/Reportes/valanceMedico',
            data:{id_medico:id_medico,fecha_inicio:fecha_inicio,fecha_termino:fecha_termino},
            dataType: 'json',
            success: function(data){

                arregloCompleto = data;
                var base_url= "<?php echo base_url(); ?>";
                var total = 0;
                var tarjeta=0;
                var efectivo=0;
                var convenio=0;
                var html = '';
                for (i = 0; i < data.length; i++) {
                    
                    if(data[i].formapago==1)
                    {
                       efectivo = efectivo + parseInt(data[i].haber);
                    }
                    else if(data[i].formapago==2)
                    {
                        tarjeta = tarjeta + parseInt(data[i].haber);
                    }else if(data[i].formapago==3)
                    {
                        convenio = convenio + parseInt(data[i].haber);
                    }
                   total = efectivo+tarjeta+convenio;
                }
                if(total>0)
                {
                   
                    html +='<tr>'+
                                    '<td><center><img src="'+base_url+'assets/img/formaPagoo1.png'+'" alt="">  Efectivo</center></td>'+
                                    '<td><center>$'+efectivo+'</center></td>'+
                                    '<td rowspan="3" style="vertical-align:middle" align="center">$'+total+'</td></tr>';
                    html +='<tr>'+
                                    '<td><center><img src="'+base_url+'assets/img/formaPagoo2.png'+'" alt="">Vouchers: <b><u>';
                    
                    for (i = 0; i < data.length; i++) {
                        if(data[i].formapago == 2)
                        {
                            html +="<p>"+ data[i].boucher+"</p>";
                        }
                    } 
                    html+='</u></b></center></td>'+
                                    '<td style="vertical-align:middle"><center>$'+tarjeta+'</center></td></tr>';
                    html +='<tr>'+
                                    '<td><center><img src="'+base_url+'assets/img/formaPagoo3.png'+'" alt="">  Convenio</center></td>'+
                                    '<td><center>$'+convenio+'</center></td></tr>';
                
                }
                $('#contenidoTabla').html(html);
                
                labelsArray(arregloCompleto);
            },
            error: function(){
              alert('Could not get Data from Database');
            }
            });
    });
    
    function labelsArray (arregloCompleto)
    {
        labels=[];
        for (i = 0; i < arregloCompleto.length; i++) {
            if(labels.length==0){
              labels.push(arregloCompleto[i].fecha_haber);  
            }
            
            for (j = 0; j < labels.length; j++) {
                if(labels.indexOf(arregloCompleto[i].fecha_haber) < 0)
                {
                   labels.push(arregloCompleto[i].fecha_haber);
                }
            } 
        } 
        console.log(labels);
        datasArray();
    }
    
    function datasArray()
    {
        suma=0;
        
        datas=[];
        for (i = 0; i < labels.length; i++) {
            var suma = 0;
            for (j = 0; j < arregloCompleto.length; j++) {
                if(arregloCompleto[j].fecha_haber == labels[i])
                {
                    suma = suma + parseInt(arregloCompleto[j].haber);
                }
            }
            datas.push(suma);
        } 
        console.log(datas);
        
        
        
        var ctx = document.getElementById("myChart").getContext('2d');
        var chart = new Chart(ctx, {
        // The type of chart we want to create
        type: 'line',

        // The data for our dataset
        data: {
        labels: labels,
        datasets: [{
            label: "Ingreso del día",
            borderColor: 'rgb(21, 230, 0)',
            backgroundColor: 'rgb(198, 255, 192)',
            data: datas,
        }]
        },

        // Configuration options go here
        options: {}
        }
        );
    }
</script>
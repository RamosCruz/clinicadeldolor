<br><br><br>
<h1>Cuentas</h1>
<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">Listado de cuentas del día</h3>
  </div>
  <div class="panel-body">
       
        
        <div class="table-responsive">
          <table class="table table-striped table-bordered table table-hover" style="margin-top: 20px;">
              <thead>
                  <tr>
                   <th><center>Paciente</center></th>
                   <th><center>Medico</center></th>
                    <th><center>Cargo</center></th>
                    <th><center>Forma de pago</center></th>
                    <th><center>Abono</center></th>
                  </tr>
                </thead>
              <tbody id="contenidoTabla">
                  <?php
                  if($cuentas!= false)
                  {
                      foreach ($cuentas as $value)
                      {?>
                        <tr>
                            <td><center><?php echo $value->nombre.' '.$value->app.' '.$value->apm; ?></center></td>
                            <td><center>Dr. <?php echo $value->nombreMedico; ?></center></td>
                            <td><center>$<?php echo $value->debe; ?></center></td>
                            <?php
                                if ($value->haber!=null)
                                { 
                                    if ($value->formapago==1)
                                    { ?>
                                        <td><center><img src="<?php echo base_url('assets/img/formaPagoo'.$value->formapago.'.png'); ?>" alt=""> Efectivo</center></td>
                                   <?php }
                                    else if ($value->formapago==2)
                                    { ?>
                                        <td><center><img src="<?php echo base_url('assets/img/formaPagoo'.$value->formapago.'.png'); ?>" alt=""><b><u> <?php echo $value->boucher; ?></u></b></center></td>
                                   <?php } else if ($value->formapago==3)
                                    { ?>
                                        <td><center><img src="<?php echo base_url('assets/img/formaPagoo'.$value->formapago.'.png'); ?>" alt=""> Convenio</center></td>
                                   <?php }
                                }
                                else
                                { ?>
                                    <td><center>
                                        <select id="formaPago<?php echo $value->id_contabilidad; ?>">
                                            <option value="0"></option>
                                            <option value="1">Efectivo</option>
                                            <option value="2">Tarjeta</option>
                                            <option value="3">Convenio</option>
                                        </select>
                                    </center></td>
                                <?php }
                            ?>
                            <?php if ($value->haber != null)
                            { ?>
                                <td><center>$<?php echo $value->haber; ?></center></td> 
                            <?php }
                            else
                            { ?>
                                <td><center><a href="javascript:;" class="btn btn-success item-id-pagar" data_id_conta="<?php echo $value->id_contabilidad; ?>" data_debe="<?php echo $value->debe; ?>">Registrar pago</a></center></td>   
                            <?php } ?>
                            
                        </tr>
                      <?php } 
                  }?>
              </tbody>
              
          </table>
        </div>
  </div>
</div>


<script>
    $('#contenidoTabla').on('click', '.item-id-pagar', function(){
        var id_contabilidad = $(this).attr('data_id_conta');
        var formaPago = $('#formaPago'+id_contabilidad+' option:selected').val();
        
        var debe = $(this).attr('data_debe');
        if(formaPago !=0)
        {
            if(formaPago ==1)
            {
                swal({
                    title: 'Confirmar',
                    text: "Confirme el pago con un monto de $"+debe+"; despues este proceso sera Irreversible!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Pagar'
                }).then(function () {
                    pagar(id_contabilidad,debe,formaPago,'');
                })
            }else if(formaPago ==2)
            {   
                swal({
                    title: "Confirme e Introdusca el numero de serie del voucher",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Pagar',
                    html: "Voucher valido por $"+debe+": <input type='text' id='boucher'>"
                }).then(function () {
                    var boucher= $('#boucher').val();
                    pagar(id_contabilidad,debe,formaPago,boucher);
                });
            
            }else if(formaPago ==3)
            {   
                swal({
                    title: 'Confirmar',
                    text: "Confirme el Convenio con un monto de $"+debe+"; despues este proceso sera Irreversible!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Pagar'
                }).then(function () {
                    pagar(id_contabilidad,debe,formaPago,'');
                })
            
            }
            
            
        }else
        {
            swal({
                    title: "Alto!",
                    text: "Seleccione la forma de pago!",
                      type: "warning",
                      timer: 2000,
                      showConfirmButton: false
                }).catch(swal.noop);
        }
		});
    
    
    
    
    
    
    function actualizarT()
    {
        
        $.ajax({//En este metodo falta repillar la consulta para que sea mas cercana a la respuesta
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>secretaria/reportes/cuentasDeHoy',
               dataType: 'json',
               success: function(data){
                if(data==false){

                        
              

                    }
                    else{
                             
                            var base_url= "<?php echo base_url(); ?>";
                            var html = '';
                            var i;
                            for(i=0; i<data.length; i++){
                                    html +='<tr>'+
                                    '<td><center>'+data[i].nombre+' '+data[i].app+' '+data[i].apm+'</center></td>'+
                                    '<td><center>Dr. '+data[i].nombreMedico+'</center></td>'+    
                                    '<td><center>$'+data[i].debe+'</center></td>';
                                
                                    if(data[i].haber!=null)
                                    {
                                       
                                        if(data[i].formapago==1)
                                           {
                                            html+= '<td><center><img src="'+base_url+'assets/img/formaPagoo'+data[i].formapago+'.png'+'" alt="">  Efectivo</center></td>';
                                           }
                                           else if(data[i].formapago==2)
                                           {
                                            html+= '<td><center><img src="'+base_url+'assets/img/formaPagoo'+data[i].formapago+'.png'+'" alt=""> <b><u>'+data[i].boucher+'</u></b></center></td>';
                                           }else if(data[i].formapago==3)
                                           {
                                            html+= '<td><center><img src="'+base_url+'assets/img/formaPagoo'+data[i].formapago+'.png'+'" alt=""> Convenio</center></td>';
                                           }
                                    }else
                                    {
                                        html+= '<td><center><select  id="formaPago'+data[i].id_contabilidad+'"><option value="0"></option><option value="1">Efectivo</option><option value="2">Tarjeta</option><option value="3">Convenio</option></select></center></td>';
                                    }
                                
                                
                                    if(data[i].haber!=null)
                                    {
                                       html+= '<td><center>$'+data[i].haber+'</center></td></tr>';
                                    }else
                                    {
                                        html+= '<td><center><a href="javascript:;" class="btn btn-success item-id-pagar" data_id_conta="'+data[i].id_contabilidad+'" data_debe="'+data[i].debe+'">Registrar pago</a></center></td></tr>';
                                    }
                            }
                            
                            $('#contenidoTabla').html(html);
                        }

                    },
                    error: function(error){
                        console.log(error);
                        alert('Could not get Data from Database');
                    }
                });
        
       // setTimeout(actualizarT(),20000); 
       
    }
    
    
    function pagar(id_contabilidad,haber,formaPago,boucher)
    {
        $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>secretaria/reportes/registrarPago",
                    data: {id_contabilidad:id_contabilidad,haber:haber,formapago:formaPago,boucher:boucher},
                    dataType: 'json',
                    success: function(response){

                        if(response.success){
                            actualizarT()
                          swal({
                                title: "Pagado!",
                                text: "Pago registrado",
                                  type: "success",
                                  timer: 2000,
                                  showConfirmButton: false
                            }).catch(swal.noop);
                        }
                        else{
                             swal({
                                title: "Error!",
                                text: "Intente de nuevo",
                                  type: "warning",
                                  timer: 2000,
                                  showConfirmButton: false
                            }).catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
    }
    
    
    
</script>
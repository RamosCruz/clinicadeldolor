<hr>
<hr>
<hr>

<div>
   <div class="well">
        <div class="input-group">
          <input type="text" class="form-control" placeholder="Buscar por nombre del paciente" aria-describedby="basic-addon2" id="buscarPaciente" >
          <span class="input-group-addon" id="basic-addon2"><span class="glyphicon glyphicon-search"></span></span>
        </div> 
        </div>
    <br>
  
          
      <div class="panel panel-primary">
         
         <div class="panel-heading">
            <h3 class="panel-title">Pacientes</h3>
          </div>
          <div class="panel-body">
          
       <div class="table-responsive">
        <table class="table table-bordered" id="tablaBusqueda">
         <thead>
            <th>C.U.R.P.</th>
            <th>Nombre</th>
            <th>Apellido paterno</th>
            <th>Apellido materno</th>
            <th>Grupo sanguineo</th>
            <th>Telefono</th>
            <th><center>Acciones</center></th>
         </thead>
         <tbody>
             <?php foreach($listarPacientes as $value) { ?>
                <tr>
                    <td><?php echo $value->curp; ?></td>
                    <td><?php echo $value->nombre; ?></td>
                    <td><?php echo $value->app; ?></td>
                    <td><?php echo $value->apm; ?></td>
                    <td><?php echo $value->tipoSangre; ?></td>
                    <td><?php echo $value->telefono; ?></td>
                    <td>
                       <center>
                        <!--a href="<?php echo base_url('secretaria/paciente/eliminar/').$value->curp;?>" class="btn btn-default glyphicon glyphicon-trash"></a-->
                        <a href="<?php echo base_url('secretaria/paciente/editar/').$value->curp;?>"class="btn btn-default glyphicon glyphicon-pencil" title="Editar datos del paciente"></a>
                        </center>
                    </td>
                </tr> 
             <?php } ?>
         </tbody>
        </table>
        </div>
    </div>
            </div>
      
    
        

</div>


<script type="text/javascript">

var baseurl = '<?php echo base_url("secretaria/Paciente/buscarPaciente/"); ?>';

$('#buscarPaciente').keyup(function(){
    $('#tablaBusqueda tbody').html('');
    
    var texto = $('#buscarPaciente').val();
    $.post(baseurl,
        {text : texto},
        function(data){
            
        var obj = JSON.parse(data);
        var output = '';
        $.each(obj,function(i,item){
            if(item.id_paciente != "")
            {
                output +=
                    '<tr>'+
                        '<td>'+item.curp+'</td>'+
                        '<td>'+item.nombre+'</td>'+
                        '<td>'+item.app+'</td>'+
                        '<td>'+item.apm+'</td>'+
                        '<td>'+item.tipoSangre+'</td>'+
                        '<td>'+item.telefono+'</td>'+
                        '<td>'+
                            '<center>'+
                                '<a href="'+baseurl+'paciente/editar/'+item.curp+'" class="btn btn-default glyphicon glyphicon-pencil" title="Editar datos del paciente"></a>'+
                            '<center>'+
                        '</td>'
                    '</tr>';
            }
        });
        $('#tablaBusqueda tbody').append(output);
    });
});


</script>


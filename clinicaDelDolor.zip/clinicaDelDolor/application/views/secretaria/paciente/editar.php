

<!-- ------------------------------------------------------------------------------------------ -->

<hr>
<hr>
         <hr>

         <div class="col-md-8 col-md-offset-2">
            <!--<form class="form-horizontal" method="post" action="">-->
            
            <!--<div class="col-md-12">-->
                 <div class="panel panel-primary">
                 <div class="panel-heading">
                    <h3 class="panel-title">Nuevo paciente</h3>
                  </div>
                  <div class="panel-body">
                      <!------------------------>
                      <form class="form-horizontal"  id="formularioActualizarDePacientes" method="post" action="<?php echo base_url('secretaria/paciente/actualizar');?>">
                        <!-------------------------->
                        <div class="panel panel-default">                           
                          <div class="panel-body">
                            <div class="col-sm-12">Datos generales
                              <hr style="color: #0056b2;" />
                              <!-- INICIO DE ENCAPSULACIÓN -->
                              <div class="row">
                                
                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                                      <label  for="nombre" class="control-label">*Nombre</label>
                                      <input type="text" class="form-control" id="nombre_paciente" placeholder="Nombre" name="nombre"  value="<?php echo $datosPaciente[0]->nombre;?>"required >
                                    </div>
                                  </div>

                                </div>

                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                                      <label for="app" class="control-label">*Apellido paterno</label>
                                      <input type="text" class="form-control" id="ap_paterno_paciente" placeholder="Apellido paterno" name="app"  value="<?php echo $datosPaciente[0]->app;?>" required >
                                    </div>
                                  </div>
                                </div>

                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                                      <label for="apm" class="control-label">Apellido materno</label>
                                      <input type="text" class="form-control" id="am_paterno_paciente" placeholder="Apellido materno" name="apm" value="<?php echo $datosPaciente[0]->apm;?>" >
                                    </div>
                                  </div>
                                </div>

                              </div>

                              
                              <div class="row">

                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                                      <label for="sexo" class="control-label">*Sexo</label>
                    <center>
                                         <?php 
                                  $class = array('class' => 'sexo_paciente1');
                                  if($datosPaciente[0]->sexo=='H')
                                  {
                                      echo '<label class="radio-inline">'.form_radio('sexo', 'H',TRUE,$class).'Hombre</label>';
                                      echo '<label class="radio-inline">'.form_radio('sexo', 'M',FALSE,$class).'Mujer</label>';
                                  }else{
                                      echo '<label class="radio-inline">'.form_radio('sexo', 'H',FALSE,$class).'Hombre</label>';
                                      echo '<label class="radio-inline">'.form_radio('sexo', 'M',TRUE,$class).'Mujer</label>'; 
                                  }
                              ?>
                            </center>
                                    </div>
                                  </div>
                                </div>

                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                                      <label for="estado" class="control-label">*Estado de nacimiento</label>

                                      <?php
                                    foreach($datosPaciente as $value){    
                                        $lista = array();
                                        foreach($selEstados as $registro)
                                        {
                                            $lista[$registro->clave_estado] = $registro->estado;
                                        }
                                        echo form_dropdown('estado',$lista,$value->estado,'class="form-control" id="estado_paciente1 required"');
                                    }
                                        ?>

                                   </div>
                                 </div>
                               </div>


                               <div class="col-sm-4">
                                 <div class="form-group">
                                  <div class="col-md-12 col-sm-12">
                                    <label for="fecha_nacimiento" class="control-label">*Fecha de nacimiento</label>

                                      <?php
                                  $date = new DateTime($datosPaciente[0]->fecha_nacimiento);
                                    $fecha_nacimiento = $date->format('d-m-Y');
                                ?>
                                      <div class="input-group date  input-append" id="datetimepicker4" placeholder="12/02/1994">
                                        <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="fecha_nacimiento" id="fecha_nacimiento"  value="<?php echo $fecha_nacimiento; ?>" required><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                                      </div>
                                      


                                    <script type="text/javascript">
                                    $(function() {
                                      var today = new Date();
                                      $('#datetimepicker4').datetimepicker({
                                        pickTime: false,
                                        language: 'es-MX',
                                        endDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
                                        startDate: new Date(today.getFullYear()-90, today.getMonth(), today.getDate()),

                                      });});
                                    </script>

                                  </div>
                                </div>
                              </div>

                            </div>
                            <div class="row">
                              <div class="col-md-4">
                               <div class="form-group">
                                <div class="col-md-12">
                                  <label for="estado" class="control-label">*C.U.R.P.</label>

                                  <input type="text" class="form-control" id="curp" placeholder="CURP" name="curp"  value="<?php echo $datosPaciente[0]->curp;?>" required>
                                </div>
                              </div>
                            </div>
                            <div class="col-sm-4">
                              <div class="form-group">
                                <div class="col-md-12">
                                  <label for="alergia" class="control-label">Alergia</label>

                                  <input type="text" class="form-control" id="inputEmail3" placeholder="Alergia" name="alergia" value="<?php echo $datosPaciente[0]->alergia;?>"required>
                                </div>
                              </div>
                            </div>
                            <div class="col-sm-4">
                              <div class="form-group">
                                <div class="col-md-12">
                                  <label for="estado_civil" class="control-label">Estado civil</label>

                                  <?php
                                    foreach($datosPaciente as $value){    
                                        $lista = array();
                                        foreach($selestadoCivil as $registro)
                                        {
                                            $lista[$registro->idestadoCivil] = $registro->estadoCivil;
                                        }
                                        echo form_dropdown('estado_civil',$lista,$value->estado_civil,'class="form-control"  required');
                                    }
                                   ?>

                                </div>
                              </div>
                            </div>



                          </div>

                          
                          <div class="row">
                           <div class="col-md-4">
                            <div class="form-group">
                              <div class="col-md-12">
                                <label for="tipo_sangre" class="control-label">*Grupo sanguineo</label>
                                
                                
                                <?php
                                    foreach($datosPaciente as $value){    
                                        $lista = array();
                                        foreach($seltipoSangre as $registro)
                                        {
                                            $lista[$registro->idtipoSangre] = $registro->tipoSangre;
                                        }
                                        echo form_dropdown('tipo_sangre',$lista,$value->tipo_sangre,'class="form-control" required');
                                    }
                                   ?>
                                
                              </div>
                            </div>
                          </div>
                        </div>
                        <!-- FIN DE ENCAPSULACIÓN -->
                      </div>
                    </div>
                  </div>
                  <!-------------------------->

                  <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="col-sm-12">Domiciliar
                        <hr style="color: #0056b2;" />
                        <!-- INICIO DE ENCAPSULACIÓN -->

                        <div class="row">
                          <div class="col-md-4">
                            <div class="form-group">
                              <div class="col-md-12">
                                <label for="localidad" class="control-label">Estado</label>
                               
                               
                               <?php
                                    foreach($datosPaciente as $value){    
                                        $lista = array();
                                        foreach($selEstados as $registro)
                                        {
                                            $lista[$registro->clave_estado] = $registro->estado;
                                        }
                                        echo form_dropdown('estado_D',$lista,$value->estado_D,'class="form-control" id="estado_D" required onchange="cambiarCombos(this.value);"');
                                    }
                                   ?>
                             </div>

                           </div>
                         </div>


                         <div class="col-md-4">
                          <div class="form-group">
                            <div class="col-md-12">
                              <label for="localidad" class="control-label">Municipio</label>
                             <?php
                                    foreach($datosPaciente as $value){    
                                        $lista = array();
                                        foreach($selmunicipios as $registro)
                                        {
                                            $lista[$registro->clave_municipio] = $registro->nombre_municipio;
                                        }
                                        echo form_dropdown('colonia',$lista,$value->municipio,'class="form-control" id="listaDeMunicipios" required onchange="cambiarCombosLocalidades(this.value);"');
                                    }
                                   ?>
                           </div>
                         </div>
                       </div>
                       

                       <div class="col-md-4">
                         <div class="form-group">
                          <div class="col-md-12">
                            <label for="colonia" class="control-label">Localidad</label>
                            
                            <?php
                                    foreach($datosPaciente as $value){    
                                        $lista = array();
                                        foreach($sellocalidades as $registro)
                                        {
                                            $lista[$registro->clave_localidad] = $registro->nombre;
                                        }
                                        echo form_dropdown('localidad',$lista,$value->localidad,'class="form-control" required id="listadoDeLocalidades"');
                                    }
                                   ?>
                            
                         </div>
                       </div>
                     </div>
                   </div>

                   <div class="row">
                    
                    <div class="col-md-4">
                      <div class="form-group">
                        <div class="col-md-12">
                          <label for="domicilio" class="control-label">Domicilio</label>
                          <input type="text" class="form-control" id="calle" placeholder="Calle #" name="domicilio" value="<?php echo $datosPaciente[0]->domicilio;?>">
                        </div>
                      </div>
                    </div>

                    <div class="col-md-4">
                      <div class="form-group">
                        <div class="col-md-12">
                          <label for="telefono" class="control-label">Telefono</label>
                          
                          <input type="tel" class="form-control" id="telefono" placeholder="Telefono" name="telefono" value="<?php echo $datosPaciente[0]->telefono;?>" required>
                          
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--                         -->

                </div>
              </div>
            </div>
            

            <div class="form-group">
              <div class="col-sm-2"></div>
              <div class="col-sm-10">
               <h5>*Campos requeridos.</h5>  
             </div>

           </div>

           <center>
            <div class="form-group">
              <div class="col-sm-offset-2 col-sm-10">
                <button id="btn-actualizarPaciente" class="btn btn-primary">Actualizar</button>
                <a href="<?php echo base_url('secretaria/paciente');?>" type="button" class="btn btn-default">Regresar</a>
              </div>
            </div>

          </center>


          <!---------------------------->  
        </form>
                  </div>
                </div>
            <!--</div>-->
          </div>




           
                
            <!--</form>-->
         
             
        
       
      
     
    
   
<!--                        USO DE MODALS -->



<!-- MODAL EDITAR FECHA-->
<div id="confirmarModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
        <h2><center><i class="glyphicon glyphicon-calendar"></i>REGISTRAR CURP</center></h2>
        <h8><center>Porfavor confirme su dos ultimos dÌgitos</center></h8>
      </div>
      <div class="modal-body">
            <form class="form-horizontal" id="formularioActualizarFecha" method="post" action="">
                
                <div class="form-group">
                                    <div class='col-sm-2'>
                                        <label for="fecha-cita" class="control-label" style="color:#336699">CURP</label>
                                    </div>
                                    <div class="col-sm-10">

                                            <div class="input-group  input-append" >
                                              <input type="text" class="form-control input-append"  type="text" name="curp-modal" id="curp-modal"  min="18"  max="18" disabled required><span class="input-group-addon add-on" ><i class=""><input id="caracteres-de-validacion" name="caracteres-de-validacion" type="text" min="2"  max="2" ></i></span>
                                            </div>

                                        
                                    </div>
                                </div>
            </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default"  data-dismiss="modal">Cancelar</button>
        <button type="button" id="btnValidaCURP" class="btn btn-primary">Confirmar</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


          
<script>





 $('#curp').click(function(){
     //document.getElementById("curp").value=curp;
     var totalCurp=generaCurpAutomatico().length;
     //var curp    = $('input[name=curp]').val(generaCurpAutomatico());
     
     var nombres    = $('input[name=nombre]').val();
     var apellido_p = $('input[name=app]').val();
     var apellido_m = $('input[name=apm]').val();
     var fecha_nace = $('input[name=fecha_nacimiento]').val();
     var estado     = $('select[name=estado] option:selected').text();
     var sexo       = $('input:radio[name=sexo]:checked').val();
     
     if(nombres!=""&&apellido_p!=""&&fecha_nace!=""&&estado!=""&& totalCurp<=18){

         var curp=generaCurpAutomatico();
         var curpAcotada16    = $('input[name=curp-modal]').val(curp.substring(0,16));
         var curpAcotada2    = curp.substring(16,18);
         
         $("#caracteres-de-validacion").attr("placeholder", curpAcotada2);
         
         //alert("El CURP es: "+curp.substring(0,16)+" TOTAL "+curp.substring(0,16).length);
         
         $('#confirmarModal').modal('show');    
         
         $('#btnValidaCURP').unbind().click(function(){
                var fu=$('input[name=curp-modal]').val();
                var cion=$('#caracteres-de-validacion').val().toUpperCase();
             //alert(fu+cion);
             if(cion!=""){
              var curpPost=fu+""+cion;
                //$('#confirmarModal').modal('hide');
                //var fecha = $('input[name=fecha-cita]').val();
                //validaFechaDelMedico(id_medico,id_paciente,hora,fecha_vieja,fecha);
             
               $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>secretaria/Paciente/validaCURP",
                    data: {curp:curpPost},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        //$('#confirmarModal').modal('hide');

                        if(response){
                            //alert("Tu curp fue valida exitosamente!");
                            $('#confirmarModal').modal('hide');
                            
                            $('input[name=curp]').val(curpPost);
                          swal({
                                      title: "CURP validada exitosamente!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                        else{
                            //alert("Esta curp ya se encuentra registrada,puedes intentar modificando tus 2 ultimos numeros de aoutentificacion o bien hagaselo saber  al administrador del sistema!");
                            swal({
                                      title: "Esta CURP ha sido registrada anteriormete!",
                                      type: "warning",//,cambiar
                                      text: "Cambie los ultimos 2 digitos",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
             }
                
            });

         
         //VALIDAR CURP EN LA BASE DE DATOS

   

         
       }
    
});
    

    
    
    
    
    
    
//------EVENTOS PARA BLOQUEAR Y DESBLOQUEAR  EL INPUT CURP
     $("#curp").blur(function(){
            $(this).prop("readonly",""); 
        });

        $("#curp").focus(function(){
            $(this).prop("readonly","readonly"); 
        });
   

    
    
   
    
function generaCurpAutomatico(){
    var nomb=          document.getElementById("nombre_paciente").value;      //---Completo
    var apellido_pat = document.getElementById("ap_paterno_paciente").value;  //---Completo
    var apellido_mat = document.getElementById("am_paterno_paciente").value;  //---Completo
    var sex;
    if(document.getElementsByClassName("sexo_paciente")[0].checked){
        sex = 'H'        //---Completo
    }else{
        sex = 'M';
    }

    var esta =           digitos_estados.letrasDigitos(document.getElementById("estado_paciente").value);      //---Completo

    var fecha =document.getElementById("fecha_nace_paciente").value;
    var arreNumFecha=fecha.split("-");                                           //---Completo

    for(var i=0;i<arreNumFecha.length;i++){  
      arreNumFecha[i]=parseInt(arreNumFecha[i]);
    }

    var curp = generaCurp({
        nombre            : nomb,
        apellido_paterno  : apellido_pat,
        apellido_materno  : apellido_mat,
        sexo              : sex,
        estado            : esta,
        fecha_nacimiento  : arreNumFecha
      });

    return curp;
    }
    
    
    
    
    
    /*$('#btn-actualizarPaciente').click(function(){
     
        var datos=$('#formularioActualizarDePacientes').serialize();
       
        alert(datos);
        
      
    });*/
    
    $('#fecha_nace_paciente').blur(function(){
        $(this).prop("readonly","")
    });
    $('#fecha_nace_paciente').focus(function(){
        $(this).prop("readonly","readonly")
    });
    

        
function cambiarCombos(dato) {
    
  var html = '';
  $('#listaDeMunicipios').html(html);
    
  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>secretaria/Paciente/getMunicipiosDelEstado",
                    data: {id_estado:dato},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        //$('#confirmarModal').modal('hide');
                        var html = '<option></option>';
                         $('#listaDeMunicipios').html(html);
                        

                        if(response!=false){
                        //var consola = document.getElementById("listaDeMunicipios");
                            for (var i = 0; i < response.length; i++) {
                              $('#listaDeMunicipios').append('<option value="'+response[i].clave_municipio+'">'+response[i].nombre_municipio+'</option>'); 
                              //alert(response[i].clave_municipio+" --> "+response[i].nombre_municipio);
                              //console.log("clave de estado: "+response[i].clave_estado+" clave muni: "+response[i].clave_municipio+" municipio: "+response[i].nombre);
                            }
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
  

  }
    
function cambiarCombosLocalidades(dato) {
  var html = '';
   var idEstado = $('#estado_D option:selected').val();
  $('#listadoDeLocalidades').html(html);
  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>secretaria/Paciente/getLocalidadesDelMunicipioDe",
                    data: {id_municipio:dato, id_estado : idEstado},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        //$('#confirmarModal').modal('hide');
                        var html = '<option></option>';
                         $('#listadoDeLocalidades').html(html);
                        

                        if(response!=false){
                        //var consola = document.getElementById("listaDeMunicipios");
                            for (var i = 0; i < response.length; i++) {
                              $('#listadoDeLocalidades').append('<option value="'+response[i].clave_municipio+'">'+response[i].nombre+'</option>'); 
                              //console.log("clave de estado: "+response[i].clave_estado+" clave muni: "+response[i].clave_municipio+" municipio: "+response[i].nombre);
                            }
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
  

  }

    
</script>

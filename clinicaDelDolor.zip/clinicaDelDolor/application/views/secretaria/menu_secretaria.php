<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
<img src="<?php echo base_url('assets/img/logotipo.png');?>" alt="">
<!--a class="navbar-brand" href="#">Clinica del dolor</a-->
    </div>
    

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/medical-records(1).png');?>" alt=""> Agenda de citas <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('secretaria/Agenda/nuevaCita');?>">Nueva cita</a></li>
            <li><a href="<?php echo base_url('secretaria/Agenda/listarAgenda');?>">Administrar citas</a></li>
            <li><a href="<?php echo base_url('secretaria/Agenda/fullCalendar');?>">Calendario</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/pain.png');?>" alt=""> Pacientes <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('secretaria/paciente/nuevoPaciente');?>">Nuevo paciente</a></li>
            <li><a href="<?php echo base_url('secretaria/paciente'); ?>">Listar pacientes</a></li>
          </ul>
        </li>
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/analytics.png');?>" alt=""> Reportes <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('secretaria/Reportes/Cuentas'); ?>">Cuentas</a></li>
            <li><a href="<?php echo base_url('secretaria/Reportes/Valance'); ?>">Balance de ingresos</a></li>
          </ul>
        </li>
        
      </ul>
      <ul class="nav navbar-nav navbar-right">
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/users.png');?>" alt="">  <?php echo ucfirst(strtolower($this->ion_auth->user()->row()->first_name)); ?><span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('Auth/logout');?>"> Salir</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<hr>
<hr>
<script async defer src="https://apis.google.com/js/api.js"
    onload="this.onload=function(){};handleClientLoad()"
    onreadystatechange="if (this.readyState === 'complete') this.onload()">
</script>
 <div class="page-header">
</div>
<div class="container">
 <div class="row">
     <div class="col-md-12" >
         <!----------------ALERT------------------------- -->
        
         <div class="panel panel-primary class">
            <div class="panel-heading">
                <h3 class="panel-title" >CITAS MEDICAS</h3>
            </div>
            <div class="panel-body">
                <div class="row">

                    <div class="col-md-12">

                        <!-- --------------------EL FORMULARIO DE CITAS-------------------------- -->
                              <div class="panel panel-default">
                                    <div class="panel-body">
                                         <div class="row">
                                         
                                        <!--<form class="form-horizontal" method="post" action="#">-->
                                            <div class="col-md-4">
                                                        <!--<div class="form-group">-->
                                                            <div class="col-sm-2">
                                                                <label for="estado" class="control-label">Medico</label>
                                                            </div>
                                                            <div class="col-sm-10">
                                                                <select class="form-control" name="id-medico" id="id-medico" required>
                                                                    <?php foreach($medicos as $medico) { ?>
                                                                    <option value="<?php echo $medico->id_medico; ?>"> DR. <?php echo $medico->nombre;?> </option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                         <!--</div>-->
                                                    
                                            </div>

                                            <div class="col-md-4">
                                                         <!--<div class="form-group">-->
                                                            <div class="col-sm-5">
                                                                <label for="estatus" class="control-label">Estatus de cita</label>
                                                            </div>
                                                            <div class="col-sm-7">
                                                                <select class="form-control" name="id-estatus" id="id-estatus" required>
                                                                    <option value="0">PENDIENTE</option>
                                                                    <option value="1">APLICADA</option>
                                                                </select>
                                                            </div>
                                                         <!--</div>-->

                                            </div>

                                            <div class="col-md-4">
                                                        <!--<div class="form-group">-->
                                                            <div class="col-sm-offset-2 col-sm-10">
                                                                <button type="button" class="btn btn-success btn-lg btn-block" id="btn-buscarCita"><span class="glyphicon glyphicon-search"></span> Buscar</button>
                                                            </div>
                                                        <!--</div>-->

                                            </div>
                                        <!--</form>-->

                                         </div>
                                    </div>
                                </div>
                                <!-- -->
                                <!-- <br> -->
                                <!-- -->
                                <div class="alert alert-success" style="display: none;">
		
	                            </div>
                                <div class="table-responsive" id="conexion">
                                    <div class="nuevaTabla" id="showdata">
                                         
                                    </div>  
                                </div>
                                
                             

                        <!-- --------------------FIN FORMULARIO CITAS-------------------------- -->

                    </div>

                </div>
                <hr>
            </div>
        </div>
        <!----------------------------------------- -->
    </div>
</div>
</div>





<!-- ------------------------------------MODAL ELIMINAR------------------------------------ -->
<!-- Trigger the modal with a button -->
<!--<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>-->

<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Eliminar</h4>
      </div>
      <div class="modal-body">
        	Estas seguro de eliminar el registro?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="button" id="btnDelete" class="btn btn-danger">Eliminar</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!-- MODAL EDITAR HORA-->
<div id="editarHoraModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-time"></i> Modificar Hora</center></h2>
      </div>
      <div class="modal-body">
            <form class="form-horizontal" id="formularioActualizarHora" method="post" action="">
                <div class="form-group">
                    <div class='col-sm-2'>
                        <label for="" class="control-label" style="color:#336699">Hora*</label>
                    </div>
                    <div class='col-sm-10'>
                        <select class="form-control" name="hora-cita" id="hora-cita" required>
                            <?php for ($i = 0; $i <count($horario); $i++){ ?>
                            <option value="<?php echo $horario[$i]; ?>"><?php echo $horario[$i]; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="button" id="btnActualizarHora" class="btn btn-primary">Actualizar</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- MODAL EDITAR FECHA-->
<div id="editarFechaModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-calendar"></i> Modificar Fecha</center></h2>
      </div>
      <div class="modal-body">
            <form class="form-horizontal" id="formularioActualizarFecha" method="post" action="">
                
                <div class="form-group">
                                    <div class='col-sm-2'>
                                        <label for="fecha-cita" class="control-label" style="color:#336699">Fecha*</label>
                                    </div>
                                    <div class="col-sm-10">

                                            <div class="input-group date  input-append" id="datetimepicker4">
                                              <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="fecha-cita" id="fecha-cita"   required><span class="input-group-addon add-on"><i class=""></i></span>
                                            </div>

                                        <script type="text/javascript">
                                        $(function() {
                                            var today = new Date();
                                            $('#datetimepicker4').datetimepicker({
                                                pickTime: false,
                                                language: 'es-MX',
                                                endDate: new Date(today.getFullYear(), today.getMonth()+2, today.getDate()),
                                                startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
                                                
                                            });



                                        });

                                        </script>

                                    </div>
                                </div>
            </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="button" id="btnActualizarFecha" class="btn btn-primary">Actualizar</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- MODAL EDITAR NOTA-->
<div id="editarNotaModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-paste"></i> Modificar Nota</center></h2>
      </div>
      <div class="modal-body">
            <form class="form-horizontal" id="formularioActualizarNota" method="post" action="">
               <div class="form-group">
                                    <div class='col-sm-2'>
                                        <label for="app" class="col-sm-2 control-label" style="color:#336699">Nota</label>
                                    </div>
                                    <div class="col-sm-10">
                                        <textarea class="form-control" rows="3" name="nota" id="nota"></textarea>
                                        <style type="text/css">
                                        textarea {
                                            max-width: 100%; 
                                            max-height: 100%;
                                        }
                                        </style>
                                    </div>
                                </div>


            </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="button" id="btnActualizarNota" class="btn btn-primary">Actualizar</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



<!----------------EVENTOS JAVASCRIPT------------------------- -->
<script>

mostrarBusqueda();

            $('#btn-buscarCita').click(function(){
                mostrarBusqueda();
            })

  //.--------------FUNCION PARA ACTUALIZAR LA FECHA

    $('#showdata').on('click', '.item-editar-fecha', function(){
            var id_paciente = $(this).attr('data-paciente');
            var id_medico   = $(this).attr('data-medico');
            var hora        = $(this).attr('data-hora');
            var fecha_vieja = $(this).attr('data-fecha');
            var idEventgoogle = $(this).attr('data-idGoogle');
            var nombre_paciente = $(this).attr('data-nombrePaciente');////////////////////////////////////////////////////////////////////////////////////////
            var nombre_medico = $('#id-medico').find('option:selected').text();
            var nota = $(this).attr('data-nota');
            var summary = nombre_medico+" : "+nombre_paciente;
            var description = nota;

            
            $('#editarFechaModal').modal('show');
            document.getElementById("fecha-cita").value=fecha_vieja;

            $('#btnActualizarFecha').unbind().click(function(){

                var fecha = $('input[name=fecha-cita]').val();
                validaFechaDelMedico(id_medico,id_paciente,hora,fecha_vieja,fecha,idEventgoogle,summary,description);
                
            });

        });


//----------------------FUNCION PARA ACTUALIZAR LA NOTA

    $('#showdata').on('click', '.item-editar-nota', function(){
            var id_paciente = $(this).attr('data-paciente');
            var id_medico   = $(this).attr('data-medico');
            var hora        = $(this).attr('data-hora');
            var fecha       = $(this).attr('data-fecha');
            var nota       = $(this).attr('data-nota');//////////////////////////////////////////////////////////////////////Nota//////
        
            var idEventgoogle = $(this).attr('data-idGoogle');
            var nombre_paciente = $(this).attr('data-nombrePaciente');////////////////////////////////////////////////////////////////////////////////////////
            var nombre_medico = $('#id-medico').find('option:selected').text();
            var summary = nombre_medico+" : "+nombre_paciente;
            var description;

            $('#editarNotaModal').modal('show');
            document.getElementById("nota").value=nota;

              $('#btnActualizarNota').unbind().click(function(){
               nota = document.getElementById("nota").value;
               description = nota;
                  
               $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>secretaria/agenda/actualizarNotaDeCita",
                    data: {fecha:fecha,hora:hora,id_medico:id_medico,id_paciente:id_paciente,nota:nota},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        $('#editarNotaModal').modal('hide');

                        if(response.success){
                          swal({
                                      title: "Cita Actualizada por cambio de nota!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        actualizarFechaGoogle(hora,fecha,idEventgoogle,summary,description); 
                          mostrarBusqueda();
                        }
                        else{
                            $('.alert-warning').html('No se pudo actualizar la cita, favor de rectificar los datos!').fadeIn().delay(1000).fadeOut('slow');
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
             
             });

        });









          










    function validaFechaDelMedico(id_medico,id_paciente,hora,fecha_vieja,fecha,idEventgoogle,summary,description){

               
            $.ajax({
                    type: 'ajax',
                    method: 'get',
                    async: false,
                    url: '<?php echo base_url() ?>secretaria/agenda/ValidaFechaDelMedico',
                    data:{id_paciente:id_paciente,id_medico:id_medico,hora:hora,fecha:fecha},
                    dataType: 'json',
                    success: function(response){
                        if(response){
                            //alert("El medico esta disponible! continua verificando");
                            ValidaFechaDelPaciente(fecha,hora,id_medico,id_paciente,fecha_vieja,idEventgoogle,summary,description);
                        }
                        else{
                            swal({
                                    title: "No se ha podido actualizar la fecha de la cita",
                                    text: "El medico ya tiene registrado una cita a esa fecha, favor de cambiarla!",
                                    type: "warning",
                                    showConfirmButton: true
                                })
                            .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error en la petición!');
                    }
                });

}

   function ValidaFechaDelPaciente(fecha,hora,id_medico,id_paciente,fecha_vieja,idEventgoogle,summary,description){
      $.ajax({
                type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>secretaria/agenda/validaFechaDelPaciente',
               data:{fecha:fecha,hora:hora,id_medico:id_medico,id_paciente:id_paciente},
               dataType: 'json',
               success: function(data){
               

               if(data){
                //alert("El paciente esta disponible a esa hora");
                ActualizarFecha(fecha,hora,id_medico,id_paciente,fecha_vieja,idEventgoogle,summary,description);
                //location.reload();
                }
                else{
                  swal({
                                    title: "No se ha podido actualizar la fecha de la cita",
                                    text: "El paciente ya cuenta con una cita recervada a la misma fecha por otro médico, porfavor modifique la hora o la fecha para poder actualizar correctamente la cita!",
                                    type: "warning",
                                    showConfirmButton: true
                                }
                                )
                     .catch(swal.noop);
                }

                


                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
        }


        function ActualizarFecha(fecha,hora,id_medico,id_paciente,fecha_vieja,idEventgoogle,summary,description){
                $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>secretaria/agenda/actualizarFechaDeCita",
                    data: {fecha:fecha,hora:hora,id_medico:id_medico,id_paciente:id_paciente,fecha_vieja:fecha_vieja},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        $('#editarFechaModal').modal('hide');
                        if(response.success){
                          swal({
                                      title: "Cita Actualizada por cambio de fecha!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        actualizarFechaGoogle(hora,fecha,idEventgoogle,summary,description);    
                          mostrarBusqueda();


                        }
                        else{
                            $('.alert-warning').html('No se pudo actualizar la fecha, favor de rectificar los datos!').fadeIn().delay(1000).fadeOut('slow');
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

}

 
            
  //----------------FUNCION PARA ACTUALIZAR LA HORA         
    $('#showdata').on('click', '.item-editar-hora', function(){
            var id_paciente = $(this).attr('data-paciente');
            var id_medico   = $(this).attr('data-medico');
            var hora_vieja        = $(this).attr('data-hora');
            var fecha       = $(this).attr('data-fecha');/////////////////////////////////////////////////////////////////Hora//////////
        
            var idEventgoogle = $(this).attr('data-idGoogle');
            var nombre_paciente = $(this).attr('data-nombrePaciente');
            var nombre_medico = $('#id-medico').find('option:selected').text();
            var nota = $(this).attr('data-nota');
            var summary = nombre_medico+" : "+nombre_paciente;
            var description = nota;
        

            $('#editarHoraModal').modal('show');

             document.getElementById("hora-cita").value=hora_vieja;

            $('#btnActualizarHora').unbind().click(function(){

                var hora = $('select[name=hora-cita] option:selected').text();
                //alert("La hora nueva es: "+hora);
                //alert("La hora vieja es: "+hora_vieja);
                //alert("Datos enviados:"+fecha+" **  "+hora+"  ** "+id_medico+" "+id_paciente);
                validaHoraDelMedico(fecha,hora,id_medico,id_paciente,hora_vieja,idEventgoogle,summary,description);
                
            });

        });



function validaHoraDelMedico(fecha,hora,id_medico,id_paciente,hora_vieja,idEventgoogle,summary,description){

               
$.ajax({
                    type: 'ajax',
                    method: 'get',
                    async: false,
                    url: '<?php echo base_url() ?>secretaria/agenda/ValidaHoraDelMedico',
                    data:{id_paciente:id_paciente,id_medico:id_medico,hora:hora,fecha:fecha},
                    dataType: 'json',
                    success: function(response){
                        if(response){
                            //alert("El medico esta disponible! continua verificando");
                            ValidaHoraDelPaciente(fecha,hora,id_medico,id_paciente,hora_vieja,idEventgoogle,summary,description);
                        }
                        else{
                            swal({
                                    title: "No se ha podido actualizar la hora de la cita",
                                    text: "El medico ya tiene registrado una cita a esa hora, favor de cambiarla!",
                                    type: "warning",
                                    showConfirmButton: true
                                })
                            .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error en la petición!');
                    }
                });

}


    function ValidaHoraDelPaciente(fecha,hora,id_medico,id_paciente,hora_vieja,idEventgoogle,summary,description){
            $.ajax({
                type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>secretaria/agenda/validaHoraDelPaciente',
               data:{fecha:fecha,hora:hora,id_medico:id_medico,id_paciente:id_paciente},
               dataType: 'json',
               success: function(data){
               

               if(data){
                //alert("El paciente esta disponible a esa hora");
                ActualizarHora(fecha,hora,id_medico,id_paciente,hora_vieja,idEventgoogle,summary,description);
                //location.reload();
                }
                else{
                  swal({
                                    title: "No se ha podido actualizar la hora de la cita",
                                    text: "El paciente ya cuenta con una cita recervada a la misma hora por otro médico, porfavor modifique la hora o la fecha para poder actualizar correctamente la cita!",
                                    type: "warning",
                                    showConfirmButton: true
                                }
                                )
                     .catch(swal.noop);
                }

                


                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
        }




function ActualizarHora(fecha,hora,id_medico,id_paciente,hora_vieja,idEventgoogle,summary,description){

 //alert("Datos enviados:"+fecha+" **  "+hora+"  ** "+id_medico+" "+id_paciente+" hora vieja "+hora_vieja);
                $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>secretaria/agenda/actualizarHoraDeCita",
                    data: {fecha:fecha,hora:hora,id_medico:id_medico,id_paciente:id_paciente,hora_vieja:hora_vieja},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        $('#editarHoraModal').modal('hide');
                        if(response.success){
                          swal({
                                      title: "Cita Actualizada por cambio de hora!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                          mostrarBusqueda();
                        
                        actualizarFechaGoogle(hora,fecha,idEventgoogle,summary,description);
                        }
                        else{
                            $('.alert-warning').html('No se pudo actualizar la cita, favor de rectificar los datos!').fadeIn().delay(1000).fadeOut('slow');
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

}







    //--------------------------------------------
    $('#showdata').on('click', '.item-id-delete', function(){
			var id_paciente = $(this).attr('data-paciente');
            var id_medico   = $(this).attr('data-medico');
            var hora        = $(this).attr('data-hora');
            var fecha       = $(this).attr('data-fecha');
            var idEventgoogle = $(this).attr('data-idGoogle');
			$('#deleteModal').modal('show');
			//prevent previous handler - unbind()
			$('#btnDelete').unbind().click(function(){
				$.ajax({
					type: 'ajax',
					method: 'get',
					async: false,
					url: '<?php echo base_url() ?>secretaria/agenda/eliminarCita',
					data:{id_paciente:id_paciente,id_medico:id_medico,hora:hora,fecha:fecha},
					dataType: 'json',
					success: function(response){
						if(response.success){
							$('#deleteModal').modal('hide');
							$('.alert-success').html('La cita ha sido eliminada con éxito!').fadeIn().delay(4000).fadeOut('slow');
							mostrarBusqueda();
						}else{
							alert('Error');
						}
                        
                        eliminarEventoGoogle(idEventgoogle);
					},
					error: function(){
						alert('Error deleting');
					}
				});
			});
		});


    //---------------------------------------------

           


    		function mostrarBusqueda(){
                var id_medico=document.getElementById("id-medico").value;
                var id_status=document.getElementById("id-estatus").value;
            
			$.ajax({
				type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>secretaria/agenda/buscarCita',
               data:{id_medico:id_medico,id_status:id_status},
               dataType: 'json',
               success: function(data){
                    //alert(data);
                    if(data==false){
                        //alert(data);
                        var html = '';
                        $('#showdata').html(html);
                            var estado;
                            if(id_status=='1'){
                                estado='APLICADA';
                            }
                            else{
                                estado='PENDIENTE';
                            }
                        $('.alert-success').html('El médico no tiene citas en estado '+estado).fadeIn().delay(1000).fadeOut('slow');
							

                    }
                    else{
                        var html = '';
                        var i;
                        html +='<table class="table table-bordered table-condensed table-responsive table table-hover" id="tabla-citas-medicas">'+
                                            '<thead>'+
                                            '<tr class="success">'+
                                                //'<th>MEDICO</th>'+
                                                '<th>PACIENTE</th>'+
                                                '<th>FECHA Y HORA</th>'+
                                                '<th>NOTA</th>'+
                                                '<th><center>ACCIONES</center></th>'+
                                            '</tr>'+
                                            '</thead>'+
                                                '<tbody>';
                                            for(i=0; i<data.length; i++){
                                                if(data[i].nota==null||data[i].nota==""){
                                                    data[i].nota="NINGUNA";
                                                }
                                                html +='<tr>'+
                                                //'<td>'+data[i].nombre_medico+'</td>'+
                                                '<td>'+data[i].nombre_paciente+' '+data[i].apellido_paciente+'</td>'+
                                                '<td>'+data[i].fecha+"  ("+data[i].hora+' HRS)</td>'+
                                                '<td>'+data[i].nota+'</td>'+
                                                '<td>'+
                                                '<center>'+
                                                    //'<a href="<?php echo base_url('secretaria/agenda/editarCita/')?>'+data[i].id_paciente+'/'+data[i].id_medico+'/'+data[i].fecha+'/'+data[i].hora+'" type="button" class="btn btn-default item-id-paciente" style="color:#29A9CC" title="Editar Cita"><i class="glyphicon glyphicon-pencil"></i></a>'+
                                                    '<div class="only-desktops" style="white-space: nowrap">'+
                                                      '<div class="btn-group">'+
                                                        '<button type="button" class="btn btn-default dropdown-toggle gc-bootstrap-dropdown" data-toggle="dropdown" style="color:#29A9CC" title="Editar Cita"><i class="glyphicon glyphicon-pencil"></i><span class="caret"></span></button>'+
                                                          '<ul class="dropdown-menu" role="menu">'+//ACTUALIZAR FECHA U HORA
                                                            '<li ><a href="javascript:void(0)"  data-paciente="'+data[i].id_paciente+'" '+'data-nombrePaciente="'+data[i].nombre_paciente+' '+data[i].apellido_paciente+'" '+'data-medico="'+data[i].id_medico+'" '+'data-idGoogle="'+data[i].idEventgoogle+'" '+'data-hora="'+data[i].hora+'" '+'data-fecha="'+data[i].fecha+'" data-nota="'+data[i].nota+'" class="item-editar-fecha"><i class="glyphicon glyphicon-calendar">  Fecha</i><span class="text-danger"></span></a></li>'+
                                                            '<li ><a href="javascript:void(0)"  data-paciente="'+data[i].id_paciente+'" '+'data-nombrePaciente="'+data[i].nombre_paciente+' '+data[i].apellido_paciente+'" '+'data-medico="'+data[i].id_medico+'" '+'data-idGoogle="'+data[i].idEventgoogle+'" '+'data-hora="'+data[i].hora+'" '+'data-fecha="'+data[i].fecha+'" data-nota="'+data[i].nota+'" class="item-editar-hora"><i class="glyphicon glyphicon-time">  Hora</i><span class="text-danger"></span></a></li>'+ 
                                                            '<li ><a href="javascript:void(0)"  data-paciente="'+data[i].id_paciente+'" '+'data-nombrePaciente="'+data[i].nombre_paciente+' '+data[i].apellido_paciente+'" '+'data-medico="'+data[i].id_medico+'" '+'data-idGoogle="'+data[i].idEventgoogle+'" '+'data-hora="'+data[i].hora+'" '+'data-fecha="'+data[i].fecha+'" data-nota="'+data[i].nota+'" class="item-editar-nota"><i class="glyphicon glyphicon-paste">  Nota</i><span class="text-danger"></span></a></li>'+ 
                                                          '</ul>'+
                                                      '</div>'+
                                                     '<div class="btn-group">'+//ELIMINAR
                                                        '<a href="javascript:;" data-paciente="'+data[i].id_paciente+'" '+'data-medico="'+data[i].id_medico+'" '+'data-idGoogle="'+data[i].idEventgoogle+'" '+'data-hora="'+data[i].hora+'" '+'data-fecha="'+data[i].fecha+'" class="btn btn-default item-id-delete" style="color:RED" title="Eliminar Cita"><i class="glyphicon glyphicon-remove"></i></a>'+
                                                     '</div>'+

                                                     
                                                     
                                                      '</div>'+
                                                '</center>'+                                                                             
                                                '</td>'+
                                                '</tr>';
                                            }
                                            html +='</tbody>'+'</table>';
                                            
                                            $('#showdata').html(html);



                                            //--CONTEMOS LAS FILAS PARA QUE APAREZCA EL SCROLL
                                            //var filas=$("#tabla-citas-medicas tr").length;
                                            //if(filas>5){

                                              //$("#tabla-general tr").css({'display':'inline-table'});
                                              //$("#estatico").css({'width':'500px',});

                                              //$("#tabla-citas-medicas").css({'overflow-y':'scroll','height':'300px','display':'block'});
                                            //}
                                              //alert("El total de filas es mayor a: "+filas);



                    }       
				},
				error: function(){
					alert('Could not get Data from Database');
				}
			});
		}

    
    
    
    
    
    
    
    var CLIENT_ID = '864684357201-vt5jg4fqhpid9enjh94gi8avtc2188tj.apps.googleusercontent.com';

// Array of API discovery doc URLs for APIs used by the quickstart
var DISCOVERY_DOCS = ["https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest"];

// Authorization scopes required by the API; multiple scopes can be
// included, separated by spaces.
var SCOPES = "https://www.googleapis.com/auth/calendar";

function actualizarFechaGoogle(hora,fecha,idEventgoogle,summary,description)
{
    var dia = fecha.split("-")[0];
    var mes = fecha.split("-")[1];
    var ano = fecha.split("-")[2];

    var nuevaFecha = ano+"-"+mes+"-"+dia;

    ////////////////sumar una hora ///////////////
    var hours = parseInt(hora.split(":")[0])+1;
    var minutes = hora.split(":")[1];
    if (hours == 24) {
        hours = 0;
    }
    var horaStrinfg = "";
    if(hours <10)
    {
        horaStrinfg = "0"+hours.toString();
    }else{
        horaStrinfg = hours.toString();
    }
    /////////////////////////////////
    var masUnahora = horaStrinfg+':'+minutes;

    var start_dateTime = nuevaFecha+'T'+hora+':00-05:00';
    var end_dateTime = nuevaFecha+'T'+masUnahora+':00-05:00';
    
    
   
    
    
    
    
    if (isSignedIn) {
            var event = {
                "summary": summary,
                "description": description,
                "start": {
                    "dateTime": start_dateTime
                    },
                "end": {
                    "dateTime": end_dateTime
                },
                      "attendees": [
                                   {"email": "lerc1991@gmail.com"}
                                   ]
            };

            var request2 = gapi.client.calendar.events.update({
                'calendarId': 'clinicadeldolor2017@gmail.com',
                'eventId' : idEventgoogle,
                'resource': event
            });

            request2.execute(function(event) {
            console.log('evento actualizado');
            });
        } else {
          alert('Inicia Sesion');
        }
}    
    
    


function eliminarEventoGoogle(idEventgoogle) {
        if (isSignedIn) {
            

            var request = gapi.client.calendar.events.delete({
              'calendarId': 'clinicadeldolor2017@gmail.com',
              'eventId' : idEventgoogle,
              'sendNotifications': true,
            });

            request.execute(function(event) {
              console.log('Eliminado');
            });
        } else {
          alert('Inicia Sesion');
        }
}


var isSignedIn;
function initClient() {
        gapi.client.init({
          discoveryDocs: DISCOVERY_DOCS,
          clientId: CLIENT_ID,
          scope: SCOPES
        }).then(function () {
          // Handle the initial sign-in state.
          isSignedIn = gapi.auth2.getAuthInstance().isSignedIn.get();
        });
      }


function handleClientLoad() {
        gapi.load('client:auth2', initClient);
      }
</script>


<!----------------------------------------------------------- -->
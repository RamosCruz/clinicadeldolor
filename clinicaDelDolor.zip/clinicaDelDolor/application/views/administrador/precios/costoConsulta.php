<hr>
<hr>
<hr>
        
        <br>
        <br>

         <div class="col-md-8  col-md-offset-2">
            
             <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Actualize el costo de consulta</h3>
              </div>

              <div class="alert alert-info alert-dismissable">
                    <p align="justify"><h3><center> El costo de la consulta actual es de $ <strong><?php echo $precioConsulta[0]->preciosDeConsulta ?></strong>.00</center></h3></p>
              </div>
              <div class="panel-body">

                <form class="form-horizontal"  id="formularioAltaDePacientes" method="post" action="<?php echo base_url('administrador/Catalogos/actualizarCostoDeConsulta');?>">
                  <div class="form-group">
                    <div class="col-md-8 col-sm-8 col-md-offset-3">

                      <div class="col-md-4 col-sm-4">
                      <label  for="nombre" class="control-label">*Costo de consulta: </label>
                      </div>
                      <div class="col-md-4 col-sm-4">
                      <input type="number" class="form-control" id="costoDeConsulta" name="costoDeConsulta" required >
                    </div>
                    </div>
                      
                    
                  </div>

                  <center>
                    <div class="form-group">
                        <button id="btn-registraPaciente" class="btn btn-primary">Actualizar costo</button>
                      
                    </div>
                  </center>
                </form>


              </div>
            </div>
          </div>



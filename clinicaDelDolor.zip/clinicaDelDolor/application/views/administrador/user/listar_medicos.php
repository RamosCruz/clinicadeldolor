<br>
<br>
<br>
<br>

<div class="container">
  <div class="col-md-offset-10">

    <form class="form"  method="post" action="<?php echo base_url('administrador/Medicos/crearNuevoMedico');?>">
      <button type="submit" class="btn btn-info" >Crear nuevo médico</button>
    </form>


  <!--<h1><?php echo lang('index_heading');?></h1>
  <p class="lead">Listado de usuarios existentes en el sistema</p>-->
  
</div>
<br>


<hr>

<div class="panel panel-primary">

 <div class="panel-heading">
  <h3 class="panel-title">Medicos</h3>
</div>
<div class="panel-body">
<div class="table-responsive">
  <div id="listaDeMedicos">

  </div>
</div>
</div>
</div>




</div>


<div id="modalEditarHonorario" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header modal-header-primary">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><img src="<?php echo base_url('assets/img/formaPagoo1.png');?>" alt="" > Editar precio de consulta</center></h2>
        
      </div>
      <div class="modal-body">
       <div class="panel panel-default">
        <div class="panel-body">

          <div class="col-md-12">
            <form class="form-horizontal" role="form">

              <div class="form-group col-md-10">
                <div class="row">
                  <div class="col-md-4">
                   <label  class="control-label">Precio de consulta</label>
                </div>
               
                <div class="col-md-6 ">
                  <input type="number" class="form-control" name ="honorario" id="honorario"
                  placeholder="precio de consulta" required>
                </div>
                </div>
                
              </div>
              <div class="col-md-2">
                <button type="submit" class="btn btn-primary" id="actualizarHonorario">Actualizar</button>
              </div>
            </form>
            
          </div>
          
        </div>
      </div>
      

    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script type="text/javascript">

//setInterval(soloNumeros,1);

/*function  soloNumeros() {
   var honorarioinput=$('#honorario').val();

   $('#honorario').val("");
   var numeros=/[0-9]$/;

    if(!numeros.test(honorarioinput)){

    }

 };*/

$('#listaDeMedicos').on('click', '.item-id-edit-costo', function(){
  var honorario = $(this).attr('honorario');
  var id_medico = $(this).attr('id-medico');

   $('#honorario').val(honorario);

$('#modalEditarHonorario').modal('show');

  $('#actualizarHonorario').unbind().click(function(){
    var honorarioinput=$('#honorario').val();
    if(honorarioinput.trim()!=""){
      $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,                
                    url: "<?php echo base_url()?>administrador/Medicos/actualizarHonorario",
                    data: {id_medico:id_medico,honorario:honorarioinput},
                    dataType: 'json',
                    success: function(response){

                        if(response){
                            swal({
                                      title: "Costo de consulta actualizado exitosamente!",
                                      type: "success",
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                          $('#modalEditarHonorario').modal('hide');
                          obtenerListaDeMedicos();
                        }
                        else{
                            swal({
                                      title: "Hubo un problema al actualizar el honorario del mèdico!",
                                      type: "warning",
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

      return false;
    }




    

  });

});

  
    obtenerListaDeMedicos();
    function obtenerListaDeMedicos()
    {
        $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>administrador/Medicos/obtenerListaDeMedicos',
               dataType: 'json',
               success: function(data){
                    //alert(data);
                    if(data==false){

                        var html = '';
                        $('#listaDeMedicos').html(html);
                    }
                    else{

                    var html ='<table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-especialidades">'+
                                            '<thead>'+
                                            '<tr>'+
                                              '<th>CURP</th>'+
                                              '<th>Nombre</th>'+
                                              '<th>Cédula</th>'+
                                              '<th>Especialidad</th>'+
                                              '<th>Correo</th>'+
                                              '<th>Télefono</th>'+
                                              '<th><center>Costo de consulta</center></th>'+
                                              '<th><center>Acciones</center></th>'+
                                            '</tr>'+
                                            '</thead>'+
                                                '<tbody>';

                                                for(i=0; i<data.length; i++){
                                                html +='<tr>'+
                                                              '<td>'+data[i].id_medico+'</td>'+
                                                              '<td>'+data[i].nombre+" "+data[i].app+" "+data[i].apm+'</td>'+
                                                              '<td>'+data[i].cedula+'</td>'+
                                                              '<td>'+data[i].especialidad+'</td>'+
                                                              '<td>'+data[i].correo_electronico+'</td>'+
                                                              '<td>'+data[i].telefono+'</td>'+
                                                              '<td><center>$'+data[i].honorario+'.00</center></td>'+
                                                              '<td>'+
                                                                '<center>'+
                                                                  '<a href="<?=base_url()?>administrador/Medicos/editar_medico/'+data[i].id_medico+'" class="btn btn-warning btn-sm glyphicon glyphicon-pencil" title="Editar datos del médico"></a>'+
                                                                  '<a href="javascript:;" honorario="'+data[i].honorario+'" '+'id-medico="'+data[i].id_medico+'"  class="btn btn-default btn-xs item-id-edit-costo" title="Actualizar costo de consulta del médico"><img src="<?php echo base_url()?>assets/img/formaPagoo1.png" alt=""></a>'+
                                                                '<center>'+
                                                              '</td>'+
                                                       '</tr>';
                                                     }





                    html +=                     '</tbody>'+
                            '</table>';
                    $('#listaDeMedicos').html(html);

 
                                             
                                          }


                },
                error: function(){
                    $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                }
            });
        }




</script>
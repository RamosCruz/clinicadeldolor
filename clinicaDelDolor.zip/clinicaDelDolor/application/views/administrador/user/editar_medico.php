<hr>
<hr>
<hr>
		<div class="col-md-12  col-md-offset-11">
         		<a href="<?php echo base_url('administrador/Medicos/listar_medicos');?>" type="button" class="btn btn-info">Regresar</a>
         </div>
         <br>
         <br>

         <div class="col-md-8  col-md-offset-2">

            
             <div class="panel panel-primary">
             <div class="panel-heading">
                <h3 class="panel-title">Editar datos del Médico</h3>
              </div>
              <div class="panel-body">



                <form class="form-horizontal" id="formularioAltaDeMedicos" method="post" action="<?php echo base_url('administrador/Medicos/actualizar_datos');?>">
                  <div class="panel panel-default">                           
                        <div class="panel-body">
                          <div class="col-sm-12">Datos generales
                          <hr style="color: #0056b2;" />
                          <!-- INICIO DE ENCAPSULACIÓN -->

                           <div class="row">


                           

                          <div class="col-md-4">
                              <div class="form-group">
                                    <div class="col-md-12">
                              <label  for="nombre" class="control-label">*Nombre</label>                                     
                              
                                <input type="text" class="form-control"  id="nombre" name="nombre" placeholder="Nombre" value="<?php echo $datosDelmedico[0]->nombre;?>" required >
                              
                            </div>
                          </div>
                          </div>



                         <div class="col-md-4">
                              <div class="form-group">
                                    <div class="col-md-12">
                                <label for="app" class="control-label">*Apellido paterno</label>
                               
                                  <input type="text" class="form-control" id="app" name="app" placeholder="Apellido paterno" value="<?php echo $datosDelmedico[0]->app;?>"required >
                                
                              </div>
                            </div>
                          </div>


                          <div class="col-md-4">
                              <div class="form-group">
                                    <div class="col-md-12">
                                <label for="apm" class="control-label">Apellido materno</label>
                                
                                  <input type="text" class="form-control" id="apm" name="apm" placeholder="Apellido materno" value="<?php echo $datosDelmedico[0]->apm;?>">
                                
                            </div>
                          </div>
                          </div>

                           </div>


                           <div class="row">

                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                                      <label for="sexo" class="control-label">*Sexo</label>
										<center>
	                                       <?php 
							                    $class = array('class' => 'sexo_paciente1');
							                    if($datosDelmedico[0]->sexo=='H')
							                    {
							                        echo '<label class="radio-inline">'.form_radio('sexo', 'H',TRUE,$class).'Hombre</label>';
							                        echo '<label class="radio-inline">'.form_radio('sexo', 'M',FALSE,$class).'Mujer</label>';
							                    }else{
							                        echo '<label class="radio-inline">'.form_radio('sexo', 'H',FALSE,$class).'Hombre</label>';
							                        echo '<label class="radio-inline">'.form_radio('sexo', 'M',TRUE,$class).'Mujer</label>'; 
							                    }
							                ?>
						               	</center>
                                    </div>
                                  </div>
                                </div>


                           <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                                    <label for="estado" class="control-label">*Estado de nacimiento</label>
                                    
                                       <select class="form-control" name="estado_nacimiento" id="estado_nacimiento" placeholder="OAXACA"  required>
                                            <option ></option>
                                            <?php foreach($estados as $value) { ?>
                                              <option value="<?php echo $value->clave_estado; ?>"><?php echo $value->estado; ?></option>
                                            <?php } ?>
                                        </select>
                              </div>
                            </div>
                          </div>


                           <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="fecha_nacimiento" class="control-label">*Fecha de nacimiento</label>
                               			<?php
				                          $date = new DateTime($datosDelmedico[0]->fecha_nace);
				                            $fecha_nacimiento = $date->format('d-m-Y');
				                        ?>
                                      <div class="input-group date  input-append" id="datetimepicker4" placeholder="12/02/1994">
                                        <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="fecha_nacimiento" id="fecha_nacimiento"  value="<?php echo $fecha_nacimiento; ?>" required><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                                      </div>
                                      
                                  <script type="text/javascript">
                                    $(function() {
                                        var today = new Date();
                                        $('#datetimepicker4').datetimepicker({
                                            pickTime: false,
                                            language: 'es-MX',
                                            endDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
                                            startDate: new Date(today.getFullYear()-90, today.getMonth(), today.getDate()),

                                        });
                                    });</script>
                                </div>
                              </div>
                          </div>

                        </div>

                         <div class="row">

                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="estado" class="control-label">*C.U.R.P.</label>
                               
                                <input type="text" class="form-control" id="curp" name="curp"  placeholder="Valide su curp" value="<?php echo $datosDelmedico[0]->id_medico;?>" required>
                              </div>
                            </div>
                          </div>

                           <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="estado" class="control-label">*C&eacute;dula de M&eacute;dico General</label>
                               
                                <input type="number" class="form-control" id="cedula" name="cedula"  value="<?php echo $datosDelmedico[0]->cedula;?>" required>
                              </div>
                            </div>
                          </div>


                           <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="estado" class="control-label">C&eacute;dula de M&eacute;dico Especialista</label>
                               
                                <input type="number" class="form-control" id="cedulae" name="cedulae"  value="<?php echo $datosDelmedico[0]->cedulae;?>" required>
                              </div>
                            </div>
                          </div>

                           
                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="estado" class="control-label">*Especialidad</label>
                              
                                 <select class="form-control" name="especialidad" id="especialidad" placeholder="GASTRENTEROLÓGO" required>
                                      <option></option>
                                      <?php foreach($especialidades as $value) { ?>
                                        <option value="<?php echo $value->id_especialidad; ?>"><?php echo $value->especialidad; ?></option>
                                      <?php } ?>
                                  </select>
                              </div>
                            </div>

                          </div>
                        </div>

                          <!-- FIN DE ENCAPSULACIÓN -->
                        </div>
                      </div>
                  </div>


                  <!--  -->
                  <!--  -->


                  <div class="panel panel-default">
                     
                    <div class="panel-body">
                      <div class="col-sm-12">Datos para contacto
                          <hr style="color: #0056b2;" />
                          <!-- INICIO DE ENCAPSULACIÓN -->

                        
                         <div class="row">

                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                            <label for="colonia" class="control-label">*Estado</label>
                          
                                
                                
                                <?php
                                    foreach($datosDelmedico as $value){    
                                        $lista = array();
                                        foreach($estados as $registro)
                                        {
                                            $lista[$registro->clave_estado] = $registro->estado;
                                        }
                                        echo form_dropdown('estado_domicilio',$lista,$value->estado,'class="form-control" required onchange="cambiarCombos(this.value);" id="estado_domicilio" style="heigth: 10px" required');
                                    }
                                   ?>
                             </div>
                          </div>
                        </div>

                         <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="localidad" class="control-label">*Municipio</label>
                              
                                
                                <?php
                                    foreach($datosDelmedico as $value){    
                                        $lista = array();
                                        foreach($selmunicipios as $registro)
                                        {
                                            $lista[$registro->clave_municipio] = $registro->nombre_municipio;
                                        }
                                        echo form_dropdown('listaDeMunicipios',$lista,$value->municipio,'id="listaDeMunicipios" class="form-control"  placeholder="Santa Cruz Xoxocotlán" onchange="cambiarCombosLocalidades(this.value);" style="heigth: 10px"required');
                                    }
                                   ?>
                              </div>
                          </div>
                        </div>

                         <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="localidad" class="control-label">*Colonia o Localidad</label>
                            
                                
                                <?php
                                    foreach($datosDelmedico as $value){    
                                        $lista = array();
                                        foreach($sellocalidades as $registro)
                                        {
                                            $lista[$registro->clave_localidad] = $registro->nombre;
                                        }
                                        echo form_dropdown('listadoDeLocalidades',$lista,$value->localidad,'id="listadoDeLocalidades" class="form-control"  placeholder="Lomas de Buenos A." required');
                                    }
                                   ?>
                              </div>
                          </div>
                        </div>

                      </div>

                      <div class="row">

                         <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="localidad" class="control-label">*Calle</label>
                              
                                <input type="text" class="form-control" placeholder="Calle y número" name="calle" id="calle" value="<?php echo $datosDelmedico[0]->calle;?>" required>
                              </div>
                          </div>
                        </div>

                        <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="localidad" class="control-label">*Correo electrónico</label>
                            
                                  <input type="email"  class="form-control" name="correo_elect" id="correo_elect" placeholder="Correo electrónico"  value="<?php echo $datosDelmedico[0]->correo_electronico;?>" required>
                              </div>
                          </div>
                        </div>

                        <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="telefono" class="control-label">*Teléfono</label>
                      
                                <input type="number" class="form-control" id="telefono"  name="telefono" placeholder="Teléfono" value="<?php echo $datosDelmedico[0]->telefono;?>" required>
                              </div>
                            </div>
                        </div>
                      </div>


                          

                        </div>
                      </div>
                  </div>

                

                  
                  <div class="form-group">
                      <div class="col-sm-2"></div>
                      <div class="col-sm-10">
                        <h5>*Campos requeridos.</h5>  
                      </div>
                  </div>

                  <div class="form-group">
                    <div class="col-md-12">
                    	<center>
                    		<button  class="btn btn-success btn-large">Guardar</button>
                    	</center>
                    </div>
                  </div>

                </form>


                  
                


              </div>
            </div>
            
         </div>
             
<!-- MODAL GENERA CURP -->
<div id="confirmarCorreoModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
        <h2><center><i class="glyphicon glyphicon-calendar"></i>CORREO ELÉCTRONICO</center></h2>
        <h8><center>Valide el correo electrónico</center></h8>
      </div>
      <div class="modal-body">
            <form class="form-horizontal" id="formularioCorreoElectronico" method="post" action="">
                
                <div class="form-group">
                                    <div class='col-sm-4'>
                                        <label  class="control-label" style="color:#336699">Correo Electrónico</label>
                                    </div>
                                    <div class="col-sm-8">
                                      <input type="email" class="form-control "  type="text" name="correo-modal" id="correo-modal"  placeholder="ejemplo@gmail.com" pattern="[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@gmail.com" required>
                                    </div>
                </div>
                <div class="form-group">
                  <div class='col-sm-6'>
                  </div>
                  <div class='col-sm-6'>
                  <button type="button" class="btn btn-default"  data-dismiss="modal">Cancelar</button>
                  <button type="submit" id="btnValidaCorreo" class="btn btn-primary">Validar Correo Electrónico</button>
                  </div>
                </div>
            </form>
      </div>
      <!--<div class="modal-footer">
        <button type="button" class="btn btn-default"  data-dismiss="modal">Cancelar</button>
        <button type="button" id="btnValidaCorreo" class="btn btn-primary">Validar Correo Electrónico</button>
      </div>-->
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script type="text/javascript">

function rellenaDatos(){
    //En esta funcion nos interesa marcar el elemento que se habia prevamente seleccionado por el usuario y es a traves de esta manera que se logra
    
    document.getElementById("estado_nacimiento").value="<?php echo $datosDelmedico[0]->estado_nace;?>";
    document.getElementById("especialidad").value     ="<?php echo $datosDelmedico[0]->especialidad;?>";

    document.getElementById("estado_domicilio").value     ="<?php echo $datosDelmedico[0]->estado;?>";
    

    

  

    //window.open("http://www.google.com/")
}

window.onload = rellenaDatos;
  
  setInterval(autocompletaNewUser, 1000);

  
function autocompletaNewUser(){
    $('#username').val($('#curp').val());
    $('#correo_elect_user').val($('#correo_elect').val());
}



     


 function InsertarNuevoUser(nombre,app,apm,telefono,identity,email){

  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,                
                    url: "<?php echo base_url() ?>Auth/crearNuevoUsuario",
                    data: {nombre:nombre,app:app,apm:apm,telefono:telefono,identity:identity,email:email},
                    dataType: 'json',
                    success: function(response){
                      //alert("Resltado de crear un nuevo Usuario"+ response);
                          
                          //alert("Usuario: ->  "+response);

                        if(response){
                          
                            InsertarNuevoMedico(response);
                        }
                        else{
                            //alert("Esta curp ya se encuentra registrada,puedes intentar modificando tus 2 ultimos numeros de aoutentificacion o bien hagaselo saber  al administrador del sistema!");
                            swal({
                                      title: "Esta CORREO ha sido registrado por un usuario anteriormete!",
                                      type: "warning",//,cambiar
                                      text: "Porfavor cambie el correo electrónico",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

  } 


function InsertarNuevoMedico(id_user){
  alert(id_user);

  var data=$('#formularioAltaDeMedicos').serialize();
  data=data+"&id_user="+id_user;


  //alert("DATOS A POST :"+data);
  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,                
                    url: "<?php echo base_url() ?>administrador/Medicos/RegistrarNuevoMedico",
                    data: data,
                    dataType: 'json',
                    success: function(response){
                      //alert("Resltado de crear un nuevo Usuario"+ response);
                          
                          

                        if(response){
                          
                            swal({
                                      title: "Médico registrado  exitosamente!",
                                      type: "success",//,cambiar
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                        else{
                            //alert("Esta curp ya se encuentra registrada,puedes intentar modificando tus 2 ultimos numeros de aoutentificacion o bien hagaselo saber  al administrador del sistema!");
                            swal({
                                      title: "Esta CORREO ha sido registrado por un usuario anteriormete!",
                                      type: "warning",//,cambiar
                                      text: "Porfavor cambie el correo electrónico",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

  } 
    

    
</script>



<script type="text/javascript">

  $('#correo_elect').click(function(){
    $('#correo-modal').val($('#correo_elect').val());

    $('#confirmarCorreoModal').modal('show');
     $('#btnValidaCorreo').unbind().click(function(){


      if($('#correo-modal').val().trim()!=""&&ValidaEmail($('#correo-modal').val().trim())){

        validaCorreoPorUser($('#correo-modal').val().trim());
        return false;
      }
                
             
               
                
    });
  });

 function validaCorreoPorUser(correo){

  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,                
                    url: "<?php echo base_url() ?>administrador/Medicos/validaCorreoUnicoEnUsers",
                    data: {correo:correo},
                    dataType: 'json',
                    success: function(response){

                        if(response){
                            validaCorreoPorMedicos(correo);
                        }
                        else{
                            //alert("Esta curp ya se encuentra registrada,puedes intentar modificando tus 2 ultimos numeros de aoutentificacion o bien hagaselo saber  al administrador del sistema!");
                            swal({
                                      title: "Esta CORREO ha sido registrado por un usuario anteriormete!",
                                      type: "warning",//,cambiar
                                      text: "Porfavor cambie el correo electrónico",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

  }

   function validaCorreoPorMedicos(correo){

  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,                
                    url: "<?php echo base_url() ?>administrador/Medicos/validaCorreoUnicoEnMedicos",
                    data: {correo:correo},
                    dataType: 'json',
                    success: function(response){

                        if(response){
                          $('#confirmarCorreoModal').modal('hide');
                          $('#correo_elect').val(correo);

                           swal({
                                      title: "Correo Validado exitosamente!",
                                      type: "success",//,cambiar
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                            
                        }
                        else{
                            //alert("Esta curp ya se encuentra registrada,puedes intentar modificando tus 2 ultimos numeros de aoutentificacion o bien hagaselo saber  al administrador del sistema!");
                            swal({
                                      title: "Esta CORREO ha sido registrado por un usuario anteriormete!",
                                      type: "warning",//,cambiar
                                      text: "Porfavor cambie el correo electrónico",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

  }




  $("#correo-modal").on('keyup', function(){
        var value = $(this).val().substring($(this).val().length-1,$(this).val().length);
        if(value.trim()=="@"){
         $('#correo-modal').val($('#correo-modal').val()+'gmail.com');

        }
  });

  function ValidaEmail(email) {
    var regex = /^([a-zA-Z0-9_])+\@gmail.com+$/;
    return regex.test(email);
  }


//------EVENTOS PARA BLOQUEAR Y DESBLOQUEAR LOS INPUTS INDICADOS
  $("#correo_elect").blur(function(){
            $(this).prop("readonly",""); 
    });

    $("#correo_elect").focus(function(){
            $(this).prop("readonly","readonly"); 
    });

</script>

<!-- MODAL GENERA CURP -->
<div id="confirmarModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
        <h2><center><i class="glyphicon glyphicon-calendar"></i>REGISTRAR CURP</center></h2>
        <h8><center>Porfavor confirme su dos ultimos dÌgitos</center></h8>
      </div>
      <div class="modal-body">
            <form class="form-horizontal" id="formularioActualizarFecha" method="post" action="">
                
                <div class="form-group">
                                    <div class='col-sm-2'>
                                        <label for="fecha-cita" class="control-label" style="color:#336699">CURP</label>
                                    </div>
                                    <div class="col-sm-10">

                                            <div class="input-group  input-append" >
                                              <input type="text" class="form-control input-append"  type="text" name="curp-modal" id="curp-modal"  min="18"  max="18" disabled required><span class="input-group-addon add-on" ><i class=""><input id="caracteres-de-validacion" name="caracteres-de-validacion" type="text" min="2"  max="2" ></i></span>
                                            </div>

                                        
                                    </div>
                                </div>
            </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default"  data-dismiss="modal">Cancelar</button>
        <button type="button" id="btnValidaCURP" class="btn btn-primary">Confirmar</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


          
<script>
//onchange="javascript:cambiarCombos(this.value);"
function cambiarCombos(dato) {
  //alert(dato);
  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>administrador/Medicos/getMunicipiosDelEstado",
                    data: {id_estado:dato},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        //$('#confirmarModal').modal('hide');
                        var html = '<option></option>';
                         $('#listaDeMunicipios').html(html);
                        

                        if(response!=false){
                        //var consola = document.getElementById("listaDeMunicipios");
                            for (var i = 0; i < response.length; i++) {
                              $('#listaDeMunicipios').append('<option value="'+response[i].clave_municipio+'">'+response[i].nombre_municipio+'</option>'); 
                              //alert(response[i].clave_municipio+" --> "+response[i].nombre_municipio);
                              //console.log("clave de estado: "+response[i].clave_estado+" clave muni: "+response[i].clave_municipio+" municipio: "+response[i].nombre);
                            }
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
  

  }

function cambiarCombosLocalidades(dato) {
  //alert(dato);
    var idEstado = $('#estado_domicilio option:selected').val();
  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>administrador/Medicos/getLocalidadesDelMunicipioDe",
                    data: {id_municipio:dato, id_estado: idEstado},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        //$('#confirmarModal').modal('hide');
                        var html = '<option></option>';
                         $('#listadoDeLocalidades').html(html);
                        

                        if(response!=false){
                        //var consola = document.getElementById("listaDeMunicipios");
                            for (var i = 0; i < response.length; i++) {
                              $('#listadoDeLocalidades').append('<option value="'+response[i].clave_municipio+'">'+response[i].nombre+'</option>'); 
                              //console.log("clave de estado: "+response[i].clave_estado+" clave muni: "+response[i].clave_municipio+" municipio: "+response[i].nombre);
                            }
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
  

  }
  
 $('#estado_nacimiento').click(function(){
   //$('select[name=dosis] option:selected').text();
  //onSelectItemEvent
 });

<!--  -->
 $('#curp').click(function(){
     
     var nombres    = $('#nombre').val();
     var apellido_p = $('#app').val();
     var apellido_m = $('#apm').val();
     var fecha_nace = $('#fecha_nacimiento').val();
     var estado     = $('#estado_nacimiento').val();
     var sexo       = $('input:radio[name=sexo]:checked').val();




    

     if(typeof(sexo) != "undefined" && nombres.trim()!="" && apellido_p.trim()!="" && fecha_nace.trim()!="" && estado.trim()!=""){
      
         var curp=generaCurpAutomatico(nombres,apellido_p,apellido_m,sexo,estado,fecha_nace);
         var curpAcotada16    = $('input[name=curp-modal]').val(curp.substring(0,16));
         var curpAcotada2    = curp.substring(16,18);
         
         $("#caracteres-de-validacion").attr("placeholder", curpAcotada2);
         
         //alert("El CURP es: "+curp.substring(0,16)+" TOTAL "+curp.substring(0,16).length);
         
         $('#confirmarModal').modal('show');    
         
         $('#btnValidaCURP').unbind().click(function(){
                var fu=$('input[name=curp-modal]').val();
                var cion=$('#caracteres-de-validacion').val().toUpperCase();
             //alert(fu+cion);
             if(cion!=""){
              var curpPost=fu+""+cion;
                //$('#confirmarModal').modal('hide');
                //var fecha = $('input[name=fecha-cita]').val();
                //validaFechaDelMedico(id_medico,id_paciente,hora,fecha_vieja,fecha);
             
               $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>administrador/Medicos/validaCURP",
                    data: {curp:curpPost},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        //$('#confirmarModal').modal('hide');

                        if(response){
                            //alert("Tu curp fue valida exitosamente!");
                            $('#confirmarModal').modal('hide');
                            
                            $('input[name=curp]').val(curpPost);
                          swal({
                                      title: "CURP validada exitosamente!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                        else{
                            //alert("Esta curp ya se encuentra registrada,puedes intentar modificando tus 2 ultimos numeros de aoutentificacion o bien hagaselo saber  al administrador del sistema!");
                            swal({
                                      title: "Esta CURP ha sido registrada anteriormete!",
                                      type: "warning",//,cambiar
                                      text: "Cambie los ultimos 2 digitos",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
             }
                
            });

     }

     
     
    
});
//------EVENTOS PARA BLOQUEAR Y DESBLOQUEAR LOS INPUTS INDICADOS
    $("#curp").blur(function(){
            $(this).prop("readonly",""); 
    });

    $("#curp").focus(function(){
            $(this).prop("readonly","readonly"); 
    });

    $('#fecha_nacimiento').blur(function(){
        $(this).prop("readonly","")
    });

    $('#fecha_nacimiento').focus(function(){
        $(this).prop("readonly","readonly")
    });
function generaCurpAutomatico(nomb,apellido_pat,apellido_mat,sex,esta,fecha){
    var esta =        digitos_estados.letrasDigitos(esta);
    var arreNumFecha= fecha.split("-");                                           //---Completo

    for(var i=0;i<arreNumFecha.length;i++){  
      arreNumFecha[i]=parseInt(arreNumFecha[i]);
    }

    var curp = generaCurp({
        nombre            : nomb,
        apellido_paterno  : apellido_pat,
        apellido_materno  : apellido_mat,
        sexo              : sex,
        estado            : esta,
        fecha_nacimiento  : arreNumFecha
      });

    return curp;
    }
</script>
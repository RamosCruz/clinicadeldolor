<hr>
<hr>
<hr>
        <div class="col-md-12">
                    <a href="<?php echo base_url('administrador/Medicos/listar_medicos');?>" type="button" class="btn btn-info">Regresar</a>
        </div>
        <br>
        <br>

         <div class="col-md-8  col-md-offset-2">
            
             <div class="panel panel-primary">
             <div class="panel-heading">
                <h3 class="panel-title">Nuevo Médico</h3>
              </div>
              <div class="alert alert-info alert-dismissable">
                    <p align="justify"><center><strong>Nota!</strong> Para el registro de un usuario médico todos los campos son requeridos (*).</center></p>
              </div>
              <div class="panel-body">

                <form  class="form-horizontal" id="formularioAltaDeMedicos" method="post" action="<?php echo base_url('administrador/Medicos/listar_medicos');?>" autocomplete="off">



                <!-- ------------------------ -->
                <div class="panel-group" id="accordion">

                  <div class="panel panel-default">
                    <div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse1">
                      <div class="col-md-offset-1">
                        <h4 style="color:#AF81C9">1. <strong style="color:#336699">Datos Generales</strong></h4>
                        
                      </div>
                    </div>
                      <div id="collapse1" class="panel-collapse collapse in">
                        <hr style="color: #0056b2;" />
                        <div class="panel-body">

                           <div class="row">


                           

                          <div class="col-md-4">
                              <div class="form-group">
                                    <div class="col-md-12">
                              <label  for="nombre" class="control-label">*Nombre</label>
                              
                                <input type="text" class="form-control"  id="nombre" name="nombre" placeholder="Nombre"  >
                              
                            </div>
                          </div>
                          </div>



                         <div class="col-md-4">
                              <div class="form-group">
                                    <div class="col-md-12">
                                <label for="app" class="control-label">*Apellido paterno</label>
                               
                                  <input type="text" class="form-control" id="app" name="app" placeholder="Apellido paterno"  >
                                
                              </div>
                            </div>
                          </div>


                          <div class="col-md-4">
                              <div class="form-group">
                                    <div class="col-md-12">
                                <label for="apm" class="control-label">Apellido materno</label>
                                
                                  <input type="text" class="form-control" id="apm" name="apm" placeholder="Apellido materno">
                                
                            </div>
                          </div>
                          </div>

                           </div>


                           <div class="row">

                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                                      <label for="sexo" class="control-label">*Sexo</label>
                                      <center>
                                        <label class="radio-inline"><input type="radio" name="sexo" class="sexo" value="H" >Hombre</label>
                                        <label class="radio-inline"><input type="radio" name="sexo" class="sexo" value="M" >Mujer</label>
                                      </center>
                                    </div>
                                  </div>
                                </div>


                           <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                                    <label for="estado" class="control-label">*Estado de nacimiento</label>
                                    
                                       <select class="form-control" name="estado_nacimiento" id="estado_nacimiento" placeholder="OAXACA" >
                                            <option></option>
                                            <?php foreach($estados as $value) { ?>
                                              <option value="<?php echo $value->clave_estado; ?>"><?php echo $value->estado; ?></option>
                                            <?php } ?>
                                        </select>
                              </div>
                            </div>
                          </div>


                           <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="fecha_nacimiento" class="control-label">*Fecha de nacimiento</label>
                                      <div class="input-group date  input-append" id="datetimepicker4" >
                                        <input type="text" class="form-control input-append"  data-format="dd-MM-yyyy" type="text" name="fecha_nacimiento" id="fecha_nacimiento"   ><span class="input-group-addon add-on"><i class="glyphicon glyphicon-calendar"></i></span>
                                      </div>
                                  <script type="text/javascript">
                                    $(function() {
                                        var today = new Date();
                                        $('#datetimepicker4').datetimepicker({
                                            pickTime: false,
                                            language: 'es-MX',
                                            endDate: new Date(today.getFullYear()-26, today.getMonth(), today.getDate()),
                                            startDate: new Date(today.getFullYear()-90, today.getMonth(), today.getDate()),

                                        });
                                    });</script>
                                </div>
                              </div>
                          </div>

                        </div>

                         <div class="row">

                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="estado" class="control-label">*C.U.R.P.</label>
                               
                                <input type="text" class="form-control" id="curp" name="curp"  placeholder="Valide su curp">
                              </div>
                            </div>
                          </div>

                           <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="estado" class="control-label">*C&eacute;dula de Medico General</label>
                               
                                <input type="number" class="form-control" id="cedula" name="cedula"  >
                              </div>
                            </div>
                          </div>

                           <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="estado" class="control-label">C&eacute;dula de Medico Especialista</label>
                               
                                <input type="number" class="form-control" id="cedulae" name="cedulae"  >
                              </div>
                            </div>
                          </div>
                           
                                <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="estado" class="control-label">*Especialidad</label>
                              
                                 <div class="input-group">
                                     <select class="form-control" name="especialidad" id="especialidad"  onchange="abrirVentanaDesplegable2(this.value);" aria-describedby="basic-addon2">
                                          
                                      </select>
                                      <span class="input-group-addon glyphicon glyphicon-plus btn-success" id="new_especialidad"></span>
                                  </div>
                                  
                              </div>
                            </div>

                          </div>
                        </div>


                        </div>
                      </div>
                  </div>

                  <div class="panel panel-default">
                          <div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse2">
                            <div class="col-md-offset-1">
                              <h4 style="color:#AF81C9">2. <strong style="color:#336699">Datos para contacto</strong></h4>
                             
                            </div>
                          </div>                 
                        <div id="collapse2" class="panel-collapse collapse">
                          <hr style="color: #0056b2;" />
                          <div class="panel-body">

                            <!-- ----------------CUERPO PARA CONTACTOS -------------------- -->

                            

                        
                         <div class="row">

                                <div class="col-md-4">

                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                            <label for="colonia" class="control-label">*Estado</label>
                          
                                <select class="form-control" name="estado_domicilio" id="estado_domicilio" placeholder="OAXACA"  onchange="cambiarCombos(this.value);" style="heigth: 10px" >
                                      <option></option>
                                      <?php foreach($estados as $value) { ?>
                                        <option value="<?php echo $value->clave_estado; ?>"><?php echo $value->estado; ?></option>
                                      <?php } ?>
                                </select>
                             </div>
                          </div>
                        </div>

                         <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="localidad" class="control-label">*Municipio</label>
                              
                                <select id="listaDeMunicipios" class="form-control" name="listaDeMunicipios" placeholder="Santa Cruz Xoxocotlán" onchange="cambiarCombosLocalidades(this.value);" style="heigth: 10px">
                                   <option></option>  
                                </select>
                              </div>
                          </div>
                        </div>

                         <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="localidad" class="control-label">*Colonia o Localidad</label>
                            
                                <select id="listadoDeLocalidades" class="form-control" name="listadoDeLocalidades"  placeholder="Lomas de Buenos A." >
                                     <option></option> 
                                </select>
                              </div>
                          </div>
                        </div>

                      </div>

                      <div class="row">

                         <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="localidad" class="control-label">*Calle</label>
                              
                                <input type="text" class="form-control" placeholder="Calle y número" name="calle" id="calle" >
                              </div>
                          </div>
                        </div>

                        <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="localidad" class="control-label">*Correo electrónico</label>
                            
                                  <input type="email"  class="form-control" name="correo_elect" id="correo_elect" placeholder="Correo electrónico" autocomplete="off" >
                              </div>
                          </div>
                        </div>

                        <div class="col-md-4">
                                  <div class="form-group">
                                    <div class="col-md-12 col-sm-12">
                              <label for="telefono" class="control-label">*Teléfono</label>
                      
                                <input type="number" class="form-control" id="telefono"  name="telefono" placeholder="Teléfono" >
                              </div>
                            </div>
                        </div>
                      </div>


                          

                        

                            <!-- ---------------------------------------------------------- -->   

                          </div>
                        </div>
                  </div>

                  <div class="panel panel-default">
                          <div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse3">
                            <div class="col-md-offset-1">
                              <h4 style="color:#AF81C9">3. <strong style="color:#336699">Costo de consulta</strong></h4>
                              
                            </div>
                          </div>
                                
                              

                            <div id="collapse3" class="panel-collapse collapse">
                              <hr style="color: #0056b2;" />
                              <div class="panel-body">
                                <!-- ----------------- CUERPO DEL PANEL---------------------- -->

                        <div class="form-group">
                          <div class="col-sm-10">
                              <label for="localidad" class="col-sm-4 control-label">*Costo de consulta</label>
                              <div class="col-sm-3">
                                  <input type="number" class="form-control" name="costoDeConsulta" id="costoDeConsulta">
                              </div>
                          </div>
                        </div>
                                <!--  -----------------------------------------------        -->
                              </div>
                            </div>
                  </div>


                  <div class="panel panel-default">
                          <div class="panel-title" data-toggle="collapse" data-parent="#accordion" href="#collapse4">
                            <div class="col-md-offset-1">
                              <h4 style="color:#AF81C9">3. <strong style="color:#336699">Datos del usuario para acceso al sistema</strong></h4>
                              
                            </div>
                          </div>
                                
                              

                            <div id="collapse4" class="panel-collapse collapse">
                              <hr style="color: #0056b2;" />
                              <div class="panel-body">
                                <!-- ----------------- CUERPO DEL PANEL---------------------- -->

                        <div class="form-group">
                          <div class="col-sm-10">
                              <label for="localidad" class="col-sm-4 control-label">*Correo electrónico</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" name="correo_elect_user" id="correo_elect_user" placeholder="Correo eléctronico" disabled >
                              </div>
                          </div>
                        </div>
                        
                        <div class="form-group">
                          <div class="col-sm-10">
                              <label for="localidad" class="col-sm-4 control-label">*Contraseña</label>
                              <div class="col-sm-8">
                                <input type="password" class="form-control"  name="password" id="password" autocomplete="off">
                              </div>
                          </div>
                        </div>


                        

                                <!--  -----------------------------------------------        -->
                              </div>
                            </div>
                  </div>
                </div>
                <!-- ------------------------ -->


                  <div class="form-group">
                    <div class="col-md-4">
                    </div>
                    <div class="col-md-4">
                      <button id="btn-registraMedico" type="submit" class="btn btn-primary btn-block">Registrar</button>
                    </div>
                     <div class="col-md-4">
                    </div>
                  </div>
                  </form>


                  
                


              </div>
            </div>
            
         </div>
             
<!-- MODAL GENERA CORREO ELECTRONICO-->
<div id="confirmarCorreoModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
        <h2><center><i class="glyphicon glyphicon-calendar"></i>CORREO ELÉCTRONICO</center></h2>
        <h8><center>Valide el correo electrónico</center></h8>
      </div>
      <div class="modal-body">
            <form class="form-horizontal" id="formularioCorreoElectronico" method="post" action="">
                
                <div class="form-group">
                                    <div class='col-sm-4'>
                                        <label  class="control-label" style="color:#336699">Correo Electrónico</label>
                                    </div>
                                    <div class="col-sm-8">
                                      <input type="email" class="form-control "  type="text" name="correo-modal" id="correo-modal"  placeholder="ejemplo@gmail.com" pattern="[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@gmail.com" required>
                                    </div>
                </div>
                <div class="form-group">
                  <div class='col-sm-6'>
                  </div>
                  <div class='col-sm-6'>
                  <button type="button" class="btn btn-default"  data-dismiss="modal">Cancelar</button>
                  <button type="submit" id="btnValidaCorreo" class="btn btn-primary">Validar Correo Electrónico</button>
                  </div>
                </div>
            </form>
      </div>
      <!--<div class="modal-footer">
        <button type="button" class="btn btn-default"  data-dismiss="modal">Cancelar</button>
        <button type="button" id="btnValidaCorreo" class="btn btn-primary">Validar Correo Electrónico</button>
      </div>-->
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script type="text/javascript">





  
  setInterval(autocompletaNewUser, 1000);
  setInterval(eliminaFechaActual,  1);

  
function autocompletaNewUser(){
    //$('#username').val($('#curp').val());
    $('#correo_elect_user').val($('#correo_elect').val());
}

function eliminaFechaActual(){
    //como verificar si los campos de un formulario estan completos??
    //aceptar puros numeros en el telefono, limitarlo a 10 numeros
 

var hoy = new Date();
var dia = hoy.getDate(); 
var mes = hoy.getMonth()+1;
var anio= hoy.getFullYear();
if(dia<10){
  dia="0"+dia+"";
}
if(mes<10){
  mes="0"+mes+"";
}
var fecha_actual = String(dia+"-"+mes+"-"+anio);
//fecha_actual = new Date(fecha_actual);

var fechaDeInput = $('#fecha_nacimiento').val();
if(fecha_actual==fechaDeInput){
  $('#fecha_nacimiento').val("");
}
//if(fechaActual==fechaDeInput){
  
//}

    
}


$('#btn-registraMedico').click(function(){
  //alert("respuesta:" +<?php  if($this->form_validation->run()===TRUE){ echo "true";}else{echo "false";} ?>);
  //if()
  //$('#formularioAltaDeMedicos')
  var nombre=$('#nombre').val();
  var app=$('#app').val();
  var apm=$('#apm').val();
  var fecha_nacimiento=$('#fecha_nacimiento').val();
  var estado_nacimiento=$('#estado_nacimiento').val();
  var sexo       = $('input:radio[name=sexo]:checked').val();
  var curp=$('#curp').val();
  var cedula=$('#cedula').val();
  var cedulae=$('#cedulae').val();
  var especialidad=$('#especialidad').val();

  var estado_domicilio=$('#estado_domicilio').val();
  var municipio_domicilio=$('#listaDeMunicipios').val(); 
  var localidad_domicilio=$('#listadoDeLocalidades').val();
  var calle=$('#calle').val();
  var correo_elect=$('#correo_elect').val();
  var telefono=$('#telefono').val();
  var contrasena=$('#password').val();

  //alert(estado_nacimiento);

  //alert("Nombre: "+nombre+" \nAPP: "+app+" \nAPM: "+apm+" \nfecha_nacimiento: "+fecha_nacimiento+"\n Estado nace: "+estado_nacimiento+"\n sexo: "+sexo+" \ncurp: "+curp+"\n cedula "+cedula+"\n especialidad "+especialidad);
  //alert("Estado domicilio: "+estado_domicilio+" \nmunicipio: "+municipio_domicilio+" \nlocalidad: "+localidad_domicilio+" \ncalle: "+calle+"\n correo: "+correo_elect+"\n telefono: "+telefono+"\n contraseña: "+contrasena);
  
  if(nombre.trim()!=""&&app.trim()!=""&&apm.trim()!=""&&fecha_nacimiento.trim()!=""&& typeof(sexo) != "undefined" &&curp.trim()!=""&&cedula.trim()!=""&&especialidad.trim()!=""&&estado_domicilio.trim()!=""&&municipio_domicilio.trim()!=""&&localidad_domicilio.trim()!=""&&calle.trim()!=""&&correo_elect.trim()!=""&&telefono.trim()!=""&&contrasena.trim()!=""){
    InsertarNuevoUser(nombre,app,apm,telefono,curp,correo_elect,contrasena);
    //location.href = '<?php echo base_url(); ?>administrador/Medicos/listar_medicos';
    
    //return false;
  }


  
});
     


 function InsertarNuevoUser(nombre,app,apm,telefono,identity,email,contrasena){

  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,                
                    url: "<?php echo base_url() ?>Auth/crearNuevoUsuario",
                    data: {nombre:nombre,app:app,apm:apm,telefono:telefono,identity:identity,email:email,contrasena:contrasena},
                    dataType: 'json',
                    success: function(response){
                      //alert("Resltado de crear un nuevo Usuario"+ response);
                          
                          //alert("Usuario: ->  "+response);

                        if(response){
                          
                            InsertarNuevoMedico(response);
                        }
                        else{
                            //alert("Esta curp ya se encuentra registrada,puedes intentar modificando tus 2 ultimos numeros de aoutentificacion o bien hagaselo saber  al administrador del sistema!");
                            swal({
                                      title: "Hubo un problema al guardar los datos!",
                                      type: "warning",//,cambiar
                                      //text: "Porfavor cambie el correo electrónico",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

  } 


function InsertarNuevoMedico(id_user){
  //alert(id_user);

  var data=$('#formularioAltaDeMedicos').serialize();
  data=data+"&id_user="+id_user;


  //alert("DATOS A POST :"+data);
  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,                
                    url: "<?php echo base_url() ?>administrador/Medicos/RegistrarNuevoMedico",
                    data: data,
                    dataType: 'json',
                    success: function(response){
                      //alert("Resltado de crear un nuevo Usuario"+ response);
                          
                          

                        if(response){
                          
                            swal({
                                      title: "Médico registrado  exitosamente!",
                                      type: "success",//,cambiar
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                        else{
                            //alert("Esta curp ya se encuentra registrada,puedes intentar modificando tus 2 ultimos numeros de aoutentificacion o bien hagaselo saber  al administrador del sistema!");
                            swal({
                                      title: "Hubo un problema al ingresar los datos!",
                                      type: "warning",//,cambiar
                                      //text: "Porfavor cambie el correo electrónico",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

  } 
    

    
</script>



<script type="text/javascript">

  $('#correo_elect').click(function(){
    $('#correo-modal').val($('#correo_elect').val());

    $('#confirmarCorreoModal').modal('show');
     $('#btnValidaCorreo').unbind().click(function(){


      if($('#correo-modal').val().trim()!=""&&ValidaEmail($('#correo-modal').val().trim())){

        validaCorreoPorUser($('#correo-modal').val().trim());
        return false;
      }
                
             
               
                
    });
  });

 function validaCorreoPorUser(correo){

  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,                
                    url: "<?php echo base_url() ?>administrador/Medicos/validaCorreoUnicoEnUsers",
                    data: {correo:correo},
                    dataType: 'json',
                    success: function(response){

                        if(response){
                            validaCorreoPorMedicos(correo);
                        }
                        else{
                            //alert("Esta curp ya se encuentra registrada,puedes intentar modificando tus 2 ultimos numeros de aoutentificacion o bien hagaselo saber  al administrador del sistema!");
                            swal({
                                      title: "Esta CORREO ha sido registrado por un usuario anteriormete!",
                                      type: "warning",//,cambiar
                                      text: "Porfavor cambie el correo electrónico",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

  }

   function validaCorreoPorMedicos(correo){

  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,                
                    url: "<?php echo base_url() ?>administrador/Medicos/validaCorreoUnicoEnMedicos",
                    data: {correo:correo},
                    dataType: 'json',
                    success: function(response){

                        if(response){
                          $('#confirmarCorreoModal').modal('hide');
                          $('#correo_elect').val(correo);

                           swal({
                                      title: "Correo Validado exitosamente!",
                                      type: "success",//,cambiar
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                            
                        }
                        else{
                            //alert("Esta curp ya se encuentra registrada,puedes intentar modificando tus 2 ultimos numeros de aoutentificacion o bien hagaselo saber  al administrador del sistema!");
                            swal({
                                      title: "Esta CORREO ha sido registrado por un usuario anteriormete!",
                                      type: "warning",//,cambiar
                                      text: "Porfavor cambie el correo electrónico",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });

  }




  $("#correo-modal").on('keyup', function(){
        var value = $(this).val().substring($(this).val().length-1,$(this).val().length);
        if(value.trim()=="@"){
         $('#correo-modal').val($('#correo-modal').val()+'gmail.com');

        }
  });

  function ValidaEmail(email) {
    var regex = /^([a-zA-Z0-9_])+\@gmail.com+$/;
    return regex.test(email);
  }


//------EVENTOS PARA BLOQUEAR Y DESBLOQUEAR LOS INPUTS INDICADOS
  $("#correo_elect").blur(function(){
            $(this).prop("readonly",""); 
    });

    $("#correo_elect").focus(function(){
            $(this).prop("readonly","readonly"); 
    });

</script>

<!-- MODAL GENERA CURP -->
<div id="confirmarModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <!--<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>-->
        <h2><center><i class="glyphicon glyphicon-calendar"></i>REGISTRAR CURP</center></h2>
        
      </div>
      <div class="modal-body">
            <form class="form-horizontal" id="formularioActualizarFecha" method="post" action="">
                
                <div class="form-group">
                                    <div class='col-sm-2'>
                                        <label for="fecha-cita" class="control-label" style="color:#336699">CURP</label>
                                    </div>
                                    <div class="col-sm-10">
                                      <div class="input-group  input-append" >
                                        <input type="text" class="form-control input-append"  type="text" name="curp-modal" id="curp-modal"  min="18"  max="18" disabled required>
                                        <span class="input-group-addon add-on" >
                                          
                                            <input id="caracteres-de-validacion" name="caracteres-de-validacion" type="text" min="2"  max="2" style="width: 40px;" required >
                                          
                                        </span>
                                      </div>

                                        
                                    </div>
                                    <div class="col-sm-12">
                                      <h4><center><strong>Por favor confirme sus 2 últimos dígitos de verificación de la curp para acompletar la acción</strong></center></h4>
                                    </div>
                                </div>
            </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default"  data-dismiss="modal">Cancelar</button>
        <button type="button" id="btnValidaCURP" class="btn btn-primary">Confirmar</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- MODAL NUEVA ESPECIALIDAD-->
<div id="nuevaEspecialidad" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-paste"></i> Registre una nueva especialidad</center></h2>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" id="formularioActualizarNota" method="post" action="">
         <div class="form-group">

          <div class="row">
            <div class='col-md-2'>
            </div>
            <div class='col-md-4'>
              <label  class="control-label" style="color:#336699">Nombre de la especialidad:</label>
            </div>
            <div class="col-md-4">
              <input type="text" class="form-control" name="registrarEspecialidad" id="registrarEspecialidad" required>

            </div>
          </div>
        </div>

        <div class="form-group">
          <div class="row">
            <div class='col-md-2'>
            </div>

            <div class='col-md-4' >

              <button type="button" class="btn btn-danger  btn-block" data-dismiss="modal">Cancelar</button>
            </div>
            <div class='col-md-4' >
              <button type="submit" id="btnNuevaEspecialidad" class="btn btn-primary btn-block">Registrar</button>
            </div>
          </div>

        </div>


      </form>
      </div>
      <div class="modal-footer">
        
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
          
<script>

getEspecialidades();

$('#btnNuevaEspecialidad').click(function(){
  //$('#nuevaEspecialidad').modal('hide');
  var new_especialidad=$('#registrarEspecialidad').val().trim().toUpperCase();;

 if(new_especialidad!=""){
   $.ajax({
                                   type: 'ajax',
                                   method: 'post',
                                   async: false,
                                   url: '<?php echo base_url() ?>administrador/Catalogos/agregarEspecialidad',
                                   data:{especialidad:new_especialidad},
                                   dataType: 'json',
                                   success: function(response){
                                     if(response){
                                         swal({
                                                        title: "Exito!",
                                                        type: "success",
                                                        title: "La especialidad ha sido registrado exitosamente!",
                                                        timer: 1800,
                                                        showConfirmButton: false
                                                    }
                                             )
                                         .catch(swal.noop);
                                         $('#registrarEspecialidad').val('');
                                         $('#nuevaEspecialidad').modal('hide');
                                         getEspecialidades();
                                         //buscarEspecialidad();
                                      }
                                      else{
                                       swal({
                                                          title: "Error!",
                                                          type: "warning",//,cambiar
                                                          text: "Revise los datos e intente de nuevo",
                                                          timer: 1800,
                                                          showConfirmButton: false
                                                      }
                                                      )
                                              .catch(swal.noop);

                                      }

                                    },
                                    error: function(){
                                        alert('Could not get Data from Database');
                                    }
                                });
return false;
 }
 $('#registrarEspecialidad').val("");
 
 


  
});

function getEspecialidades(){
  $.ajax({
                    type: 'ajax',
                    method: 'get',
                    async: false,
                    url: "<?php echo base_url() ?>administrador/Medicos/getEspecialidades",
                    //data: {id_estado:dato},
                    dataType: 'json',
                    success: function(response){
                        var html = '<option></option>';
                         $('#especialidad').html(html);
                        if(response!=false){
                            for (var i = 0; i < response.length; i++) {
                              $('#especialidad').append('<option value="'+response[i].id_especialidad+'">'+response[i].especialidad+'</option>'); 
                            }
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
}


//<option></option>
//<?php foreach($especialidades as $value) { ?>
//<option value="<?php echo $value->id_especialidad; ?>"><?php echo $value->especialidad; ?></option>
//<?php } ?>

function abrirVentanaDesplegable2(dato){
  if(dato!=""){
    $(".collapse").collapse("show");
    //limpiaCampos();
    //$("#collapse1").collapse("hide");
    //"#collapse3").collapse("show");
   // $("#collapse2").collapse('hide');
    //Podria meter una condicion que validara si los campos anteriores estan realmente rellenos
    //alert("seleccionaste algo!");
  }

};
//onchange="javascript:cambiarCombos(this.value);"
function cambiarCombos(dato) {
  //alert(dato);
  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>administrador/Medicos/getMunicipiosDelEstado",
                    data: {id_estado:dato},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        //$('#confirmarModal').modal('hide');
                        var html = '<option></option>';
                         $('#listaDeMunicipios').html(html);
                        

                        if(response!=false){
                        //var consola = document.getElementById("listaDeMunicipios");
                            for (var i = 0; i < response.length; i++) {
                              $('#listaDeMunicipios').append('<option value="'+response[i].clave_municipio+'">'+response[i].nombre_municipio+'</option>'); 
                              //alert(response[i].clave_municipio+" --> "+response[i].nombre_municipio);
                              //console.log("clave de estado: "+response[i].clave_estado+" clave muni: "+response[i].clave_municipio+" municipio: "+response[i].nombre);
                            }
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
  

  }

function cambiarCombosLocalidades(dato) {
  //alert(dato);
    var idEstado = $('#estado_domicilio option:selected').val();
  $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>administrador/Medicos/getLocalidadesDelMunicipioDe",
                    data: {id_municipio:dato, id_estado : idEstado},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        //$('#confirmarModal').modal('hide');
                        var html = '<option></option>';
                         $('#listadoDeLocalidades').html(html);
                        

                        if(response!=false){
                        //var consola = document.getElementById("listaDeMunicipios");
                            for (var i = 0; i < response.length; i++) {
                              $('#listadoDeLocalidades').append('<option value="'+response[i].clave_municipio+'">'+response[i].nombre+'</option>'); 
                              //console.log("clave de estado: "+response[i].clave_estado+" clave muni: "+response[i].clave_municipio+" municipio: "+response[i].nombre);
                            }
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
  

  }


setInterval(limitaCarateresDeConfirmacionCurp, 1);
  function limitaCarateresDeConfirmacionCurp(){
    var numDigitosVerificadores=$('#caracteres-de-validacion').val();
    $('#caracteres-de-validacion').val(numDigitosVerificadores.substring(0,2)); 
  }
  
 $('#estado_nacimiento').click(function(){
   //$('select[name=dosis] option:selected').text();
  //onSelectItemEvent
 });

<!--  -->
 $('#curp').click(function(){
     
     var nombres    = $('#nombre').val();
     var apellido_p = $('#app').val();
     var apellido_m = $('#apm').val();
     var fecha_nace = $('#fecha_nacimiento').val();
     var estado     = $('#estado_nacimiento').val();
     var sexo       = $('input:radio[name=sexo]:checked').val();




    

     if(typeof(sexo) != "undefined" && nombres.trim()!="" && apellido_p.trim()!="" && fecha_nace.trim()!="" && estado.trim()!=""){
      
         var curp=generaCurpAutomatico(nombres,apellido_p,apellido_m,sexo,estado,fecha_nace);
         var curpAcotada16    = $('input[name=curp-modal]').val(curp.substring(0,16));
         var curpAcotada2    = curp.substring(16,18);
         
         $("#caracteres-de-validacion").attr("placeholder", curpAcotada2);
         $("#caracteres-de-validacion").val(curpAcotada2);
         
         //alert("El CURP es: "+curp.substring(0,16)+" TOTAL "+curp.substring(0,16).length);
         
         $('#confirmarModal').modal('show');    
         
         $('#btnValidaCURP').unbind().click(function(){
                var fu=$('input[name=curp-modal]').val();
                var cion=$('#caracteres-de-validacion').val().toUpperCase();
             //alert(fu+cion);
             if(cion!=""&&cion.length==2){
              var curpPost=fu+""+cion;
                //$('#confirmarModal').modal('hide');
                //var fecha = $('input[name=fecha-cita]').val();
                //validaFechaDelMedico(id_medico,id_paciente,hora,fecha_vieja,fecha);
             
               $.ajax({
                    type: 'ajax',
                    method: 'post',
                    async: false,
                    url: "<?php echo base_url() ?>administrador/Medicos/validaCURP",
                    data: {curp:curpPost},
                    dataType: 'json',
                    success: function(response){
                        //alert(response.success);
                        //$('#confirmarModal').modal('hide');

                        if(response){
                            //alert("Tu curp fue valida exitosamente!");
                            $('#confirmarModal').modal('hide');
                            
                            $('input[name=curp]').val(curpPost);
                          swal({
                                      title: "CURP validada exitosamente!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                        else{
                            //alert("Esta curp ya se encuentra registrada,puedes intentar modificando tus 2 ultimos numeros de aoutentificacion o bien hagaselo saber  al administrador del sistema!");
                            swal({
                                      title: "Esta CURP ha sido registrada anteriormete!",
                                      type: "warning",//,cambiar
                                      text: "Cambie los ultimos 2 digitos",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                  }
                                  )
                          .catch(swal.noop);
                        }
                    },
                    error: function(){
                        alert('Error!');
                    }
                });
             }
                
            });

     }

     
     
    
});
//------EVENTOS PARA BLOQUEAR Y DESBLOQUEAR LOS INPUTS INDICADOS
    $("#curp").blur(function(){

            $(this).prop("readonly",""); 
    });

    $("#curp").focus(function(){
            $(this).prop("readonly","readonly"); 
    });

    $('#fecha_nacimiento').blur(function(){
        $(this).prop("readonly","")
    });

    $('#fecha_nacimiento').focus(function(){
        $(this).prop("readonly","readonly")
    });

function generaCurpAutomatico(nomb,apellido_pat,apellido_mat,sex,esta,fecha){
    var esta =        digitos_estados.letrasDigitos(esta);
    var arreNumFecha= fecha.split("-");                                           //---Completo

    for(var i=0;i<arreNumFecha.length;i++){  
      arreNumFecha[i]=parseInt(arreNumFecha[i]);
    }

    var curp = generaCurp({
        nombre            : nomb,
        apellido_paterno  : apellido_pat,
        apellido_materno  : apellido_mat,
        sexo              : sex,
        estado            : esta,
        fecha_nacimiento  : arreNumFecha
      });

    return curp;
    }

$('#new_especialidad') .click(function(){

  $('#nuevaEspecialidad').modal('show');
  
     
});
</script>

<script src="<?php echo base_url('assets/jquery-validation-1.17.0/dist/jquery.validate.js');?>"></script>

<script type="text/javascript">
$(function(){


$.validator.addMethod('telefono',function(value, element){
return this.optional(element)||/[0-9]$/.test(value); 
});

$.validator.addMethod('costoDeConsulta',function(value, element){
return this.optional(element)||/[0-9]$/.test(value); 
});

  $("#btn-registraMedico").on("click",function(){
    $("#formularioAltaDeMedicos").validate({
      rules:
      {
        nombre:{required:true,minlength:4,maxlength:30},
        app:{required:true},
        apm:{required:true},
        sexo:{required:true},
        estado_nacimiento:{required:true},
        fecha_nacimiento:{required:true},
        curp:{required:true},
        cedula:{required:true,minlength:6,maxlength:8},
        especialidad:{required:true},
        estado_domicilio:{required:true},
        listaDeMunicipios:{required:true},
        listadoDeLocalidades:{required:true},
        calle:{required:true},
        correo_elect:{required:true},
        telefono:{required:true,telefono:true,minlength:10,maxlength:20},
        password:{required:true,minlength:8,maxlength:20},
        costoDeConsulta:{required:true,minlength:3,maxlength:4}
      },
      messages:
      {
          nombre:{required:"El campo es requerido",minlength:"El número de caracteres minímo son 4",maxlength:"El número de caracteres máximo son 30"},
          app:{required:"El campo es requerido"},
          apm:{required:"El campo es requerido"},
          sexo:{required:"El campo es requerido"},
          estado_nacimiento:{required:"El campo es requerido"},
          fecha_nacimiento:{required:"El campo es requerido"},
          curp:{required:"El campo es requerido"},
          cedula:{required:"El campo es requerido",minlength:"El número de caracteres minímo son 6",maxlength:"El número de caracteres máximo son 8"},
          especialidad:{required:"El campo es requerido"},
          estado_domicilio:{required:"El campo es requerido"},
          listaDeMunicipios:{required:"El campo es requerido"},
          listadoDeLocalidades:{required:"El campo es requerido"},
          calle:{required:"El campo es requerido"},
          correo_elect:{required:"El campo es requerido"},
          telefono:{required:"El campo es requerido",telefono:"Solo se acepta valores numericos",minlength:"El número de caracteres minímo son 10",maxlength:"El número de caracteres máximo son 20"},
          password:{required:"El campo es requerido",minlength:"El número de caracteres minímo son 8",maxlength:"El número de caracteres máximo son 20"},
          costoDeConsulta: {required:"El campo es requerido",minlength:"El número de caracteres minímo son 3",maxlength:"El número de caracteres máximo son 4"}
      }

      });
  });

});
</script>

<style type="text/css">
.error{
  color: red;/*tengo que hacer que solo cambie este color del texto para que no se pinte lo demas de rojo*/
}
</style>
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
       <a href="<?php echo base_url('administrador/Home/fullCalendar');?>"><img src="<?php echo base_url('assets/img/logotipo.png');?>" alt=""> </a>
    </div>
    

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        
        <li>
          <a href="<?php echo base_url('administrador/Home/fullCalendar');?>"><img src="<?php echo base_url('assets/img/homepage.png');?>" alt="">Inicio</a>
        </li>
        
         <li>
          <a href="<?php echo base_url('Auth/listarUsuarios');?>"><img src="<?php echo base_url('assets/img/team.png');?>" alt=""> Usuarios</a>
        </li>

        <li>
          <a href="<?php echo base_url('administrador/Medicos/listar_medicos');?>"><img src="<?php echo base_url('assets/img/surgeon.png');?>" alt=""> Médicos</a>
        </li>

        

<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/medical-history.png');?>" alt=""> Listados <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('administrador/Catalogos/medicamentos'); ?>">Médicamentos</a></li>
            <li><a href="<?php echo base_url('administrador/Catalogos/especialidades'); ?>">Especialidades</a></li>
            <li><a href="<?php echo base_url('administrador/Intervenciones'); ?>">Intervensiones</a></li>
            <li><a href="<?php echo base_url('administrador/Laboratorio'); ?>">Estudios de Laboratorio</a></li>
            <li><a href="<?php echo base_url('administrador/Gabinete'); ?>">Estudios de Gabinete</a></li>

          </ul>
        </li>

      <li>
          <a href="<?php echo base_url('administrador/Home/respaldarBD');?>" title="Descargue el respaldo actual de la base de datos"><img src="<?php echo base_url('assets/img/storing.png');?>" alt=""> Respaldar B.D.</a>
        </li>
        
      </ul>
      
      
      
      <ul class="nav navbar-nav navbar-right">
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="<?php echo base_url('assets/img/users.png');?>" alt=""> <?php echo ucfirst(strtolower($this->ion_auth->user()->row()->first_name)); ?><span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo base_url('Auth/logout');?>"> Salir</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<hr>
<hr>
<div class="page-header">
</div>
<div class="container">
 <div class="row">
   <div class="col-md-12" >
     <!-- --------------ALERT------------------------- -->

     <div class="panel panel-primary class" >
      <div class="panel-heading">
        <h3 class="panel-title" >CATÁLOGO DE INTERVENCIONES</h3>
      </div>
      <div class="panel-body">

        <div class="panel panel-default">

          <div class="panel-heading">
            <h1 class="panel-title" >Nueva Intervención</h1>
          </div>

          <div class="panel-body">
           <div class="row">
            <form class="form-horizontal"  id="formularioGuardarIntervension"  method="post" action="">
              <div class="col-md-8">
               <div class="form-group">
                <div class="col-sm-2">
                  <label for="categoria" class="control-label">*Intervención</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="intervension" placeholder="Nombre de la intervención médica" name="intervension" required />
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2">
                  <label for="categoria" class="control-label">*Descripción</label>
                </div>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="sugerencia" placeholder="Describa brevemente la intervención" name="sugerencia" required />
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2">
                  <label for="categoria" class="control-label">*Costo</label>
                </div>
                <div class="col-sm-10">
                  <input type="number" class="form-control" id="costo" placeholder="Ingrese el costo de la intervención" name="costo" required />
                </div>
              </div>
              <p>*Campo requerido.</p>
            </div>

            <div class="col-md-4">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" id="btn-agregarIntervension" name="btn-agregarIntervension" class="btn btn-success btn-md btn-block"><span class="glyphicon  glyphicon-ok"></span> Agregar</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>

      <!-- -->
      <!-- <br> -->
      <!-- -->
    </div>

    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title">Lista de intervenciones</h3>
      </div>
      <div class="panel-body">
       <div class="alert alert-success" role="alert" style="display: none;">
       </div>
       <div class="alert alert-danger" role="alert" style="display: none;">
       </div>
       <div class="table-responsive">
        <table class="table table-striped">
          <thead>
            <th>Intervención</th>
            <th>Descripción</th>
            <th>Costo</th>
            <center><th>Accion</th></center>
          </thead>
          <tbody id="showdata">

          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
</div>
<!----------------------------------------- -->
</div>
</div>
</div>

<!-- ------------------------------------MODAL ELIMINAR------------------------------------ -->
<div id="deleteModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Eliminar</h4>
      </div>
      <div class="modal-body">
       Estas seguro de eliminar la intervención seleccionada?
     </div>
     <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
      <button type="button" id="btnDelete" class="btn btn-danger">Si</button>
    </div>
  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--        :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::            -->


<!-- MODAL EDITAR INTERVENCION-->
<div id="editarIntervencionModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-paste"></i> Editar intervención</center></h2>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" id="formularioActualizarNota" method="post" action="">
         <div class="form-group">
          <div class="col-sm-2">
            <label for="categoria" class="control-label">*Intervención</label>
          </div>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="editintervension" placeholder="Nombre de intervención" name="editintervension" required />
            <input type="hidden" class="form-control" id="editid"  name="editid" required />
          </div>
        </div>

        <div class="form-group">
          <div class="col-sm-2">
            <label for="categoria" class="control-label">*Descripción</label>
          </div>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="editsugerencia" placeholder="Descripción de la intervención" name="editsugerencia" required />
          </div>
        </div>

        <div class="form-group">
          <div class="col-sm-2">
            <label for="categoria" class="control-label">*Costo</label>
          </div>
          <div class="col-sm-10">
            <input type="number" class="form-control" id="editcosto" placeholder="costo de intervención" name="editcosto" required />
          </div>
        </div>

        <div class="form-group">
          <div class="col-sm-2">
            
          </div>
          <div class="col-sm-8">
            <button type="submit" id="btnActualizarIntervencion" class="btn btn-primary btn-block">Actualizar</button>
          </div>
        </div>



      </form>
    </div>
    <div class="modal-footer">
      <!--<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      <button type="button" id="btnActualizarNota" class="btn btn-primary">Actualizar</button>-->
    </div>
  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script>
window.onload = mostrarIntervensiones();


$('#btn-agregarIntervension').click(function(){
  var intervension = $('input[name=intervension]').val().toUpperCase();
  var sugerencia = $('input[name=sugerencia]').val().toUpperCase();
  var costo = $('input[name=costo]').val();

  if(intervension!="" && costo!="")
  {   

    $.ajax({
      type: 'ajax',
      method: 'post',
      async: false,
      url: '<?php echo base_url() ?>administrador/intervenciones/agregarIntervension',
      data: {intervension:intervension,sugerencia:sugerencia,costo:costo},
      dataType: 'json',
      success: function(response){
       if(response){
         swal({
          title: "Intervención agregada con éxito!",
          type: "success",
          //text: "La intervensión se añadió exitosamente!",
          timer: 1800,
          showConfirmButton: false
        }
        )
         .catch(swal.noop);
         //$('.alert-success').html('Hecho.').fadeIn().delay(2000).fadeOut('slow');
       }
       else{
         swal({
          title: "Error!",
                                      type: "warning",//,cambiar
                                      text: "No se pudo agregar la intervensión",
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                    }
                                    )
         .catch(swal.noop);

       }

     },
     error: function(){
      alert('No se pudieron obtener datos de la base de datos');
    }
  });
$('input[name=intervension]').val("");
$('input[name=sugerencia]').val("");
$('input[name=costo]').val("");
mostrarIntervensiones();
return false;
}
else
{
  $( "#formularioGuardarIntervension" ).validate({
    rules: {
      field: {
        required: true
      }
    }
  });
}

});

$('#showdata').on('click', '.item-id-edit', function(){
  var id_intervencion = $(this).attr('data-id');
  var intervencion   = $(this).attr('data-intervencion');
  var sugerencia        = $(this).attr('data-sugerencia');
  var costo       = $(this).attr('data-costo');
  $('#editarIntervencionModal').modal('show');

  $("#editintervension").val(intervencion);
  $("#editsugerencia").val(sugerencia);
  $("#editcosto").val(costo);
  $("#editid").val(id_intervencion);

  $('#btnActualizarIntervencion').unbind().click(function(){

        //Falta evaluar que los valores sean requeridos
        var inter=$("#editintervension").val();
        var sugeren=$("#editsugerencia").val();
        var cost=$("#editcosto").val();
        var id=$("#editid").val();

        inter=inter.trim();
        sugeren=sugeren.trim();
        cost=cost.trim();
        id=id.trim();

        if(inter.trim()!=""&&sugeren.trim()!=""&&cost.trim()!=""){
          $.ajax({
            type: 'ajax',
            method: 'post',
            async: false,
            url: "<?php echo base_url() ?>administrador/intervenciones/actualizarIntervecion",
            data: {id_intervencion:id,intervencion:inter,sugerencia:sugeren,costo:cost},
            dataType: 'json',
            success: function(response){
                        //alert(response.success);
                        $('#editarIntervencionModal').modal('hide');

                        if(response.success){
                          swal({
                            title: "La información de la Intervención se actualizó exitosamente!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                    }
                                    )
                          .catch(swal.noop);
                          mostrarIntervensiones();
                        }
                        else{
                          $('.alert-warning').html('No se pudo actualizar la cita, favor de rectificar los datos!').fadeIn().delay(1000).fadeOut('slow');
                        }
                      },
                      error: function(){
                        alert('Error!');
                      }
                    });

          return false;

        }
        if(inter.trim()==""){
          $("#editintervension").val("");
        }
        if(sugeren.trim()==""){
          $("#editsugerencia").val("");
        }
        if(cost.trim()==""){
          $("#editcosto").val("");
        }






});

});

<!--Eliminar intervension-->

$('#showdata').on('click', '.item-id-delete', function(){
  var id_intervension = $(this).attr('data');

  $('#deleteModal').modal('show');
      //prevent previous handler - unbind()
      $('#btnDelete').unbind().click(function(){
        $.ajax({
          type: 'ajax',
          method: 'get',
          async: false,
          url: '<?php echo base_url() ?>administrador/intervenciones/eliminarIntervencion',
          data:{id_intervension:id_intervension},
          dataType: 'json',
          success: function(response){
            if(response){
              $('#deleteModal').modal('hide');
              swal({
                title: "Intervención eliminada con éxito!",
                type: "success",
                //text: "La intervensión se añadió exitosamente!",
                timer: 1800,
                showConfirmButton: false
              }
              )
               .catch(swal.noop);

              mostrarIntervensiones();
            }else{
              alert('Error');
            }
          },
          error: function(){
            alert('Error deleting');
          }
        });
      });
    });



function mostrarIntervensiones(){

  $.ajax({
   type: 'ajax',
   method: 'post',
   async: false,
   url: '<?php echo base_url() ?>administrador/intervenciones/getIntervensiones',
   dataType: 'json',
   success: function(data){
                    //alert(data);

                    if(data==false){
                        //alert(data);
                        var html = '';
                        $('#showdata').html(html);

                        $('.alert-danger').html('El catalogo esta vacio.').fadeIn().delay(1500).fadeOut('slow');


                      }
                      else{

                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
                          html +='<tr>'+
                          '<td>'+data[i].intervension+'</td>'+
                          '<td>'+data[i].sugerencia+'</td>'+
                          '<td>'+data[i].costo+'</td>'+
                          '<td>'+
                          '<center>'+
                          '<a href="javascript:;" data-id="'+data[i].id_intervension+'" '+'data-intervencion="'+data[i].intervension+'"'+'data-sugerencia="'+data[i].sugerencia+'"'+'data-costo="'+data[i].costo+'"  class="btn btn-primary btn-xs item-id-edit" title="Eliminar"><i class="glyphicon glyphicon-pencil"></i></a>'+
                          '<a href="javascript:;" data="'+data[i].id_intervension+'"  class="btn btn-danger btn-xs item-id-delete" title="Eliminar"><i class="glyphicon glyphicon-remove"></i></a>'+
                          '<center>'+                                                                                
                          '</td>'+
                          '</tr>';
                        }

                        $('#showdata').html(html);
                      }

                    },
                    error: function(){
                      alert('Could not get Data from Database');
                    }
                  });

}
</script>
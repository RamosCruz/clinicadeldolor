<br><br><hr>
<div class="container">
    <div class="row">
        <div class="col-md-12" >
           <!--Inicio Panel 1-->
            <div class="panel panel-primary" >
                <div class="panel-heading">
                    <h3 class="panel-title" >Administrar especialidades</h3>
                </div>
                <div class="panel-body">
                    <div class="col-md-12">
                        <div class="col-md-4">
                        
                           <!--Inicio Panel 2-->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title" >Agregar</h3>
                                </div>
                                <div class="panel-body">
                                   <!--Inicio form 1 -->

                                    <form action="" method="post">
                                        <div class="form-group">
                                            <label for="nombregenerico">Nombre de la Especialidad</label>
                                            <input type="text" class="form-control" id="nombreEspecialidad" placeholder="Escriba una especialidad" required>
                                        </div>
                                        
                                        <button type="submit" id="agregarEspecialidad" class="btn btn-success control-label">Agregar</button>
                                    </form>

                                    <!--Fin form 1 -->
                                </div>
                            </div>
                            <!--Fin Panel 2-->
                            
                        </div>    
                        <div class="col-md-8">
                            <!--Inicio panel 3 -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                   
                                    <h3 class="panel-title" >Lista de especialidades</h3>
                                    
                                </div>
                                <div class="panel-body">
                                    <div class="alert alert-danger" role="alert" style="display: none;">
                                    </div>
                                    <div class="alert alert-warning" role="alert" style="display: none;">
                                    </div>
                                    <div class="table-responsive">
                                        <div id="especialidadesTabla">
                                        </div>  
                                    </div>
                                
                                </div>
                            </div>
                            <!--Fin panel 3 -->
                        </div>
                    </div>
                </div>
            </div>
            <!--Fin Panel 1-->
        </div>
    </div>
</div>




<!-- inicio modal eliminar especialidad -->

<div id="deleteEspecialidadModal" class="modal fade" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Eliminar</h4>
          </div>
          <div class="modal-body">
            Esta a punto de eliminar, ¿desea continuar?
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
            <button type="button" id="btnDelete" class="btn btn-danger">Eliminar</button>
          </div>
        </div>
      </div>
    </div>

<!-- fin modal eliminar especialidad-->


<!-- MODAL EDITAR INTERVENCION-->
<div id="editarEspecialidad" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-paste"></i> Editar especialidad médica</center></h2>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" id="formularioActualizarNota" method="post" action="">
         <div class="form-group">
          <div class="col-sm-2">
            <label for="categoria" class="control-label">*Especialidad</label>
          </div>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="edit-especialidad" placeholder="Nombre de la especialidad" name="editespecialidad" required />
            <input type="hidden" class="form-control" id="editid-especialidad"  name="editid" required />
          </div>
        </div>

        

        <div class="form-group">
          <div class="col-sm-2">
            
          </div>
          <div class="col-sm-8">
            <button type="submit" id="btnActualizarEspecialidad" class="btn btn-primary btn-block">Actualizar</button>
          </div>
        </div>



      </form>
    </div>
    <div class="modal-footer">
      <!--<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      <button type="button" id="btnActualizarNota" class="btn btn-primary">Actualizar</button>-->
    </div>
  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script>

$('#especialidadesTabla').on('click', '.item-id-edit', function(){
  var id_especialidad = $(this).attr('data-id-especialidad');
  var especialidad    = $(this).attr('data-especialidad');
  $('#editarEspecialidad').modal('show');

  $("#edit-especialidad").val(especialidad);
  $("#editid-especialidad").val(id_especialidad);

  $('#btnActualizarEspecialidad').unbind().click(function(){
    especialidad=$("#edit-especialidad").val();


  if(especialidad.trim()!=""){
          $.ajax({
            type: 'ajax',
            method: 'post',
            async: false,
            url: "<?php echo base_url() ?>administrador/Catalogos/actualizarEspecialidades",
            data: {id_especialidad:id_especialidad,especialidad:especialidad},
            dataType: 'json',
            success: function(response){
                        //alert(response.success);
                        $('#editarEspecialidad').modal('hide');

                        if(response.success){
                          swal({
                            title: "La información de la Especialidad se actualizó exitosamente!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                    }
                                    )
                          .catch(swal.noop);

                          buscarEspecialidad();
                        }
                        else{
                          $('.alert-warning').html('No se pudo actualizar la cita, favor de rectificar los datos!').fadeIn().delay(1000).fadeOut('slow');
                        }
                      },

          error: function(){
            swal(
              'Advertencia!',
              'Esta especialidad no puede ser eliminada porque es usada por un registro médico!',
              'warning'
            )
              $('#editarEspecialidad').modal('hide');
          }
                    });

          return false;

        }
        if(especialidad.trim()==""){
          $("#edit-especialidad").val("");
        }
  });

});

window.onload = buscarEspecialidad();
    
    
    
    $('#agregarEspecialidad').click(function() {
        var especialidad= $('#nombreEspecialidad').val();
        especialidad=especialidad.toUpperCase();
        if(especialidad.trim() != '')
        {
            $.ajax({
                       type: 'ajax',
                       method: 'post',
                       async: false,
                       url: '<?php echo base_url() ?>administrador/Catalogos/agregarEspecialidad',
                       data:{especialidad:especialidad},
                       dataType: 'json',
                       success: function(response){
                         if(response){
                             swal({
                                            title: "Exito!",
                                            type: "success",
                                            title: "La especialidad ha sido registrado exitosamente!",
                                            timer: 1800,
                                            showConfirmButton: false
                                        }
                                 )
                             .catch(swal.noop);
                             $('#nombreEspecialidad').val('');
                             buscarEspecialidad();
                          }
                          else{
                           swal({
                                              title: "Error!",
                                              type: "warning",//,cambiar
                                              text: "Revise los datos e intente de nuevo",
                                              timer: 1800,
                                              showConfirmButton: false
                                          }
                                          )
                                  .catch(swal.noop);

                          }

                        },
                        error: function(){
                            alert('Could not get Data from Database');
                        }
                    });
return false;
        }
    });
    
    
    function buscarEspecialidad()
    {
        $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>administrador/Catalogos/obtenerEspecialidades',
               dataType: 'json',
               success: function(data){
                    //alert(data);
                    if(data==false){

                        var html = '';
                        $('#especialidadesTabla').html(html);

                        $('.alert-warning').html('No hay especialidades!').fadeIn().delay(3000).fadeOut('slow');


                    }
                    else{

                    var html = '';
                        var i;
                        html +='<table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-especialidades">'+
                                            '<thead>'+
                                            '<tr>'+
                                                '<th>Nombre de la especialidad</th>'+
                                                '<th><center>Acciones</center></th>'+
                                            '</tr>'+
                                            '</thead>'+
                                                '<tbody>';
                                            for(i=0; i<data.length; i++){
                                                html +='<tr>'+
                                                '<td>'+data[i].especialidad+'</td>'+
                                                '<td>'+
                                                '<center>'+
                                                    '<a href="javascript:;" data-id-especialidad="'+data[i].id_especialidad+'" '+'data-especialidad="'+data[i].especialidad+'"  class="btn btn-primary btn-xs item-id-edit" title="Eliminar"><i class="glyphicon glyphicon-pencil"></i></a>'+
                                                    '<a href="javascript:;" id_especialidad="'+data[i].id_especialidad+'"  '+'class="btn btn-danger btn-xs item-id-especialidad-eliminar"  title="Eliminar"><i class="glyphicon glyphicon-trash"></i></a>'+
                                                
                                                '<center>'+
                                                '</td>'+
                                                '</tr>';
                                            }
                                            html +='</tbody>'+'</table>';

                                            $('#especialidadesTabla').html(html);

                                             //--CONTEMOS LAS FILAS PARA QUE APAREZCA EL SCROLL
                                            var filas=$("#tabla-especialidades tr").length;
                                            if(filas>5){

                                              $("#tabla-especialidades").css({'overflow-y':'scroll','height':'310px'});
                                            }
                                          }


                },
                error: function(){
                    $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                }
            });
        }
    var id_especialidad;
    $('#especialidadesTabla').on('click', '.item-id-especialidad-eliminar', function(){
        $('#deleteEspecialidadModal').modal('show');
        id_especialidad = $(this).attr('id_especialidad');
      });
    
    
    $('#btnDelete').unbind().click(function(){
        $('#deleteEspecialidadModal').modal('hide');
            $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>administrador/Catalogos/eliminarEspecialidadPorID',
               data:{id_especialidad:id_especialidad},
               dataType: 'json',
               success: function(response){
                    //alert(data);
                    if(response)
                    {
                        var html = '';
                        swal({
                            title: "Exito!",
                            type: "success",
                            title: "La especialidad se eliminó exitosamente!",
                            timer: 1800,
                            showConfirmButton: false
                            }
                         )
                        .catch(swal.noop);
                        var html = '';
                        
                        buscarEspecialidad();
                    }
                    else
                    {
                        swal({
                          title: "Error!",
                          type: "warning",
                          text: "No se pudo eliminar la especialidad",
                          timer: 1800,
                          showConfirmButton: false
                              }
                        )
                        .catch(swal.noop);
                    }
                },
                error: function(){
                    $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                }
            });
        
            $('#deleteMedicamentoModal').modal('hide');
        });

</script>
<br><br><hr>
<div class="container">
    <div class="row">
        <div class="col-md-12" >
           <!--Inicio Panel 1-->
            <div class="panel panel-primary" >
                <div class="panel-heading">
                    <h3 class="panel-title" >Administrar Estudios de Laboratorio</h3>
                </div>
                <div class="panel-body">
                    <div class="col-md-12">
                        <div class="col-md-4">
                        
                           <!--Inicio Panel 2-->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title" >Areas de Estudios de Laboratorio</h3>
                                </div>
                                <div class="panel-body">
                                   <!--Inicio form 1 -->
                                    <form action="" method="post">
                                        <div class="form-group">
                                            <label for="nombregenerico">Areas Existentes </label>
                                            <select multiple class="form-control" name="areas_laboratorio" id="areas_laboratorio">
                                                
                                            </select>
                                        </div>
                                    </form>
                                    
                                    <hr>
                                    
                                    <form action="" method="post">
                                        <div class="form-group">
                                            <label for="nombregenerico">Agregar Area</label>
                                            <input type="text" class="form-control" id="nombreAreaEstudio" placeholder="Escriba el nombre del area" required>
                                        </div>
                                        
                                        <button type="submit" id="agregarArea" class="btn btn-success control-label">Agregar</button>
                                    </form>

                                    <!--Fin form 1 -->
                                </div>
                            </div>
                            <!--Fin Panel 2-->
                            
                        </div>    
                        <div class="col-md-8">
                            <!--Inicio panel 3 -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                   
                                    <h3 class="panel-title" >Lista de estudios de laboratorio</h3>
                                    
                                </div>
                                <div class="panel-body">
                                    <div class="alert alert-danger" role="alert" style="display: none;">
                                    </div>
                                    <div class="alert alert-warning" role="alert" style="display: none;">
                                    </div>
                                    
                                    <form action="" method="post">
                                        <div class="form-group">
                                            <label for="nombregenerico">Agregar Estudio de Laboratorio en el area de <strong id="area1" style="color:RED"></strong></label>
                                            <input type="text" class="form-control" id="nombreEstudio" placeholder="Escriba el nombre del estudio" required>
                                        </div>
                                        
                                        <button type="submit" id="agregarEstudio" class="btn btn-success control-label">Agregar</button>
                                    </form>
                                    
                                    <hr>
                                    
                                    <div class="table-responsive">
                                        <div id="estudiosdeLaboratorio">
                                        </div>  
                                    </div>
                                
                                </div>
                            </div>
                            <!--Fin panel 3 -->
                        </div>
                    </div>
                </div>
            </div>
            <!--Fin Panel 1-->
        </div>
    </div>
</div>




<!-- inicio modal eliminar especialidad -->

<div id="deleteEstudioModal" class="modal fade" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Eliminar</h4>
          </div>
          <div class="modal-body">
            Esta a punto de eliminar, ¿desea continuar?
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
            <button type="button" id="btnDelete" class="btn btn-danger">Eliminar</button>
          </div>
        </div>
      </div>
    </div>

<!-- fin modal eliminar especialidad-->


<!-- MODAL EDITAR -->
<div id="editarEstudioLab" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-paste"></i> Editar estudio de Laboratorio</center></h2>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" id="formularioActualizarNota" method="post" action="">
         <div class="form-group">
          <div class="col-sm-2">
            <label for="categoria" class="control-label">*Estudio</label>
          </div>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="modal_estudios_laboratorio" placeholder="Nombre " name="modal_estudios_laboratorio" required />
            <input type="hidden" class="form-control" id="modal_id_estudios_laboratorio"  name="modal_id_estudios_laboratorio" required />
          </div>
        </div>

        

        <div class="form-group">
          <div class="col-sm-2">
            
          </div>
          <div class="col-sm-8">
            <button type="submit" id="btnActualizarEstudioLab" class="btn btn-primary btn-block">Actualizar</button>
          </div>
        </div>



      </form>
    </div>
    <div class="modal-footer">
      <!--<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      <button type="button" id="btnActualizarNota" class="btn btn-primary">Actualizar</button>-->
    </div>
  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- Fin MODAL EDITAR -->



<script>
window.onload = buscarAreasLaboratorio();
    
    /////Rellenar Areas de Estudios de Laboratorio
    function buscarAreasLaboratorio()
    {
        $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>administrador/Laboratorio/getAreasEstudio',
               dataType: 'json',
               success: function(data){
                    //alert(data);
                    if(data==false){

                        var html = '';
                        $('#estudiosdeLaboratorio').html(html);

                        $('.alert-warning').html('No hay especialidades!').fadeIn().delay(3000).fadeOut('slow');


                    }
                    else
                    {
                        for (i = 0; i < data.length; i++)
                        { 
                             $('#areas_laboratorio').append( '<option value="'+data[i].id_area_estudio_laboratorio+'">'+data[i].area_estudio+'</option>' );
                        }
                    }


                },
                error: function(){
                    $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                }
            });
        }
    var id_areas_lab;
    /////Evento para obtener el ID de las Areas de Estudios de Laboratorio
    $("#areas_laboratorio").change(function(){

        id_areas_lab = ""+$(this).val();
        var area1 = $("#areas_laboratorio option[value='"+id_areas_lab+"']").text();
        $('#area1').html(area1);
        estudioDeLaboratorio(id_areas_lab);
    });
    
    
    /////Llenar tabla de estudios de laboratorio
    
    
    function estudioDeLaboratorio(id_areas_lab)
    {
        $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>administrador/Laboratorio/getEstudiosDeLaboratorio',
               data: {id_area_estudio_laboratorio:id_areas_lab},
               dataType: 'json',
               success: function(data){
                    //alert(data);
                    if(data==false){

                        var html = '';
                        $('#estudiosdeLaboratorio').html(html);

                        $('.alert-warning').html('No hay estudios de laboratorio!').fadeIn().delay(3000).fadeOut('slow');


                    }
                    else{
                    var html = '';
                        var i;
                        html +='<table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-estudios">'+
                                            '<thead>'+
                                            '<tr>'+
                                                '<th>Nombre del estudio de lab</th>'+
                                                '<th><center>Acciones</center></th>'+
                                            '</tr>'+
                                            '</thead>'+
                                                '<tbody>';
                                            for(i=0; i<data.length; i++){
                                                html +='<tr>'+
                                                '<td>'+data[i].estudios_laboratorio+'</td>'+
                                                '<td>'+
                                                '<center>'+
                                                    '<a href="javascript:;" id_estudios_laboratorio="'+data[i].id_estudios_laboratorio+'" '+'estudios_laboratorio="'+data[i].estudios_laboratorio+'"  class="btn btn-default item-id-edit" style="color:green" title="Editar"><i class="glyphicon glyphicon-pencil"></i></a>'+
                                                    '<a href="javascript:;" id_estudios_laboratorio="'+data[i].id_estudios_laboratorio+'"  '+'class="btn btn-default item-id-estudio-eliminar" style="color:#FE001A" title="Eliminar"><i class="glyphicon glyphicon-trash"></i></a>'+
                                                '<center>'+
                                                '</td>'+
                                                '</tr>';
                                            }
                                            html +='</tbody>'+'</table>';

                                            $('#estudiosdeLaboratorio').html(html);

                                             //--CONTEMOS LAS FILAS PARA QUE APAREZCA EL SCROLL
                                            var filas=$("#tabla-estudios tr").length;
                                            if(filas>5){

                                              $("#tabla-estudios").css({'overflow-y':'scroll','height':'310px'});
                                            }
                                          }


                },
                error: function(error){
                    $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                    console.log(error.responseText);
                }
            });
        }
    
    
    
    $('#agregarArea').click(function() {
        var area_estudio= $('#nombreAreaEstudio').val();
        if(area_estudio.trim() != '')
        {
            $.ajax({
                       type: 'ajax',
                       method: 'post',
                       async: false,
                       url: '<?php echo base_url() ?>administrador/Laboratorio/agregarAreaEstudio',
                       data:{area_estudio:area_estudio},
                       dataType: 'json',
                       success: function(response){
                         if(response){
                             swal({
                                            title: "Exito!",
                                            type: "success",
                                            title: "La area de estudio ha sido registrado exitosamente!",
                                            timer: 1800,
                                            showConfirmButton: false
                                        }
                                 )
                             .catch(swal.noop);
                             $('#nombreAreaEstudio').val('');
                             buscarAreasLaboratorio();
                          }
                          else{
                           swal({
                                              title: "Error!",
                                              type: "warning",//,cambiar
                                              text: "Revise los datos e intente de nuevo",
                                              timer: 1800,
                                              showConfirmButton: false
                                          }
                                          )
                                  .catch(swal.noop);

                          }

                        },
                        error: function(){
                            alert('Could not get Data from Database');
                        }
                    });
        }
    });
    
    
    var id_estudios_laboratorio;
    $('#estudiosdeLaboratorio').on('click', '.item-id-estudio-eliminar', function(){
        $('#deleteEstudioModal').modal('show');
        id_estudios_laboratorio = $(this).attr('id_estudios_laboratorio');
      });
    
    
    $('#btnDelete').unbind().click(function(){
        $('#deleteEstudioModal').modal('hide');
            $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>administrador/Laboratorio/eliminarEstudioPorID',
               data:{id_estudios_laboratorio:id_estudios_laboratorio},
               dataType: 'json',
               success: function(response){
                    //alert(data);
                    if(response)
                    {
                        var html = '';
                        swal({
                            title: "Exito!",
                            type: "success",
                            title: "La especialidad se elimino exitosamente!",
                            timer: 1800,
                            showConfirmButton: false
                            }
                         )
                        .catch(swal.noop);
                        var html = '';
                        
                        estudioDeLaboratorio(id_areas_lab);
                    }
                    else
                    {
                        swal({
                          title: "Error!",
                          type: "warning",
                          text: "No se pudo eliminar la especialidad",
                          timer: 1800,
                          showConfirmButton: false
                              }
                        )
                        .catch(swal.noop);
                    }
                },
                error: function(){
                    $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                }
            });
        
            $('#deleteEstudioModal').modal('hide');
        });
    
$('#estudiosdeLaboratorio').on('click', '.item-id-edit', function(){
  var id_estudios_laboratorio = $(this).attr('id_estudios_laboratorio');
  var estudios_laboratorio    = $(this).attr('estudios_laboratorio');
  
  $('#editarEstudioLab').modal('show');
  $("#modal_id_estudios_laboratorio").val(id_estudios_laboratorio);
  $("#modal_estudios_laboratorio").val(estudios_laboratorio);

  $('#btnActualizarEstudioLab').unbind().click(function(){
    estudios_laboratorio=$("#modal_estudios_laboratorio").val();


  if(estudios_laboratorio.trim()!=""){
          $.ajax({
            type: 'ajax',
            method: 'post',
            async: false,
            url: "<?php echo base_url() ?>administrador/Catalogos/actualizarEstudioLab",
            data: {id_estudios_laboratorio:id_estudios_laboratorio,estudios_laboratorio:estudios_laboratorio},
            dataType: 'json',
            success: function(response){
                        //alert(response.success);
                        $('#editarEstudioLab').modal('hide');

                        if(response.success){
                          swal({
                            title: "La información del estudio se actualizó exitosamente!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                    }
                                    )
                          .catch(swal.noop);

                          estudioDeLaboratorio(id_areas_lab);
                        }
                        else{
                          $('.alert-warning').html('Intente de nuevo!').fadeIn().delay(1000).fadeOut('slow');
                        }
                      },

          error: function(error){
              console.log(error);
            swal(
              'Advertencia!',
              'No se pudo realizar la edicion, intente de nuevo!\n '+error.responseText,
                
              'warning'
            )
              $('#editarEstudioLab').modal('hide');
          }
                    });

          return false;

        }
        if(estudios_laboratorio.trim()==""){
          $("#modal_estudios_laboratorio").val("");
        }
  });

});
    
    
    $('#agregarEstudio').click(function() {
        var nombreEstudio= $('#nombreEstudio').val().toUpperCase();
        if(!id_areas_lab=='')
        {
            if(nombreEstudio.trim() != '')
            {
                $.ajax({
                           type: 'ajax',
                           method: 'post',
                           async: false,
                           url: '<?php echo base_url() ?>administrador/Laboratorio/agregarEstudio',
                           data:{id_area_estudio_laboratorio:id_areas_lab,estudios_laboratorio:nombreEstudio},
                           dataType: 'json',
                           success: function(response){
                             if(response){
                                 swal({
                                                title: "Exito!",
                                                type: "success",
                                                title: "El estudio ha sido registrado exitosamente!",
                                                timer: 1800,
                                                showConfirmButton: false
                                            }
                                     )
                                 .catch(swal.noop);
                                 $('#nombreAreaEstudio').val('');
                                 estudioDeLaboratorio(id_areas_lab);
                              }
                              else{
                               swal({
                                                  title: "Error!",
                                                  type: "warning",//,cambiar
                                                  text: "Revise los datos e intente de nuevo",
                                                  timer: 1800,
                                                  showConfirmButton: false
                                              }
                                              )
                                      .catch(swal.noop);

                              }

                            },
                            error: function(){
                                alert('Could not get Data from Database');
                            }
                        });
            }
        }else
        {
            swal({
                                                  title: "Error!",
                                                  type: "warning",//,cambiar
                                                  text: "Seleccione un area de especialidad",
                                                  timer: 1800,
                                                  showConfirmButton: false
                                              }
                                              )
                                      .catch(swal.noop);
        }
    });

</script>
<br><br><hr>
<div class="container">
    <div class="row">
        <div class="col-md-12" >
           <!--Inicio Panel 1-->
            <div class="panel panel-primary" >
                <div class="panel-heading">
                    <h3 class="panel-title" >Administrar Estudios de Gabinete</h3>
                </div>
                <div class="panel-body">
                    <div class="col-md-12">
                        <div class="col-md-4">
                        
                           <!--Inicio Panel 2-->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title" >Areas de Estudios de Gabinete</h3>
                                </div>
                                <div class="panel-body">
                                   <!--Inicio form 1 -->
                                    
                                    
                                    <form action="" method="post">
                                        <div class="form-group">
                                            <label for="nombregenerico">Agregar Estudio</label>
                                            <input type="text" class="form-control" id="nombreGabinete" placeholder="Escriba el nombre del estudio" required>
                                        </div>
                                        
                                        <button type="submit" id="agregarGabinete" class="btn btn-success control-label">Agregar</button>
                                    </form>

                                    <!--Fin form 1 -->
                                </div>
                            </div>
                            <!--Fin Panel 2-->
                            
                        </div>    
                        <div class="col-md-8">
                            <!--Inicio panel 3 -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                   
                                    <h3 class="panel-title" >Lista de estudios de laboratorio</h3>
                                    
                                </div>
                                <div class="panel-body">
                                    <div class="alert alert-danger" role="alert" style="display: none;">
                                    </div>
                                    <div class="alert alert-warning" role="alert" style="display: none;">
                                    </div>
                                    
                                    
                                    <div class="table-responsive">
                                        <div id="estudiosTabla">
                                        </div>  
                                    </div>
                                
                                </div>
                            </div>
                            <!--Fin panel 3 -->
                        </div>
                    </div>
                </div>
            </div>
            <!--Fin Panel 1-->
        </div>
    </div>
</div>




<!-- inicio modal eliminar especialidad -->

<div id="deleteEstudioModal" class="modal fade" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Eliminar</h4>
          </div>
          <div class="modal-body">
            Esta a punto de eliminar, ¿desea continuar?
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
            <button type="button" id="btnDelete" class="btn btn-danger">Eliminar</button>
          </div>
        </div>
      </div>
    </div>

<!-- fin modal eliminar especialidad-->

<!-- MODAL EDITAR -->
<div id="editarEstudioGab" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-paste"></i> Editar estudio de Laboratorio</center></h2>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" id="formularioActualizarNota" method="post" action="">
         <div class="form-group">
          <div class="col-sm-2">
            <label for="categoria" class="control-label">*Estudio</label>
          </div>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="modal_estudios_de_gabinete" placeholder="Nombre " name="modal_estudios_de_gabinete" required />
            <input type="hidden" class="form-control" id="modal_id_estudios_de_gabinete"  name="modal_id_estudios_de_gabinete" required />
          </div>
        </div>

        

        <div class="form-group">
          <div class="col-sm-2">
            
          </div>
          <div class="col-sm-8">
            <button type="submit" id="btnActualizarEstudioGab" class="btn btn-primary btn-block">Actualizar</button>
          </div>
        </div>



      </form>
    </div>
    <div class="modal-footer">
      <!--<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      <button type="button" id="btnActualizarNota" class="btn btn-primary">Actualizar</button>-->
    </div>
  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- Fin MODAL EDITAR -->


<script>
window.onload = estudioDeGabinete();
    
    
    
    
    function estudioDeGabinete()
    {
        $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>administrador/Gabinete/getEstudiosDeGabinete',
               dataType: 'json',
               success: function(data){
                    //alert(data);
                    if(data==false){

                        var html = '';
                        $('#estudiosTabla').html(html);

                        $('.alert-warning').html('No hay estudios de laboratorio!').fadeIn().delay(3000).fadeOut('slow');


                    }
                    else{
                    var html = '';
                        var i;
                        html +='<table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-estudios">'+
                                            '<thead>'+
                                            '<tr>'+
                                                '<th>Nombre del estudio de lab</th>'+
                                                '<th><center>Acciones</center></th>'+
                                            '</tr>'+
                                            '</thead>'+
                                                '<tbody>';
                                            for(i=0; i<data.length; i++){
                                                html +='<tr>'+
                                                '<td>'+data[i].estudios_de_gabinete+'</td>'+
                                                '<td>'+
                                                '<center>'+
                                                    '<a href="javascript:;" id_estudios_de_gabinete="'+data[i].id_estudios_de_gabinete+'" '+'estudios_de_gabinete="'+data[i].estudios_de_gabinete+'"  class="btn btn-default item-id-edit" style="color:green" title="Editar"><i class="glyphicon glyphicon-pencil"></i></a>'+
                                                    '<a href="javascript:;" id_estudios_de_gabinete="'+data[i].id_estudios_de_gabinete+'"  '+'class="btn btn-default item-id-estudio-eliminar" style="color:#FE001A" title="Eliminar"><i class="glyphicon glyphicon-trash"></i></a>'+
                                                '<center>'+
                                                '</td>'+
                                                '</tr>';
                                            }
                                            html +='</tbody>'+'</table>';

                                            $('#estudiosTabla').html(html);

                                             //--CONTEMOS LAS FILAS PARA QUE APAREZCA EL SCROLL
                                            var filas=$("#tabla-estudios tr").length;
                                            if(filas>5){

                                              $("#tabla-estudios").css({'overflow-y':'scroll','height':'310px'});
                                            }
                                          }


                },
                error: function(error){
                    $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                    console.log(error.responseText);
                }
            });
        }
    
    
    
 
    
    var id_estudios_de_gabinete;
    $('#estudiosTabla').on('click', '.item-id-estudio-eliminar', function(){
        $('#deleteEstudioModal').modal('show');
        id_estudios_de_gabinete = ""+$(this).attr('id_estudios_de_gabinete');
      });
    
    
    $('#btnDelete').unbind().click(function(){
        $('#deleteEstudioModal').modal('hide');
            $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>administrador/Gabinete/eliminarEstudioPorID',
               data:{id_estudios_de_gabinete:id_estudios_de_gabinete},
               dataType: 'json',
               success: function(response){
                    //alert(data);
                    if(response)
                    {
                        var html = '';
                        swal({
                            title: "Exito!",
                            type: "success",
                            title: "La especialidad se elimino exitosamente!",
                            timer: 1800,
                            showConfirmButton: false
                            }
                         )
                        .catch(swal.noop);
                        var html = '';
                        
                        estudioDeGabinete();
                    }
                    else
                    {
                        swal({
                          title: "Error!",
                          type: "warning",
                          text: "No se pudo eliminar la especialidad",
                          timer: 1800,
                          showConfirmButton: false
                              }
                        )
                        .catch(swal.noop);
                    }
                },
                error: function(error){
                    $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                    console.log(error);
                }
            });
        
            
        });
    
    
    $('#agregarGabinete').click(function() {
        var nombreGabinete= $('#nombreGabinete').val().toUpperCase();
        
            if(nombreGabinete.trim() != '')
            {
                $.ajax({
                           type: 'ajax',
                           method: 'post',
                           async: false,
                           url: '<?php echo base_url() ?>administrador/Gabinete/agregarEstudio',
                           data:{estudios_de_gabinete:nombreGabinete},
                           dataType: 'json',
                           success: function(response){
                             if(response){
                                 swal({
                                                title: "Exito!",
                                                type: "success",
                                                title: "El estudio ha sido registrado exitosamente!",
                                                timer: 1800,
                                                showConfirmButton: false
                                            }
                                     )
                                 .catch(swal.noop);
                                 $('#nombreAreaEstudio').val('');
                                 estudioDeGabinete();
                              }
                              else{
                               swal({
                                                  title: "Error!",
                                                  type: "warning",//,cambiar
                                                  text: "Revise los datos e intente de nuevo",
                                                  timer: 1800,
                                                  showConfirmButton: false
                                              }
                                              )
                                      .catch(swal.noop);

                              }

                            },
                            error: function(error){
                                $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                                alert(error.responseText);
                            }
                        });
            }
        
    });
    
$('#estudiosTabla').on('click', '.item-id-edit', function(){
  var id_estudios_de_gabinete = $(this).attr('id_estudios_de_gabinete');
  var estudios_de_gabinete    = $(this).attr('estudios_de_gabinete');
  
  $('#editarEstudioGab').modal('show');
  $("#modal_id_estudios_de_gabinete").val(id_estudios_de_gabinete);
  $("#modal_estudios_de_gabinete").val(estudios_de_gabinete);

  $('#btnActualizarEstudioGab').unbind().click(function(){
    estudios_de_gabinete=$("#modal_estudios_de_gabinete").val();


  if(estudios_de_gabinete.trim()!=""){
          $.ajax({
            type: 'ajax',
            method: 'post',
            async: false,
            url: "<?php echo base_url() ?>administrador/Catalogos/actualizarEstudioGab",
            data: {id_estudios_de_gabinete:id_estudios_de_gabinete,estudios_de_gabinete:estudios_de_gabinete},
            dataType: 'json',
            success: function(response){
                        //alert(response.success);
                        $('#editarEstudioGab').modal('hide');

                        if(response.success){
                          swal({
                            title: "La información del estudio se actualizó exitosamente!",
                                      type: "success",//,
                                      //allowOutsideClick:false
                                      timer: 1800,
                                      showConfirmButton: false
                                    }
                                    )
                          .catch(swal.noop);

                          estudioDeGabinete();
                        }
                        else{
                          $('.alert-warning').html('Intente de nuevo!').fadeIn().delay(1000).fadeOut('slow');
                        }
                      },

          error: function(error){
            swal(
              'Advertencia!',
              'No se pudo realizar la edicion, intente de nuevo!\n '+error.responseText,
                
              'warning'
            )
              $('#editarEstudioGab').modal('hide');
          }
                    });

          return false;

        }
        if(estudios_de_gabinete.trim()==""){
          $("#modal_estudios_de_gabinete").val("");
        }
  });

});
    


</script>
<br><br><hr>
<div class="container">
    <div class="row">
        <div class="col-md-12" >
           <!--Inicio Panel 1-->
            <div class="panel panel-primary" >
                <div class="panel-heading">
                    <h3 class="panel-title" >Administrar medicamentos</h3>
                </div>
                <div class="panel-body">
                   <p>* Manipular el catálogo de medicamentos es importante para que el sistema funcione correctamente, por favor rellene todos los campos.</p>
                    <div class="col-md-12">
                        <div class="col-md-4">
                        
                           <!--Inicio Panel 2-->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title" >Agregar</h3>
                                </div>
                                <div class="panel-body">
                                   <!--Inicio form 1 -->

                                    <form action="" method="post">
                                        <div class="form-group">
                                            <label for="nombregenerico">*Nombre generico</label>
                                            <input type="text" class="form-control" id="nombregenerico" placeholder="Ibuprofeno" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="formafarmaceutica">*Forma farmaceutica</label>
                                            <input type="text" class="form-control" id="formafarmaceutica" placeholder="Tableta" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="concentracion">*Concentración</label>
                                            <input type="text" class="form-control" id="concentracion" placeholder="400 mg" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="presentacion">*Presentación</label>
                                            <input type="text" class="form-control" id="presentacion" placeholder="Envase con 12 tabletas." required>
                                        </div>
                                        <button type="submit" id="agregarMedicamento" class="btn btn-success control-label">Agregar</button>
                                    </form>

                                    <!--Fin form 1 -->
                                </div>
                            </div>
                            <!--Fin Panel 2-->
                            
                        </div>    
                        <div class="col-md-8">
                            <!--Inicio panel 3 -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                   
                                    <h3 class="panel-title" >Lista de medicamentos</h3>
                                    <div class="input-group">
                                        <input id="texto_buscar" type="text" class="form-control" placeholder="Buscar por nombre generico">
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" type="button" id="buscar"><span class="glyphicon glyphicon-search"></span></button>
                                        </span>
                                    </div>
                                    
                                </div>
                                <div class="panel-body">
                                    <div class="alert alert-danger" role="alert" style="display: none;">
                                    </div>
                                    <div class="alert alert-warning" role="alert" style="display: none;">
                                    </div>
                                    <div class="table-responsive">
                                        <div id="medicamentosTabla">
                                        </div>  
                                    </div>
                                
                                </div>
                            </div>
                            <!--Fin panel 3 -->
                        </div>
                    </div>
                </div>
            </div>
            <!--Fin Panel 1-->
        </div>
    </div>
</div>



<!-- inicio modal eliminar medicamento -->

<div id="deleteMedicamentoModal" class="modal fade" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Eliminar</h4>
          </div>
          <div class="modal-body">
            Estas seguro de eliminar el medicamento de su base de datos?
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
            <button type="button" id="btnDelete" class="btn btn-danger">Eliminar</button>
          </div>
        </div>
      </div>
    </div>

<!-- fin modal eliminar medicamento-->


<!-- inicio modal editar medicamento -->




    <div id="editMedicamentoModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header  modal-header-success">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2><center><i class="glyphicon glyphicon-paste"></i> Editar medicamento</center></h2>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" id="formularioActualizarNota" method="post" action="">
         <div class="form-group">
          <div class="col-sm-2">
            <label for="categoria" class="control-label">*Nombre genérico</label>
          </div>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="nombregenerico1" placeholder="Nombre genérico" name="editespecialidad" required />
            
          </div>
        </div>

        <div class="form-group">
          <div class="col-sm-2">
            <label for="categoria" class="control-label">*Forma farmacéutica</label>
          </div>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="formafarmaceutica1" placeholder="Forma formacéutica" name="editespecialidad" required />

          </div>
        </div>

        <div class="form-group">
          <div class="col-sm-2">
            <label for="categoria" class="control-label">*Concentración</label>
          </div>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="concentracion1" placeholder="Concentración" name="editespecialidad" required />
           
          </div>
        </div>

        <div class="form-group">
          <div class="col-sm-2">
            <label for="categoria" class="control-label">*Presentación</label>
          </div>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="presentacion1" placeholder="Presentación" name="editespecialidad" required />
         
          </div>
        </div>

        

        <div class="form-group">
          <div class="col-sm-2">
            
          </div>
          <div class="col-sm-8">
            <button type="submit" id="btnEdit" class="btn btn-primary btn-block">Actualizar</button>
          </div>
        </div>



      </form>
    </div>
    <div class="modal-footer">
      <!--<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      <button type="button" id="btnActualizarNota" class="btn btn-primary">Actualizar</button>-->
    </div>
  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- fin modal editar medicamento-->






<script>


var options = {
      url: "<?php echo base_url('administrador/Catalogos/getGenericos');?>",

      getValue: "nombre_generico",
      placeholder: "Escriba el nombre de un medicamento o genérico",
      theme: "bootstrap",

      template: {
        type: "custom",

        method:function(value,item){
          var forma="";
          var concentra="";
          if(item.forma_farmaceutica.length>20){
            forma=item.forma_farmaceutica.substring(0,20)+" ...";

          }
          else{
            forma=item.forma_farmaceutica
          }

          if(item.concentracion.length>20){
            concentra=item.concentracion.substring(0,20)+" ...";

          }
          else{
            concentra=item.concentracion
          }


          return item.nombre_generico+" - "+forma+" ("+concentra+")";
        }
      },


      list: {
       
        //maxNumberOfElements: 7,
        match: {
          enabled: true
        },
        onSelectItemEvent: function() {
          var texto_buscar = $('#texto_buscar').val();
        buscarMedicamento(texto_buscar);
        }

      }
    };
    

    //LISTA DE EVENTOS
    $("#texto_buscar").easyAutocomplete(options);





    $('#buscar').click(function() {
        var texto_buscar = $('#texto_buscar').val();
        buscarMedicamento(texto_buscar);
    });
    
    $('#agregarMedicamento').click(function() {
        var nombre_generico= $('#nombregenerico').val();
        var forma_farmaceutica = $('#formafarmaceutica').val();
        var concentracion = $('#concentracion').val();
        var presentacion = $('#presentacion').val();
        
        if(nombre_generico != '' && forma_farmaceutica != '' && concentracion != '' && presentacion != '')
        {
            $.ajax({
                       type: 'ajax',
                       method: 'post',
                       async: false,
                       url: '<?php echo base_url() ?>administrador/Catalogos/agregarMedicamento',
                       data:{nombre_generico:nombre_generico,forma_farmaceutica:forma_farmaceutica,concentracion:concentracion,presentacion:presentacion},
                       dataType: 'json',
                       success: function(response){
                         if(response){
                             swal({
                                            title: "Exito!",
                                            type: "success",
                                            title: "El medicamento ha sido registrado exitosamente!",
                                            timer: 1800,
                                            showConfirmButton: false
                                        }
                                 )
                             .catch(swal.noop);
                             $('#nombregenerico').val('');
                            $('#formafarmaceutica').val('');
                            $('#concentracion').val('');
                            $('#presentacion').val('');

                          }
                          else{
                           swal({
                                              title: "Error!",
                                              type: "warning",//,cambiar
                                              text: "Revise los datos e intente de nuevo",
                                              timer: 1800,
                                              showConfirmButton: false
                                          }
                                          )
                                  .catch(swal.noop);

                          }

                        },
                        error: function(){
                            alert('Could not get Data from Database');
                        }
                    });
return false;
        }else
        {
        }
    });
    
    
    function buscarMedicamento(texto_buscar)
    {
        $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>administrador/Catalogos/obtenerMedicamentosPorNombre',
               data:{texto_buscar:texto_buscar},
               dataType: 'json',
               success: function(data){
                    //alert(data);
                    if(data==false){

                        var html = '';
                        $('#medicamentosTabla').html(html);

                        $('.alert-warning').html('No existe este medicamentos, intente con otro!').fadeIn().delay(3000).fadeOut('slow');


                    }
                    else{

                    var html = '';
                        var i;
                        html +='<table class="table table-condensed table-bordered table-responsive table table-hover" id="tabla-medicamentos">'+
                                            '<thead>'+
                                            '<tr>'+
                                                '<th>Nombre generico</th>'+
                                                '<th>Forma farmaceutica</th>'+
                                                '<th>Concentración</th>'+
                                                '<th>Presentación</th>'+
                                                '<th><center>Acciones</center></th>'+
                                            '</tr>'+
                                            '</thead>'+
                                                '<tbody>';
                                            for(i=0; i<data.length; i++){
                                                html +='<tr>'+
                                                '<td>'+data[i].nombre_generico+'</td>'+
                                                '<td>'+data[i].forma_farmaceutica+'</td>'+
                                                '<td>'+data[i].concentracion+'</td>'+
                                                '<td>'+data[i].presentacion+'</td>'+
                                                '<td>'+
                                                '<center>'+
                                                    '<a href="javascript:;" id_medicamento="'+data[i].id_medicamento+'"  '+'class="btn btn-default item-id-medicamento-eliminar" style="color:#FE001A" title="Eliminar"><i class="glyphicon glyphicon-trash"></i></a>'+
                                                '<center>'+
                                                '<center>'+
                                                    '<a href="javascript:;" id_medicamento="'+data[i].id_medicamento+'" nombre_generico="'+data[i].nombre_generico+'"forma_farmaceutica="'+data[i].forma_farmaceutica+'" concentracion="'+data[i].concentracion+'" presentacion="'+data[i].presentacion+'"    '+'class="btn btn-default item-id-medicamento-editar" style="color:green" title="Editar"><i class="glyphicon glyphicon-pencil"></i></a>'+
                                                '<center>'+ 
                                                '</td>'+
                                                '</tr>';
                                            }
                                            html +='</tbody>'+'</table>';

                                            $('#medicamentosTabla').html(html);

                                             //--CONTEMOS LAS FILAS PARA QUE APAREZCA EL SCROLL
                                            var filas=$("#tabla-medicamentos tr").length;
                                            if(filas>5){

                                              $("#tabla-medicamentos").css({'overflow-y':'scroll','height':'310px','display':'block'});
                                            }
                                          }


                },
                error: function(){
                    $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                }
            });
        }
    
    var id_medicamento;
    var nombre_generico;
    var forma_farmaceutica;
    var concentracion;
    var presentacion;
    $('#medicamentosTabla').on('click', '.item-id-medicamento-eliminar', function(){
        $('#deleteMedicamentoModal').modal('show');
        id_medicamento = $(this).attr('id_medicamento');
      });
    
    $('#medicamentosTabla').on('click', '.item-id-medicamento-editar', function(){
        id_medicamento = $(this).attr('id_medicamento');
        nombre_generico = $(this).attr('nombre_generico');
        forma_farmaceutica = $(this).attr('forma_farmaceutica');
        concentracion = $(this).attr('concentracion');
        presentacion = $(this).attr('presentacion');
        $('#nombregenerico1').val(nombre_generico);
        $('#formafarmaceutica1').val(forma_farmaceutica);
        $('#concentracion1').val(concentracion);
        $('#presentacion1').val(presentacion);
        $('#editMedicamentoModal').modal('show');
        
      });
    
    $('#btnDelete').unbind().click(function(){
            $.ajax({
               type: 'ajax',
               method: 'get',
               async: false,
               url: '<?php echo base_url() ?>administrador/Catalogos/eliminarMedicamentoPorID',
               data:{id_medicamento:id_medicamento},
               dataType: 'json',
               success: function(response){
                    //alert(data);
                    if(response)
                    {
                        var html = '';
                        swal({
                            title: "Exito!",
                            type: "success",
                            title: "El medicamento se elimino exitosamente!",
                            timer: 1800,
                            showConfirmButton: false
                            }
                         )
                        .catch(swal.noop);
                        var html = '';
                        $('#medicamentosTabla').html(html);
                    }
                    else
                    {
                        swal({
                          title: "Error!",
                          type: "warning",
                          text: "No se pudo eliminar el medicamento",
                          timer: 1800,
                          showConfirmButton: false
                              }
                        )
                        .catch(swal.noop);
                    }
                },
                error: function(){
                    $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                }
            });
        
            $('#deleteMedicamentoModal').modal('hide');
        });
    
    $('#btnEdit').unbind().click(function(){

        nombre_generico = $('#nombregenerico1').val();
        forma_farmaceutica = $('#formafarmaceutica1').val();
        concentracion = $('#concentracion1').val();
        presentacion = $('#presentacion1').val();
        
        if(nombre_generico.trim()!=""&&forma_farmaceutica.trim()!=""&&concentracion.trim()!=""&&presentacion.trim()!=""){
          $.ajax({
               type: 'ajax',
               method: 'post',
               async: false,
               url: '<?php echo base_url() ?>administrador/Catalogos/editarMedicamentoPorID',
               data:  {id_medicamento:id_medicamento,nombre_generico:nombre_generico,forma_farmaceutica:forma_farmaceutica,concentracion:concentracion,presentacion:presentacion},
               dataType: 'json',
               success: function(response){
                    //alert(data);
                    if(response)
                    {
                        var html = '';
                        swal({
                            title: "Exito!",
                            type: "success",
                            title: "El medicamento se actualizo exitosamente!",
                            timer: 1800,
                            showConfirmButton: false
                            }
                         )
                        .catch(swal.noop);
                        $('#editMedicamentoModal').modal('hide');
                        var html = '';
                        $('#medicamentosTabla').html(html);
                    }
                    else
                    {
                        swal({
                          title: "No se detectó alguna modificación sobre el medicamento seleccionado!",
                          type: "warning",
                          //text: "No se pudo actualizar el medicamento",
                          timer: 1800,
                          showConfirmButton: false
                              }
                        )
                        .catch(swal.noop);
                    }
                },
                error: function(){
                    $('.alert-danger').html('Error al conectar con la base de datos!').fadeIn().delay(3000).fadeOut('slow');
                }
            });
return false;
        }

        if(nombre_generico.trim()==""){
          $('#nombregenerico1').val("");
        }
        if(forma_farmaceutica.trim()==""){
          $('#formafarmaceutica1').val("");
        }
        if(concentracion.trim()==""){
          $('#concentracion1').val("");
        }
        if(presentacion.trim()==""){
          $('#presentacion1').val("");
        }
        
    });
        
</script>
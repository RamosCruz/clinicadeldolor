<br><br><br><br>
<script type="text/javascript" src="<?php echo base_url("assets/js/iniciaSesionGoogle.js");?>"></script>
<link href='<?php echo base_url("assets/fullcalendar/fullcalendar.min.css");?>' rel='stylesheet' />
<link href='<?php echo base_url("assets/fullcalendar/fullcalendar.print.min.css");?>' rel='stylesheet' media='print' />
<script src='<?php echo base_url("assets/fullcalendar/lib/moment.min.js");?>'></script>
<script src='<?php echo base_url("assets/fullcalendar/lib/jquery.min.js");?>'></script>
<script src='<?php echo base_url("assets/fullcalendar/fullcalendar.min.js");?>'></script>
<script src='<?php echo base_url("assets/fullcalendar/gcal.js");?>'></script>
<script src='<?php echo base_url("assets/fullcalendar/locale-all.js");?>'></script>
<script async defer src="https://apis.google.com/js/api.js"
    onload="this.onload=function(){};handleClientLoad()"
    onreadystatechange="if (this.readyState === 'complete') this.onload()">
</script>


<script>

	$(document).ready(function() {
        var citas =<?php echo json_encode($citas); ?>;
        
		$('#calendar').fullCalendar({
            locale: 'es',
            
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay,listWeek'
			},
			navLinks: true, // can click day/week names to navigate views
			
			eventLimit: true, // allow "more" link when too many events
			eventSources: citas
		});
		
	});

</script>
<style>


	#calendar {
		max-width: 900px;
		margin: 0 auto;
        font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
	}

</style>
   <div class="row">
       <div class="col-md-2">
           <?php
            for ($i = 0; $i < count($acotaciones); $i++)
            {
                echo 
                    '<div class="form-inline">
                        <div class="form-group">
                            <p class="glyphicon glyphicon-stop" style="color:'.$acotaciones[$i]['color'].'; font-size:30px;"></p>
                        </div>
                        <div class="form-group">
                            <p style="font-size:18px;">'.$acotaciones[$i]['doctor'].'</p>
                        </div>
                    </div>';  
            }
            
           ?>
       </div>
        <div class="col-md-8">
            <div class="text-left col-md-6">
                <button class="btn btn-success" id="authorize-button" style="display: none;" title="Para ver los calendarios es necesario iniciar sesión con Google">Activar calendario</button>
                <button class="btn btn-danger" id="signout-button" style="display: none;" title="No podra ver los calendarios si cierra la sesión ">Cerrar calendario</button>
            </div>
            
        
            <div class="col-md-12" id='calendar'></div>
        
            <pre style="display: none;" id="content"></pre>
        </div>
       <div class="col-md-2"></div>
    </div>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinica del Dolor</title>

    <?php echo link_tag('assets/css/login/logotipo.png', 'shortcut icon', 'image/png');?> 

 <!-- --------------------------------- LIBRERIAS DE JQUERY UI ------------------------------------------ -->

    




    
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap-theme.min.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">   
    <!-- CSS PARA LOS MODALS -->
     <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/modals_estilizado.css') ?>">
   <script src="<?php echo base_url('assets/js/jquery-3.1.1.min.js');?>"></script> 
    <script src="<?php echo base_url('assets/js/bootstrap.js');?>"></script>
    <script src="<?php echo base_url('assets/js/curp.js');?>"></script>
    <script src="<?php echo base_url('assets/js/digitos_estados.js');?>"></script>
    
     <!-- --------------------------------- LIBRERIAS DE SWEETALERT------------------------------------------ -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/sweetalert2/sweetalert2.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/sweetalert2/sweetalert2.min.css') ?>">
    <script type="text/javascript" src="<?php echo base_url('assets/sweetalert2/sweetalert2.js');?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/sweetalert2/sweetalert2.min.js');?>"></script>

    <!-- --------------------------------- LIBRERIAS DE DATETIMEPICKER------------------------------------------ -->
    <link href="<?php echo base_url("assets/datepicker/css/bootstrap-datepicker.css")?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/datepicker/css/bootstrap-datetimepicker.min.css")?>" rel="stylesheet">


    <script type="text/javascript" src="<?php echo base_url('assets/datepicker/js/bootstrap-datetimepicker.min.js');?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/datepicker/js/bootstrap-datepicker.min.js');?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/datepicker/js/bootstrap-datepicker.es.min.js');?>"></script>



        <script type="text/javascript" src="<?php echo base_url('assets/EasyAutocomplete-1.3.5/jquery.easy-autocomplete.min.js');?>"></script>
        <link href="<?php echo base_url("assets/EasyAutocomplete-1.3.5/easy-autocomplete.min.css")?>" rel="stylesheet">
        <link href="<?php echo base_url("assets/EasyAutocomplete-1.3.5/easy-autocomplete.themes.min.css")?>" rel="stylesheet">
  
    
</head>
<body>
    <header>
        <?php 
            $this->load->view($menu);
        ?>
    </header>
    <div class="container">
       <div class="row">
           <div class="col-md-12" >
               <?php 
                    $this->load->view($contenido);
                ?>
           </div>
       </div>
    </div>






    <footer>
        <center><p>&copy; 2017 Clinica del Dolor Oaxaca | Derechos Reservados. <p></center>
    </footer>
    
    <script type="text/javascript"
     src="<?php echo base_url('assets/js/bootstrap-datetimepicker.min.js');?>">
    </script>
    <script type="text/javascript"
     src="<?php echo base_url('assets/js/bootstrap-datetimepicker.Idiomas.js');?>">
    </script>
    <script type="text/javascript"
     src="<?php echo base_url('assets/js/buscar.js');?>">
    </script>
    <script type="text/javascript" src="<?php echo base_url('assets/momentjs/momentjs.min.js');?>"></script>
    <link rel="stylesheet" type="text/css" media="screen"
     href="<?php echo base_url('assets/css/bootstrap-datetimepicker.min.css');?>">
     <!--  FUENTES -->

    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/fuente.css') ?>">
     
</body>
</html>
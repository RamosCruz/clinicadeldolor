!-- .............................................................................................................. -->

<footer class="footer"> 
    <div class="container text-center">
      <p>Copyright &copy; 2017 CLÍNICA DEL DOLOR OAXACA | DERECHOS RESERVADOS</p>
    </div>
</footer>

<!-- .........................................................................................................  -->

   

</body>

</html>

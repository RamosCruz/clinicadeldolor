<?php defined('BASEPATH') OR exit('No direct script access allowed');
    
class Gabinete extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        $this->load->model('administrador/Model_Gabinete');
    } 
    function index ()
    {
        $data ['contenido'] = 'administrador/catalogos/listar_estudios_gabinete';
        $data ['menu'] = 'administrador/menu_administrador';
		$this->load->view('plantilla',$data);
    }
    
    function getEstudiosDeGabinete()
    {
        
        $result=$this->Model_Gabinete->getEstudiosDeGabinete();
        echo json_encode($result);
    }
    
    public function eliminarEstudioPorID()
    {
        $result = $this->Model_Gabinete->eliminarEstudioPorID();
        
        echo json_encode($result);
    }
    public function agregarEstudio()
    {
        
        $result=$this->Model_Gabinete->agregarEstudio();
        echo json_encode($result);
    }
}
?>
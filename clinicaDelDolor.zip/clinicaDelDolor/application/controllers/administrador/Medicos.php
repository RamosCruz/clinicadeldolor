<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Medicos extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        //if (!$this->ion_auth->is_admin()) {
            //show_404();
        //}
        $this->load->model('administrador/Modelo_medicos');
        //$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
    }
    public function index()
    {
        
    }

    public function actualizar_datos()
    {
        $datos = $this->input->post();
        if(isset($datos))
        {
            $nombre = $datos['nombre'];
            $app = $datos['app'];
            $apm = $datos['apm'];
            $sexo = $datos['sexo'];
            $estado_nacimiento = $datos['estado_nacimiento'];
            $fecha_nacimiento = $datos['fecha_nacimiento'];
            $curp = $datos['curp'];
            $cedula = $datos['cedula'];
            $cedulae = $datos['cedulae'];
            $especialidad = $datos['especialidad'];
            $estado_domicilio = $datos['estado_domicilio'];
            $listaDeMunicipios = $datos['listaDeMunicipios'];
            $listadoDeLocalidades = $datos['listadoDeLocalidades'];
            $calle = $datos['calle'];
            $correo_elect = $datos['correo_elect'];
            $telefono = $datos['telefono']; 
            //$precio_consulta = $datos['precio_consulta']; 

            $this->Modelo_medicos->actualizarMedico($curp,$nombre,$app,$apm,$sexo,$estado_nacimiento,$fecha_nacimiento,$cedula,$cedulae,$especialidad,$estado_domicilio,$listaDeMunicipios,$listadoDeLocalidades,$calle,$correo_elect,$telefono);
            redirect('administrador/Medicos/listar_medicos');
        }
    }

     public function editar_medico($curp)
    {
        $medico = $this->Modelo_medicos->getMedico($curp);
        $data ['datosDelmedico'] =$medico;
        $data ['estados'] = $this->Modelo_medicos->getEstados();
        $data ['especialidades'] = $this->Modelo_medicos->getEspecialidades();
        $data ['selmunicipios'] = $this->Modelo_medicos->getMunicipiosDelEstado1($medico[0]->estado);
        $data ['sellocalidades'] = $this->Modelo_medicos->getLocalidadesDelMunicipioDe1($medico[0]->municipio,$medico[0]->estado);
            
        $data ['menu'] = 'administrador/menu_administrador';
        $data ['contenido'] = 'administrador/user/editar_medico';
        $this->load->view('administrador/plantilla',$data);

    }

        public function actualizarHonorario(){
        $result=$this->Modelo_medicos->actualizarHonorario();
        $msg['success'] = false;
        $msg['type'] = 'update';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg);      
    }

    public function listar_medicos()
    {
         //-----CARGAMOS LOS RESPECTIVOS CATÁLOGOS------------
        //CATALOGO DE ESTADOS
        //$data ['estados'] = $this->Modelo_medicos->getEstados();
        //$data ['especialidades'] = $this->Modelo_medicos->getEspecialidades();
        $data ['medicos'] = $this->Modelo_medicos->getMedicos();
        //-----------------------------------------------------------------
        $data ['menu'] = 'administrador/menu_administrador';
        $data['contenido'] = 'administrador/user/listar_medicos';
        $this->load->view('administrador/plantilla',$data);
    }

    public function validaCURP(){
        $result=$this->Modelo_medicos->validaCURP();
        echo json_encode($result);
    }

    public function validaCorreoUnicoEnUsers(){
        $result=$this->Modelo_medicos->validaCorreoUnicoEnUsers();
        echo json_encode($result);
    }

    public function validaCorreoUnicoEnMedicos(){
        $result=$this->Modelo_medicos->validaCorreoUnicoEnMedicos();
        echo json_encode($result);
    }

    public function getMunicipiosDelEstado(){
        $result=$this->Modelo_medicos->getMunicipiosDelEstado();
        echo json_encode($result);
    }

    public function getLocalidadesDelMunicipioDe(){
        $result=$this->Modelo_medicos->getLocalidadesDelMunicipioDe();
        echo json_encode($result);
    }

    public function RegistrarNuevoMedico(){
        $costoDeConsulta=$this->input->post('costoDeConsulta');
        $curp                 =$this->input->post('curp');

        $result=$this->Modelo_medicos->RegistrarNuevoMedico();

        if($result){
            $result=$this->Modelo_medicos->RegistrarCostoConsulta($costoDeConsulta,$curp);
        }
        echo json_encode($result);
    }

    public function getEspecialidades(){
        $result=$this->Modelo_medicos->getEspecialidades();
        echo json_encode($result);
        //$data ['especialidades'] = $this->Modelo_medicos->getEspecialidades();
    }

        public function obtenerListaDeMedicos(){
        $result=$this->Modelo_medicos->getMedicos();
        echo json_encode($result);
    }
    
    

    public function crearNuevoMedico()
    {
        //-----CARGAMOS LOS RESPECTIVOS CATÁLOGOS------------
        $data ['estados'] = $this->Modelo_medicos->getEstados();
        $data ['especialidades'] = $this->Modelo_medicos->getEspecialidades();
        

        //---------------------------------------------------
        
        $data ['menu'] = 'administrador/menu_administrador';
        $data['contenido'] = 'administrador/user/nuevoMedico';
        $this->load->view('administrador/plantilla',$data);
       
    }

}
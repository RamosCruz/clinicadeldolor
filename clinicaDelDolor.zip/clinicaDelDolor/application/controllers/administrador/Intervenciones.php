<?php defined('BASEPATH') OR exit('No direct script access allowed');
    
class Intervenciones extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        //if (!$this->ion_auth->is_admin()) {
            //show_404();
        //}
         
        $this->load->model('administrador/Model_Intervenciones');
    } 
    public function index ()
    {
        $data ['contenido'] = 'administrador/catalogos/listar_intervensiones';
        $data ['menu'] = 'administrador/menu_administrador';
		$this->load->view('plantilla',$data);
    }
    
    public function agregarIntervension()
    {
        $result=$this->Model_Intervenciones->agregarIntervension();
        echo json_encode($result);
    }
    public function eliminarIntervencion()
    {
        $result = $this->Model_Intervenciones->eliminarIntervencion();
        
        echo json_encode($result);
    }
    
    public function getIntervensiones()
    {
        $result=$this->Model_Intervenciones->getIntervensiones();
        echo json_encode($result);
    }
    
    public function getIntervensionID ()
    {
        $result = $this->Model_Intervenciones->getIntervensionID();
        
        echo json_encode($result);
    }


        public function actualizarIntervecion()
    {
        $result=$this->Model_Intervenciones->actualizarIntervecion();
        $msg['success'] = false;
        $msg['type'] = 'update';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg);

        
        
    }
}
?>
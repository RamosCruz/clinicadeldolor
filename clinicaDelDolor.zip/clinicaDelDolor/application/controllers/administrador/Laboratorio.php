<?php defined('BASEPATH') OR exit('No direct script access allowed');
    
class Laboratorio extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        $this->load->model('administrador/Model_Laboratorio');
    } 
    function index ()
    {
        $data ['contenido'] = 'administrador/catalogos/listar_estudios_laboratorio';
        $data ['menu'] = 'administrador/menu_administrador';
		$this->load->view('plantilla',$data);
    }
    function getAreasEstudio()
    {
        
        $result=$this->Model_Laboratorio->getAreasEstudio();
        echo json_encode($result);
    }
    
    function getEstudiosDeLaboratorio ()
    {
        
        $result=$this->Model_Laboratorio->getEstudiosDeLaboratorio();
        echo json_encode($result);
    }
    
    public function agregarAreaEstudio()
    {
        $result=$this->Model_Laboratorio->agregarAreaEstudio();
        echo json_encode($result);
    }
    
    public function eliminarEstudioPorID()
    {
        $result = $this->Model_Laboratorio->eliminarEstudioPorID();
        
        echo json_encode($result);
    }
    public function agregarEstudio()
    {
        
        $result=$this->Model_Laboratorio->agregarEstudio();
        echo json_encode($result);
    }
}
?>
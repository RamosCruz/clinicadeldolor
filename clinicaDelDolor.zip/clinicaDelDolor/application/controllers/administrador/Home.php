<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->is_admin()) {
            show_404();
        }
        $this->load->model('administrador/Modelo_Calendar');
    }
    public function index()
    {
        //$this->load->model('medico/Model_Paciente');
        //--------------------------------------------------
        //$this->load->model('medico/Modelo_consulta');
        //$data ['viasDeAdministracion'] = $this->Modelo_consulta->ObtenerCatalogoViaDeAdministracion();
        //--------------------------------------------------
        //$data ['listarPacientes'] = $this->Model_medicos->listarPacientes();
        //$data ['contenido'] = 'administrador/user/crear_consulta';
        //$this->ion_auth->is_admin();
        /*$data ['menu'] = 'administrador/menu_administrador';
        $data['contenido'] = 'administrador/principal';
		$this->load->view('administrador/plantilla',$data);*/
        redirect ('administrador/Home/fullCalendar');
    }

    public function fullCalendar ()
    {
        
        
        $doctoresConCita = $this->Modelo_Calendar->getMedicosConCita();
        
        $acotaciones = array();
        $citas = $this->Modelo_Calendar->getFullCalendarTodas();
        $arreglo1 = array();
        $arreglo2 = array();
        if(count($citas)>0){
            for ($i = 0; $i < count($doctoresConCita); $i++)
            {
                $medico = $doctoresConCita[$i]->id_medico;
                for ($j = 0; $j < count($citas); $j++)
                {
                    if($medico == $citas[$j]->id_medico)
                    {
                        $timestamp = strtotime($citas[$j]->hora) + 60*60;
                        $time = date('H:i:s', $timestamp);


                        array_push($arreglo1,array(
                            'title'=>'Cita: '.$citas[$j]->nombre.' '.$citas[$j]->app.' '.$citas[$j]->apm, 
                            'start'=>$citas[$j]->fecha.'T'.$citas[$j]->hora, 
                            'end'=>$citas[$j]->fecha.'T'.$time
                        ));
                    }
                }
                $color = substr(md5(rand(5, 15)), 0, 6);
                $color =  '#'.$color;
                array_push($arreglo2,array(
                        'events'=>$arreglo1,
                        'color'=> $color
                    ));
                $arreglo1 = array();
            }  
            for ($x = 0; $x < count($doctoresConCita); $x++)
            {
                $getNombre = $this->Modelo_Calendar->nombreDelDoc($doctoresConCita[$x]->id_medico);
                $nombre = $getNombre[0]->nombre;
                $color1 = $arreglo2[$x]['color'];
                array_push($acotaciones,array(
                                'doctor'=>'Dr '.$nombre, 
                                'color'=>$color1
                            ));
            }
        }else
        {
           array_push($arreglo2,array(
                        'events'=>array(
                                    'title'=>'No citas', 
                                    'start'=>date('Y-m-dTH:i:s-5:00'), 
                                    'end'=>date('Y-m-dTH:i:s-5:00')),
                        'color'=> '#AAA'
                    ));
            array_push($acotaciones,array(
                            'doctor'=>'No hay citas', 
                            'color'=>'#AAA'
                        ));
        }
        
        
        
        $data ['acotaciones'] = $acotaciones;
        $data ['citas'] = $arreglo2;
        $data ['menu'] = 'administrador/menu_administrador';
        $data['contenido'] = 'administrador/Principal';
        $this->load->view('plantilla',$data);
    }
    public function respaldarBD ()
    {
        $this->load->dbutil();

        $prefs = array(     
                'format'      => 'zip',             
                'filename'    => 'my_db_backup.sql'
              );


        $backup =& $this->dbutil->backup($prefs); 

        $db_name = 'backup-on-'. date("Y-m-d-H-i-s") .'.zip';
        $save = 'pathtobkfolder/'.$db_name;

        $this->load->helper('file');
        write_file($save, $backup); 


        $this->load->helper('download');
        force_download($db_name, $backup); 
    }
}
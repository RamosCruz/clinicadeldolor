<?php defined('BASEPATH') OR exit('No direct script access allowed');
    
class Catalogos extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->is_admin()) {
            show_404();
        }
        $this->load->model('administrador/Model_Catalogo');
    } 
    public function index ()
    {
        echo 'Directorio invalido';;
    }
    public function medicamentos ()
    {
        $data ['menu'] = 'administrador/menu_administrador';
        $data['contenido'] = 'administrador/catalogos/view_medicamentos';
		$this->load->view('administrador/plantilla',$data);
    }
    public function especialidades ()
    {
       $data ['menu'] = 'administrador/menu_administrador';
        $data['contenido'] = 'administrador/catalogos/view_especialidades';
		$this->load->view('administrador/plantilla',$data); 
    }
    public function agregarMedicamento()
    {
        $response = $this->Model_Catalogo->insertMedicamento();
        echo json_encode($response);
    }
    public function obtenerMedicamentosPorNombre()
    {
        $result=$this->Model_Catalogo->obtenerMedicamentosPorNombre();
        echo json_encode($result);
    }
    public function eliminarMedicamentoPorID()
    {
        $result=$this->Model_Catalogo->eliminarMedicamentoPorID();
        echo json_encode($result);
    }
    public function editarMedicamentoPorID ()
    {
        $response = $this->Model_Catalogo->editarMedicamentoPorID();
        echo json_encode($response);
    }
    public function obtenerEspecialidades()
    {
        $result=$this->Model_Catalogo->obtenerEspecialidades();
        echo json_encode($result);
    }
    public function eliminarEspecialidadPorID ()
    {
        $result=$this->Model_Catalogo->eliminarEspecialidadPorID();
        echo json_encode($result);
    }
    public function agregarEspecialidad()
    {
        $response = $this->Model_Catalogo->agregarEspecialidad();
        echo json_encode($response);
    }

    public function editarCostoDeConsulta()
    {
        $data ['menu'] = 'administrador/menu_administrador';
        $data ['precioConsulta']=$this->Model_Catalogo->obtenerPrecioConsulta();
        $data['contenido'] = 'administrador/precios/costoConsulta';
        $this->load->view('administrador/plantilla',$data); 
        //$response = $this->Model_Catalogo->agregarEspecialidad();
        //echo json_encode($response);
    }

    public function actualizarCostoDeConsulta()
    {
        $costo=$this->input->post('costoDeConsulta');
        $this->Model_Catalogo->actualizarCostoDeConsulta($costo);
        redirect('administrador/Catalogos/editarCostoDeConsulta');
        
    }


        public function actualizarEspecialidades()
    {
        $result=$this->Model_Catalogo->actualizarEspecialidades();
        $msg['success'] = false;
        $msg['type'] = 'update';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg);

        
        
    }

        public function getGenericos(){
        $this->load->model('medico/Modelo_consulta');
        $result=$this->Modelo_consulta->getGenericos();
        echo json_encode($result);
    }

    public function actualizarEstudioLab()
    {
        $result=$this->Model_Catalogo->actualizarEstudioLab();
        $msg['success'] = false;
        $msg['type'] = 'update';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg);

        
        
    }
    
    public function actualizarEstudioGab()
    {
        $result=$this->Model_Catalogo->actualizarEstudioGab();
        $msg['success'] = false;
        $msg['type'] = 'update';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg);

        
        
    }

}
?>
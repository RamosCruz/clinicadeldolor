<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Usuarios extends CI_Controller {
    function __construct()
    {
        parent::__construct();
         //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->is_admin()) {
            show_404();
        }
    }
    public function index()
    {
        //$this->load->model('medico/Model_Paciente');
        //--------------------------------------------------
        //$this->load->model('medico/Modelo_consulta');
        //$data ['viasDeAdministracion'] = $this->Modelo_consulta->ObtenerCatalogoViaDeAdministracion();
        //--------------------------------------------------
        //$data ['listarPacientes'] = $this->Model_medicos->listarPacientes();
        //$data ['contenido'] = 'administrador/user/crear_usuario';
        $data ['menu'] = 'medico/menu_administrador';
		$this->load->view('plantilla',$data);
    }
}
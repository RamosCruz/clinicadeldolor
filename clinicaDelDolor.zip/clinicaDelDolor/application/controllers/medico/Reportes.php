<?php defined('BASEPATH') OR exit('No direct script access allowed');
    
class Reportes extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model('medico/Modelo_reportes');
    }
    public function Cuentas()
    {
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $medico = $this->Modelo_medicos->getUser_Medico();
        $datos ['medico_logueado'] = $medico;
        //-----------------------------------------------------------------
        
        $datos ['cuentas'] = $this->Modelo_reportes->cuentasDeHoy($medico[0]->id_medico);
        $datos ['menu'] = 'medico/menu_medico';
        $datos ['contenido'] = 'medico/reportes/cuentas';
        $this->load->view('plantilla',$datos);
        
    }
    public function cuentasDeHoy()
    {
        $this->load->model('administrador/Modelo_medicos');
        $medico = $this->Modelo_medicos->getUser_Medico();
        $datos ['medico_logueado'] = $medico;
        
        $result=$this->Modelo_reportes->cuentasDeHoy($medico[0]->id_medico);
        echo json_encode($result);
    }

    public function Balance ()
    {
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $datos ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        
        $datos ['menu'] = 'medico/menu_medico';
        $datos ['contenido'] = 'medico/reportes/valance';
        $this->load->view('plantilla',$datos);
    }

    public function buscarCuenta ()
    {
        
        $id_paciente=$this->input->get('id_paciente');
        $id_medico=$this->input->get('id_medico');
        $result=$this->Modelo_reportes->buscarCuenta($id_paciente,$id_medico);
        echo json_encode($result);
    }
    public function registrarPago()
    {
        $result=$this->Modelo_reportes->registrarPago();
        $msg['success'] = false;
		$msg['type'] = 'update';
		if($result){
			$msg['success'] = true;
		}
		echo json_encode($msg);
    }
    public function valanceMedico()
    {
        $id_medico=$this->input->get('id_medico');
        $fecha_inicio=$this->input->get('fecha_inicio');
        $fecha_termino=$this->input->get('fecha_termino');
        $data['Ganancias']=$this->Modelo_reportes->valance($id_medico,$fecha_inicio,$fecha_termino);
        $data['BalanceGral']=$this->Modelo_reportes->BalanceGral($id_medico,$fecha_inicio,$fecha_termino);
        
        echo json_encode($data);
    }
}
?>
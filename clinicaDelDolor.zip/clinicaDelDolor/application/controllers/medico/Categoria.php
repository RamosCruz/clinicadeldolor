<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//CONTROLADOR

class Categoria extends CI_Controller {
   public function __construct() {
      parent::__construct();
       //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->in_group('medico')) {
            show_404();
        }
     
      $this->load->model('medico/modelo_categoria');//Carga el modelo cada ves que se ejecuta algun metodo delcontrolador
   }

   function index(){
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $medico = $this->Modelo_medicos->getUser_Medico();
        $datos ['medico_logueado'] = $medico;
        //-----------------------------------------------------------------
       $datos['medicos']=$this->modelo_categoria->getCategorias($medico[0]->id_medico);
        //Nos faltaria llamar el modelo que no hemos creado de la  tabla estatus

        $datos ['menu'] = 'medico/menu_medico';
        $datos ['contenido'] = 'medico/categoria/listar_categorias';
        $this->load->view('plantilla',$datos);
  }
    //.................................................................
    function validarCategoria(){
            $result=$this->modelo_categoria->validarCategoria();
            echo json_encode($result);
    }

    function insertarCategoria(){
            $result=$this->modelo_categoria->insertarCategoria();
            $msg['success'] = false;
            $msg['type'] = 'add';
                if($result){
                    $msg['success'] = true;
                }
                echo json_encode($msg);
    }



    function getCategorias(){
        $id_medico = $this->input->get('id_mmedic');
        $result=$this->modelo_categoria->getCategorias($id_medico);
        echo json_encode($result);
    }


    public function eliminarCategoria(){
        $result = $this->modelo_categoria->eliminarCategoria();
        $msg['success'] = false;
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg);
    }


    public function editarCategoria(){
        $result = $this->modelo_categoria->editarCategoria();
        echo json_encode($result);
    }



    

    public function actualizarCategoria(){
        $result = $this->modelo_categoria->actualizarCategoria();
        $msg['success'] = false;
        $msg['type'] = 'update';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg);
    }

    public function nueva_Imagen ()
    {
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $medico = $this->Modelo_medicos->getUser_Medico();
        $datos ['medico_logueado'] = $medico;
        //-----------------------------------------------------------------
        $datos ['menu'] = 'medico/menu_medico';
        $datos ['contenido'] = 'medico/categoria/nueva_imagen';
        $datos['categorias']=$this->modelo_categoria->getCategorias($medico[0]->id_medico);
        $this->load->view('plantilla',$datos);
    }
    public function galeria ()
    {
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $medico = $this->Modelo_medicos->getUser_Medico();
        $datos ['medico_logueado'] = $medico;
        //-----------------------------------------------------------------
        $datos['categorias']=$this->modelo_categoria->getCategorias($medico[0]->id_medico);
        $datos['mostrarImg']=$this->modelo_categoria->mostrarImg($medico[0]->id_medico);
        $datos ['menu'] = 'medico/menu_medico';
        $datos ['contenido'] = 'medico/categoria/ver_galeria';
        $this->load->view('plantilla',$datos);
    }
    
    public function cargarImagen()
    {
        
        $datos = $this->input->post();
        if(isset($datos))
        {
            $id_categoria = $datos['selec_categoria'];
            $nombre = $datos['nombreImg'];
            $id_mdco = $datos['id_medico'];

            $config['upload_path'] = './uploads/galeria/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['encrypt_name'] = true;
            
            $this->load->library('upload', $config);

            if (!$this->upload->do_upload())
            {
                // echo $this->upload->display_errors();
                redirect('medico/Categoria/galeria');
            }
            else
            {
                $data = $this->upload->data();
                foreach ($data as $key => $value)
                {
                    if ($key == 'file_name')
                    {
                        $nombreArchivo = $value;
                        $this->modelo_categoria->cargarImagen($nombreArchivo,$id_categoria,$nombre,$id_mdco);
                    }
                }
                redirect('medico/Categoria/galeria');


            }
        }
    }
    public function eliminarImagen ($nombreArchivo)
    {
        $imagen = './uploads/galeria/'.$nombreArchivo;
        if($nombreArchivo!=null){
            $this->modelo_categoria->eliminarImagen($nombreArchivo);
            unlink($imagen);
        }
        redirect('medico/Categoria/galeria');
    }

    public function getImg()
    {
        $datos = $this->input->get();
        $id_mdco = $datos['id_medico'];
        $result = $this->modelo_categoria->mostrarImg($id_mdco);
        echo json_encode($result);
    }

    





}
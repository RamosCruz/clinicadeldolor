<?php defined('BASEPATH') OR exit('No direct script access allowed');
    
class Formatos extends CI_Controller {
    function __construct()
    {
        parent::__construct();
         //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->in_group('medico')) {
            show_404();
        }
        $this->load->model('medico/Model_Historial');
    } 
    public function index ()
    {
        echo 'Hola';
    }
    public function NuevaNotaPreoperatoriayValoracionPreanestesica()
    {
         //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        
        $data ['contenido'] = 'medico/formatos/view_PreoperatoriayValoracionPreanestesica';
        $data ['menu'] = 'medico/menu_medico';
        $this->load->view('plantilla',$data);
    }
    public function NuevaCartadeConsentimientoBajoInformacionSedacion()
    {
         //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        
        $data ['contenido'] = 'medico/formatos/view_CartadeConsentimientoBajoInformacionSedacion';
        $data ['menu'] = 'medico/menu_medico';
        $this->load->view('plantilla',$data);
    }

    public function NuevaCartadeConsentimientoBajoInformacionAnestesiaRegional()
    {
         //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        
        $data ['contenido'] = 'medico/formatos/view_CartadeConsentimientoBajoInformacionAnestesiaRegional';
        $data ['menu'] = 'medico/menu_medico';
        $this->load->view('plantilla',$data);
    }

    public function imprimirCartadeConsentimientoBajoInformacionAnestesiaRegional()
    {
        $html = '
        <div class="panel panel-primary" style="width:814px; height:1056px;">
            <div class="panel-body">
                <table>
                    <tr>
                        <td style="width:250px; padding: 10px;" align="center">
                        <i>Doctor: Hola</i><br><i>Cedula: Hola</i>
                        </td>

                        <td rowspan="2" style="width:300px;  padding: 10px;" align="center">
                        <p><i>Paciente: Hola</i></p>
                        <p>1 años</p>
                        <p>Hombre</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:250px; padding: 10px;" align="center">
                        <b><h4>CARTA DE CONSENTIMIENTO BAJO INFORMACION ANESTESIA REGIONAL</h4></b>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" align="right" id="1">
                        <p style="font-size:15px">Oaxaca, Oaxaca de Juarez a x  13 hrs</p>

                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" align="justify" id="2">
                        <p style="font-size:15px">Nombre del Paciente: Luis</p>
                        <br>
                        <p style="font-size:15px">
                            El que suscribe la presente, con el con carácter de Paciente ( ) Familiar Responsable y/o Respresentante Legal del Paciente ( ) de manera libre y en plena conciencia, autorizo al (a la) Doctor(a) ____________ a que me (le) proporcione (al paciente) anestesia loco-regional, durante el procedimiento médico y/o quirúrgico que el Dr(a). _____________ me (le) practicará (al paciente) y a quien de forma expresa he autorizado para tal efecto con la plena conciencia de la naturaleza, riesgos y beneficios de del citado procedimiento, las alternativas de tratamiento, las probabilidades de éxito, los eventos adversos que pudieran presentarse, así como las consecuencias de no someterse (someterse el paciente) al mismo.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Bajo ese entendimiento, reconozco que el médico anestesiólogo arriba citado, me ha explicado la informacioón que a continuación se detalla y que contiene entre otros aspectos, la naturaleza del plan de anestésico propuesto y los riesgos inherentes; información que he comprendido y acepto en plena conciencia.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>1. Descripción del plan anestésico propuesto.</b></p>
                        <p style="font-size:15px">
                            La anestesia loco-regional constituye en la  inyeccion, con la ayuda de aguajas especiales, y por medio de diferentes técnicas, de medicamentos llamados anestésicos locales, en la proximidad de un nervio o de la columna vertebral, consiguiendo asi que no se sienta ningún tipo de dolor en la región donde se realizará la intervención quirúrgica. Es prácticamente un acto anestésico completo que requiere la misma preparación, precaución y vigilacia que en la anestesia general.
                        </p>
                        <br><br>
                        <p style="font-size:15px">
                            El anestesiólogo es el responsable de realizar y controlar todo el proceso de la anestesia loco-regional de principio a fin, así como de tratar todas las posibles complicaciones que pudieran surgir.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Mediante diferentes métodos clínicos y monitores, se controlan y vigilan los signos vitales(presión arterial, electrocardiograma, frecuencia respiratoria), además de la cantidad de oxígeno de la sangre, la función cerebral, bióxido de carbono exhalado y otros, con lo que se mantiene una vigilancia permanente durante todo el acto anestésico y se consigue la máxima seguridad.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>2. Objetivos del procedimiento anestésico.</b></p>
                        <p style="font-size:15px">
                            El propósito principal de la anestesia loco-regional es permitir la realización de una intervención quirúrgica sin dolor. Esto se consigue produciendo insensibilidad en la zona a operar, que permanecerá "dormida" (anestesiada). A diferencia de la Anestesia General, el paciente permanece conciente y despierto, o sedado, pero sin sentir ningún dolor.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>3. Alternativas razonables al plan anestésico propueto.</b></p>
                        <p style="font-size:15px">
                            En los casos en los que la anestesia loco-regional no sea posible, o no se consiga por razones técnicas, puede ser necesario realizar anestesia general.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>4. Riesgos.</b></p>
                        <p style="font-size:15px">
                           Los riesgos de una anestesia loco-regional son pocos frecuentes, pero como en todo procedimiento médico se pueden presentar, en condiciones normales y de forma inevitable, una serie de complicaciones que podrían requerir tratamientos complementarios tanto médicos como quirúrgicos. Son riesgos aceptados de acuerdo a la experiencia y el estado actual de la ciencia médica. Estos son:
                        </p>
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="panel panel-primary" style="width:814px; height:1056px;">
            <div class="panel-body">
                <table>
                    <tr>
                        <td colspan="2" align="justify" id="3">
                            <p style="font-size:14.5px">
                            A) En ocaciones excepcionales, como consecuencia de la dificultad que se encuentre para colocar el anestésico en un punto concreto, la anestesia administrada pasa rápidamente a la sangre o al sistema nervioso, produciéndose un efecto parecido al de la anestesia general, pero que puede verse acompañado de complicaciones graves, como alteración de la tensión arterial, alteraciones cardiacas, respiratorias, pérdida de la conciencia, temblores intensos y convulsiones. Normalmente estas complicaciones se solucionan, pero en ocasiones puede ser que obliguen a no realizar el procedimiento médico y/o quirúrgico, o bien realizarlo bajo anestesia general.
                            </p>
                            <br>
                            <p style="font-size:14.5px">
                            B) Después de administrar una anestesia  loco-regional a nivel de la columna vertebral (anestesia peridural o subaracnoidea) pueden surgir molestias tales como dolor de cabeza o de espalda, que normalmente desaparecen en los días posteriores y que en raras ocasiones necesitan tratamiento médico.
                            </p>
                            <br>
                            <p style="font-size:14.5px">
                            C) Después de administrar una anestesia loco-regional en la proximidad de un nervio, pueden surgir molestias, como alteraciones en la sensibilidad de la zona, con entumecimiento u hormigueo. Entre otras ocasiones pueden aparecer alteraciones motoras con dificultad para realizar movimientos preciosos, todo esto, generalmente es pasajero.
                            </p>
                            <br>
                            <p style="font-size:14.5px">
                            D) Después de administrar una anestesia loco-regional pueden aparecer diferentes síntomas, como descenso de la presión arterial, aumento de la frecuencia cardiaca, dificultad respiratoria, agitación, mareo, náusea, vómito, temblores, que en general son considerados como molestias, llegando, en muy pocos casos, a ser complicaciones. 
                            </p>
                            <br>
                            <p style="font-size:14.5px">
                            E) La administración de soluciones y medicamentos que sean impredescibles durante la anestesia, pueden reproducir reacciones alérgicas que pueden llegar a ser graves. No se recomienda la práctica sistemática de pruebas alérgicas a los fármacos que vayan a emplearse durante la anestesia, ya que dichas pruebas no están libres de riesgos, ni aun siendo su resultado negativo, garantizan que no se produzcan reacciones adversas durante el procedimiento anestésico.
                            </p>
                            <br>

                            <p style="font-size:14.5px">
                            <b>5. Riesgos en función del estado clínico del paciente.</b>
                            </p>
                            <br>

                            <p style="font-size:14.5px">
                            Todo el acto quirúrgico lleva implícitas una serie de complicaciones comunes y potencialmente serias que podrían requerir tratamientos complementarios; tanto médicos como quirúrgicos. Dependiendo el estado clínico del paciente y la existencia de otras patologías, como diabetes, cardiopatía, hipertensión, anemia, edad avanzada, obesidad, el riesgo anestésico puede ser mayor o aparecer complicaciones que pudieran aumentar el traslado del paciente a una unidad de cuidados intensivos, provocar lesiones graves al paciente o inclusive, la muerte.
                            </p>
                            <br>
                            <p style="font-size:14.5px">
                            Comprendo que la práctica de la medicina no es una ciencia exacta, por lo que reconozco que no se me ha asegurado ni garantizado que los resultados del evento anestésico y del procedimiento médico/quirúrgico que se me(le) practicarán (al paciente), necesariamente alcancen los beneficios esperados y que pueden presentarse imprevistos que varíen el(los) citado(os) procedimiento(s); por consiguiente ante cualquier complicación o efecto adverso durante el procedimiento anestésico propuesto, especialmente ante una urgencia médica, autorizo y solicito al médico anestesiólogo y al médico tratante al principio de este documento citados y/o a quienes ellos designen conjunta o separadamente, a que realicen los procedimientos médico(s) y/o quirúrgico(s) que consideren necesarios en ejercicio de su juicio y experiencia profesional, para la protección de mi(la) salud(del paciente), en la inteligencia que la extensión de esta autorización tambien será aplicada a cualquier condición que requiera de procedimientos médicos y/o quirúrgicos que sea desconocida por los facultativos y surja dirante procedimiento médico/quirúrgico-anestésico autorizado.
                            </p>
                            <br>
                            <p style="font-size:14.5px">
                            <div class="form-inline">
                            Declaro que el médico anestesiólogo Dr(a). _______ me ha explicado que es conveniente/necesario, en mi(la) sitación(del paciente), que durante el procedimiento de sedación al que seré (será) sometido (el paciente), me (le) administrarán diferentes fármacos, lo cual en plena conciencia autorizo.
                            </div>
                            </p>
                            <br>
                            <p style="font-size:14.5px">

                            Entendiendo el contenido de este documento y conforme con el mismo, lo firmo en ciudad de Oaxaca en la fecha arriba anotada.
                            </p>
                        </td>
                    </tr>  
                    <tr>
                        <td align="center" id="4">
                            <p>_________________________________________</p>
                            <p>Firma del Paciente</p>
                            </td>
                            <td align="center" id="5">
                            <p>____________________________________________________</p>
                            <p>Nombre y Firma del Familiar Responsable y/o Representante legal del Paciente</p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        
        
        <style>@page {
         margin: 0;
         padding:0;
        }
        table{
            width:792px;
            margin: 10px;
            border: 2px solid #0086b3;
        }
        th, td {
            border: 1px solid #0086b3;
            color: #00ace6;
            padding:15px;
        }
        #1{
            border-bottom: 0;
        }
        #2{
            border-top: 0;
        }
        
        #3{
            border-bottom: 0;
        }
        #4{
            border-top: 0;
            border-right: 0;
        }
        #5{
            border-top: 0;
            border-left: 0;
        }
        
        </style>';
        $hoy = date("dmyhis");
        $pdfFilePath = "CartaConsentimientoBajoInfAnestReag".$hoy.".pdf"; //Nombre del archivo
        $this->load->library('M_pdf');
        $mpdf = new mPDF('c', 'Letter');// ('carta', 'tamaño A4')
        $css = file_get_contents(base_url('assets/css/bootstrap.css')); // cargar estilo
        $mpdf->WriteHTML($css,1);
        $mpdf->WriteHTML($html);
        $mpdf->Output($pdfFilePath, "I");
        
    }


     public function NuevaCartadeConsentimientoBajoInformacionAnestesiaGeneral()
    {
         //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        
        $data ['contenido'] = 'medico/formatos/view_CartadeConsentimientoBajoInformacionAnestesiaGeneral';
        $data ['menu'] = 'medico/menu_medico';
        $this->load->view('plantilla',$data);
    }

    public function imprimirCartadeConsentimientoBajoInformacionAnestesiaGeneral()
    {
        $html = '
        <div class="panel panel-primary" style="width:814px; height:1056px;">
            <div class="panel-body">
                <table>
                    <tr>
                        <td style="width:250px; padding: 10px;" align="center">
                        <i>Doctor: Hola</i><br><i>Cedula: Hola</i>
                        </td>

                        <td rowspan="2" style="width:300px;  padding: 10px;" align="center">
                        <p><i>Paciente: Hola</i></p>
                        <p>1 años</p>
                        <p>Hombre</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:250px; padding: 10px;" align="center">
                        <b><h4>CARTA DE CONSENTIMIENTO BAJO INFORMACION ANESTESIA GENERAL</h4></b>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" align="right" id="1">
                        <p style="font-size:15px">Oaxaca, Oaxaca de Juarez a x  13 hrs</p>

                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" align="justify" id="2">
                        <p style="font-size:15px">Nombre del Paciente: <u>Luis</u></p>
                        <br>
                        <p style="font-size:15px">
                           <div class="form-inline">
                            El que suscribe la presente, con el con carácter de Paciente ( ) Familiar Responsable y/o Respresentante Legal del Paciente ( ) de manera libre y en plena conciencia, autorizo al (a la) Doctor(a) <u>XXXXXXXXXXXXX</u> a que me (le) proporcione (al paciente) anestesia general, durante el procedimiento médico y/o quirúrgico que <u>XXXXXXXXXXX</u> me (le) practicará (al paciente) y a quien de forma expresa he autorizado para tal efecto con la plena conciencia de la naturaleza, riesgos y beneficios de del citado procedimiento, las alternativas de tratamiento, las probabilidades de éxito, los eventos adversos que pudieran presentarse, así como las consecuencias de no someterse (someterse el paciente) al mismo.
                            </div>
                            
                        </p>
                        
                        <br>
                        <p style="font-size:15px">
                            Bajo ese entendimiento, reconozco que el médico anestesiólogo arriba citado, me ha explicado la informacioón que a continuación se detalla y que contiene entre otros aspectos, la naturaleza del plan de anestésico propuesto y los riesgos inherentes; información que he comprendido y acepto en plena conciencia.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>1. Descripción del plan anestésico propuesto.</b></p>
                        <p style="font-size:15px">
                            La anestesia general  consiste en proporcionar al paciente un  estado reversible de pérdida de la conciencia, de analgesia y relajación muscular. Para ello, se necesita realizar la punción de una vena y la introducción de un catéter (tubito de plástico) por el cual se administrarán las soluciones y medicamentos necesarios según las necesidades del paciente y el tipo de procedimientoal que será sometido.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Durante la anestesia general, al estar dormidoy relajado , es necesario mantener la respiración de forma artificial, y para ello se necesita colocar un dispositivo (tubo endotraqueal, mascarilla laríngea u otros) a través de la boca o la nariz, que llega a la faringeo a la tráquea. 
                        </p>
                        <br>
                        <p style="font-size:15px">
                            El médico anestesiólogo es el encargado de realizar y controlar todo el proceso de la anestesia de principio a fin, así como de tratar todas las posibles complicaciones que pudieran surgir. Mediante diferentes métodos clínicos y monitores, se controlan y vigilan los signos vitales (presión arterial, electrocardiograma, frecuencia respiratoria), además de la cantidad de oxigeno de la sangre, la función cerebral, el bióxido de carbono exhalado y otros, con lo que se mantiene una vigilacia permanente durante todo el acto anestésico, alcanzando la máxima seguridad.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>2. Objetivos del procedimiento anestésico.</b></p>
                        <p style="font-size:15px">
                            El propósito principal de la anestesia general es permitir la realización  de un procedimiento médico y/o qirúrgico sin dolor. 
                        </p>
                        <br>
                        <p style="font-size:15px"><b>3. Alternativas razonables al plan anestésico propueto.</b></p>
                        <p style="font-size:15px">
                            ______________________________________________
                            ____________________________________________________
                        </p>
                        <p style="font-size:15px"><b>4. Riesgos.</b></p>
                        <p style="font-size:15px">
                            La aplicación de anestesia general, como sucede en todo procedimieto médico, conlleva una serie de riesgos que son aceptados de acuerdo con la experiecia y el estado actual de  la ciencia médica, y que son:
                        </p>
                        <br>
                        <p style="font-size:15px">
                            A) Punciones repetidas por la dificultad en la introducción del catéter venoso, que pudiera condicionar salida de la vena de los diferentes medicamentos empleados en la anestesia, y provocar desde un simple enrojecimiento hasta problemas circulatorios locales.
                        </p>
                        
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="panel panel-primary" style="width:814px; height:1056px;">
            <div class="panel-body">
                <table>
                    <tr>
                        <td colspan="2" align="justify" id="3">
                            <p style="font-size:15px">
                                B) En algunas ocasiones, la introducción del tubo endotraqueal o cualquier otro dispositivo en la tráquea o la faringe, puede entrañar gran dificultad, dando lugar a rotura de piezas dentales y a lesiones de las mucosas de la zona.
                            </p>
                            <br>
                            <p style="font-size:15px">
                                C) Durante la colocación del tubo endotraqueal o cualquier otro dispisitivo, puede pasasr al pulmón parte del contenido del estómago, ocasionando problemas repiratorios que pueden llegar a ser importante. Es una complicación que puede ser grave pero poco frecuente y que para tratar de evita, se recomienda al paciente que guarde ayuno de 4 a 6 horas antes de la intervención quirúrgica que pueden llegar a ser graves. No se recomienda la práctica sistemática de pruebas alérgicas a los fármacos que vayan a emplearse durante la anestesia general, ya que dichas pruebas no están libres de riesgos ni aun siendo su resultado negativo garantizan que no seproduzcan reacciones adversas durante el procedimiento anestésico.        
                            </p>
                            <br>
                            <p style="font-size:15px">
                                D) La administración de soluciones y medicamentos que sean imprescindibles durante la anestesia, pueden producir reacciones alérgicas que pueden llegar a ser graves. No se recomienda la práctica sistematica de pruebas alérgicas a los fármacos que vayan a emplearse durante la anestesia general, ya que dichas pruebas no están libres de riesgos ni aun siendo su resultado negativo garantizan que no se produzcan reacciones adversas durante el procedimiento anestésico. 
                            </p>
                            <br>
                             <p style="font-size:15px">
                                E) Después de la anestesia general, pueden aparecer diferentes síntomas, como descenso de la presión arterial, aumento de la frecuencia cardiaca, dificultad respiratoria, agitación, mareo, náusea, vómito, temblores, que en general son considerados como molestias, llegando, en muy pocos casos, a ser complicaciones. 
                            </p>
                            <br>

                            <p style="font-size:15px">
                                <b>5. Riesgos en función del estado clínico del paciente.</b>
                            </p>
                            <br>

                            <p style="font-size:15px">
                                Todo el acto quirúrgico lleva implícitas una serie de complicaciones comunes y potencialmente serias que podrían requerir tratamientos complementarios; tanto médicos como quirúrgicos. Dependiendo el estado clínico del paciente y la existencia de otras patologías, como diabetes, cardiopatía, hipertensión, anemia, edad avanzada, obesidad, el riesgo anestésico puede ser mayor o aparecer complicaciones que pudieran aumentar el traslado del paciente a una unidad de cuidados intensivos, provocar lesiones graves al paciente o inclusive, la muerte.
                            </p>
                            <br>
                            <p style="font-size:15px">
                                Comprendo que la práctica de la medicina no es una ciencia exacta, por lo que reconozco que no se me ha asegurado ni garantizado que los resultados del evento anestésico y del procedimiento médico/quirúrgico que se me(le) practicarán (al paciente), necesariamente alcancen los beneficios esperados y que pueden presentarse imprevistos que varíen el(los) citado(os) procedimiento(s); por consiguiente ante cualquier complicación o efecto adverso durante el procedimiento anestésico propuesto, especialmente ante una urgencia médica, autorizo y solicito al médico anestesiólogo y al médico tratante al principio de este documento citados y/o a quienes ellos designen conjunta o separadamente, a que realicen los procedimientos médico(s) y/o quirúrgico(s) que consideren necesarios en ejercicio de su juicio y experiencia profesional, para la protección de mi(la) salud(del paciente), en la inteligencia que la extensión de esta autorización tambien será aplicada a cualquier condición que requiera de procedimientos médicos y/o quirúrgicos que sea desconocida por los facultativos y surja dirante procedimiento médico/quirúrgico-anestésico autorizado.
                            </p>
                            <br>
                            <p style="font-size:15px">
                               <div class="form-inline">
                                Declaro que el médico anestesiólogo <u>XXXXXXX</u> me ha explicado que es conveniente/necesario, en mi(la) sitación(del paciente), que durante el procedimiento de sedación al que seré (será) sometido (el paciente), me (le) administrarán diferentes fármacos, lo cual en plena conciencia autorizo.
                                </div>
                            </p>
                            <br>
                            <p style="font-size:15px">

                                Entendiendo el contenido de este documento y conforme con el mismo, lo firmo en ciudad de Oaxaca en la fecha arriba anotada.
                            </p>
                            <br>
                            <br>
                            <br>
                        </td>
                    </tr>  
                    <tr>
                        <td align="center" id="4">
                            <p>_________________________________________</p>
                            <p>Firma del Paciente</p>
                        </td>
                        <td align="center" id="5">
                            <p>____________________________________________________</p>
                            <p>Nombre y Firma del Familiar Responsable y/o Representante legal del Paciente</p>
                        </td>
                   </tr>
                </table>
            </div>
        </div>
        
        
        
        <style>@page {
         margin: 0;
         padding:0;
        }
        table{
            width:792px;
            margin: 10px;
            border: 2px solid #0086b3;
        }
        th, td {
            border: 1px solid #0086b3;
            color: #00ace6;
            padding:15px;
        }
        #1{
            border-bottom: 0;
        }
        #2{
            border-top: 0;
        }
        
        #3{
            border-bottom: 0;
        }
        #4{
            border-top: 0;
            border-right: 0;
        }
        #5{
            border-top: 0;
            border-left: 0;
        }
        
        </style>';
        $hoy = date("dmyhis");
        $pdfFilePath = "CartaConsentimientoBajoInfAnestGen".$hoy.".pdf"; //Nombre del archivo
        $this->load->library('M_pdf');
        $mpdf = new mPDF('c', 'Letter');// ('carta', 'tamaño A4')
        $css = file_get_contents(base_url('assets/css/bootstrap.css')); // cargar estilo
        $mpdf->WriteHTML($css,1);
        $mpdf->WriteHTML($html);
        $mpdf->Output($pdfFilePath, "I");
        
    }

public function receta ()
    {
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        $this->load->model('medico/Modelo_consulta');
        $data ['viasDeAdministracion'] = $this->Modelo_consulta->ObtenerCatalogoViaDeAdministracion();
        $data ['contenido'] = 'medico/formatos/view_receta1';
        $data ['menu'] = 'medico/menu_medico';
        $this->load->view('plantilla',$data); 
    }


    public function imprimirReceta ()
    {

        $id_medico = $this->input->post("id_medico");
        $id_paciente = $this->input->post("id_paciente");
        $id_consulta = $this->input->post("id_consulta");

        //$tipoFormularioDiagnostico = $this->input->post("optradio");
        $tipoFormularioTratamiento = $this->input->post("optradio");
        //$indicaciones_gral = $this->input->post("indicaciones_gral");

        $this->load->model('medico/Model_Paciente');
        $paciente = $this->Model_Paciente->obtenerPacienteConCurp($id_paciente);
        $this->load->model('administrador/Modelo_medicos');
        $medico = $this->Modelo_medicos->getMedico($id_medico);

        $hoy = date("dmyhis");

        $html='';







                ///Validamos la opción con formulario abierto
        if($tipoFormularioTratamiento==1){
                    $html = ' <!DOCTYPE html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Nueva Receta - Clinica del Dolor</title>
                    <link rel="stylesheet" href="style.css" media="all" />
                  </head>
                  <body>
                    <header class="clearfix">
                      <div id="logo">
                        <img src="'.base_url('assets/img/logotipo.png').'">
                      </div>
                      <div id="company">
                        <h2 class="name">Clinica del Dolor - Oaxaca</h2>
                        <div>Mario Pérez Ramírez 122, Colonia Reforma, Oaxaca</div>
                        <div>(951) 132 91 53</div>
                        <div><a href="mailto:victorscasti@hotmail.com">victorscasti@hotmail.com</a></div>
                      </div>
                    </header>
                    <main>
                      <div id="details" class="clearfix">
                        <div id="client">
                          <div class="to">Expedido a:</div>
                          <h2 class="name">'.$paciente[0]->nombre.' '.$paciente[0]->app.' '.$paciente[0]->apm.'</h2>
                          <div class="address">'.'</div>
                          <div class="phone">'.'</div>
                        </div>
                        <div id="invoice">
                          <h1>Receta Médica</h1>
                          <div class="date">Fecha de expedición: '.date("d/m/y").'</div>
                        </div>
                      </div>
                        <center>
                            <div style="width:600px; height:300px;">';
            //Imprimimos el diagnostico abierto
            $html=$html.$this->adjuntarTratamientosAbiertos($id_consulta);
        }
        else{
                    $html = ' <!DOCTYPE html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Nueva Receta - Clinica del Dolor</title>
                    <link rel="stylesheet" href="style.css" media="all" />
                  </head>
                  <body>
                    <header class="clearfix">
                      <div id="logo">
                        <img src="'.base_url('assets/img/logotipo.png').'">
                      </div>
                      <div id="company">
                        <h2 class="name">Clinica del Dolor - Oaxaca</h2>
                        <div>Mario Pérez Ramírez 122, Colonia Reforma, Oaxaca</div>
                        <div>(951) 132 91 53</div>
                        <div><a href="mailto:victorscasti@hotmail.com">victorscasti@hotmail.com</a></div>
                      </div>
                    </header>
                    <main>
                      <div id="details" class="clearfix">
                        <div id="client">
                          <div class="to">Expedido a:</div>
                          <h2 class="name">'.$paciente[0]->nombre.' '.$paciente[0]->app.' '.$paciente[0]->apm.'</h2>
                          <div class="address">'.'</div>
                          <div class="phone">'.'</div>
                        </div>
                        <div id="invoice">
                          <h1>Receta Médica</h1>
                          <div class="date">Fecha de expedición: '.date("d/m/y").'</div>
                        </div>
                      </div>
                        <center>
                            <div style="width:600px; height:300px;">
                            <br>
                            <br>
                            <br>';
            //Imprimimos el diagnostico cerrado
            $html=$html.$this->adjuntarTratamientos($id_consulta);
        }

        $html=$html.'</div>
                        </center>
                      <br>
                      <br>
                      <br>
                      <br>
                      <div>
                          <p style="margin:-0% 0;" align="center">______________________________________________</p>
                          <h4 style="margin:-0.5% 0;" align="center">Dr. '.$medico[0]->nombre.' '.$medico[0]->app.' '.$medico[0]->apm.'</h4>
                          <p style="margin:-0.5% 0;" align="center"><strong>Cedula: '.$medico[0]->cedula.'</strong></p>
                          <p style="margin:-0.5% 0;" align="center">Sello y firma del médico</p>
                      </div>
                  </body>
                </html>';

        $pdfFilePath = "receta_".$hoy.".pdf"; //Nombre del archivo
        $this->load->library('M_pdf');
        $mpdf = new mPDF('c', 'Letter');// ('carta', 'tamaño A4')
        $css = file_get_contents(base_url('assets/css/style.css')); // cargar estilo
        $mpdf->WriteHTML($css,1);
        $mpdf->WriteHTML($receta.$html);
        $mpdf->Output($pdfFilePath, "I");
    }



    public function adjuntarTratamientosAbiertos($id_consulta){
         $this->load->model('medico/Modelo_consulta');
        
        $tratamientos=$this->Modelo_consulta->getTratamientosAbiertosDelaConsulta($id_consulta);

        $concatena='';
        $conta=1;
        if($tratamientos!=null){
            for ($i = 0; $i < count($tratamientos); $i++){//------------------
                $concatena.='<p >'.'<strong>'.$conta.'.- </strong><b>'.$tratamientos[$i]->medicamento.'</b><p align="justify"><strong>Frecuencia y duracíon del tratamiento: </strong>'.$tratamientos[$i]->descripcion_del_tratamiento.' <strong> Vía de administración: </strong>'.$tratamientos[$i]->via_de_administracion.' <strong> Indicaciones generales: </strong>'.$tratamientos[$i]->indicaciones_grales.'</p>';
                $conta=$conta+1;

            }//------------------------------------------------------------
            return $concatena;

        }
        else{
            return $concatena;
        }

    }

    public function adjuntarTratamientos($id_consulta){
         $this->load->model('medico/Modelo_consulta');
        
        $tratamientos=$this->Modelo_consulta->getTratamientosDelaConsulta($id_consulta);

        $concatena='';
        $conta=1;
        if($tratamientos!=null){
            for ($i = 0; $i < count($tratamientos); $i++){//------------------
                $concatena.='<p align="justify">'.'<strong>'.$conta.'.- </strong><b>'.$tratamientos[$i]->nombre_generico.'</b> ('.$tratamientos[$i]->forma_farmaceutica.' -'.$tratamientos[$i]->concentracion.') : '.$tratamientos[$i]->dosis_preescrita.' '.$tratamientos[$i]->forma_farmaceutica.' '.$tratamientos[$i]->frec_de_la_dosis;
                if($tratamientos[$i]->tiempo_indefinido=='1'){

                    $concatena.='<b> por un indefinido.</b></p>';
                }
                else{

                     $concatena.=' hasta el d&iacute;a '.$this->formatoFecha_DMA($tratamientos[$i]->fin_tratamiento).'.</p>';
                }


                $conta=$conta+1;

            }//------------------------------------------------------------
            return $concatena;

        }
        else{
            return $concatena;
        }

    }
    
    public function imprimirReceta2 ()
    {

        $campo1 = $this->input->post("campo1");
        $campo2 = $this->input->post("campo2");
        $campo3 = $this->input->post("campo3");
        $campo4 = $this->input->post("campo4");   ////
        $campo5 = $this->input->post("campo5");
        $campo6 = $this->input->post("campo6");
        //$domicilio = $this->input->post("domicilio");
        //$telefono = $this->input->post("telefono");
        $hoy = date("dmyhis");

        $html = ' <!DOCTYPE html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Nueva Receta - Clinica del Dolor</title>
                    <link rel="stylesheet" href="style.css" media="all" />
                  </head>
                  <body>
                    <header class="clearfix">
                      <div id="logo">
                        <img src="'.base_url('assets/img/logotipo.png').'">
                      </div>
                      <div id="company">
                        <h2 class="name">Clinica del Dolor - Oaxaca</h2>
                        <div>Mario Pérez Ramírez 122, Colonia Reforma, Oaxaca</div>
                        <div>(951) 132 91 53</div>
                        <div><a href="mailto:victorscasti@hotmail.com">victorscasti@hotmail.com</a></div>
                      </div>
                    </header>
                    <main>
                      <div id="details" class="clearfix">
                        <div id="client">
                          <div class="to">Expedido a:</div>
                          <h2 class="name">'.$campo1.'</h2>
                          <div class="address">'.$campo2.'</div>
                          <div class="phone">'.$campo3.'</div>
                        </div>
                        <div id="invoice">
                          <h1>Receta Médica</h1>
                          <div class="date">Fecha de expedición: '.date("d/m/y").'</div>
                        </div>
                      </div>
                        <center>
                            <div style="width:600px; height:300px;">'.
                                  $campo4
                            .'</div>
                        </center>
                      <br>
                      <br>
                      <br>
                      <br>
                      <div>
                          <p style="margin:-0% 0;" align="center">______________________________________________</p>
                          <h4 style="margin:-0.5% 0;" align="center">Dr. '.$campo5.'</h4>
                          <p style="margin:-0.5% 0;" align="center"><strong>Cedula: '.$campo6.'</strong></p>
                          <p style="margin:-0.5% 0;" align="center">Sello y firma del medico</p>
                      </div>
                  </body>
                </html>';

        $pdfFilePath = "receta_".$hoy.".pdf"; //Nombre del archivo
        $this->load->library('M_pdf');
        $mpdf = new mPDF('c', 'Letter');// ('carta', 'tamaño A4')
        $css = file_get_contents(base_url('assets/css/style.css')); // cargar estilo
        $mpdf->WriteHTML($css,1);
        $mpdf->WriteHTML($receta.$html);
        $mpdf->Output($pdfFilePath, "I");
    }

    public function imprimirTratamientosEnOrden ($tratamiento)
    {
        $porciones = explode("?", $tratamiento);
        $var="";
        for ($i = 0; $i <count($porciones); $i++)
        {
            $var .= "<p>".$porciones[$i]."</p>";
        }
        return $var;
    }

     public function VerExpediente ()
    {
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        $data ['contenido'] = 'medico/formatos/view_expediente';
        $data ['menu'] = 'medico/menu_medico';
        $this->load->view('plantilla',$data); 
    }

        public function ImprimirExpediente ()
    {

        
        $futuro_POST = $this->input->post("curp");//Recibe el id de un paciente

        $this->load->model('medico/Model_Paciente');
        $paciente = $this->Model_Paciente->obtenerPacienteConCurp($futuro_POST);
        
        if($paciente[0]->sexo=="H"){
            $sexo="Hombre";
        }
        else{
            $sexo="Mujer";
        }

        $this->load->model('medico/Model_Historial');
        $AntecedentesGinecobstetricos = $this->Model_Historial->selAntGinecoObst($paciente[0]->id_expediente);
        //$AntecedentesHeredoFamiliares = $this->Model_Historial->selAnteHeredoFam($paciente[0]->id_expediente);
        $AntecedentesHeredoFamiliares=$this->Model_Historial->selAnteHeredoFam($paciente[0]->id_expediente);
        $AntecedentesPersonalesPatologicos=$this->Model_Historial->selAntePersoPato($paciente[0]->id_expediente);
        $AntecedentesPersonalesNoPatologicos=$this->Model_Historial->selAnteNoPersoPato($paciente[0]->id_expediente);

         $html = '
        <style>@page {
         margin: 0;
         padding:0;
        }
        table{
            width:792px;
            margin: 10px;
            border: 0.1px 
        }
        th, td {
            
            color: #08298A;
            padding:10px;
        }</style>
        
        
        <div class="panel panel-primary" style="width:814px; height:1056px;">
          <div class="panel-body">
            <table>
                <tr>
                    <td colspan="2" style="width:250px; padding: 10px; border: 0px;" align="left" >
                        <img src="'.base_url('assets/img/logotipo.png').'" style="padding: 0px; border: 0px;" >
                    </td>
                    <td colspan="2" style="padding: 10px; border: 0px;" align="center" >
                        <h3 style="padding: 0px; border: 0px;">Expediente Clinico</h3>
                        <p><b>Num.:</b> '.$paciente[0]->id_expediente.'</p>
                    </td>
                    <td colspan="2" style="width:250px; padding: 10px; border: 0px;" align="right" >
                        <h5>Clinica del Dolor<h5>
                        <p style="font-size:9px">Mario Pérez Ramírez 122,Colonia Reforma</p>
                        <p style="font-size:9px">Oaxaca de Juarez, Oaxaca</p>
                        <p style="font-size:9px">(951) 132 91 53</p>
                        <p style="font-size:9px"><a href="mailto:victorscasti@hotmail.com">victorscasti@hotmail.com</a></p>
                    </td>
                </tr>
                
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px;">
                        <hr style="margin-top: 0em; margin-bottom: 0em;">
                    </td>
                </tr>
                <tr style="padding: 0px;">
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:12px"><b>Paciente: </b> '.$paciente[0]->nombre.' '.$paciente[0]->app.' '.$paciente[0]->apm.'   </p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:12px"><b>Edad:</b> '.$paciente[0]->edad.' años</p>
                    </td>
                    
                </tr>
                
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 6px solid #E7433D; background-color: #67C18F;">
                        <p style="font-size:12px"><b>INFORMACIÓN GENERAL:</b></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Sexo:</b> '.$sexo.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Fecha de Nacimiento:</b> '.$this->formatoFecha_DMA($paciente[0]->fecha_nacimiento).'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>CURP:</b> '.$paciente[0]->curp.'</p>
                    </td>
                    
                </tr>
                
                <tr>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Alergia:</b> '.$paciente[0]->alergia.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Estado civil:</b> '.$paciente[0]->estadocivil.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Grupo sanguineo:</b> '.$paciente[0]->tiposangre.'</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Telefono:</b> '.$paciente[0]->telefono.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Domicilio:</b> '.$this->obtenerDomicilio($paciente).'</p>
                    </td>
                </tr>
                
                
                
                
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 6px solid #E7433D; background-color: #67C18F;">
                        <p style="font-size:12px"><b>HISTORIALES:</b></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:12px; color:red;"><b><i>1. Antecedentes Gineco-Obstetricos:</i></b></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 0.5px solid #C7C7C7;">
                        <p style="font-size:12px"><b>Características de la menstruación:</b></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Menarquia:</b> '.$AntecedentesGinecobstetricos[0]->menarquia.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Duración:</b> '.$this->evaluaDuracion($AntecedentesGinecobstetricos[0]->duracion).' </p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Cantidad de sangre:</b> '.$AntecedentesGinecobstetricos[0]->cantidad_sangre.'</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Frecuencia:</b> '.$AntecedentesGinecobstetricos[0]->frecuencia.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Presencia del dolor:</b> '.$AntecedentesGinecobstetricos[0]->presencia_dolor.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Presencia de otras secresiones vaginales:</b> '.$AntecedentesGinecobstetricos[0]->otras_secreciones_vag.'</p>
                        
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px;">
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 0.5px solid #C7C7C7;">
                        <p style="font-size:12px"><b>Actividad Sexual:</b></p>
                        
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Vida sexual activa:</b> '.$AntecedentesGinecobstetricos[0]->vida_sexual_activa.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Edad a la que inició vida sexual activa:</b> '.$this->evaluaIncioVidaSexual($AntecedentesGinecobstetricos[0]->edad_inicio_sexual).'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Número de compañeros sexuales:</b> '.$AntecedentesGinecobstetricos[0]->numero_companeros_sexuales.'</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Método anticonceptivo:</b> '.$AntecedentesGinecobstetricos[0]->metodo_anticonceptivo.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Relaciones:</b> '.$AntecedentesGinecobstetricos[0]->tipo_relaciones.'</p>
                    </td>
                    <td colspan="2" colspan="3" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Enfermedades de transmisión sexual:</b> '.$AntecedentesGinecobstetricos[0]->enfermedades_trans_sex.'</p>
                        
                    </td>
                </tr>
                
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px;">
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 0.5px solid #C7C7C7;">
                        <p style="font-size:12px"><b>Información de embarazos previos:</b></p>
                        
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Gestaciones:</b> '.$AntecedentesGinecobstetricos[0]->gestaciones.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Partos:</b> '.$AntecedentesGinecobstetricos[0]->partos.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Abortos:</b> '.$AntecedentesGinecobstetricos[0]->abortos.'</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Cesáreas:</b> '.$AntecedentesGinecobstetricos[0]->cesareas.'</p>
                    </td>
                    <td colspan="4" style="border: 0px 0px 0px 0px;">
                        <p style="font-size:11px"><b>Antecedentes perinatales de importancia:</b> '.$AntecedentesGinecobstetricos[0]->ant_perinatales_de_imp.'</p>
                        
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px;">
                    
                    </td>
                </tr>
                
            </table>
          </div>
        </div>
        
        <div class="panel panel-primary" style="width:814px; height:1056px;">
          <div class="panel-body">
            <table>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:12px; color:red;"><b><i>2. Antecedentes Heredo-Familiares</i></b></p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">Padre</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">Madre</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">Abuelos paternos</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">Abuelos maternos</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">Hermanos</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Diabetes Mellitus</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'diabetes_mellitus',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'diabetes_mellitus',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'diabetes_mellitus',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'diabetes_mellitus',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'diabetes_mellitus',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Hipertensión Arterial Sistémica</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'hiper_sistemica',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'hiper_sistemica',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'hiper_sistemica',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'hiper_sistemica',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'hiper_sistemica',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Obesidad</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'obesidad',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'obesidad',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'obesidad',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'obesidad',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'obesidad',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Neoplasias</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'neoplasias',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'neoplasias',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'neoplasias',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'neoplasias',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'neoplasias',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Malformaciones hereditarias / congénitas</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'malformaciones',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'malformaciones',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'malformaciones',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'malformaciones',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'malformaciones',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Alergias</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'alergias',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'alergias',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'alergias',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'alergias',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'alergias',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Enfermedades psiquiatricas</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'psiquiatricas',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'psiquiatricas',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'psiquiatricas',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'psiquiatricas',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'psiquiatricas',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Enfermedades neurológicas</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'neurologicas',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'neurologicas',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'neurologicas',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'neurologicas',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'neurologicas',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Enfermedades cardiovasculares</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'cardiovasculares',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'cardiovasculares',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'cardiovasculares',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'cardiovasculares',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'cardiovasculares',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Enfermedades broncopulmonares</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'broncopulmonares',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'broncopulmonares',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'broncopulmonares',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'broncopulmonares',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'broncopulmonares',1).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Enfermedades tiroideas</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'tiroideas',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'tiroideas',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'tiroideas',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'tiroideas',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'tiroideas',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Enfermedades renales</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'renales',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'renales',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'renales',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'renales',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'renales',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Enfermedades osteoarticulares</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'osteoarticulares',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'osteoarticulares',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'osteoarticulares',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'osteoarticulares',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'osteoarticulares',5).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 1px;" align="right">
                        <p style="font-size:11px">Enfermedades infectocontagiosas</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'infectocontagiosas',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'infectocontagiosas',2).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'infectocontagiosas',3).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'infectocontagiosas',4).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:11px">'.$this->check($AntecedentesHeredoFamiliares,'infectocontagiosas',5).'</p>
                    </td>
                </tr>
                
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 1px;" >
                        <p style="font-size:11px"><b>Anotaciones:</b> '.$AntecedentesHeredoFamiliares[0]->anotaciones.'</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 1px;" align="center">
                        
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:12px; color:red;"><b><i>3. Antecedentes Personales Patológicos </i></b></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 0.5px solid #C7C7C7;">
                        <p style="font-size:12px"><b>Generales:</b></p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Alergicos:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'alergicos',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Hospitalizaciones:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'hospitalizaciones',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Quirúrgicos:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'quirurgicos',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Traumáticos:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'traumaticos',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px width:135px;;" >
                        <p style="font-size:11px"><b>Transfusionales:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'transfusionales',1).'</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px;">
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 0.5px solid #C7C7C7;">
                        <p style="font-size:12px"><b>Adicciones:</b></p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Alcoholismo:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'alcoholismo',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Tabaquismo:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'tabaquismo',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Otras sustancias psicoactivas:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'otras_sus',1).'</p>
                    </td>
                </tr>
                
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px;">
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 0.5px solid #C7C7C7;">
                        <p style="font-size:12px"><b>Patologias exantemáticas:</b></p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Exantema súbito:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'exantema',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Roséola escarlatina:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'roseola',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Rubéola:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'rubeola',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Sarampión:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'sarampion',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Varicela:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'varicela',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Otra patología exantemática:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'otras_pato_exant',1).'</p>
                    </td>
                </tr>
                <br>
                <br>
                <br>
            </table>
          </div>
        </div> 
        
        <div class="panel panel-primary" style="width:814px; height:1056px;">
          <div class="panel-body">
            <table>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 0.5px solid #C7C7C7;">
                        <p style="font-size:12px"><b>Patologías Infectocontagiosas:</b></p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Faringoamigdalitis:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'faringoamigdalitis',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Fiebre Reumática:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'fiebre_reumatica',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Hepatitis:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'hepatitis',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Parasitosis:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'parasitosis',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Tifoidea:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'tifoidea',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Transmision sexual:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'transmision_sexual',1).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Tuberculosis:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'tuberculosis',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Otra patología infectocontagiosa:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'otras_pato_infecto',1).'</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px;">
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 0.5px solid #C7C7C7;">
                        <p style="font-size:12px"><b>Patologías Crónico-Degenerativas:</b></p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Diabetes Mellitus:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'diabetes_mellitus',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Hipertensión Arterial Sistémica:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'hipert_art_sis',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Obesidad:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'obesidad',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Neoplásicas:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'neoplasicas',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Artritis Reumatoide:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'artritis_reumatoide',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Enfermedad de Gota:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'enfermedad_de_gota',1).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Enfermedades psiquiatricas:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'enfer_psiquiatricas',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Enfermedades del sistema nervioso:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'enfer_sist_nervio',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Enfermedades del sistema cardiovascular:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'enfer_sist_cardiov',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Enfermedades del sistema respiratorio:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'enfer_sist_respir',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Enfermedades del sistema gastrointestinal:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'enfer_sist_gastroint',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Enfermedades del sistema endocrino:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'enfer_sist_endocri',1).'</p>
                    </td>
                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Enfermedades del sistema urinario:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'enfer_sist_urin',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Enfermedades del sistema musculoesquelético:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'enfer_sist_musculoes',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Enfermedades del sistema tegumentarior:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'enfer_sist_tegum',1).'</p>
                    </td>
                    <td style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Otra enfermedad crónico-degenerativa:</b> '.$this->checkSiNo($AntecedentesPersonalesPatologicos,'otra_enfer_cron_degen',1).'</p>
                    </td>
                    
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; width:135px;" >
                        <p style="font-size:11px"><b>Observaciones:</b> '.$AntecedentesPersonalesPatologicos[0]->observaciones.'</p>
                    </td>
                    </td>
                    
                </tr>

                  <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px;">
                    </td>
                </tr>
                
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 1px;" align="center">
                        <p style="font-size:12px; color:red;"><b><i>4. Antecedentes Personales no Patológicos </i></b></p>
                    </td>
                </tr>
                  <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px;">
                    </td>
                </tr>
                <tr>
                    <td  colspan="2" style="border: 0px 0px 0px 0px; ">
                        <p style="font-size:12px;"><b>Tabaquismo:</b> '.$AntecedentesPersonalesNoPatologicos[0]->tabaquismo.'</p>
                    </td>
                    <td colspan="1" style="border: 0px 0px 0px 0px; ">
                        <p style="font-size:12px;"><b>Alcoholismo:</b> '.$AntecedentesPersonalesNoPatologicos[0]->alcoholismo.'</p>
                    </td>
                    <td colspan="1" style="border: 0px 0px 0px 0px; ">
                        <p style="font-size:12px;"><b>Inmunizaciones:</b> '.$AntecedentesPersonalesNoPatologicos[0]->inmunizaciones.'</p>
                    </td>
                    <td colspan="2" style="border: 0px 0px 0px 0px; ">
                        <p style="font-size:12px;"><b>Conciencia de enfermedad:</b> '.$AntecedentesPersonalesNoPatologicos[0]->conciencia.'</p>
                    </td>

                    
                    
                   
                </tr>
                <tr>
                    <td colspan="1" style="border: 0px 0px 0px 0px; ">
                        <p style="font-size:12px;"><b>Escolaridad:</b> '.$AntecedentesPersonalesNoPatologicos[0]->escolaridad.'</p>
                    </td>
                    <td colspan="1" style="border: 0px 0px 0px 0px; ">
                        <p style="font-size:12px;"><b>Tipo de vivienda:</b> '.$AntecedentesPersonalesNoPatologicos[0]->vivienda.'</p>
                    </td>
                    <td  colspan="2" style="border: 0px 0px 0px 0px; ">
                        <p style="font-size:12px;"><b>Uso de tiempo libre:</b> '.$AntecedentesPersonalesNoPatologicos[0]->tiempo_libre.'</p>
                    </td>
                    
                    <td colspan="2" style="border: 0px 0px 0px 0px; ">
                        <p style="font-size:12px;"><b>Ocupacion actual:</b> '.$AntecedentesPersonalesNoPatologicos[0]->ocupacion.'</p>
                    </td>
                    
                </tr>

                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; ">
                        <p style="font-size:12px;"><b>Habitos higienicos:</b> '.$AntecedentesPersonalesNoPatologicos[0]->higienicos.'</p>
                    </td>

                </tr>
                <tr>
                    <td style="border: 0px 0px 0px 0px; ">
                    </td>
                </tr>
                
            </table>
          </div>
        </div>'.
                $this->imprimirListaDeconsultas($futuro_POST).''.
                $this->fotosgrafiasDelPaciente($futuro_POST).''.
                $this->constanciasDelPaciente($futuro_POST);
        
        $hoy = date("dmyhis");
        $pdfFilePath = "expediente".$hoy.".pdf"; //Nombre del archivo
        $this->load->library('M_pdf');
        $mpdf = new mPDF('c', 'Letter');// ('carta', 'tamaño A4')
        $css = file_get_contents(base_url('assets/css/bootstrap.css')); // cargar estilo
        $mpdf->WriteHTML($css,1);
        $mpdf->WriteHTML($html);
        $mpdf->Output($pdfFilePath, "I");
    }



    public function obtenerDomicilio($paciente){
        if($paciente!=null){
           $concatena="";
           $this->load->model('medico/Modelo_consulta');

           $domicilio= $paciente[0]->domicilio;
           $localidad= $paciente[0]->localidad;
           $municipio= $paciente[0]->municipio;
           $estado_D=  $paciente[0]->estado_D;

           if($domicilio!=null){

            $concatena.=$domicilio;
           }
            if($localidad!=null and $estado_D!=null and $municipio!=null){

        
                $localidad=$this->Modelo_consulta->getLocalidad($estado_D,$municipio,$localidad);
                
                $concatena.=', '.$localidad[0]->nombre;
           }
            if($municipio!=null){
                $municipio=$this->Modelo_consulta->getMunicipio($estado_D,$municipio);
               
                $concatena.=', '.$municipio[0]->nombre_municipio;
           }
            if($estado_D!=null){
                $estado_D=$this->Modelo_consulta->getEstado($estado_D);
                

            $concatena.=', '.$estado_D[0]->estado;
           }
           return $concatena;
        }
        else{
            return '';
        }

    }


    public function evaluaDuracion($duracion){
        if($duracion!=null){
            return $duracion.' días';
        }
        else{
            return '';
        }

    }

    public function evaluaIncioVidaSexual($edad){
        if($edad!=null){
            return $edad.' años';
        }
        else{
            return '';
        }

    }
    
    

    public function formatoFecha_DMA($fecha){
        $arrayFecha = explode("-", $fecha);
        $anio=$arrayFecha[0];
        $mes=$arrayFecha[1];
        $dia=$arrayFecha[2];
        return $dia.'/'.$mes.'/'.$anio;
        //Encontrando el mes
    }

    public function adjuntarDiagnosticos($id_consulta = ''){
        $this->load->model('medico/Modelo_consulta');
        
        $diagnostico=$this->Modelo_consulta->getDiagnosticosDelaConsulta($id_consulta);

        $concatena='';
        if($diagnostico!=null){
            for ($i = 0; $i < count($diagnostico); $i++){//------------------
                $concatena.='<p>'.'<b>'.$diagnostico[$i]->nombre.'</b> ('.$diagnostico[$i]->diagnostico.')'.' Comentario: '.$diagnostico[$i]->comentario.'</p>';
        }//------------------------------------------------------------
            return $concatena;
        }
        else{
            return $concatena;
        }

    }

//---------------------------------------------------------------------------
    public function adjuntarDiagnosticosAbiertos($id_consulta = ''){
        $this->load->model('medico/Modelo_consulta');
        
        $diagnostico=$this->Modelo_consulta->getDiagnosticosDelaConsultaAbierto($id_consulta);

        $concatena='';
        if($diagnostico!=null){
            for ($i = 0; $i < count($diagnostico); $i++){//------------------
                $concatena.='<p>'.'<b>'.$diagnostico[$i]->diagnostico.'</b> '.' Observación: '.$diagnostico[$i]->observacion.'</p>';
        }//------------------------------------------------------------
            return $concatena;
        }
        else{
            return $concatena;
        }

    }
//----------------------------------------------------------------------------



    //-----------------------------------------------
    public function obtenerMedicoDeConsulta($id_medico){
        $this->load->model('administrador/Modelo_medicos');
        return $this->Modelo_medicos->getUser_Medico();
    }

    //---------------------------------------------

    public function formatoFechaHora($fechaHora){
         $fechaYhoraDeConsulta = new DateTime($fechaHora);
        return $fechaYhoraDeConsulta->format('d/m/Y - g:i A');
    }

    public function imprimirListaDeconsultas ($curp)
    {
        

        $this->load->model('medico/Modelo_consulta');
        
        $consultas=$this->Modelo_consulta->getConsultasDelPacienteGroupByConsulta($curp);
        //$consultasAbiertas=$this->Modelo_consulta->getConsultasAbiertasDelPacienteGroupByConsulta($curp);

     $iniciohoja='
            <div class="panel panel-primary" style="width:814px; height:1056px;">
              <div class="panel-body">
                <TABLE >
                    <TR>
                        <TD COLSPAN=6 style="  border: 0px 0px 0px 0px; border-bottom: 6px solid #E7433D; background-color: #67C18F;">
                        <p style="font-size:12px"><b>CONSULTAS REGISTRADAS:</b></p>
                        </TD>
                    </TR>

                    <tr>
                       <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 1.5px solid #08298A;">
                       </td>
                    </tr>';
     $cierreHoja='
                </table>

              </div>
            </div>';

        $hoja="";
        $addConsulta = "";
        $nuevaHojaMultiploDe2=2;
        $contador=1;

        $contadorColum=0;
        
        if($consultas!=false)
        {//-------------------------------------------------------------

            for ($i = 0; $i < count($consultas); $i++)
            {
               
      $addConsulta.='<tr >
                           <td colspan="6" style="border: 0px 0px 0px 0px; ">
                           
                           <p style="font-size:12px">'.'<b>Fecha de consulta: </b> '.$this->formatoFechaHora($consultas[$i]->fecha_consulta).'</p>
                           <p style="font-size:12px">'.'<b>Atendió Dr(a): </b> '.$this->obtenerMedicoDeConsulta($consultas[$i]->id_medico)[0]->nombre.' '.$this->obtenerMedicoDeConsulta($consultas[$i]->id_medico)[0]->app.' '.$this->obtenerMedicoDeConsulta($consultas[$i]->id_medico)[0]->apm.'         <b>Cédula profesional:</b> '.$this->obtenerMedicoDeConsulta($consultas[$i]->id_medico)[0]->cedula.'</p>
                           </td>
                    </tr>
                    <tr>
                           <td colspan="6" style="border: 0px 0px 0px 0px;">
                           <hr style="margin-top: 0em; margin-bottom: 0em;" border-bottom: 5px>
                           </td>
                    </tr>

                       <tr>
                           <td colspan="6" style="border: 0px 0px 0px 0px;">
                           <p style="font-size:11px"><b>Signos vitales:</b></p>
                           </td>
                       </tr>

                    <TR>
                        <TD colspan="1"><p style="font-size:11px"><b>Peso (kg):</b> '.$this->existePeso($consultas[$i]->peso).'</p></TD>
                        <TD colspan="1"><p style="font-size:11px"><b>Altura (cm):</b> '.$this->existeAltura($consultas[$i]->altura).'</p></TD>
                        <TD colspan="1"><p style="font-size:11px"><b>IMC:</b> '.$this->existeIndice($consultas[$i]->indice_de_masa_corp).'</p></TD>
                        <TD colspan="1"><p style="font-size:11px"><b>Temperatura (*C):</b> '.$this->existeTemperatura($consultas[$i]->temperatura).'</p></TD>
                        <TD colspan="1"><p style="font-size:11px"><b>F. cardiaca(lat/min):</b> '.$this->existeFrecCardiaca($consultas[$i]->f_cardiaca).'</p></TD>
                    </TR>
                     <TR>
                        
                        <TD colspan="1"><p style="font-size:11px"><b>Glucosa (mg/dL):</b> '.$this->existeGlucosa($consultas[$i]->glucosa).'</p></TD>
                        <TD colspan="2"><p style="font-size:11px"><b>Escala de dolor (1-10):</b> '.$this->existeEscalaDolor($consultas[$i]->escala_del_dolor).'</p></TD>
                        
                        <TD colspan="1"><p style="font-size:11px"><b>F. respiratoria(resp/min):</b> '.$this->existeFrecRespiratoria($consultas[$i]->f_respiratoria).'</p></TD>
                        <TD colspan="1"><p style="font-size:11px"><b>Pres. arterial (mmHg):</b> '.$this->existeFrecArterial($consultas[$i]->press_arterial).'</p></TD>

                    </TR>

                    <tr>
                           <td colspan="6" style="border: 0px 0px 0px 0px;">
                           <hr style="margin-top: 0em; margin-bottom: 0em;" border-bottom: 5px>
                           </td>
                    </tr>

                    <TR>
                        <TD colspan="1"> <p style="font-size:11px"><b>Motivos de la consulta: </b> </p></TD>
                        <TD colspan="5"> <p style="font-size:11px">'.$consultas[$i]->motivo.'</p></TD> 
                    </TR>
                    <TR>
                        <TD colspan="1"><p style="font-size:11px"><b>Exploración Física</b></p></TD>
                        <TD colspan="5"><p style="font-size:11px">'.$this->adjuntaExploracionFisicaDeLaConsulta($consultas[$i]->id_consulta).'</p></TD> 
                    </TR>
                    <TR>
                        <TD colspan="1"><p style="font-size:11px"><b>Diagnóstico:</b></p></TD>
                        <TD colspan="5"> <p style="font-size:11px">'.$this->adjuntaDiagnosticosDeLaConsulta($consultas[$i]->id_consulta).'</p></TD> 
                    </TR>
                    <TR>
                        <TD colspan="1"><p style="font-size:11px"><b>Tratamiento:</b></p></TD>
                        <TD colspan="5"><p style="font-size:11px; text-align: justify;"  >'.$this->adjuntaTratamientosDeLaConsulta($consultas[$i]->id_consulta).'</p></TD> 
                    </TR>
                    <tr>
                           <td colspan="6" style="border: 0px 0px 0px 0px;">
                           <hr style="margin-top: 0em; margin-bottom: 0em;" border-bottom: 5px>
                           </td>
                    </tr>
                    <TR>
                        <TD colspan="6"> <p style="font-size:11px"><b>Análisis de Laboratorio: </b> </p></TD>
                        
                    </TR>';
          
                    $estLab = $this->adjuntarEstudiosLaboratorio($consultas[$i]->id_consulta);
                    $porciones1 = explode("#",$estLab );
                    for ($b = 0; $b < count($porciones1); $b++)
                    {
                       $addConsulta.='<TR>
                        <TD colspan="6"> <p style="font-size:11px">'.$porciones1[$b].'</p></TD> 
                    </TR>'; 
                    }
                    
                    $addConsulta.= '<tr>
                           <td colspan="6" style="border: 0px 0px 0px 0px;">
                           <hr style="margin-top: 0em; margin-bottom: 0em;" border-bottom: 5px>
                           </td>
                    </tr>
                    <TR>
                        <TD colspan="6"> <p style="font-size:11px"><b>Pruebas de Gabinete: </b> </p></TD>
                        
                    </TR>';


                    $estGab = $this->adjuntarEstudiosGabinete($consultas[$i]->id_consulta);
                    $porciones2 = explode("#",$estGab );
                    for ($f = 0; $f < count($porciones2); $f++)
                    {
                       $addConsulta.='<TR>
                        <TD colspan="6"> <p style="font-size:11px">'.$porciones2[$f].'</p></TD> 
                    </TR>'; 
                    }
                    

                    $addConsulta.='<tr>
                       <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 1.5px solid #08298A;">
                       </td>
                    </tr>';
                      
            $hoja.=$iniciohoja.$addConsulta.$cierreHoja;
            $addConsulta="";
            
            }//------------------------------------------------------------
        }//-------------------------------------------------------------
        else{
            $hoja.=$iniciohoja.$cierreHoja;
        }
        
        return $hoja;
    }

    public function adjuntaDiagnosticosDeLaConsulta($id_consulta){
        $this->load->model('medico/Modelo_consulta');


        if($this->Modelo_consulta->getDiagnosticosDelaConsulta($id_consulta)!=false){
            return $this->adjuntarDiagnosticos($id_consulta);
        }
        else{
            return $this->adjuntarDiagnosticosAbiertos($id_consulta);
        }
    }

    public function adjuntaTratamientosDeLaConsulta($id_consulta){
        $this->load->model('medico/Modelo_consulta');

        if($this->Modelo_consulta->getTratamientosDelaConsulta($id_consulta)!=false){
            return $this->adjuntarTratamientos($id_consulta);
        }
        else{
            return $this->adjuntarTratamientosAbiertos($id_consulta);
        }
    }

    public function adjuntaExploracionFisicaDeLaConsulta($id_consulta){
         $this->load->model('medico/Modelo_consulta');
        
        $exploracion_fisica=$this->Modelo_consulta->adjuntaExploracionFisicaDeLaConsulta($id_consulta);

        $concatena='';
        $conta=1;
        if($exploracion_fisica!=null){
            for ($i = 0; $i < count($exploracion_fisica); $i++){//------------------
                $concatena.='<p align="justify">'.'<strong>'.$conta.'.- </strong><b>'.$exploracion_fisica[$i]->nombre_de_la_region.'</b>('.$exploracion_fisica[$i]->nombre_de_la_zona.') : '.$exploracion_fisica[$i]->observaciones;
                


                $conta=$conta+1;

            }//------------------------------------------------------------
            return $concatena;

        }
        else{
            return $concatena;
        }

    }
    
    public function adjuntarEstudiosLaboratorio($id_consulta){
         $this->load->model('medico/Modelo_consulta');
        
        $estudiosLab = $this->Modelo_consulta->getEstudiosLaboratorio($id_consulta);
        $concatena='';
        if($estudiosLab!=null){
            
            $concatena.=$estudiosLab[0]->estudiosdelab;
            return $concatena;
        }
        else{
            return $concatena;
        }

    }
    
    public function adjuntarEstudiosGabinete($id_consulta){
         $this->load->model('medico/Modelo_consulta');
        
        $estudiosGab = $this->Modelo_consulta->getEstudiosGabinete($id_consulta);

        $concatena='';
        if($estudiosGab!=null){
            $concatena.=$estudiosGab[0]->estudiosdegab;
            return $concatena;
        }
        else{
            return $concatena;
        }

    }

    //---------------------------------------------------------
        public function adjuntarTratamientosAbiertos1($id_consulta){
         $this->load->model('medico/Modelo_consulta');
        
        $tratamientos=$this->Modelo_consulta->getTratamientosAbiertosDelaConsulta($id_consulta);

        $concatena='';
        $conta=1;
        if($tratamientos!=null){
            for ($i = 0; $i < count($tratamientos); $i++){//------------------
                $concatena.='<p >'.'<strong>'.$conta.'.- </strong><b>'.$tratamientos[$i]->medicamento.'</b><p align="justify"><strong>Frecuencia y duracíon del tratamiento: </strong>'.$tratamientos[$i]->descripcion_del_tratamiento.' <strong> Vía de administración: </strong>'.$tratamientos[$i]->via_de_administracion.' <strong> Indicaciones generales: </strong>'.$tratamientos[$i]->indicaciones_grales.'</p>';
                $conta=$conta+1;

            }//------------------------------------------------------------
            //echo json_encode($result);
             echo json_encode($concatena);

        }
        else{
             echo json_encode($concatena);
        }

    }

        public function adjuntarTratamientos1($id_consulta){
         $this->load->model('medico/Modelo_consulta');
        
        $tratamientos=$this->Modelo_consulta->getTratamientosDelaConsulta($id_consulta);

        $concatena='';
        $conta=1;
        if($tratamientos!=null){
            for ($i = 0; $i < count($tratamientos); $i++){//------------------
                $concatena.='<p align="justify">'.'<strong>'.$conta.'.- </strong><b>'.$tratamientos[$i]->nombre_generico.'</b> ('.$tratamientos[$i]->forma_farmaceutica.' -'.$tratamientos[$i]->concentracion.') : '.$tratamientos[$i]->dosis_preescrita.' '.$tratamientos[$i]->forma_farmaceutica.' '.$tratamientos[$i]->frec_de_la_dosis;
                if($tratamientos[$i]->tiempo_indefinido=='1'){

                    $concatena.='<b> por un indefinido.</b></p>';
                }
                else{

                     $concatena.=' hasta el d&iacute;a '.$this->formatoFecha_DMA($tratamientos[$i]->fin_tratamiento).'.</p>';
                }


                $conta=$conta+1;

            }//------------------------------------------------------------
             echo json_encode($concatena);

        }
        else{
             echo json_encode($concatena);
        }

    }

        public function adjuntarDiagnosticos1($id_consulta = ''){
        $this->load->model('medico/Modelo_consulta');
        
        $diagnostico=$this->Modelo_consulta->getDiagnosticosDelaConsulta($id_consulta);

        $concatena='';
        if($diagnostico!=null){
            for ($i = 0; $i < count($diagnostico); $i++){//------------------
                $concatena.='<p>'.'<b>'.$diagnostico[$i]->nombre.'</b> ('.$diagnostico[$i]->diagnostico.')'.' Comentario: '.$diagnostico[$i]->comentario.'</p>';
        }//------------------------------------------------------------
             echo json_encode($concatena);
        }
        else{
             echo json_encode($concatena);
        }

    }

    //----------------------------------------------
        public function adjuntarDiagnosticosAbiertos1($id_consulta = ''){
        $this->load->model('medico/Modelo_consulta');
        
        $diagnostico=$this->Modelo_consulta->getDiagnosticosAbiertosDelaConsulta($id_consulta);

        $concatena='';
        if($diagnostico!=null){
            for ($i = 0; $i < count($diagnostico); $i++){//------------------
                $concatena.='<p>'.'<b>'.$diagnostico[$i]->diagnostico.'</b> '.' Observación: '.$diagnostico[$i]->observacion.'</p>';
        }//------------------------------------------------------------
             echo json_encode($concatena);
        }
        else{
             echo json_encode($concatena);
        }

    }


    public function existePeso($peso){
        if($peso!=0){
            return $peso.'';
        }
        else{
            '';
        }

    }

    public function existeAltura($altura){
        if($altura!=0){
            return $altura.'';
        }
        else{
            '';
        }

    }

    public function existeIndice($indice){
        if($indice!=0){
            return $indice.'';
        }
        else{
            '';
        }

    }

    public function existeTemperatura($temperatura){
        if($temperatura!=0){
            return $temperatura.'';
        }
        else{
            '';
        }

    }

    public function existeEscalaDolor($escalaDolor){
        if($escalaDolor!=0){
            return $escalaDolor;
        }
        else{
            '';
        }

    }

    public function existeGlucosa($glucosa){
        if($glucosa!=null){
            return $glucosa;
        }
        else{
            '';
        }

    }

     public function existeFrecRespiratoria($f_respiratoria){
        if($f_respiratoria!=null){
            return $f_respiratoria;
        }
        else{
            '';
        }

    }

    public function existeFrecArterial($f_arterial){
        if($f_arterial!=null){
            return $f_arterial;
        }
        else{
            '';
        }

    }

    public function existeFrecCardiaca($frecuencia_c){
        if($frecuencia_c!=null){
            return $frecuencia_c;
        }
        else{
            '';
        }

    }

    public function check($datos,$valorSeleccionado,$indice){

        $ecode=json_encode($datos);
        $decode=json_decode($ecode);

         // Orden del reemplazo
        $str     = $decode[0]->$valorSeleccionado;
        $order   = array('[','"',']');
        $replace = '';

        // Procesa primero \r\n así no es convertido dos veces.
        $newstr = str_replace($order, $replace, $str);
        $arrayDatos=explode(",",$newstr);

        if (in_array($indice, $arrayDatos)) {
            return '<input type="radio"  checked="checked" >'; //&#10003;
        }
        else{
            return '<input type="radio" >';
        }
    }

    public function checkSiNo($datos,$valorSeleccionado,$indice){

        $ecode=json_encode($datos);
        $decode=json_decode($ecode);

         // Orden del reemplazo
        $str     = $decode[0]->$valorSeleccionado;
        $order   = array('[','"',']');
        $replace = '';

        // Procesa primero \r\n así no es convertido dos veces.
        $newstr = str_replace($order, $replace, $str);
        $arrayDatos=explode(",",$newstr);

        if (in_array($indice, $arrayDatos)) {
            return 'Si';
        }
        else{
            return 'No';
        }
    }

 


        

    public function constanciasDelPaciente($curp = '')
    {
        $constancias = $this->Model_Historial->constanciasDelPaciente($curp);

         $iniciohoja=
         '<div class="panel panel-primary" style="width:814px; height:1056px;">
          <div class="panel-body">
            <table >
                <tr>
                    <td colspan="6" style="  border: 0px 0px 0px 0px; border-bottom: 6px solid #E7433D; background-color: #67C18F;">
                        <p style="font-size:12px"><b>CONSTANCIAS Y ANEXOS:</b></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; ">
                        <!--Espacio en blanco-->
                    </td>
                </tr>
                
               ';   
        $cierreHoja='
                
               
            </table>
            <br>
            <br>
            <br>
          </div>
        </div>';


        $hoja="";
        $addConstancia = "";
        $nuevaHojaMultiploDe6=6;
        $contador=1;
        $this->load->model('medico/Model_Historial');
        $constancias = $this->Model_Historial->constanciasDelPaciente($curp);
        $contadorColum=0;
        
        for ($i = 0; $i < count($constancias); $i++)
        {
            if($i==0){
                $nuevaHojaMultiploDe6=$nuevaHojaMultiploDe6*$contador;
                $contador=$contador+1;

            }

            while($i<$nuevaHojaMultiploDe6 && $i < count($constancias)){

                if($contadorColum<3){
                    if($contadorColum==0){
                         $addConstancia.='<tr>';
                    }

                    $addConstancia.=
                     '<td  style="border: 0px 0px 0px 0px; ">'.
                        "<img src='".base_url('uploads/constancias/'.$constancias[$i]->nombre_archivo)."' height='380' width='248' style='border: 0px;'> <br><br> <p style='font-size:12px'>".$constancias[$i]->fecha_inclusion."</p>".
                     '</td>';

                    if($contadorColum==2){
                        $addConstancia.='</tr>';
                    }

                    $contadorColum=$contadorColum+1;
                }
                else{

                     if($contadorColum==3){
                         $addConstancia.='<tr>';
                    }

                    $addConstancia.=
                     '<td  style="border: 0px 0px 0px 0px; ">'.
                        "<img src='".base_url('uploads/constancias/'.$constancias[$i]->nombre_archivo)."' height='380' width='248' style='border: 0px;'> <br><br> <p style='font-size:12px'>".$constancias[$i]->fecha_inclusion."</p>".
                     '</td>';
                     if($contadorColum==5){
                        $addConstancia.='</tr>';
                     }

                     $contadorColum=$contadorColum+1;


                }


                    $i++;
                    if($i==$nuevaHojaMultiploDe6){
                        $contadorColum=0;
                    }

            }

                $hoja.=$iniciohoja.$addConstancia.$cierreHoja;
                $addConstancia="";
                $nuevaHojaMultiploDe6=$nuevaHojaMultiploDe6*$contador;
                $contador=$contador+1;
                $i=$i-1;


            
        }
         if(count($constancias)==0){
            $hoja.=$iniciohoja.$cierreHoja;

        }
        
        return $hoja;
    }
    
  

        public function fotosgrafiasDelPaciente($curp = '')
    {
        //$this->load->model('medico/Model_Historial');
        $fotografias = $this->Model_Historial->fotosgrafiasDelPaciente($curp);

        $iniciohoja=
        '<div class="panel panel-primary" style="width:814px; height:1056px;">
          <div class="panel-body">
            <table>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; border-bottom: 6px solid #E7433D; background-color: #67C18F;">
                        <p style="font-size:12px"><b>FOTOGRAFIAS DEL PACIENTE:</b></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="6" style="border: 0px 0px 0px 0px; ">
                        <!--Espacio en blanco-->
                    </td>
                </tr>';

                $cierreHoja='
                
            </table>
            <br>
            <br>
            <br>
          </div>
        </div>';



        $hoja="";
        $addFotografia = "";
        $nuevaHojaMultiploDe6=6;
        $contador=1;
        //$this->load->model('medico/Model_Historial');
        //$fotografias = $this->Model_Historial->constanciasDelPaciente($curp);
        $contadorColum=0;
        
        for ($i = 0; $i < count($fotografias); $i++)
        {
            if($i==0){
                $nuevaHojaMultiploDe6=$nuevaHojaMultiploDe6*$contador;
                $contador=$contador+1;

            }

            while($i<$nuevaHojaMultiploDe6 && $i < count($fotografias)){

                if($contadorColum<3){
                    if($contadorColum==0){
                         $addFotografia.='<tr>';
                    }

                    $addFotografia.=
                     '<td  style="border: 0px 0px 0px 0px; ">'.
                        "<img src='".base_url('uploads/fotografias/'.$fotografias[$i]->nombre_archivo)."' height='256' width='384' style='border: 0px;'> <br><br> <p style='font-size:12px'>".$this->formatoFechaHora($fotografias[$i]->fecha_inclusion)."</p>".
                     '</td>';

                    if($contadorColum==2){
                        $addFotografia.='</tr>';
                    }

                    $contadorColum=$contadorColum+1;
                }
                else{

                     if($contadorColum==3){
                         $addFotografia.='<tr>';
                    }

                    $addFotografia.=
                     '<td  style="border: 0px 0px 0px 0px; ">'.
                        "<img src='".base_url('uploads/fotografias/'.$fotografias[$i]->nombre_archivo)."' height='256' width='384' style='border: 0px;'> <br><br> <p style='font-size:12px'>".$this->formatoFechaHora($fotografias[$i]->fecha_inclusion)."</p>".
                     '</td>';
                     if($contadorColum==5){
                        $addFotografia.='</tr>';
                     }

                     $contadorColum=$contadorColum+1;


                }


                    $i++;
                    if($i==$nuevaHojaMultiploDe6){
                        $contadorColum=0;
                    }

            }

                $hoja.=$iniciohoja.$addFotografia.$cierreHoja;
                $addFotografia="";
                $nuevaHojaMultiploDe6=$nuevaHojaMultiploDe6*$contador;
                $contador=$contador+1;
                $i=$i-1;


            
        }

        if(count($fotografias)==0){
            $hoja.=$iniciohoja.$cierreHoja;

        }
        
        return $hoja;
    }
    




    public function imprimirNotaPreoperatoriayValoracionPreanestesicaPDF()
    {
        $datos = $this->input->post();
        if(isset($datos))
        {
            $campo1 = $datos['campo1'];
            $campo2 = $datos['campo2'];
            $campo3 = $datos['campo3'];
            $campo4 = $datos['campo4'];
            $campo5 = $datos['campo5'];
            $campo6 = $datos['campo6'];
            $campo7 = $datos['campo7'];
            $campo8 = $datos['campo8'];
            $campo9 = $datos['campo9'];
            $campo10 = $datos['campo10'];
            $campo11 = $datos['campo11'];
            $campo12 = $datos['campo12'];
            $campo13 = $datos['campo13'];
            $campo14 = $datos['campo14'];
            $campo15 = $datos['campo15'];
            $campo16 = $datos['campo16'];
            $campo17 = $datos['campo17'];
            $campo18 = $datos['campo18'];
            $campo19 = $datos['campo19'];
            $campo20 = $datos['campo20'];
            $campo21 = $datos['campo21'];
            $campo22 = $datos['campo22'];
            $campo23 = $datos['campo23'];
            $campo24 = $datos['campo24'];
            $campo25 = $datos['campo25'];
            $campo26 = $datos['campo26'];
            $campo27 = $datos['campo27'];
            $campo28 = $datos['campo28'];
            $campo29 = $datos['campo29'];
            
            $campo40 = $datos['campo40'];
            $campo41 = $datos['campo41'];
            $campo42 = $datos['campo42'];
            $campo43 = $datos['campo43'];
            $campo44 = $datos['campo44'];
            $campo45 = $datos['campo45'];
            $campo46 = $datos['campo46'];
            $campo47 = $datos['campo47'];
            $campo48 = $datos['campo48'];
            $campo49 = $datos['campo49'];
            $campo50 = $datos['campo50'];
            $campo51 = $datos['campo51'];
            $campo52 = $datos['campo52'];
            $campo53 = $datos['campo53'];
            $campo54 = $datos['campo54'];
            
        }

        if ($campo15 === 'Bueno')
        {
            $bueno = 'X';
            $delicado = '';
            $grave = '';
        }
        if ($campo15 === 'Delicado')
        {
            $bueno = '';
            $delicado = 'X';
            $grave = '';
        }
        if ($campo15 === 'Grave')
        {
            $bueno = '';
            $delicado = '';
            $grave = 'X';
        }
        
        
        
        if ($campo17 === 'Tabaquismo')
        {
            $tabaquismo = 'X';
            $alcoholismo = '';
            $otrasadicciones = '';
        }
        if ($campo17 === 'Alcoholismo')
        {
            $tabaquismo = '';
            $alcoholismo = 'X';
            $otrasadicciones = '';
        }
        if ($campo17 === 'Otrasadicciones')
        {
            $tabaquismo = '';
            $alcoholismo = '';
            $otrasadicciones = 'X';
        }
        $html = '
        <div class="panel panel-primary" style="width:792px; height:1122px;">
          <div class="panel-body">
            <table>
                <tr>
                    <td style="width:250px; padding: 10px;" align="center">
                        <i>Doctor:'.$campo1.'</i><br><i>Cedula: '.$campo2.'</i>
                    </td>
                    
                    <td rowspan="2" style="width:300px;  padding: 10px;" align="center">
                        <p><i>Paciente: '.$campo3.'</i></p>
                        <p>'.$campo4.' años</p>
                        <p>'.$campo5.'</p>
                    </td>
                </tr>
                <tr>
                    <td style="width:250px; padding: 10px;" align="center">
                        <b><h4>NOTA PREOPERATORIA Y VALORACIÓN PREANESTESICA</h4></b>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <b><h6>NOTA PREOPERATORIA</h6></b>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                       <p>
                            Fecha:&nbsp;  <u>'.$campo6.'</u>  
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                            Hora:&nbsp;   <u>'.$campo7.'hrs</u>  
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                            Edad:&nbsp;   <u>'.$campo8.' años</u>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                            Sexo:&nbsp;   <u>'.$campo9.'</u>
                        </p>
                        <p>
                            Fecha cirugía:&nbsp;  <u>'.$campo10.'</u>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            Diagnostico:&nbsp;   <u>'.$campo11.'</u>
                        </p>
                        <p>
                            Plan quirúrgico:&nbsp;  <u>'.$campo12.'</u>
                        </p>
                    </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:100px; vertical-align: top; text-align:left;">
                        <p>Tipo de intervención quirúrgica</p>
                        <p>'.$campo13.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:100px; vertical-align: top; text-align:left;">
                        <p>Cuidados y plan terapeútico pre-operatorios</p>
                        <p>'.$campo14.'</p>
                   </td>
                </tr>
                
                <tr>
                    <td colspan="2" >
                       <p>
                            Estado preoperatorio:&nbsp;&nbsp;&nbsp; Bueno('.$bueno.')&nbsp;  Delicado('.$delicado.')&nbsp; Grave('.$grave.')&nbsp;
                        </p>
                        <p>
                            Pronóstico:&nbsp;<u>'.$campo16.'</u>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tabaquismo('.$tabaquismo.')&nbsp; Alcoholismo('.$alcoholismo.')&nbsp; Otras adicciones('.$otrasadicciones.')&nbsp;
                        </p>
                        <p>
                            Nombre completo de quien elaboró la nota:&nbsp;  <u>'.$campo18.'</u>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            Firma:&nbsp;________________________
                        </p>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <b><h6>VALORACIÓN PREANESTESICA</h6></b>
                    </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:100px; vertical-align: top; text-align:left;">
                        <p>Fecha:&nbsp;  <u>'.$campo19.'</u></p>
                        <p>Diagnóstico preoperatorio</p>
                        <p>'.$campo20.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:70px; vertical-align: top; text-align:left;">
                        <p>Cirugía propuesta</p>
                        <p>'.$campo21.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:70px; vertical-align: top; text-align:left;">
                        <p>Padecimiento actual</p>
                        <p>'.$campo22.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:70px; vertical-align: top; text-align:left;">
                        <p>Estado fisíco</p>
                        <p>'.$campo23.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:100px; vertical-align: top; text-align:left;">
                        <p>Alergias:&nbsp; <u>'.$campo24.'</u></p>
                        <p>
                            F.C.:&nbsp; <u>'.$campo25.'</u>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                            F.R.:&nbsp; <u>'.$campo26.'</u>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                            Temp.:&nbsp; <u>'.$campo27.'</u>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                            Talla:&nbsp; <u>'.$campo28.'</u>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            Peso:&nbsp; <u>'.$campo29.'</u>
                        </p><br>
                        <p>Antecedentes personales patológicos:</p>
                        <p>'.$campo40.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:180px; vertical-align: top; text-align:left;">
                        <p>Medicamentos:</p>
                        <p>'.$campo41.'</p>
                        <p>Medicación preanestésica:</p>
                        <p>'.$campo42.'</p>
                        <p>Ultimo alimento:</p>
                        <p>'.$campo43.'</p>
                   </td>
                </tr>
            </table>
          </div>
        </div>




        <div class="panel panel-primary" style="width:792px; height:1122px;">
          <div class="panel-body">
            <table>
                <tr>
                   <td colspan="2" style="height:102px; vertical-align: top; text-align:left;">
                        <p>Laboratorios:</p>
                        <p>'.$campo44.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:102px; vertical-align: top; text-align:left;">
                        <p>Rayos X:</p>
                        <p>'.$campo45.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:102px; vertical-align: top; text-align:left;">
                        <p>EKG:</p>
                        <p>'.$campo46.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:102px; vertical-align: top; text-align:left;">
                        <p>Anestesias previas:</p>
                        <p>'.$campo47.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:102px; vertical-align: top; text-align:left;">
                        <p>Vía aérea:</p>
                        <p>'.$campo48.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:102px; vertical-align: top; text-align:left;">
                        <p>Campos pulmonares:</p>
                        <p>'.$campo49.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:102px; vertical-align: top; text-align:left;">
                        <p>Area cardíaca:</p>
                        <p>'.$campo50.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:102px; vertical-align: top; text-align:left;">
                        <p>Otros:</p>
                        <p>'.$campo51.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:102px; vertical-align: top; text-align:left;">
                        <p>Plan anestésico:</p>
                        <p>'.$campo52.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:102px; vertical-align: top; text-align:left;">
                        <p>Riesgo quirúrgico:</p>
                        <p>'.$campo53.'</p>
                   </td>
                </tr>
                <tr>
                   <td colspan="2" style="height:102px; vertical-align: bottom; text-align:left;">
                        <p style="font-size:10px">
                            Nombre completo de quien elaboró la valoración:&nbsp; <u>'.$campo54.'</u>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            Firma: _________________________________
                        </p>
                   </td>
                </tr>
            </table>
          </div>
        </div>
        
        
        <style>@page {
         margin: 0;
         padding:0;
        }
        table{
            width:792px;
            margin: 10px;
            border: 2px solid #0086b3;
        }
        th, td {
            border: 1px solid #0086b3;
            color: #00ace6;
            padding:10px;
        }</style>';
        
        $hoy = date("dmyhis");
        $pdfFilePath = "NotaPreoperatoriayValoracionPreanestesicaPDF".$hoy.".pdf"; //Nombre del archivo
        $this->load->library('M_pdf');
        $mpdf = new mPDF('c', 'A4');// ('carta', 'tamaño A4')
        $css = file_get_contents(base_url('assets/css/bootstrap.css')); // cargar estilo
        $mpdf->WriteHTML($css,1);
        $mpdf->WriteHTML($html);
        $mpdf->Output($pdfFilePath, "I");
    }

    public function imprimirCartaConsentimientoBajoInfSedacion ()
    {
        $datos = $this->input->post();
        if(isset($datos))
        {
            $campo1 = $datos['campo1'];
            $campo2 = $datos['campo2'];
            $campo3 = $datos['campo3'];
            $campo4 = $datos['campo4'];
            $campo5 = $datos['campo5'];
            $campo6 = $datos['campo6'];
            $campo7 = $datos['campo7'];
            $campo8 = $datos['campo8'];
            $campo9 = $datos['campo9'];
            $campo10 = $datos['campo10'];
            $campo11 = $datos['campo11'];
            $campo12 = $datos['campo12'];
        }
        
        $html = '
        <div class="panel panel-primary" style="width:792px; height:1122px;">
          <div class="panel-body">
            <table>
                <tr>
                    <td style="width:250px; padding: 10px;" align="center">
                        <i>Doctor: '.$campo1.'</i><br><i>Cedula: '.$campo2.'</i>
                    </td>
                    
                    <td rowspan="2" style="width:300px;  padding: 10px;" align="center">
                        <p><i>Paciente: '.$campo3.'</i></p>
                        <p>'.$campo4.' años</p>
                        <p>'.$campo5.'</p>
                    </td>
                </tr>
                <tr>
                    <td style="width:250px; padding: 10px;" align="center">
                        <b><h4>CARTA CONSENTIMIENTO BAJO INFORMACION SEDACION</h4></b>
                    </td>
                </tr>
                
                
                
                
                
                
                <tr>
                    <td colspan="2" align="right" id="1">
                        <p style="font-size:15px">Oaxaca, Oaxaca de Juarez a '.$campo6.'  '.$campo7.'hrs</p>
                        
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="justify" id="2">
                        <p style="font-size:15px">Nombre del Paciente: '.$campo8.'</p>
                        <br>
                        <p style="font-size:15px">
                            El que suscribe la presente, con el con carácter de Paciente ( ) Familiar Responsable y/o Respresentante Legal del Paciente ( ) de manera libre y en plena conciencia, autorizo al (a la) Doctor(a) <u>'.$campo9.'</u> a que me(le) proporcione(al paciente) sedación, durante el procedimiento médico y/o quirúrgico <u>'.$campo10.'</u> me(le) practicará(al paciente) y a quien de forma expresa he autorizado para tal efecto con la plena conciencia de la naturaleza, riesgos y beneficios de del citado procedimient, las alternativas de tratamiento, las probabilidades de éxito, los eventos adversos que pudieran presentarse, así como las consecuencias de no someterse(someterse el paciente) al mismo.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Bajo ese entendimiento, reconozco que el médico anestesiólogo arriba citado, me ha explicado la informacioón que a continuación se detalla y que contiene entre otros aspectos, la naturaleza del plan de sedación y los riesgos inherentes; información que he comprendido y acepto en plena conciencia.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>1. Descripción del plan de sedación propuesto.</b></p>
                        <p style="font-size:15px">
                            Las técnicas de sedación se consiguen mediente la administración, a trevés de un catéter(tubito) introducido en una vena, de medicamentos anestésicos, analgésicos y tranquilizantess(sedantes), administrados en la proporción y dosis adecuada para cada paciente, según sea el procedimiento a realizar, las características personales del paciente, su sensibilidad a los fármacos y su estadi clínico.
                        </p>
                        <br><br>
                        <p style="font-size:15px">
                            Las técnicas de sedación, requieren la misma preparación, precuaución y vigilancia que la anestesia general.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            El médico anestesiologo es el encargado de realizar y controlar todo el proceso de sedación de principio a fin, así como de tratar todas las posibilidades complicaciones que puedieran surgir. Mediante diferentes métodos clínicos y monitores, se controlaran y vigilaran sus signos vitales(presión arterial, electrocardiograma, frecuencia respiratoria), ademas de la cantidad de oxígeno de la sangre, la función cerebral, bióxido de carbono exhalado y otros, con lo que se mantiene una vigilancia permanente durante todo el acto anestésico y se consigue la máxima seguridad.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>2. Objetivos del procedimiento de sedación.</b></p>
                        <p style="font-size:15px">
                            El propósito de la sedación para exploraciones de cualquier tipo o intervenciones, es proporcionar un estado consciente, relajado, confortable y sin dolor, en el que el paciente, gracias a la conservación de la conciencia, puede presentar colaboración activa en el cado de ser necesario. 
                        </p>
                        <br>
                        <p style="font-size:15px"><b>3. Alternativas razonables al plan anestésico propueto.</b></p>
                        
                        <p style="font-size:15px">'.$campo11.'<p/>
                        <br>
                        <br>
                        <p style="font-size:15px"><b>4. Riesgos.</b></p>
                        <p style="font-size:15px">
                            La administración de técnicas de sedación, como sucede en todo procedimiento médico, conlleva a una serie de riesgos que son aceptados de acuerdo con la experiencia y el estado actual de la ciencia médica, y que son:
                        </p>
                        <br>
                        <p style="font-size:15px">
                            A) Punciones repetidas por dificultad en la introducción del catéter venoso, que pudiera condicionar salida de la vena de los diferentes medicamentos empleados en la anestesia, y provocar desde un simple enrojecimiento hasta problemas circulatorios locales.
                        </p>
                    </td>
                <tr>
            </table>
          </div>
        </div>




        <div class="panel panel-primary" style="width:792px; height:1122px;">
          <div class="panel-body">
            <table>
                <tr>
                    <td colspan="2" align="justify" id="3">
                        <p style="font-size:15px">
                            B) Después de la sedación, pueden  aparecer diferentes sintomas, como descenso de la presión arterial, aimento de la frecuencia cardica, tos, depresión o dificultad respiratoria, agitación, retraso en la recuperación de la conciencia, mareo, náuseasm vómito, ronquera, temblores, que además de tomar medidad para que no sucedan, en general son consideradas como molestias, llegando en muy poco casos a ser complicaciones.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            C) No siempre es posible de predecir el punto de transición entre la sedación consiente y la inconsciente o anestesia general. Entre los riesgos potenciales se encuentran la sedación con hipotensión y depresión respiratoria, problemas que pueden incluso ser más frecuentes que con la anestesia general.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            D) La administración de soluciones y medicamentos que sean imprecindibles durante la sedación, puede producir reacciones alérgias que pueden llegar a ser graves. No se recomienda la práctica sistemática de pruebas alérgicas a los fármacos que vayan a emplearse durante la anestesia ya que dichas pruebas no están  libres de riesgos, ni aun siendo su resultado negativo, garantizan que no se produzcan reacciones adversas durante el procedimiento anestésico.
                        </p>
                        <br>
                        
                        <p style="font-size:15px">
                            <b>5. Riesgos en función del estado clínico del paciente.<b>
                        </p>
                        <br>
                        
                        <p style="font-size:15px">
                            Todo el acto quirúrgico lleva implícitas una serie de complicaciones comunes y potencialmente serias que podrían requerir tratamientos complementarios; tanto médicos como quirúrgicos. Dependiendo el estado clínico del paciente y la existencia de otras patologías, como diabetes, cardiopatía, hipertensión, anemia, edad avanzada, obesidad, el riesgo anestésico puede ser mayor o aparecer complicaciones que pudieran aumentar el traslado del paciente a una unidad de cuidados intensivos, provocar lesiones graves al paciente o inclusive, la muerte.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Comprendo que la práctica de la medicina no es una ciencia exacta, por lo que reconozco que no se me ha asegurado ni garantizado que los resultados del evento anestésico y del procedimiento médico/quirúrgico que se me(le) practicarán (al paciente), necesariamente alcancen los beneficios esperados y que pueden presentarse imprevistos que varíen el(los) citado(os) procedimiento(s); por consiguiente ante cualquier complicación o efecto adverso durante el procedimiento anestésico propuesto, especialmente ante una urgencia médica, autorizo y solicito al médico anestesiólogo y al médico tratante al principio de este documento citados y/o a quienes ellos designen conjunta o separadamente, a que realicen los procedimientos médico(s) y/o quirúrgico(s) que consideren necesarios en ejercicio de su juicio y experiencia profesional, para la protección de mi(la) salud(del paciente), en la inteligencia que la extensión de esta autorización tambien será aplicada a cualquier condición que requiera de procedimientos médicos y/o quirúrgicos que sea desconocida por los facultativos y surja dirante procedimiento médico/quirúrgico-anestésico autorizado.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Declaro que el médico anestesiólogo, '.$campo12.', me ha explicado que es conveniente/necesario, en mi(la) sitación(del paciente), que durante el procedimiento de sedación al que seré(será) sometid(el paciente), me(le) administrarán diferentes fármacos, lo cual en plena conciencia autorizo.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Entendiendo el contenido de este documento y conforme con el mismo, lo firmo en ciudad de Oaxaca en la fehca anotada.
                        </p>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                    </td>
                <tr>  
                <tr>
                    <td align="center" id="4">
                        <p>_________________________________________</p>
                        <p>Firma del Paciente</p>
                    </td>
                    <td align="center" id="5">
                        <p>____________________________________________________</p>
                        <p>Nombre y Firma del Familiar Responsable y/o Representante legal del Paciente</p>
                    </td>
                <tr>
            </table>
          </div>
        </div>
        
        
        <style>@page {
         margin: 0;
         padding:0;
        }
        table{
            width:792px;
            margin: 10px;
            border: 2px solid #0086b3;
        }
        th, td {
            border: 1px solid #0086b3;
            color: #00ace6;
            padding:15px;
        }
        #1{
            border-bottom: 0;
        }
        #2{
            border-top: 0;
        }
        
        #3{
            border-bottom: 0;
        }
        #4{
            border-top: 0;
            border-right: 0;
        }
        #5{
            border-top: 0;
            border-left: 0;
        }
        
        </style>';
        
        $hoy = date("dmyhis");
        $pdfFilePath = "CartaConsentimientoBajoInfSedacion".$hoy.".pdf"; //Nombre del archivo
        $this->load->library('M_pdf');
        $mpdf = new mPDF('c', 'A4');// ('carta', 'tamaño A4')
        $css = file_get_contents(base_url('assets/css/bootstrap.css')); // cargar estilo
        $mpdf->WriteHTML($css,1);
        $mpdf->WriteHTML($html);
        $mpdf->Output($pdfFilePath, "I");
    }
}
?>
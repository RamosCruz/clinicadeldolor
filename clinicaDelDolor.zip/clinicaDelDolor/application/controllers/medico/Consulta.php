<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Consulta extends CI_Controller {
    function __construct()
    {
        parent::__construct();
         //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->in_group('medico')) {
            show_404();
        }
       
        $this->load->model('medico/Modelo_consulta');

    }
    public function index()
    {
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        
        $this->load->model('medico/Model_Paciente');
        //-----------------------------------------------
        $data ['viasDeAdministracion'] = $this->Modelo_consulta->ObtenerCatalogoViaDeAdministracion();
        //--------------------------------------------------
        $data ['listarPacientes'] = $this->Model_Paciente->listarPacientes();
        $data ['contenido'] = 'medico/consulta/crear_consulta';
        $data ['menu'] = 'medico/menu_medico';
		    $this->load->view('plantilla',$data);
    }

    //-----------------------------------------
     public function GuardarDiagnosticoAbierto()
    {
      $result=$this->Modelo_consulta->GuardarDiagnosticoAbierto();
      echo json_encode($result);
    }

    public function GuardarTratamientoAbierto()
    {

      $result=$this->Modelo_consulta->GuardarTratamientoAbierto();
      echo json_encode($result);
      
    }
    //-----------------------------------------

  public function nuevaConsulta ($id_paciente,$hora=null,$fecha=null)
    {

      //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $medico = $this->Modelo_medicos->getUser_Medico();
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        $this->load->model('administrador/Model_Catalogo');
        $data ['costoDeConsulta']=$this->Model_Catalogo->obtenerPrecioConsulta();
    
        $data ['datos_de_la_cita'] = [];

        if($hora!=''&&$fecha!=''){
            $data ['datos_de_la_cita'] = [$hora,$fecha];
        }
        
        
        $this->load->model('medico/modelo_categoria');
        $data['categorias']=$this->modelo_categoria->getCategorias($medico[0]->id_medico);
        $data['mostrarImg']=$this->modelo_categoria->mostrarImg($medico[0]->id_medico);
        
        //--------------------------------------------------
        
        $data ['viasDeAdministracion'] = $this->Modelo_consulta->ObtenerCatalogoViaDeAdministracion();
        $data ['getRegionesDelCuerpo']    = $this->Modelo_consulta->getRegionesDelCuerpo();

        $this->load->model('administrador/Model_Intervenciones');
        $data ['getIntervenciones'] = $this->Model_Intervenciones->getIntervensiones();


        

        
        //--------------------------------------------------
        //$data ['getIntervenciones'] = $this->Model_Intervenciones->getIntervensiones();
        //$data ['consulta'] = $this->Modelo_Consulta->getConsultaByPaciente($id_paciente,$id_medico);
        $this->load->model('medico/Model_Paciente');
        $data['paciente'] = $this->Model_Paciente->obtenerPacienteConCurp($id_paciente); 
        $data ['contenido'] = 'medico/consulta/crear_consulta';
        $data ['menu'] = 'medico/menu_medico';
        $this->load->view('plantilla',$data);


    }

    public function getConsultasDelPaciente(){

        $id_paciente=$this->input->post('id_paciente');
        //$result=$this->Modelo_consulta->getConsultasDelPaciente($id_paciente);
        $data['consultasAbiertas']=$this->Modelo_consulta->getConsultasAbiertasDelPacienteGroupByConsulta($id_paciente);
        $data['consultasCerradas']=$this->Modelo_consulta->getConsultasDelPacienteGroupByConsultaTabla($id_paciente);
        echo json_encode($data);
    }


     public function GuardarConsulta ()
    {

      $result=$this->Modelo_consulta->GuardarConsulta();

      $msg['success'] = false;
      $msg['type'] = 'insert';
        if($result!=false){
            $msg['success'] = true;
            $msg['newIdconsulta']=$result;

        }
      
      echo json_encode($msg);
      
    }
    
    public function GuardarCosto ()
    {
        $result=$this->Modelo_consulta->GuardarCosto();
        echo json_encode($result);
    }
    
      public function cambiarEstatusDeCita ()
    {
      $result=$this->Modelo_consulta->cambiarEstatusDeCita();
      echo json_encode($result);
    }


     public function GuardarDiagnostico()
    {

      $result=$this->Modelo_consulta->GuardarDiagnostico();
      echo json_encode($result);
      
    }
    
    public function GuardarEstudiosLaboratorio()
    {

      $result=$this->Modelo_consulta->GuardarEstudiosLaboratorio();
      echo json_encode($result);
      
    }
    public function GuardarEstudiosGabinete()
    {

      $result=$this->Modelo_consulta->GuardarEstudiosGabinete();
      echo json_encode($result);
      
    }

     public function GuardarExploracionFisica()
    {

      $result=$this->Modelo_consulta->GuardarExploracionFisica();
      echo json_encode($result);
      
    }

    


    public function GuardarTratamiento()
    {

      $result=$this->Modelo_consulta->GuardarTratamiento();
      echo json_encode($result);
      
    }






    

    public function ObtenerCatalogoViaDeAdministracion(){
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        $data ['viasDeAdministracion'] = $this->Modelo_consulta->ObtenerCatalogoViaDeAdministracion();
        $data ['contenido'] = 'medico/consulta/crear_consulta';
        $data ['menu'] = 'medico/menu_medico';
        $this->load->view('plantilla',$data);


    }



    public function getGenericos(){
        $result=$this->Modelo_consulta->getGenericos();
        echo json_encode($result);
    }

     //-----------------------------------------------------------
    public function getGenericosOMedicamentos(){
        $this->load->model('medico/Modelo_consulta');
        $result=$this->Modelo_consulta->getGenericosOMedicamentos();
        echo json_encode($result);
    }

    public function getFormaFarmaceutica(){
        $this->load->model('medico/Modelo_consulta');
        $result=$this->Modelo_consulta->getFormaFarmaceutica();
        echo json_encode($result);
    }

    public function getConcentracion(){
        $this->load->model('medico/Modelo_consulta');
        $result=$this->Modelo_consulta->getConcentracion();
        echo json_encode($result);
    }

    public function getPresentacion(){
        $this->load->model('medico/Modelo_consulta');
        $result=$this->Modelo_consulta->getPresentacion();
        echo json_encode($result);
    }

    public function getDosisDiariaDefinida(){
        $this->load->model('medico/Modelo_consulta');
        $result=$this->Modelo_consulta->getDosisDiariaDefinida();
        echo json_encode($result);
    }


    public function validaMedicamento(){
        $this->load->model('medico/Modelo_consulta');
        $result=$this->Modelo_consulta->validaMedicamento();
        echo json_encode($result);
    }

    public function agregarMedicamento(){
        $this->load->model('medico/Modelo_consulta');
        $result = $this->Modelo_consulta->agregarMedicamento();

        $msg['success'] = false;
        $msg['type'] = 'insert';
        if($result!=false){
            $msg['success'] = true;
            $msg['newIdmedicamento']=$result;

        }
      
      echo json_encode($msg);
    }

    //-----------------------------------------------------------

     public function getDiagnosticos(){
        $result=$this->Modelo_consulta->getDiagnosticos();
        echo json_encode($result);
    }


    public function imprimirRecetaPDF()
    {
        
        //$datos = $this->input->post();
        //$receta = $datos['indicaciones_gral'];/*
        //$nombreappapm = $datos['nombreappapm'];
        //$direccioncompleta = $datos['direccioncompleta'];
        //$telefono = $datos['telefono'];*/

        $html = '
        <div class="panel panel-primary" style="width:792px; height:1122px;">
          <div class="panel-body">
            <table>
                <tr>
                    <td style="width:250px; padding: 10px;" align="center">
                        <i>Doctor: '.'</i><br><i>Cedula: '.'</i>
                    </td>
                    
                    <td rowspan="2" style="width:300px;  padding: 10px;" align="center">
                        <p><i>Paciente: '.'</i></p>
                        <p>'.' años</p>
                        <p>'.'</p>
                    </td>
                </tr>
                <tr>
                    <td style="width:250px; padding: 10px;" align="center">
                        <b><h4>CARTA CONSENTIMIENTO BAJO INFORMACION SEDACION</h4></b>
                    </td>
                </tr>
                
                
                
                
                
                
                <tr>
                    <td colspan="2" align="right" id="1">
                        <p style="font-size:15px">Oaxaca, Oaxaca de Juarez a '.'  '.'hrs</p>
                        
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="justify" id="2">
                        <p style="font-size:15px">Nombre del Paciente: '.'</p>
                        <br>
                        <p style="font-size:15px">
                            El que suscribe la presente, con el con carácter de Paciente ( ) Familiar Responsable y/o Respresentante Legal del Paciente ( ) de manera libre y en plena conciencia, autorizo al (a la) Doctor(a) <u>'.$campo9.'</u> a que me(le) proporcione(al paciente) sedación, durante el procedimiento médico y/o quirúrgico <u>'.$campo10.'</u> me(le) practicará(al paciente) y a quien de forma expresa he autorizado para tal efecto con la plena conciencia de la naturaleza, riesgos y beneficios de del citado procedimient, las alternativas de tratamiento, las probabilidades de éxito, los eventos adversos que pudieran presentarse, así como las consecuencias de no someterse(someterse el paciente) al mismo.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Bajo ese entendimiento, reconozco que el médico anestesiólogo arriba citado, me ha explicado la informacioón que a continuación se detalla y que contiene entre otros aspectos, la naturaleza del plan de sedación y los riesgos inherentes; información que he comprendido y acepto en plena conciencia.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>1. Descripción del plan de sedación propuesto.</b></p>
                        <p style="font-size:15px">
                            Las técnicas de sedación se consiguen mediente la administración, a trevés de un catéter(tubito) introducido en una vena, de medicamentos anestésicos, analgésicos y tranquilizantess(sedantes), administrados en la proporción y dosis adecuada para cada paciente, según sea el procedimiento a realizar, las características personales del paciente, su sensibilidad a los fármacos y su estadi clínico.
                        </p>
                        <br><br>
                        <p style="font-size:15px">
                            Las técnicas de sedación, requieren la misma preparación, precuaución y vigilancia que la anestesia general.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            El médico anestesiologo es el encargado de realizar y controlar todo el proceso de sedación de principio a fin, así como de tratar todas las posibilidades complicaciones que puedieran surgir. Mediante diferentes métodos clínicos y monitores, se controlaran y vigilaran sus signos vitales(presión arterial, electrocardiograma, frecuencia respiratoria), ademas de la cantidad de oxígeno de la sangre, la función cerebral, bióxido de carbono exhalado y otros, con lo que se mantiene una vigilancia permanente durante todo el acto anestésico y se consigue la máxima seguridad.
                        </p>
                        <br>
                        <p style="font-size:15px"><b>2. Objetivos del procedimiento de sedación.</b></p>
                        <p style="font-size:15px">
                            El propósito de la sedación para exploraciones de cualquier tipo o intervenciones, es proporcionar un estado consciente, relajado, confortable y sin dolor, en el que el paciente, gracias a la conservación de la conciencia, puede presentar colaboración activa en el cado de ser necesario. 
                        </p>
                        <br>
                        <p style="font-size:15px"><b>3. Alternativas razonables al plan anestésico propueto.</b></p>
                        
                        <p style="font-size:15px">'.'<p/>
                        <br>
                        <br>
                        <p style="font-size:15px"><b>4. Riesgos.</b></p>
                        <p style="font-size:15px">
                            La administración de técnicas de sedación, como sucede en todo procedimiento médico, conlleva a una serie de riesgos que son aceptados de acuerdo con la experiencia y el estado actual de la ciencia médica, y que son:
                        </p>
                        <br>
                        <p style="font-size:15px">
                            A) Punciones repetidas por dificultad en la introducción del catéter venoso, que pudiera condicionar salida de la vena de los diferentes medicamentos empleados en la anestesia, y provocar desde un simple enrojecimiento hasta problemas circulatorios locales.
                        </p>
                    </td>
                <tr>
            </table>
          </div>
        </div>




        <div class="panel panel-primary" style="width:792px; height:1122px;">
          <div class="panel-body">
            <table>
                <tr>
                    <td colspan="2" align="justify" id="3">
                        <p style="font-size:15px">
                            B) Después de la sedación, pueden  aparecer diferentes sintomas, como descenso de la presión arterial, aimento de la frecuencia cardica, tos, depresión o dificultad respiratoria, agitación, retraso en la recuperación de la conciencia, mareo, náuseasm vómito, ronquera, temblores, que además de tomar medidad para que no sucedan, en general son consideradas como molestias, llegando en muy poco casos a ser complicaciones.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            C) No siempre es posible de predecir el punto de transición entre la sedación consiente y la inconsciente o anestesia general. Entre los riesgos potenciales se encuentran la sedación con hipotensión y depresión respiratoria, problemas que pueden incluso ser más frecuentes que con la anestesia general.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            D) La administración de soluciones y medicamentos que sean imprecindibles durante la sedación, puede producir reacciones alérgias que pueden llegar a ser graves. No se recomienda la práctica sistemática de pruebas alérgicas a los fármacos que vayan a emplearse durante la anestesia ya que dichas pruebas no están  libres de riesgos, ni aun siendo su resultado negativo, garantizan que no se produzcan reacciones adversas durante el procedimiento anestésico.
                        </p>
                        <br>
                        
                        <p style="font-size:15px">
                            <b>5. Riesgos en función del estado clínico del paciente.<b>
                        </p>
                        <br>
                        
                        <p style="font-size:15px">
                            Todo el acto quirúrgico lleva implícitas una serie de complicaciones comunes y potencialmente serias que podrían requerir tratamientos complementarios; tanto médicos como quirúrgicos. Dependiendo el estado clínico del paciente y la existencia de otras patologías, como diabetes, cardiopatía, hipertensión, anemia, edad avanzada, obesidad, el riesgo anestésico puede ser mayor o aparecer complicaciones que pudieran aumentar el traslado del paciente a una unidad de cuidados intensivos, provocar lesiones graves al paciente o inclusive, la muerte.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Comprendo que la práctica de la medicina no es una ciencia exacta, por lo que reconozco que no se me ha asegurado ni garantizado que los resultados del evento anestésico y del procedimiento médico/quirúrgico que se me(le) practicarán (al paciente), necesariamente alcancen los beneficios esperados y que pueden presentarse imprevistos que varíen el(los) citado(os) procedimiento(s); por consiguiente ante cualquier complicación o efecto adverso durante el procedimiento anestésico propuesto, especialmente ante una urgencia médica, autorizo y solicito al médico anestesiólogo y al médico tratante al principio de este documento citados y/o a quienes ellos designen conjunta o separadamente, a que realicen los procedimientos médico(s) y/o quirúrgico(s) que consideren necesarios en ejercicio de su juicio y experiencia profesional, para la protección de mi(la) salud(del paciente), en la inteligencia que la extensión de esta autorización tambien será aplicada a cualquier condición que requiera de procedimientos médicos y/o quirúrgicos que sea desconocida por los facultativos y surja dirante procedimiento médico/quirúrgico-anestésico autorizado.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Declaro que el médico anestesiólogo, '.', me ha explicado que es conveniente/necesario, en mi(la) sitación(del paciente), que durante el procedimiento de sedación al que seré(será) sometid(el paciente), me(le) administrarán diferentes fármacos, lo cual en plena conciencia autorizo.
                        </p>
                        <br>
                        <p style="font-size:15px">
                            Entendiendo el contenido de este documento y conforme con el mismo, lo firmo en ciudad de Oaxaca en la fehca anotada.
                        </p>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                    </td>
                <tr>  
                <tr>
                    <td align="center" id="4">
                        <p>_________________________________________</p>
                        <p>Firma del Paciente</p>
                    </td>
                    <td align="center" id="5">
                        <p>____________________________________________________</p>
                        <p>Nombre y Firma del Familiar Responsable y/o Representante legal del Paciente</p>
                    </td>
                <tr>
            </table>
          </div>
        </div>
        
        
        <style>@page {
         margin: 0;
         padding:0;
        }
        table{
            width:792px;
            margin: 10px;
            border: 2px solid #0086b3;
        }
        th, td {
            border: 1px solid #0086b3;
            color: #00ace6;
            padding:15px;
        }
        #1{
            border-bottom: 0;
        }
        #2{
            border-top: 0;
        }
        
        #3{
            border-bottom: 0;
        }
        #4{
            border-top: 0;
            border-right: 0;
        }
        #5{
            border-top: 0;
            border-left: 0;
        }
        
        </style>';
        
        $hoy = date("dmyhis");
        $pdfFilePath = "CartaConsentimientoBajoInfSedacion".$hoy.".pdf"; //Nombre del archivo
        $this->load->library('M_pdf');
        $mpdf = new mPDF('c', 'A4');// ('carta', 'tamaño A4')
        $css = file_get_contents(base_url('assets/css/bootstrap.css')); // cargar estilo
        $mpdf->WriteHTML($css,1);
        $mpdf->WriteHTML($html);
        $mpdf->Output($pdfFilePath, "I");
    }


}
?>
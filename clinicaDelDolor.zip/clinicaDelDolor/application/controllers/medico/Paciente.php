<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$id=0;
class Paciente extends CI_Controller {

    function __construct()
    {
        parent::__construct();
         //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->in_group('medico')) {
            show_404();
        }
        
        $this->load->model('medico/Model_Paciente');
        $this->load->model('medico/Model_Expediente');
    }
    public function index()
    {
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        $data ['menu'] = 'medico/menu_medico';
        $data ['contenido'] = 'medico/paciente/listar_pacientes';
        $data ['selEstados'] = $this->Model_Paciente->selEstados();
        $data ['selestadoCivil'] = $this->Model_Paciente->selestadoCivil();
        $data ['seltipoSangre'] = $this->Model_Paciente->seltipoSangre();
        //$data ['selPaciente'] = $this->Model_Paciente->selPaciente();
        $data ['listarPacientes'] = $this->Model_Paciente->listarPacientes();
        $data ['listarExpedientes'] = $this->Model_Expediente->selExpedientes();
        $this->load->view('plantilla',$data);
    }
    public function insert()
    {
        $result=$this->Model_Paciente->insertPaciente();
        if ($result==true)
        {
           $this->crearExpediente($this->input->post('curp'));
        }
        echo json_encode($result);
    }
    public function eliminar($curp = null)
    {
        if($curp!=null){
            $this->Model_Paciente->eliminarPaciente($curp);
        }
    }
    public function editar($curp = null)
    {
        if($curp!=null){
                //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
            $this->load->model('administrador/Modelo_medicos');
            $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
            
            
            $data ['menu'] = 'medico/menu_medico';
            $data ['contenido'] = 'medico/paciente/editar';
            $paciente= $this->Model_Paciente->editarPaciente($curp);
            $data ['datosPaciente'] = $paciente;
            $data ['selestadoCivil'] = $this->Model_Paciente->selestadoCivil();
            $data ['seltipoSangre'] = $this->Model_Paciente->seltipoSangre();
            $data ['selEstados'] = $this->Model_Paciente->selEstados();
            $data ['selmunicipios'] = $this->Model_Paciente->getMunicipiosDelEstado1($paciente[0]->estado_D);
            $data ['sellocalidades'] = $this->Model_Paciente->getLocalidadesDelMunicipioDe1($paciente[0]->municipio,$paciente[0]->estado_D);
            
            $this->load->view('plantilla',$data);
        }else{
            redirect('medico/paciente');
        }
    }
    public function actualizar()
    {
        $datos = $this->input->post();
        if(isset($datos))
        {
            $curp = $datos['curp'];
            $nombre = $datos['nombre'];
            $app = $datos['app'];
            $apm = $datos['apm'];
            $sexo = $datos['sexo'];
            $fecha_nacimiento = $datos['fecha_nacimiento'];
            $alergia = $datos['alergia'];
            $estado_civil = $datos['estado_civil'];
            $tipo_sangre = $datos['tipo_sangre'];
            $telefono = $datos['telefono'];
            $domicilio = $datos['domicilio'];
            $colonia = $datos['colonia'];
            $localidad = $datos['localidad'];
            $estado = $datos['estado'];
            $estado_D = $datos['estado_D'];
            
            $this->Model_Paciente->actualizarPaciente($curp,$nombre,$app,$apm,$fecha_nacimiento,$alergia,$estado_civil,$tipo_sangre,$telefono,$domicilio,$colonia,$localidad,$estado,$sexo,$estado_D);
            redirect('medico/paciente');
        }
    }
    public function buscarPaciente()
    {
        $text = $this->input->post('text');
        $resultado = $this->Model_Paciente->buscarPacienteLike($text);
        echo json_encode($resultado);
    }
    
       
        public function obtenerDomicilioDelPaciente(){
        
            
            $curp= $this->input->get('id_paciente');

            $paciente = $this->Model_Paciente->verPaciente($curp);


           $domicilio= $paciente[0]->domicilio;
           $localidad= $paciente[0]->localidad;
           $municipio= $paciente[0]->municipio;
           $estado_D=  $paciente[0]->estado_D;

           $concatena="";
           $this->load->model('medico/Modelo_consulta');

           

           if($domicilio!=null){

            $concatena.=$domicilio;
           }
            if($localidad!=null && $estado_D!=null && $municipio!=null){

        
                $localidad=$this->Modelo_consulta->getLocalidad($estado_D,$municipio,$localidad);
                
                $concatena.=', '.$localidad[0]->nombre;
           }
            if($municipio!=null){
                $municipio=$this->Modelo_consulta->getMunicipio($estado_D,$municipio);
               
                $concatena.=', '.$municipio[0]->nombre_municipio;
           }
            if($estado_D!=null){
                $estado_D=$this->Modelo_consulta->getEstado($estado_D);
                

            $concatena.=', '.$estado_D[0]->estado;
           }
           echo json_encode($concatena);
        

    }

    

    public function verExpediente($curp = null)
    {
        $this->load->model('medico/Model_Historial');
        if($curp!=null){
            //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
            $this->load->model('administrador/Modelo_medicos');
            $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
            //-----------------------------------------------------------------
            $data ['menu'] = 'medico/menu_medico';
            $data ['contenido'] = 'medico/paciente/ver_expediente';
            $data ['a'] = 'medico/historiales/ant_gin_obs';
            $data ['b'] = 'medico/historiales/ant_her_fam';
            $data ['c'] = 'medico/historiales/ant_pers_patol';
            $data ['d'] = 'medico/historiales/ant_pers_no_patol';
            $data ['e'] = 'medico/historiales/constancias';
            $data ['f'] = 'medico/historiales/fotografias';
            $data ['verPaciente'] = $this->Model_Paciente->verPaciente($curp);
            $this->load->model('medico/Fotos_model');
            $data ['fotoDelPaciente']=$this->Fotos_model->obtenerFoto($curp);
            //$data['domicilio']=$this->obtenerDomicilioDelPaciente($data['verPaciente']);
            
            $exp = $this->Model_Expediente->selExpedienteCurp($curp);
            $data ['expediente'] = $exp;
            $numExp = $exp[0]->id_expediente;
            $data ['ant_gin_obs'] = $this->Model_Historial->selAntGinecoObst($numExp);
            $data ['ant_heredo_fam'] = $this->Model_Historial->selAnteHeredoFam($numExp);
            $data ['ant_person_patolo'] = $this->Model_Historial->selAntePersoPato($numExp);
            $data ['ant_person_no_patolo'] = $this->Model_Historial->selAnteNoPersoPato($numExp);
            $data ['mostrarImagenes'] = $this->Model_Historial->mostrarImagenes($numExp);
            $data ['mostrarFotografias'] = $this->Model_Historial->mostrarFotografias($numExp);
            
            $this->load->view('plantilla',$data);
        }else{
            redirect('medico/paciente');
        }
    }
    public function crearExpediente ($curp = 'null')
    {
        $this->load->model('medico/Model_Historial');
        $this->Model_Expediente->crearExpedienteCurp($curp);
        $exp = $this->Model_Expediente->selExpedienteCurp($curp);
        $numExp = $exp[0]->id_expediente;
        $this->Model_Historial->insertarAntGinecoObstID($numExp);
        $this->Model_Historial->insertarAnteHeredoFamID($numExp);
        $this->Model_Historial->insertarAntePersoPatoID($numExp);
        $this->Model_Historial->insertarAnteNoPersoPatoID($numExp);
    }
    
    public function nuevoPaciente()
    {
         //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        $data ['menu'] = 'medico/menu_medico';
        $data ['contenido'] = 'medico/paciente/nuevo_paciente';
        $data ['selEstados'] = $this->Model_Paciente->selEstados();
        $data ['selestadoCivil'] = $this->Model_Paciente->selestadoCivil();
        $data ['seltipoSangre'] = $this->Model_Paciente->seltipoSangre();
        $this->load->view('plantilla',$data);
    }
    
     public function validaCURP(){
        $result=$this->Model_Paciente->validaCURP();
        echo json_encode($result);

    }
    
    public function getMunicipiosDelEstado(){
        $result=$this->Model_Paciente->getMunicipiosDelEstado();
        echo json_encode($result);
    }
    
    public function getLocalidadesDelMunicipioDe(){
        $result=$this->Model_Paciente->getLocalidadesDelMunicipioDe();
        echo json_encode($result);
    }
}
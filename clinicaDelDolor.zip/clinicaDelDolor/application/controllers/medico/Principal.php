<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Principal extends CI_Controller {
    function __construct()
    {
        parent::__construct();
         //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->in_group('medico')) {
            show_404();
        }
       
    }
    public function index()
    {
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $medicoLogeado = $this->Modelo_medicos->getUser_Medico();
        $data ['medico_logueado'] = $medicoLogeado;
        //-----------------------------------------------------------------
        $this->load->model('medico/modelo_cita');
        $citas = $this->modelo_cita->getFullCalendar($medicoLogeado[0]->id_medico);
        $arreglo = array();
        if(count($citas)>0){
            for ($i = 0; $i < count($citas); $i++)
            {
                //Agregar una hora para hacer citas con duracion de 1hora//
                $timestamp = strtotime($citas[$i]->hora) + 60*60;
                $time = date('H:i:s', $timestamp);
                //fin//


                array_push($arreglo,array(
                    'title'=>'Cita: '.$citas[$i]->nombreP.' '.$citas[$i]->appP.' '.$citas[$i]->apmP.' | '.$citas[$i]->nota.'', 
                    'start'=>$citas[$i]->fecha.'T'.$citas[$i]->hora,
                    'end'=>$citas[$i]->fecha.'T'.$time

                ));
            }
        }
        else
        {
            array_push($arreglo,array(
                    'title'=>'No tiene citas', 
                    'start'=>date('Y-m-dTH:i:s-5:00'),
                    'end'=>date('Y-m-dTH:i:s-5:00')
                ));
        }
        
        $data ['citas'] = $arreglo;
        
        $data ['contenido']      = 'medico/agenda/full_calendar';
        $data ['menu']           = 'medico/menu_medico';
		$this->load->view('plantilla',$data);
    }
}
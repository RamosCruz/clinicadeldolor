<?php

class Webcam extends CI_Controller{

public function __construct() {
    parent::__construct();
    $this->load->model(array('medico/Fotos_model'));
}


public function index() {
        //$this->load->view('webcam/index_view');
    }

    public function insertFoto () {
        $src = $this->input->post('src');
        $id_paciente = $this->input->post('id_paciente');
        $result=$this->Fotos_model->grabarFoto($id_paciente,$src);
        //redirect('medico/paciente/verExpediente/'.$id_paciente);
        echo json_encode($result);

        //$foto = $this->Fotos_model->getLastFoto();
        //$this->output->set_output ($foto);

    }

    public function validaPacienteConFoto(){
        $id_paciente = $this->input->post('id_paciente');
        $src = $this->input->post('src');
        $info_foto=$this->Fotos_model->obtenerFoto($id_paciente);
        //echo $id_foto;
        if($info_foto==false){
            //Inserta la foto
            $this->Fotos_model->grabarFoto($id_paciente,$src);
        }
        elseif($this->Fotos_model->eliminarFotos($id_paciente)){
            
                $this->Fotos_model->grabarFoto($id_paciente,$src);
            
            //Obtener id_foto
            //$id_foto=$info_foto[0]->id;
           //Actualiza laa foto
             //$this->Fotos_model->actualizaFoto($id_foto,$src);
        }
    } 
}
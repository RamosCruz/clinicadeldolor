<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//CONTROLADOR

class Diagnosticos extends CI_Controller {
   public function __construct() {
      parent::__construct();
       //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->in_group('medico')) {
            show_404();
        }
     
      $this->load->model('medico/Modelo_diagnosticos');//Carga el modelo cada ves que se ejecuta algun metodo delcontrolador
   }

   function index(){
       //$datos['medicos']=$this->modelo_medicamentos->getCategorias();
        //Nos faltaria llamar el modelo que no hemos creado de la  tabla estatus
        //Tenemos que mandar el usuario que cargo los datos para cargar su lista de medicamentos usados,
        //en este caso cargare a un medico de prueba
        //medico con id GEHE940212HOCYRR03
        //$this->load->view('header');
        //$this->load->view('medico/plantillas/menu');
        //$this->load->view('medico/catalogos/listar_diagnosticos');//,$datos);
        //$this->load->view('footer');
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $datos ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------

        $datos ['menu'] = 'medico/menu_medico';
        $datos ['contenido'] = 'medico/catalogos/listar_diagnosticos';
        $this->load->view('plantilla',$datos);
  }
    //.................................................................
    function validarDiagnosticoEnListaFrecuente(){
            $result=$this->Modelo_diagnosticos->validarDiagnosticoEnListaFrecuente();
            echo json_encode($result);
    }

    function insertarDiagnosticoFrecuente(){
            $result=$this->Modelo_diagnosticos->insertarDiagnosticoFrecuente();
            $msg['success'] = false;
            $msg['type'] = 'add';
                if($result){
                    $msg['success'] = true;
                }
                echo json_encode($msg);
    }




    //-------------------------------------------------------------------*****
    function getDiagnosticosCon(){
        $result=$this->Modelo_diagnosticos->getDiagnosticosCon();
        echo json_encode($result);
    }
    //-------------------------------------------------------------------
    function listarDiagnosticosUsadosPor(){
        $result=$this->Modelo_diagnosticos->listarDiagnosticosUsadosPor();
        echo json_encode($result);
    }



    public function eliminarDianosticoFrecuentePor(){
        $result = $this->Modelo_diagnosticos->eliminarDianosticoFrecuentePor();
        $msg['success'] = false;
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg);
    }




}
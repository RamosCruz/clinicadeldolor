<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//CONTROLADOR

class Agenda extends CI_Controller {
   public function __construct() {
      parent::__construct();
       //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->in_group('medico')) {
            show_404();
        }
      
      $this->load->model('medico/modelo_cita');//Carga el modelo cada ves que se ejecuta algun metodo delcontrolador
   }

   function index(){
       //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------

        $data['medicos']=$this->modelo_cita->getMedicos();
        $data['horario']=["08:00","08:30","09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30","14:00","14:30","15:00","15:30","16:00","16:30","17:00","17:30","18:00"];
        
        $data ['menu'] = 'medico/menu_medico';
        $data ['contenido'] = 'medico/agenda/listar_citas';
        $this->load->view('plantilla',$data);
        //Nos faltaria llamar el modelo que no hemos creado de la  tabla estatus
        //$datos['medicos']=$this->modelo_cita->getMedicos();
        

        //$this->load->view('header');
        //$this->load->view('medico/plantillas/menu');
        //$this->load->view('medico/agenda/listar_citas',$datos);
        //$this->load->view('footer');
    }

    function nuevaCita(){
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $data ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------

        $data['medicos']=$this->modelo_cita->getMedicos();
        $data['horario']=["08:00","08:30","09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30","14:00","14:30","15:00","15:30","16:00","16:30","17:00","17:30","18:00"];
        
        $data ['menu'] = 'medico/menu_medico';
        $data ['contenido'] = 'medico/agenda/nueva_cita';
        $this->load->view('plantilla',$data);

        //$this->load->view('header');
        //$this->load->view('medico/menu_medico');
        //$this->load->view('medico/agenda/nueva_cita',$datos);
        //$this->load->view('footer');
    }

//----------------------------------

    function validaDisponibilidadEnLaAgendaDelMedico(){
            $result=$this->modelo_cita->validaDisponibilidadEnLaAgendaDelMedico();
            echo json_encode($result);
    }

     function validaDisponibilidadEnLasCitasDelPaciente(){
            $result=$this->modelo_cita->validaDisponibilidadEnLasCitasDelPaciente();
            echo json_encode($result);
    }

  
    function validaCitaRepetida(){
            $result=$this->modelo_cita->validaCitaRepetida();
            echo json_encode($result);
    }


//----------------------------------


    function agendarCita(){
            $result=$this->modelo_cita->agendarCita();
            echo json_encode($result);
            //redirect('medico/agenda');
    }

    function buscarPacienteLike(){
        //$data_busqueda = $this->input->post();
        $result=$this->modelo_cita->buscarPacienteLike();
        echo json_encode($result);
        ///refres();
    }

    function buscarExpediente(){
        //$data_busqueda = $this->input->post();
        $result=$this->modelo_cita->buscarExpediente();
        echo json_encode($result);
        ///refres();
    }

    //-------------------------------A PARTIR DE AQUI VA LISTAR AGENDA
    function listarAgenda(){
        //$datos['medicos']=$this->modelo_cita->getMedicos();
        //Nos faltaria llamar el modelo que no hemos creado de la  tabla estatus
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $datos ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
        //-----------------------------------------------------------------
        $datos['medicos']=$this->modelo_cita->getMedicos();
        $datos['horario']=["08:00","08:30","09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30","14:00","14:30","15:00","15:30","16:00","16:30","17:00","17:30","18:00"];
        

        $datos ['menu'] = 'medico/menu_medico';
        $datos ['contenido'] = 'medico/agenda/listar_citas';
        $this->load->view('plantilla',$datos);

        //$this->load->view('header');
        //$this->load->view('medico/plantillas/menu');
        //$this->load->view('medico/agenda/listar_citas',$datos);
        //$this->load->view('footer');
    }

    function buscarCita(){
        $result=$this->modelo_cita->getCitas();
        echo json_encode($result);
    }

    //AQUI VAN Las funciones para redirigirse a  EDITAR CITA

     function editarCita($paciente=null,$medico=null,$fechaP=null,$hora=null){

          if($paciente!=null && $medico!=null && $fechaP!=null && $hora!=null){

            $fechaP=new DateTime($fechaP);
            $fecha = $fechaP->format('Y-m-d');

                //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
            $this->load->model('administrador/Modelo_medicos');
            $dato ['medico_logueado'] = $this->Modelo_medicos->getUser_Medico();
            //-----------------------------------------------------------------


            $dato['getDatosdeCita']=$this->modelo_cita->getCitaCompuesta($paciente,$medico,$fecha,$hora);
            $dato['medicos']=$this->modelo_cita->getMedicos();
            $dato['horario']=["08:00","08:30","09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30","14:00","14:30","15:00","15:30","16:00","16:30","17:00","17:30","18:00"];
        
            
            $this->load->view('header');
            $this->load->view('medico/plantillas/menu');
            $this->load->view('medico/agenda/editar_cita',$dato);
            $this->load->view('footer');
        }
    }

    
    public function actualizarCita()
    {
        $result=$this->modelo_cita->actualizarCita();
        $msg['success'] = false;
        $msg['type'] = 'update';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg);

        
        
    }

    public function eliminarCita()
    {
        $result=$this->modelo_cita->eliminarCita();
        $msg['success'] = false;
        $msg['type'] = 'delete';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg); 
    }

    function validaCita(){
            $result=$this->modelo_cita->validaCita();
            echo json_encode($result);
    }


    

    function ValidaHoraDelMedico(){
            $result=$this->modelo_cita->ValidaHoraDelMedico();
            echo json_encode($result);
    }

     function ValidaHoraDelPaciente(){
            $result=$this->modelo_cita->ValidaHoraDelPaciente();
            echo json_encode($result);
    }

    function ValidaCitaAlActualizar(){
            $result=$this->modelo_cita->ValidaCitaAlActualizar();
            echo json_encode($result);
    }



    public function actualizarHoraDeCita()
    {
        $result=$this->modelo_cita->actualizarHoraDeCita();
        $msg['success'] = false;
        $msg['type'] = 'update';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg); 
    }

//_-----------------------------------------------------------------
    function ValidaFechaDelMedico(){
            $result=$this->modelo_cita->ValidaFechaDelMedico();
            echo json_encode($result);
    }

     function ValidaFechaDelPaciente(){
            $result=$this->modelo_cita->ValidaFechaDelPaciente();
            echo json_encode($result);
    }

     public function actualizarFechaDeCita()
    {
        $result=$this->modelo_cita->actualizarFechaDeCita();
        $msg['success'] = false;
        $msg['type'] = 'update';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg); 
    }
    public function actualizarIdGoogle()
    {
        $result=$this->modelo_cita->actualizarIdGoogle();
        $msg['success'] = false;
        $msg['type'] = 'update';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg); 
    }

    //----------------------------------------------
     public function actualizarNotaDeCita()
    {
        $result=$this->modelo_cita->actualizarNotaDeCita();
        $msg['success'] = false;
        $msg['type'] = 'update';
        if($result){
            $msg['success'] = true;
        }
        echo json_encode($msg); 
    }
    public function fullCalendar ()
    {
        //---------PARA OBTENER LOS DATOS DEL MEDICO QUE ESTA LOGUEADO-----
        $this->load->model('administrador/Modelo_medicos');
        $medicoLogeado = $this->Modelo_medicos->getUser_Medico();
        $data ['medico_logueado'] = $medicoLogeado;
        //-----------------------------------------------------------------
        
        $citas = $this->modelo_cita->getFullCalendar($medicoLogeado[0]->id_medico);
        $arreglo = array();
        if(count($citas)>0){
            for ($i = 0; $i < count($citas); $i++)
            {
                //Agregar una hora para hacer citas con duracion de 1hora//
                $timestamp = strtotime($citas[$i]->hora) + 60*60;
                $time = date('H:i:s', $timestamp);
                //fin//


                array_push($arreglo,array(
                    'title'=>'Cita: '.$citas[$i]->nombreP.' '.$citas[$i]->appP.' '.$citas[$i]->apmP.' | '.$citas[$i]->nota.'', 
                    'start'=>$citas[$i]->fecha.'T'.$citas[$i]->hora,
                    'end'=>$citas[$i]->fecha.'T'.$time

                ));
            }
        }
        {
            array_push($arreglo,array(
                    'title'=>'No tiene citas', 
                    'start'=>date('Y-m-dTH:i:s-5:00'),
                    'end'=>date('Y-m-dTH:i:s-5:00')
                ));
        }
        $data ['citas'] = $arreglo;
        
        $data ['menu'] = 'medico/menu_medico';
        $data ['contenido'] = 'medico/agenda/full_calendar';
        $this->load->view('plantilla',$data);
        
        
    }
    



}
<?php defined('BASEPATH') OR exit('No direct script access allowed');
    
class Historial extends CI_Controller {
    function __construct()
    {
        parent::__construct();
         //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->in_group('medico')) {
            show_404();
        }
       
        $this->load->model('medico/Model_Historial');
    } 
    public function index()
	{
        echo 'Invalid location';
	}
    public function guardarAnteGineObs()
    {
        $datos = $this->input->post();
        if(isset($datos))
        {
            $curp = $datos['curp'];
            $id_exp = $datos['id_exp'];
            $menarquia = $datos['menarquia'];
            $duracion = $datos['duracion'];
            $c_sangre = $datos['c_sangre'];
            $frecuencia = $datos['frecuencia'];
            $dolor = $datos['dolor'];
            $secreciones = $datos['secreciones'];
            $sexual = $datos['sexual'];
            $edad_inicio = $datos['edad_inicio'];
            $comp_sexuales = $datos['comp_sexuales'];
            $metodo = $datos['metodo'];
            $relaciones = $datos['relaciones'];
            $enfermedades = $datos['enfermedades'];
            $gestaciones = $datos['gestaciones'];
            $partos = $datos['partos'];
            $abortos = $datos['abortos'];
            $cesareas = $datos['cesareas'];
            $ant_perinatales = $datos['ant_perinatales'];
            $this->Model_Historial->actualizarAntGinecoObst($id_exp,$menarquia,$duracion,$c_sangre,$frecuencia,$dolor,$secreciones,$sexual,$edad_inicio,$comp_sexuales,$metodo,$relaciones,$enfermedades,$gestaciones,$partos,$abortos,$cesareas,$ant_perinatales);
            redirect('medico/paciente/verExpediente/'.$curp);
            
        }
    }
    public function guardarAnteHeredoFam()
    {
        $datos = $this->input->post();
        if(isset($datos))
        {
            $curp = $datos['curp'];
            $id_exp = $datos['id_exp'];
            $diabetes_mellitus = json_encode($datos['diabetes_mellitus']);
            $hiper_sistemica = json_encode($datos['hiper_sistemica']);
            $obesidad = json_encode($datos['obesidad']);
            $neoplasias = json_encode($datos['neoplasias']);
            $malformaciones = json_encode($datos['malformaciones']);
            $alergias = json_encode($datos['alergias']);
            $psiquiatricas = json_encode($datos['psiquiatricas']);
            $neurologicas = json_encode($datos['neurologicas']);
            $cardiovasculares = json_encode($datos['cardiovasculares']);
            $broncopulmonares = json_encode($datos['broncopulmonares']);
            $tiroideas = json_encode($datos['tiroideas']);
            $renales = json_encode($datos['renales']);
            $osteoarticulares = json_encode($datos['osteoarticulares']);
            $infectocontagiosas = json_encode($datos['infectocontagiosas']);
            $anotaciones = $datos['anotaciones'];
            
            
            $this->Model_Historial->actualizarAnteHeredoFam($id_exp,$diabetes_mellitus,$hiper_sistemica,$obesidad,$neoplasias,$malformaciones,$alergias,$psiquiatricas,$neurologicas,$cardiovasculares,$broncopulmonares,$tiroideas,$renales,$osteoarticulares,$infectocontagiosas,$anotaciones);
            redirect('medico/paciente/verExpediente/'.$curp);
        }
    }
    
    public function guardarAntePersoPato()
    {
        $datos = $this->input->post();
        if(isset($datos))
        {
            $id_exp = $datos['id_exp'];
            $curp = $datos['curp'];
            
            $alergicos = json_encode($datos['alergicos']);
            $hospitalizaciones = json_encode($datos['hospitalizaciones']);
            $quirurgicos = json_encode($datos['quirurgicos']);
            $traumaticos = json_encode($datos['traumaticos']);
            $transfusionales = json_encode($datos['transfusionales']);
            
            
            $alcoholismo = json_encode($datos['alcoholismo']);
            $tabaquismo = json_encode($datos['tabaquismo']);
            $otras_sus = json_encode($datos['otras_sus']);
            
            
            $exantema = json_encode($datos['exantema']);
            $roseola = json_encode($datos['roseola']);
            $rubeola = json_encode($datos['rubeola']);
            $sarampion = json_encode($datos['sarampion']);
            $varicela = json_encode($datos['varicela']);
            $otras_pato_exant = json_encode($datos['otras_pato_exant']);
            
            
            $faringoamigdalitis = json_encode($datos['faringoamigdalitis']);
            $fiebre_reumatica = json_encode($datos['fiebre_reumatica']);
            $hepatitis = json_encode($datos['hepatitis']);
            $parasitosis = json_encode($datos['parasitosis']);
            $tifoidea = json_encode($datos['tifoidea']);
            $transmision_sexual = json_encode($datos['transmision_sexual']);
            $tuberculosis = json_encode($datos['tuberculosis']);
            $otras_pato_infecto = json_encode($datos['otras_pato_infecto']);
            
           
            
            $diabetes_mellitus = json_encode($datos['diabetes_mellitus']);
            $hipert_art_sis = json_encode($datos['hipert_art_sis']);
            $obesidad = json_encode($datos['obesidad']);
            $neoplasicas = json_encode($datos['neoplasicas']);
            $artritis_reumatoide = json_encode($datos['artritis_reumatoide']);
            $enfermedad_de_gota = json_encode($datos['enfermedad_de_gota']);
            $enfer_psiquiatricas = json_encode($datos['enfer_psiquiatricas']);
            $enfer_sist_nervio = json_encode($datos['enfer_sist_nervio']);
            $enfer_sist_cardiov = json_encode($datos['enfer_sist_cardiov']);
            $enfer_sist_respir = json_encode($datos['enfer_sist_respir']);
            $enfer_sist_gastroint = json_encode($datos['enfer_sist_gastroint']);
            $enfer_sist_endocri = json_encode($datos['enfer_sist_endocri']);
            $enfer_sist_urin = json_encode($datos['enfer_sist_urin']);
            $enfer_sist_musculoes = json_encode($datos['enfer_sist_musculoes']);
            $enfer_sist_tegum = json_encode($datos['enfer_sist_tegum']);
            $otra_enfer_cron_degen = json_encode($datos['otra_enfer_cron_degen']);
            
            
            
            $observaciones = $datos['observaciones'];
            
            $this->Model_Historial->actualizarAntePersoPato($id_exp,$alergicos,$hospitalizaciones,$quirurgicos,$traumaticos,$transfusionales,$alcoholismo,$tabaquismo,$otras_sus,$exantema,$roseola,$rubeola,$sarampion,$varicela,$otras_pato_exant,$faringoamigdalitis,$fiebre_reumatica,$hepatitis,$parasitosis,$tifoidea,$transmision_sexual,$tuberculosis,$otras_pato_infecto,$diabetes_mellitus,$hipert_art_sis,$obesidad,$neoplasicas,$artritis_reumatoide,$enfermedad_de_gota,$enfer_psiquiatricas,$enfer_sist_nervio,$enfer_sist_cardiov,$enfer_sist_respir,$enfer_sist_gastroint,$enfer_sist_endocri,$enfer_sist_urin,$enfer_sist_musculoes,$enfer_sist_tegum,$otra_enfer_cron_degen,$observaciones);
            redirect('medico/paciente/verExpediente/'.$curp);
        }
    }
    
    public function concatenar($var)
    {
        $cadena = "";
        $count = count($var);
            for ($i = 1; $i < $count; $i++) {
                 if ($i == 1)
                 {
                     $cadena .= $var[$i];
                 }else
                 {
                     $cadena .= ",".$var[$i];
                 }
                
            }
        return $cadena;
    }
    
    public function guardarAntePersoNoPato()
    {
        $datos = $this->input->post();
        if(isset($datos))
        {
            $curp = $datos['curp'];
            $id_exp = $datos['id_exp'];
            $tabaquismo = $datos['tabaquismo'];
            $alcoholismo = $datos['alcoholismo'];
            $escolaridad = $datos['escolaridad'];
            $vivienda = $datos['vivienda'];
            $higienicos = $datos['higienicos'];
            $ocupacion = $datos['ocupacion'];
            $tiempo_libre = $datos['tiempo_libre'];
            $inmunizaciones = $datos['inmunizaciones'];
            $conciencia = $datos['conciencia'];
            
            $this->Model_Historial->actualizarAnteNoPersoPato($id_exp,$tabaquismo,$alcoholismo,$escolaridad,$vivienda,$higienicos,$ocupacion,$tiempo_libre,$inmunizaciones,$conciencia);
            redirect('medico/paciente/verExpediente/'.$curp);
        }
    }
    
    
   
    
    public function constancias()
    {
        $datos = $this->input->post();
            if(isset($datos))
            {
                $id_exp = $datos['id_exp'];
                $curp = $datos['curp'];
                $descripcion = $datos['descripcion'];
                
                
                $config['upload_path'] = './uploads/constancias/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['encrypt_name'] = true;
                $this->load->library('upload', $config);

                if (!$this->upload->do_upload())
                {
                    $error = $this->upload->display_errors();
                    echo '
                         <!DOCTYPE html>
                         <html lang="en">
                         <head>
                           <meta charset="utf-8" />
                           <title>Error en el expediente '.$curp.'</title>
                           <script src="'.base_url().'assets/sweetalert2/sweetalert2.min.js"></script>
                           <script src="'.base_url().'assets/sweetalert2/sweetalert2.js"></script>
                           <link rel="stylesheet" type="text/css" href="'.base_url().'assets/sweetalert2/sweetalert2.min.css">
                           <link rel="stylesheet" type="text/css" href="'.base_url().'assets/sweetalert2/sweetalert2.css">
                           <script src="'.base_url().'assets/js/jquery-3.1.1.min.js"></script>
                           <script>
                             window.onload = function() 
                             {
                              swal({html: "'.$error.' <a href='.base_url().'medico/paciente/verExpediente/'.$curp.'>Regresar</a>", showConfirmButton: false});
                             }
                           </script>
                           </head>
                           <body>

                           </body>
                           </html>
                         ';
                }
                else
                {
                    $data = $this->upload->data();
                    foreach ($data as $key => $value)
                    {
                        if ($key == 'file_name')
                        {
                            $nombre = $value;
                            $this->Model_Historial->subirConstancia($id_exp,$nombre,$descripcion);
                        }
                    }
                    redirect('medico/paciente/verExpediente/'.$curp);
                    

                }
            }
    }
    
   
    public function fotografias()
    {
        $datos = $this->input->post();
            if(isset($datos))
            {
                $id_exp = $datos['id_exp'];
                $curp = $datos['curp'];
                $descripcion = $datos['descripcion'];
                
                
                $config['upload_path'] = './uploads/fotografias/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['encrypt_name'] = true;
                $this->load->library('upload', $config);

                if (!$this->upload->do_upload())
                {
                    $error = $this->upload->display_errors();
                    echo '
                         <!DOCTYPE html>
                         <html lang="en">
                         <head>
                           <meta charset="utf-8" />
                           <title>Error en el expediente '.$curp.'</title>
                           <script src="'.base_url().'assets/sweetalert2/sweetalert2.min.js"></script>
                           <script src="'.base_url().'assets/sweetalert2/sweetalert2.js"></script>
                           <link rel="stylesheet" type="text/css" href="'.base_url().'assets/sweetalert2/sweetalert2.min.css">
                           <link rel="stylesheet" type="text/css" href="'.base_url().'assets/sweetalert2/sweetalert2.css">
                           <script src="'.base_url().'assets/js/jquery-3.1.1.min.js"></script>
                           <script>
                             window.onload = function() 
                             {
                              swal({html: "'.$error.' <a href='.base_url().'medico/paciente/verExpediente/'.$curp.'>Regresar</a>", showConfirmButton: false});
                             }
                           </script>
                           </head>
                           <body>

                           </body>
                           </html>
                         ';
                }
                else
                {
                    $data = $this->upload->data();
                    foreach ($data as $key => $value)
                    {
                        if ($key == 'file_name')
                        {
                            $nombre = $value;
                            $this->Model_Historial->subirFotografia($id_exp,$nombre,$descripcion);
                        }
                    }
                    redirect('medico/paciente/verExpediente/'.$curp);
                    

                }
            }
    }
    public function eliminarConsta($nombre_archivo,$curp)
    {
        $imagen = './uploads/constancias/'.$nombre_archivo;
        if($nombre_archivo!=null){
            $this->Model_Historial->eliminarConstancia($nombre_archivo);
            unlink($imagen);
        }
        redirect('medico/paciente/verExpediente/'.$curp);
    }
    
    
    public function eliminarFoto ($nombre_archivo,$curp)
    {
        $foto = './uploads/fotografias/'.$nombre_archivo;
        if($nombre_archivo!=null){
            $this->Model_Historial->eliminarForografia($nombre_archivo);
            unlink($foto);
        }
        redirect('medico/paciente/verExpediente/'.$curp);
    }
}
?>
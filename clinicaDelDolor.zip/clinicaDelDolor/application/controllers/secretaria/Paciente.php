<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$id=0;
class Paciente extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        //negación si no esta logueado lo mando al login
        if (!$this->ion_auth->logged_in()){
            redirect('auth/login');
        }
        //sino esta en el grupo le manda el error no encontrado
        if (!$this->ion_auth->in_group('secretaria')) {
            show_404();
        }
        $this->load->model('secretaria/Model_Paciente');
        $this->load->model('secretaria/Model_Expediente');
    }
	public function index()
	{
        $data ['menu'] = 'secretaria/menu_secretaria';
        $data ['contenido'] = 'secretaria/paciente/listar_pacientes';
        $data ['selEstados'] = $this->Model_Paciente->selEstados();
        $data ['selestadoCivil'] = $this->Model_Paciente->selestadoCivil();
        $data ['seltipoSangre'] = $this->Model_Paciente->seltipoSangre();
        //$data ['selPaciente'] = $this->Model_Paciente->selPaciente();
        $data ['listarPacientes'] = $this->Model_Paciente->listarPacientes();
		$this->load->view('plantilla',$data);
	}
    public function insert()
	{
        $result=$this->Model_Paciente->insertPaciente();
        if ($result==true)
        {
           $this->crearExpediente($this->input->post('curp'));
        }
        echo json_encode($result);
	}
    public function eliminar($curp = null)
    {
        if($curp!=null){
            $this->Model_Paciente->eliminarPaciente($curp);
        }
    }
    public function editar($curp = null)
    {
        if($curp!=null){
              
            $data ['menu'] = 'secretaria/menu_secretaria';
            $data ['contenido'] = 'secretaria/paciente/editar';
            $paciente= $this->Model_Paciente->editarPaciente($curp);
            $data ['datosPaciente'] = $paciente;
            $data ['selestadoCivil'] = $this->Model_Paciente->selestadoCivil();
            $data ['seltipoSangre'] = $this->Model_Paciente->seltipoSangre();
            $data ['selEstados'] = $this->Model_Paciente->selEstados();
            $data ['selmunicipios'] = $this->Model_Paciente->getMunicipiosDelEstado1($paciente[0]->estado_D);
            $data ['sellocalidades'] = $this->Model_Paciente->getLocalidadesDelMunicipioDe1($paciente[0]->municipio,$paciente[0]->estado_D);
            
            $this->load->view('plantilla',$data);
        }else{
            redirect('secretaria/paciente');
        }
    }
    public function actualizar()
    {
        $datos = $this->input->post();
        if(isset($datos))
        {
            $curp = $datos['curp'];
            $nombre = $datos['nombre'];
            $app = $datos['app'];
            $apm = $datos['apm'];
            $sexo = $datos['sexo'];
            $fecha_nacimiento = $datos['fecha_nacimiento'];
            $alergia = $datos['alergia'];
            $estado_civil = $datos['estado_civil'];
            $tipo_sangre = $datos['tipo_sangre'];
            $telefono = $datos['telefono'];
            $domicilio = $datos['domicilio'];
            $colonia = $datos['colonia'];
            $localidad = $datos['localidad'];
            $estado = $datos['estado'];
            $estado_D = $datos['estado_D'];
            $this->Model_Paciente->actualizarPaciente($curp,$nombre,$app,$apm,$fecha_nacimiento,$alergia,$estado_civil,$tipo_sangre,$telefono,$domicilio,$colonia,$localidad,$estado,$sexo,$estado_D);
            redirect('secretaria/paciente');
        }
    }
    public function buscarPaciente()
    {
        $text = $this->input->post('text');
        $resultado = $this->Model_Paciente->buscarPacienteLike($text);
        echo json_encode($resultado);
    }
    
    public function crearExpediente ($curp = 'null')
    {
        $this->load->model('secretaria/Model_Historial');
        $this->Model_Expediente->crearExpedienteCurp($curp);
        $exp = $this->Model_Expediente->selExpedienteCurp($curp);
        $numExp = $exp[0]->id_expediente;
        $this->Model_Historial->insertarAntGinecoObstID($numExp);
        $this->Model_Historial->insertarAnteHeredoFamID($numExp);
        $this->Model_Historial->insertarAntePersoPatoID($numExp);
        $this->Model_Historial->insertarAnteNoPersoPatoID($numExp);
    }
    
    public function nuevoPaciente()
    {
        $data ['menu'] = 'secretaria/menu_secretaria';
        $data ['contenido'] = 'secretaria/paciente/nuevo_paciente';
        $data ['selEstados'] = $this->Model_Paciente->selEstados();
        $data ['selestadoCivil'] = $this->Model_Paciente->selestadoCivil();
        $data ['seltipoSangre'] = $this->Model_Paciente->seltipoSangre();
        $this->load->view('plantilla',$data);
    }
    
     public function validaCURP(){
        $result=$this->Model_Paciente->validaCURP();
        echo json_encode($result);

    }
    
    public function getMunicipiosDelEstado(){
        $result=$this->Model_Paciente->getMunicipiosDelEstado();
        echo json_encode($result);
    }
    
    public function getLocalidadesDelMunicipioDe(){
        $result=$this->Model_Paciente->getLocalidadesDelMunicipioDe();
        echo json_encode($result);
    }
}
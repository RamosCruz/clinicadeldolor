<?php defined('BASEPATH') OR exit('No direct script access allowed');
    
class Reportes extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model('secretaria/Modelo_reportes');
    }
    public function Cuentas()
    {
        $datos ['cuentas'] = $this->Modelo_reportes->cuentasDeHoy();
        $datos ['menu'] = 'secretaria/menu_secretaria';
        $datos ['contenido'] = 'secretaria/reportes/cuentas';
        $this->load->view('plantilla',$datos);
    }
    public function cuentasDeHoy()
    {
        $result=$this->Modelo_reportes->cuentasDeHoy();
        echo json_encode($result);
    }
    public function Valance ()
    {
        
        $datos ['menu'] = 'secretaria/menu_secretaria';
        $datos ['contenido'] = 'secretaria/reportes/valance';
        $this->load->view('plantilla',$datos);
    }
    
    public function registrarPago()
    {
        $result=$this->Modelo_reportes->registrarPago();
        $msg['success'] = false;
		$msg['type'] = 'update';
		if($result){
			$msg['success'] = true;
		}
		echo json_encode($msg);
    }
    public function valanceMedico()
    {
        $id_medico=$this->input->get('id_medico');
        $fecha_inicio=$this->input->get('fecha_inicio');
        $fecha_termino=$this->input->get('fecha_termino');
        $result=$this->Modelo_reportes->valance($id_medico,$fecha_inicio,$fecha_termino);
        echo json_encode($result);
    }
    public function medicosAQuienLeDebeElPaciente ()
    {
        $id_paciente=$this->input->get('id_paciente');
        $result=$this->Modelo_reportes->medicosAQuienLeDebeElPaciente($id_paciente);
        echo json_encode($result);
    }
    public function medicosConCuenta ()
    {
        $result=$this->Modelo_reportes->medicosConCuenta();
        echo json_encode($result);
    }
}
?>